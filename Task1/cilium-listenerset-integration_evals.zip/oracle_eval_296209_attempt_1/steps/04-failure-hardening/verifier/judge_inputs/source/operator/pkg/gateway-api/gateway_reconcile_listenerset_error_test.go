// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

package gateway_api

import (
	"errors"
	"strings"
	"testing"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"
)

func TestListenerSetRouteListError(t *testing.T) {
	cause := errors.New("temporary list failure")
	err := listenerSetRouteListError("TLSRoutes", "team/listeners", cause)
	if !errors.Is(err, cause) {
		t.Fatal("wrapped error must preserve the original cause")
	}
	message := err.Error()
	if !strings.Contains(message, "TLSRoutes") || !strings.Contains(message, "team/listeners") {
		t.Fatalf("error must identify Route kind and ListenerSet: %s", message)
	}

	sets := []gatewayv1.ListenerSet{
		{ObjectMeta: metav1.ObjectMeta{Name: "one", Namespace: "team"}},
		{ObjectMeta: metav1.ObjectMeta{Name: "two", Namespace: "team"}},
	}
	err = listenerSetRouteDataError("TLSRoute", sets, cause)
	if !errors.Is(err, cause) {
		t.Fatal("Route data error must preserve the original cause")
	}
	message = err.Error()
	for _, token := range []string{"TLSRoute", "team/one", "team/two"} {
		if !strings.Contains(message, token) {
			t.Fatalf("Route data error must identify %s: %s", token, message)
		}
	}
}
