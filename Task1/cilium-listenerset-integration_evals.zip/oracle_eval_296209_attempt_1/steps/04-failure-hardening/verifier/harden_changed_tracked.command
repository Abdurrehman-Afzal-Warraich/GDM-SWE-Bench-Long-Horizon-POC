git diff --no-ext-diff --name-only 933c7402d8617fbc55323bd1b0bb1b93f9341ba6 -- .
