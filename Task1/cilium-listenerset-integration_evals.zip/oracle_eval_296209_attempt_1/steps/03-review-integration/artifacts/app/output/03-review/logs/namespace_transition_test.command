go test ./operator/pkg/gateway-api/watch-handlers -run \^TestGatewayAllowsListenerSetNamespaceSelectorTransitions\$ -count=1 
