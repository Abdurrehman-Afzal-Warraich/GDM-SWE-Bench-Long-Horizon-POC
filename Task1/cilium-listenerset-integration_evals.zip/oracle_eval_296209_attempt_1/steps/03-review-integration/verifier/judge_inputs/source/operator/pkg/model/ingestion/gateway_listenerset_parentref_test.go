// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

package ingestion

import (
	"testing"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"

	"github.com/cilium/cilium/operator/pkg/model"
)

func TestListenerWithContextHonorsParentPort(t *testing.T) {
	kind := gatewayv1.Kind("ListenerSet")
	matchingPort := gatewayv1.PortNumber(8080)
	wrongPort := gatewayv1.PortNumber(9090)
	listener := ListenerWithContext{
		Listener: gatewayv1.Listener{Name: "http", Port: matchingPort},
		Source:   model.FullyQualifiedResource{Name: "set", Namespace: "default", Kind: "ListenerSet"},
	}
	route := gatewayv1.HTTPRoute{
		ObjectMeta: metav1.ObjectMeta{Name: "route", Namespace: "default"},
		Spec: gatewayv1.HTTPRouteSpec{CommonRouteSpec: gatewayv1.CommonRouteSpec{
			ParentRefs: []gatewayv1.ParentReference{{Kind: &kind, Name: "set", Port: &wrongPort}},
		}},
	}

	if got := listener.FilterHTTPRoutes([]gatewayv1.HTTPRoute{route}); len(got) != 0 {
		t.Fatal("route with a different parent port must not attach")
	}
	route.Spec.ParentRefs[0].Port = &matchingPort
	if got := listener.FilterHTTPRoutes([]gatewayv1.HTTPRoute{route}); len(got) != 1 {
		t.Fatal("route with the matching parent port must attach")
	}
}
