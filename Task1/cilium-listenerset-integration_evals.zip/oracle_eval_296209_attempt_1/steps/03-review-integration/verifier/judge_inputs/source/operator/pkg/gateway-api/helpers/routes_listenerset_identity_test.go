// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

package helpers

import (
	"context"
	"testing"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/utils/ptr"
	gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"
)

func TestIsParentAttachableDistinguishesSameNameListenerSet(t *testing.T) {
	gw := &gatewayv1.Gateway{ObjectMeta: metav1.ObjectMeta{Name: "shared", Namespace: "default"}}
	route := &gatewayv1.HTTPRoute{ObjectMeta: metav1.ObjectMeta{Name: "route", Namespace: "default"}}
	parent := gatewayv1.RouteParentStatus{
		ParentRef: gatewayv1.ParentReference{
			Group: ptr.To(gatewayv1.Group(gatewayv1.SchemeGroupVersion.Group)),
			Kind:  ptr.To(gatewayv1.Kind("ListenerSet")),
			Name:  gatewayv1.ObjectName("shared"),
		},
		Conditions: []metav1.Condition{{
			Type: string(gatewayv1.RouteConditionAccepted), Status: metav1.ConditionTrue,
		}},
	}

	if IsParentAttachable(context.Background(), gw, route, []gatewayv1.RouteParentStatus{parent}, nil) {
		t.Fatal("ListenerSet parent must not match a same-name Gateway")
	}

	ls := gatewayv1.ListenerSet{ObjectMeta: metav1.ObjectMeta{Name: "shared", Namespace: "default"}}
	if !IsParentAttachable(context.Background(), gw, route, []gatewayv1.RouteParentStatus{parent}, []gatewayv1.ListenerSet{ls}) {
		t.Fatal("accepted route should match the attached same-name ListenerSet")
	}
}
