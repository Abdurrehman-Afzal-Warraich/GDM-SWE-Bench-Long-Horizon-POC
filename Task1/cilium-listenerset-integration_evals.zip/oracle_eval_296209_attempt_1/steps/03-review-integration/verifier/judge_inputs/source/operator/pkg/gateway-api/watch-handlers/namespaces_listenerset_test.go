// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

package watchhandlers

import (
	"log/slog"
	"testing"

	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"
)

func TestGatewayAllowsListenerSetNamespaceSelectorTransitions(t *testing.T) {
	from := gatewayv1.NamespacesFromSelector
	gw := &gatewayv1.Gateway{
		ObjectMeta: metav1.ObjectMeta{Name: "gateway", Namespace: "gateway-ns"},
		Spec: gatewayv1.GatewaySpec{
			AllowedListeners: &gatewayv1.AllowedListeners{
				Namespaces: &gatewayv1.ListenerNamespaces{
					From:     &from,
					Selector: &metav1.LabelSelector{MatchLabels: map[string]string{"team": "infra"}},
				},
			},
		},
	}
	ns := &corev1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: "app-ns", Labels: map[string]string{"team": "app"}}}

	if gatewayAllowsListenerSetNamespace(ns, gw, slog.Default()) {
		t.Fatal("non-matching namespace must not attach")
	}
	ns.Labels["team"] = "infra"
	if !gatewayAllowsListenerSetNamespace(ns, gw, slog.Default()) {
		t.Fatal("matching label must attach")
	}
	ns.Labels["team"] = "app"
	if gatewayAllowsListenerSetNamespace(ns, gw, slog.Default()) {
		t.Fatal("removing the matching label must detach")
	}
}
