// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

package watchhandlers

import (
	"context"
	"log/slog"

	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/labels"
	"k8s.io/apimachinery/pkg/types"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/handler"
	"sigs.k8s.io/controller-runtime/pkg/reconcile"
	gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"

	"github.com/cilium/cilium/operator/pkg/gateway-api/helpers"
	"github.com/cilium/cilium/pkg/logging/logfields"
)

// EnqueueRequestForAllowedNamespace returns an event handler for any changes
// with allowed namespaces
func EnqueueRequestForAllowedNamespace(c client.Client, logger *slog.Logger) handler.EventHandler {
	return handler.EnqueueRequestsFromMapFunc(func(ctx context.Context, ns client.Object) []reconcile.Request {
		gateways := getGatewaysForNamespace(ctx, c, ns, logger)
		reqs := make([]reconcile.Request, 0, len(gateways))
		for _, gw := range gateways {
			reqs = append(reqs, reconcile.Request{
				NamespacedName: gw,
			})
		}
		return reqs
	})
}

func getGatewaysForNamespace(ctx context.Context, c client.Client, ns client.Object, logger *slog.Logger) []types.NamespacedName {
	scopedLog := logger.With(
		logfields.K8sNamespace, ns.GetName(),
	)

	gwList := &gatewayv1.GatewayList{}
	if err := c.List(ctx, gwList); err != nil {
		scopedLog.WarnContext(ctx, "Unable to list Gateways", logfields.Error, err)
		return nil
	}

	var gateways []types.NamespacedName
	for _, gw := range gwList.Items {
		gwNN := client.ObjectKey{Namespace: gw.GetNamespace(), Name: gw.GetName()}
		if gatewayAllowsListenerSetNamespace(ns, &gw, scopedLog) {
			gateways = append(gateways, gwNN)
		}
		for _, l := range gw.Spec.Listeners {
			ok := addGatewayIfNamespaceMatches(ctx, c, ns, l, gw.GetNamespace(), gwNN, scopedLog, &gateways)
			if !ok {
				return nil
			}
		}
	}

	if helpers.HasListenerSetSupport(c.Scheme()) {
		lsList := &gatewayv1.ListenerSetList{}
		if err := c.List(ctx, lsList); err != nil {
			scopedLog.WarnContext(ctx, "Unable to list ListenerSets", logfields.Error, err)
			return nil
		}
		for _, ls := range lsList.Items {
			gwNN := helpers.ListenerSetParentGateway(&ls)
			if gwNN == nil {
				continue
			}
			for _, entry := range ls.Spec.Listeners {
				l := helpers.ListenerEntryToListener(entry)
				ok := addGatewayIfNamespaceMatches(ctx, c, ns, l, ls.GetNamespace(), *gwNN, scopedLog, &gateways)
				if !ok {
					return nil
				}
			}
		}
	}

	return gateways
}

func gatewayAllowsListenerSetNamespace(ns client.Object, gw *gatewayv1.Gateway, scopedLog *slog.Logger) bool {
	if gw.Spec.AllowedListeners == nil || gw.Spec.AllowedListeners.Namespaces == nil || gw.Spec.AllowedListeners.Namespaces.From == nil {
		return false
	}

	allowed := gw.Spec.AllowedListeners.Namespaces
	switch *allowed.From {
	case gatewayv1.NamespacesFromAll:
		return true
	case gatewayv1.NamespacesFromSame:
		return ns.GetName() == gw.GetNamespace()
	case gatewayv1.NamespacesFromNone:
		return false
	case gatewayv1.NamespacesFromSelector:
		if allowed.Selector == nil {
			scopedLog.Warn("AllowedListeners namespace set to Selector but no selector specified", logfields.Gateway, gw.GetName())
			return false
		}
		selector, err := metav1.LabelSelectorAsSelector(allowed.Selector)
		if err != nil {
			scopedLog.Warn("Unable to parse AllowedListeners namespace selector", logfields.Gateway, gw.GetName(), logfields.Error, err)
			return false
		}
		return selector.Matches(labels.Set(ns.GetLabels()))
	default:
		return false
	}
}

func addGatewayIfNamespaceMatches(
	ctx context.Context,
	c client.Client,
	ns client.Object,
	l gatewayv1.Listener,
	ownerNamespace string,
	gwNN types.NamespacedName,
	scopedLog *slog.Logger,
	gateways *[]types.NamespacedName,
) bool {
	if l.AllowedRoutes == nil || l.AllowedRoutes.Namespaces == nil {
		return true
	}
	switch *l.AllowedRoutes.Namespaces.From {
	case gatewayv1.NamespacesFromAll:
		*gateways = append(*gateways, gwNN)
	case gatewayv1.NamespacesFromSame:
		if ns.GetName() == ownerNamespace {
			*gateways = append(*gateways, gwNN)
		}
	case gatewayv1.NamespacesFromSelector:
		if l.AllowedRoutes.Namespaces.Selector == nil {
			scopedLog.WarnContext(ctx, "AllowedRoutes namespace set to Selector but no selector specified", logfields.Gateway, gwNN.Name)
			return true
		}
		nsList := &corev1.NamespaceList{}
		if err := c.List(ctx, nsList, client.MatchingLabels(l.AllowedRoutes.Namespaces.Selector.MatchLabels)); err != nil {
			scopedLog.WarnContext(ctx, "Unable to list Namespaces", logfields.Error, err)
			return false
		}
		for _, item := range nsList.Items {
			if item.GetName() == ns.GetName() {
				*gateways = append(*gateways, gwNN)
			}
		}
	}
	return true
}
