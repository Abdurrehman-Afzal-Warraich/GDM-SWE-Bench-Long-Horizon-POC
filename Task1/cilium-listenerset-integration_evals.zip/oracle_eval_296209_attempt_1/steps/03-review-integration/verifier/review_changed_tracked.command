git diff --no-ext-diff --name-only 4aeef2a24a6f4ff64ba98ee0808d4989777670ef -- .
