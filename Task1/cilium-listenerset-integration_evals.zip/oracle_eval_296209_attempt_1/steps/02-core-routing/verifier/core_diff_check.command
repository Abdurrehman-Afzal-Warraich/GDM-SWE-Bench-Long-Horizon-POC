git diff --no-ext-diff --check 5077a5f0fad58063844f7eb08d391f24271f3eed -- .
