go test ./operator/pkg/model/ingestion/... ./operator/pkg/model/translation/gateway-api/... -count=1 
