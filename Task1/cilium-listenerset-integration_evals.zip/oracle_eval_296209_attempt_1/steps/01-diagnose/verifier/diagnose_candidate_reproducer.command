/app/output/01-diagnose/reproduce.sh
