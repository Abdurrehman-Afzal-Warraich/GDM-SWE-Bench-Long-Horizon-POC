// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

package gateway_api

import (
	"context"
	"log/slog"
	"testing"

	"github.com/cilium/hive/hivetest"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/utils/ptr"
	ctrl "sigs.k8s.io/controller-runtime"
	"sigs.k8s.io/controller-runtime/pkg/client/fake"
	gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"
	gatewayv1alpha2 "sigs.k8s.io/gateway-api/apis/v1alpha2"

	"github.com/cilium/cilium/operator/pkg/gateway-api/helpers"
	"github.com/cilium/cilium/operator/pkg/gateway-api/indexers"
	"github.com/cilium/cilium/operator/pkg/model/translation"
	gatewayApiTranslation "github.com/cilium/cilium/operator/pkg/model/translation/gateway-api"
	ciliumv2 "github.com/cilium/cilium/pkg/k8s/apis/cilium.io/v2"
)

func TestListenerSetAllowedPolicy(t *testing.T) {
	scheme := helpers.TestScheme(helpers.AllOptionalKinds)

	gwc := &gatewayv1.GatewayClass{
		ObjectMeta: metav1.ObjectMeta{
			Name: "cilium",
		},
		Spec: gatewayv1.GatewayClassSpec{
			ControllerName: "io.cilium/gateway-controller",
		},
	}

	gwSame := &gatewayv1.Gateway{
		TypeMeta: metav1.TypeMeta{Kind: "Gateway", APIVersion: "gateway.networking.k8s.io/v1"},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "gw-same",
			Namespace: "default",
		},
		Spec: gatewayv1.GatewaySpec{
			GatewayClassName: "cilium",
			AllowedListeners: &gatewayv1.AllowedListeners{
				Namespaces: &gatewayv1.ListenerNamespaces{
					From: ptr.To(gatewayv1.NamespacesFromSame),
				},
			},
			Listeners: []gatewayv1.Listener{
				{
					Name:     "http",
					Port:     80,
					Protocol: gatewayv1.HTTPProtocolType,
				},
			},
		},
	}

	lsSame := &gatewayv1.ListenerSet{
		TypeMeta: metav1.TypeMeta{Kind: "ListenerSet", APIVersion: "gateway.networking.k8s.io/v1"},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "ls-same",
			Namespace: "default",
		},
		Spec: gatewayv1.ListenerSetSpec{
			ParentRef: gatewayv1.ParentGatewayReference{
				Name: "gw-same",
			},
			Listeners: []gatewayv1.ListenerEntry{
				{
					Name:     "extra-http",
					Port:     8080,
					Protocol: gatewayv1.HTTPProtocolType,
				},
			},
		},
	}

	lsDiff := &gatewayv1.ListenerSet{
		TypeMeta: metav1.TypeMeta{Kind: "ListenerSet", APIVersion: "gateway.networking.k8s.io/v1"},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "ls-diff",
			Namespace: "other",
		},
		Spec: gatewayv1.ListenerSetSpec{
			ParentRef: gatewayv1.ParentGatewayReference{
				Name:      "gw-same",
				Namespace: ptr.To(gatewayv1.Namespace("default")),
			},
			Listeners: []gatewayv1.ListenerEntry{
				{
					Name:     "other-http",
					Port:     8081,
					Protocol: gatewayv1.HTTPProtocolType,
				},
			},
		},
	}

	clientBuilder := fake.NewClientBuilder().
		WithScheme(scheme).
		WithStatusSubresource(&gatewayv1.Gateway{}, &gatewayv1.ListenerSet{}).
		WithIndex(&gatewayv1.HTTPRoute{}, indexers.GatewayHTTPRouteIndex, indexers.IndexHTTPRouteByGateway).
		WithIndex(&gatewayv1.GRPCRoute{}, indexers.GatewayGRPCRouteIndex, indexers.IndexGRPCRouteByGateway).
		WithIndex(&gatewayv1.TLSRoute{}, indexers.GatewayTLSRouteIndex, indexers.IndexTLSRouteByGateway).
		WithIndex(&gatewayv1alpha2.TCPRoute{}, indexers.GatewayTCPRouteIndex, indexers.IndexTCPRouteByGateway).
		WithIndex(&gatewayv1alpha2.UDPRoute{}, indexers.GatewayUDPRouteIndex, indexers.IndexUDPRouteByGateway).
		WithIndex(&gatewayv1.ListenerSet{}, indexers.GatewayListenerSetIndex, indexers.IndexListenerSetByParentGateway).
		WithObjects(gwc, gwSame, lsSame, lsDiff)

	c := clientBuilder.Build()
	logger := hivetest.Logger(t, hivetest.LogLevel(slog.LevelDebug))
	cecTranslator := translation.NewCECTranslator(translation.Config{SecretsNamespace: "cilium-secrets"})
	gwTranslator := gatewayApiTranslation.NewTranslator(cecTranslator, translation.Config{})
	r := &gatewayReconciler{
		Client:         c,
		Scheme:         scheme,
		translator:     gwTranslator,
		logger:         logger,
		controllerName: "io.cilium/gateway-controller",
	}

	_, err := r.Reconcile(context.Background(), ctrl.Request{NamespacedName: types.NamespacedName{Name: "gw-same", Namespace: "default"}})
	require.NoError(t, err)

	var updatedGw gatewayv1.Gateway
	err = c.Get(context.Background(), types.NamespacedName{Name: "gw-same", Namespace: "default"}, &updatedGw)
	require.NoError(t, err)
	require.NotNil(t, updatedGw.Status.AttachedListenerSets)
	assert.Equal(t, int32(1), *updatedGw.Status.AttachedListenerSets)

	var fetchedSameLS gatewayv1.ListenerSet
	err = c.Get(context.Background(), types.NamespacedName{Name: "ls-same", Namespace: "default"}, &fetchedSameLS)
	require.NoError(t, err)
	require.NotEmpty(t, fetchedSameLS.Status.Conditions)

	acceptedCond := getCondition(fetchedSameLS.Status.Conditions, string(gatewayv1.ListenerSetConditionAccepted))
	require.NotNil(t, acceptedCond)
	assert.Equal(t, metav1.ConditionTrue, acceptedCond.Status)

	var fetchedDiffLS gatewayv1.ListenerSet
	err = c.Get(context.Background(), types.NamespacedName{Name: "ls-diff", Namespace: "other"}, &fetchedDiffLS)
	require.NoError(t, err)
	require.NotEmpty(t, fetchedDiffLS.Status.Conditions)

	diffAcceptedCond := getCondition(fetchedDiffLS.Status.Conditions, string(gatewayv1.ListenerSetConditionAccepted))
	require.NotNil(t, diffAcceptedCond)
	assert.Equal(t, metav1.ConditionFalse, diffAcceptedCond.Status)
}

func getCondition(conds []metav1.Condition, condType string) *metav1.Condition {
	for _, c := range conds {
		if c.Type == condType {
			return &c
		}
	}
	return nil
}

func TestListenerSetRoutesAndCEC(t *testing.T) {
	scheme := helpers.TestScheme(helpers.AllOptionalKinds)

	gwc := &gatewayv1.GatewayClass{
		ObjectMeta: metav1.ObjectMeta{
			Name: "cilium",
		},
		Spec: gatewayv1.GatewayClassSpec{
			ControllerName: "io.cilium/gateway-controller",
		},
	}

	gw := &gatewayv1.Gateway{
		TypeMeta: metav1.TypeMeta{Kind: "Gateway", APIVersion: "gateway.networking.k8s.io/v1"},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "test-gw",
			Namespace: "default",
		},
		Spec: gatewayv1.GatewaySpec{
			GatewayClassName: "cilium",
			AllowedListeners: &gatewayv1.AllowedListeners{
				Namespaces: &gatewayv1.ListenerNamespaces{
					From: ptr.To(gatewayv1.NamespacesFromSame),
				},
			},
			Listeners: []gatewayv1.Listener{
				{
					Name:     "gw-http",
					Port:     80,
					Protocol: gatewayv1.HTTPProtocolType,
				},
			},
		},
	}

	ls := &gatewayv1.ListenerSet{
		TypeMeta: metav1.TypeMeta{Kind: "ListenerSet", APIVersion: "gateway.networking.k8s.io/v1"},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "test-ls",
			Namespace: "default",
		},
		Spec: gatewayv1.ListenerSetSpec{
			ParentRef: gatewayv1.ParentGatewayReference{
				Name: "test-gw",
			},
			Listeners: []gatewayv1.ListenerEntry{
				{
					Name:     "ls-http",
					Port:     8080,
					Protocol: gatewayv1.HTTPProtocolType,
				},
			},
		},
	}

	httpRoute := &gatewayv1.HTTPRoute{
		TypeMeta: metav1.TypeMeta{Kind: "HTTPRoute", APIVersion: "gateway.networking.k8s.io/v1"},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "ls-route",
			Namespace: "default",
		},
		Spec: gatewayv1.HTTPRouteSpec{
			CommonRouteSpec: gatewayv1.CommonRouteSpec{
				ParentRefs: []gatewayv1.ParentReference{
					{
						Group: ptr.To(gatewayv1.Group("gateway.networking.k8s.io")),
						Kind:  ptr.To(gatewayv1.Kind("ListenerSet")),
						Name:  "test-ls",
					},
				},
			},
			Rules: []gatewayv1.HTTPRouteRule{
				{
					BackendRefs: []gatewayv1.HTTPBackendRef{
						{
							BackendRef: gatewayv1.BackendRef{
								BackendObjectReference: gatewayv1.BackendObjectReference{
									Name: "demo-svc",
									Port: ptr.To(gatewayv1.PortNumber(8080)),
								},
							},
						},
					},
				},
			},
		},
	}

	svc := &corev1.Service{
		TypeMeta: metav1.TypeMeta{Kind: "Service", APIVersion: "v1"},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "demo-svc",
			Namespace: "default",
		},
		Spec: corev1.ServiceSpec{
			Ports: []corev1.ServicePort{
				{Port: 8080},
			},
		},
	}

	clientBuilder := fake.NewClientBuilder().
		WithScheme(scheme).
		WithStatusSubresource(&gatewayv1.Gateway{}, &gatewayv1.ListenerSet{}, &gatewayv1.HTTPRoute{}).
		WithIndex(&gatewayv1.HTTPRoute{}, indexers.GatewayHTTPRouteIndex, indexers.IndexHTTPRouteByGateway).
		WithIndex(&gatewayv1.GRPCRoute{}, indexers.GatewayGRPCRouteIndex, indexers.IndexGRPCRouteByGateway).
		WithIndex(&gatewayv1.TLSRoute{}, indexers.GatewayTLSRouteIndex, indexers.IndexTLSRouteByGateway).
		WithIndex(&gatewayv1alpha2.TCPRoute{}, indexers.GatewayTCPRouteIndex, indexers.IndexTCPRouteByGateway).
		WithIndex(&gatewayv1alpha2.UDPRoute{}, indexers.GatewayUDPRouteIndex, indexers.IndexUDPRouteByGateway).
		WithIndex(&gatewayv1.ListenerSet{}, indexers.GatewayListenerSetIndex, indexers.IndexListenerSetByParentGateway).
		WithObjects(gwc, gw, ls, httpRoute, svc)

	c := clientBuilder.Build()
	logger := hivetest.Logger(t, hivetest.LogLevel(slog.LevelDebug))
	cecTranslator := translation.NewCECTranslator(translation.Config{SecretsNamespace: "cilium-secrets"})
	gwTranslator := gatewayApiTranslation.NewTranslator(cecTranslator, translation.Config{})
	r := &gatewayReconciler{
		Client:         c,
		Scheme:         scheme,
		translator:     gwTranslator,
		logger:         logger,
		controllerName: "io.cilium/gateway-controller",
	}

	_, err := r.Reconcile(context.Background(), ctrl.Request{NamespacedName: types.NamespacedName{Name: "test-gw", Namespace: "default"}})
	require.NoError(t, err)

	var updatedGw gatewayv1.Gateway
	err = c.Get(context.Background(), types.NamespacedName{Name: "test-gw", Namespace: "default"}, &updatedGw)
	require.NoError(t, err)
	require.NotNil(t, updatedGw.Status.AttachedListenerSets)
	assert.Equal(t, int32(1), *updatedGw.Status.AttachedListenerSets)

	var updatedLS gatewayv1.ListenerSet
	err = c.Get(context.Background(), types.NamespacedName{Name: "test-ls", Namespace: "default"}, &updatedLS)
	require.NoError(t, err)
	require.NotEmpty(t, updatedLS.Status.Conditions)
	assert.Equal(t, metav1.ConditionTrue, getCondition(updatedLS.Status.Conditions, string(gatewayv1.ListenerSetConditionAccepted)).Status)

	actualRoute := &gatewayv1.HTTPRoute{TypeMeta: metav1.TypeMeta{Kind: "HTTPRoute", APIVersion: "gateway.networking.k8s.io/v1"}}
	err = c.Get(context.Background(), types.NamespacedName{Name: "ls-route", Namespace: "default"}, actualRoute)
	require.NoError(t, err)
	t.Logf("ACTUAL_ROUTE_PARENTS: %+v", actualRoute.Status.Parents)
	require.NotEmpty(t, actualRoute.Status.Parents)
	assert.Equal(t, "test-ls", string(actualRoute.Status.Parents[0].ParentRef.Name))

	var cecList ciliumv2.CiliumEnvoyConfigList
	err = c.List(context.Background(), &cecList)
	require.NoError(t, err)
	require.Len(t, cecList.Items, 1)
}
