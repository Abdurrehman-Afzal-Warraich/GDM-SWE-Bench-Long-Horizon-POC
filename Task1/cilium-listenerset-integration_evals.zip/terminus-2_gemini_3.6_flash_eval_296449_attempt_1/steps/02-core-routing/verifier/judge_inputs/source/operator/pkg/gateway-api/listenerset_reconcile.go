// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

package gateway_api

import (
	"context"
	"slices"
	"strings"
	"time"

	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/fields"
	"k8s.io/apimachinery/pkg/labels"
	"k8s.io/apimachinery/pkg/types"
	"sigs.k8s.io/controller-runtime/pkg/client"
	gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"
	gatewayv1alpha2 "sigs.k8s.io/gateway-api/apis/v1alpha2"

	"github.com/cilium/cilium/operator/pkg/gateway-api/helpers"
	"github.com/cilium/cilium/operator/pkg/gateway-api/indexers"
)

func (r *gatewayReconciler) isListenerSetAllowed(ctx context.Context, gw *gatewayv1.Gateway, ls *gatewayv1.ListenerSet) bool {
	if gw.Spec.AllowedListeners == nil || gw.Spec.AllowedListeners.Namespaces == nil {
		return false
	}
	from := gatewayv1.NamespacesFromNone
	if gw.Spec.AllowedListeners.Namespaces.From != nil {
		from = *gw.Spec.AllowedListeners.Namespaces.From
	}
	switch from {
	case gatewayv1.NamespacesFromNone:
		return false
	case gatewayv1.NamespacesFromSame:
		return gw.Namespace == ls.Namespace
	case gatewayv1.NamespacesFromAll:
		return true
	case gatewayv1.NamespacesFromSelector:
		if gw.Spec.AllowedListeners.Namespaces.Selector == nil {
			return false
		}
		selector, err := metav1.LabelSelectorAsSelector(gw.Spec.AllowedListeners.Namespaces.Selector)
		if err != nil {
			return false
		}
		ns := &corev1.Namespace{}
		if err := r.Client.Get(ctx, types.NamespacedName{Name: ls.Namespace}, ns); err != nil {
			return false
		}
		return selector.Matches(labels.Set(ns.Labels))
	}
	return false
}

func (r *gatewayReconciler) getAttachedListenerSets(ctx context.Context, gw *gatewayv1.Gateway) ([]gatewayv1.ListenerSet, []gatewayv1.ListenerSet, error) {
	lsList := &gatewayv1.ListenerSetList{}
	if err := r.Client.List(ctx, lsList); err != nil {
		return nil, nil, err
	}

	var attached []gatewayv1.ListenerSet
	var unattached []gatewayv1.ListenerSet

	for _, ls := range lsList.Items {
		parentNs := helpers.NamespaceDerefOr(ls.Spec.ParentRef.Namespace, ls.Namespace)
		if parentNs != gw.Namespace || string(ls.Spec.ParentRef.Name) != gw.Name {
			continue
		}

		if r.isListenerSetAllowed(ctx, gw, &ls) {
			attached = append(attached, ls)
		} else {
			unattached = append(unattached, ls)
		}
	}

	slices.SortFunc(attached, func(a, b gatewayv1.ListenerSet) int {
		if c := a.CreationTimestamp.Time.Compare(b.CreationTimestamp.Time); c != 0 {
			return c
		}
		nameA := a.Namespace + "/" + a.Name
		nameB := b.Namespace + "/" + b.Name
		return strings.Compare(nameA, nameB)
	})

	return attached, unattached, nil
}

func setListenerSetCondition(ls *gatewayv1.ListenerSet, conditionType gatewayv1.ListenerSetConditionType, status metav1.ConditionStatus, reason gatewayv1.ListenerSetConditionReason, message string) {
	cond := metav1.Condition{
		Type:               string(conditionType),
		Status:             status,
		Reason:             string(reason),
		Message:            message,
		ObservedGeneration: ls.Generation,
		LastTransitionTime: metav1.NewTime(time.Now()),
	}
	ls.Status.Conditions = merge(ls.Status.Conditions, cond)
}

func (r *gatewayReconciler) reconcileListenerSetStatuses(ctx context.Context, gw *gatewayv1.Gateway, attachedLS []gatewayv1.ListenerSet, unattachedLS []gatewayv1.ListenerSet, gwProgrammed bool, httpRoutes *gatewayv1.HTTPRouteList, tlsRoutes *gatewayv1.TLSRouteList, grpcRoutes *gatewayv1.GRPCRouteList, tcpRoutes *gatewayv1alpha2.TCPRouteList, udpRoutes *gatewayv1alpha2.UDPRouteList, namespaceLabels helpers.NamespaceLabelIndex) error {
	for _, ls := range unattachedLS {
		lsCopy := ls.DeepCopy()
		setListenerSetCondition(lsCopy, gatewayv1.ListenerSetConditionAccepted, metav1.ConditionFalse, gatewayv1.ListenerSetReasonNotAllowed, "ListenerSet is not allowed by parent Gateway's allowedListeners policy")
		setListenerSetCondition(lsCopy, gatewayv1.ListenerSetConditionProgrammed, metav1.ConditionFalse, gatewayv1.ListenerSetReasonParentNotAccepted, "Parent Gateway has not allowed this ListenerSet")
		_ = r.Client.Status().Update(ctx, lsCopy)
	}

	for _, ls := range attachedLS {
		lsCopy := ls.DeepCopy()
		setListenerSetCondition(lsCopy, gatewayv1.ListenerSetConditionAccepted, metav1.ConditionTrue, gatewayv1.ListenerSetReasonAccepted, "ListenerSet accepted by parent Gateway")
		if gwProgrammed {
			setListenerSetCondition(lsCopy, gatewayv1.ListenerSetConditionProgrammed, metav1.ConditionTrue, gatewayv1.ListenerSetReasonProgrammed, "ListenerSet programmed")
		} else {
			setListenerSetCondition(lsCopy, gatewayv1.ListenerSetConditionProgrammed, metav1.ConditionFalse, gatewayv1.ListenerSetReasonParentNotAccepted, "Parent Gateway is not programmed")
		}

		var entryStatuses []gatewayv1.ListenerEntryStatus
		for _, entry := range ls.Spec.Listeners {
			supportedKinds := getSupportedRouteKinds(entry.Protocol)
			var conds []metav1.Condition
			conds = merge(conds, metav1.Condition{
				Type:               string(gatewayv1.ListenerConditionAccepted),
				Status:             metav1.ConditionTrue,
				Reason:             string(gatewayv1.ListenerReasonAccepted),
				Message:            "Listener Accepted",
				ObservedGeneration: ls.Generation,
				LastTransitionTime: metav1.NewTime(time.Now()),
			})
			conds = merge(conds, metav1.Condition{
				Type:               string(gatewayv1.ListenerConditionResolvedRefs),
				Status:             metav1.ConditionTrue,
				Reason:             string(gatewayv1.ListenerReasonResolvedRefs),
				Message:            "Resolved Refs",
				ObservedGeneration: ls.Generation,
				LastTransitionTime: metav1.NewTime(time.Now()),
			})

			// Count attached routes
			l := gatewayv1.Listener{
				Name:          entry.Name,
				Hostname:      entry.Hostname,
				Port:          entry.Port,
				Protocol:      entry.Protocol,
				TLS:           entry.TLS,
				AllowedRoutes: entry.AllowedRoutes,
			}
			var attachedRoutes int32
			attachedRoutes += int32(len(r.filterHTTPRoutesByListener(ctx, gw, &l, httpRoutes.Items, namespaceLabels)))
			attachedRoutes += int32(len(r.filterGRPCRoutesByListener(ctx, gw, &l, grpcRoutes.Items, namespaceLabels)))
			attachedRoutes += int32(len(r.filterTLSRoutesByListener(ctx, gw, &l, tlsRoutes.Items, namespaceLabels)))
			attachedRoutes += int32(len(r.filterTCPRoutesByListener(ctx, gw, &l, tcpRoutes.Items, namespaceLabels)))
			attachedRoutes += int32(len(r.filterUDPRoutesByListener(ctx, gw, &l, udpRoutes.Items, namespaceLabels)))

			entryStatuses = append(entryStatuses, gatewayv1.ListenerEntryStatus{
				Name:           entry.Name,
				SupportedKinds: supportedKinds,
				AttachedRoutes: attachedRoutes,
				Conditions:     conds,
			})
		}
		lsCopy.Status.Listeners = entryStatuses
		_ = r.Client.Status().Update(ctx, lsCopy)
	}
	return nil
}

func (r *gatewayReconciler) getHTTPRoutesForGatewayAndListenerSets(ctx context.Context, gwKey string, attachedLS []gatewayv1.ListenerSet) (*gatewayv1.HTTPRouteList, error) {
	if len(attachedLS) == 0 {
		list := &gatewayv1.HTTPRouteList{}
		err := r.Client.List(ctx, list, &client.ListOptions{
			FieldSelector: fields.OneTermEqualSelector(indexers.GatewayHTTPRouteIndex, gwKey),
		})
		return list, err
	}
	keys := append([]string{gwKey}, getListenerSetKeys(attachedLS)...)
	routeMap := make(map[types.UID]gatewayv1.HTTPRoute)
	for _, key := range keys {
		list := &gatewayv1.HTTPRouteList{}
		if err := r.Client.List(ctx, list, &client.ListOptions{
			FieldSelector: fields.OneTermEqualSelector(indexers.GatewayHTTPRouteIndex, key),
		}); err != nil {
			return nil, err
		}
		for _, item := range list.Items {
			routeMap[item.UID] = item
		}
	}
	res := &gatewayv1.HTTPRouteList{}
	for _, item := range routeMap {
		res.Items = append(res.Items, item)
	}
	slices.SortFunc(res.Items, func(a, b gatewayv1.HTTPRoute) int {
		if c := strings.Compare(a.Namespace, b.Namespace); c != 0 {
			return c
		}
		return strings.Compare(a.Name, b.Name)
	})
	return res, nil
}

func (r *gatewayReconciler) getGRPCRoutesForGatewayAndListenerSets(ctx context.Context, gwKey string, attachedLS []gatewayv1.ListenerSet) (*gatewayv1.GRPCRouteList, error) {
	if len(attachedLS) == 0 {
		list := &gatewayv1.GRPCRouteList{}
		err := r.Client.List(ctx, list, &client.ListOptions{
			FieldSelector: fields.OneTermEqualSelector(indexers.GatewayGRPCRouteIndex, gwKey),
		})
		return list, err
	}
	keys := append([]string{gwKey}, getListenerSetKeys(attachedLS)...)
	routeMap := make(map[types.UID]gatewayv1.GRPCRoute)
	for _, key := range keys {
		list := &gatewayv1.GRPCRouteList{}
		if err := r.Client.List(ctx, list, &client.ListOptions{
			FieldSelector: fields.OneTermEqualSelector(indexers.GatewayGRPCRouteIndex, key),
		}); err != nil {
			return nil, err
		}
		for _, item := range list.Items {
			routeMap[item.UID] = item
		}
	}
	res := &gatewayv1.GRPCRouteList{}
	for _, item := range routeMap {
		res.Items = append(res.Items, item)
	}
	slices.SortFunc(res.Items, func(a, b gatewayv1.GRPCRoute) int {
		if c := strings.Compare(a.Namespace, b.Namespace); c != 0 {
			return c
		}
		return strings.Compare(a.Name, b.Name)
	})
	return res, nil
}

func (r *gatewayReconciler) getTLSRoutesForGatewayAndListenerSets(ctx context.Context, gwKey string, attachedLS []gatewayv1.ListenerSet) (*gatewayv1.TLSRouteList, error) {
	if len(attachedLS) == 0 {
		list := &gatewayv1.TLSRouteList{}
		err := r.Client.List(ctx, list, &client.ListOptions{
			FieldSelector: fields.OneTermEqualSelector(indexers.GatewayTLSRouteIndex, gwKey),
		})
		return list, err
	}
	keys := append([]string{gwKey}, getListenerSetKeys(attachedLS)...)
	routeMap := make(map[types.UID]gatewayv1.TLSRoute)
	for _, key := range keys {
		list := &gatewayv1.TLSRouteList{}
		if err := r.Client.List(ctx, list, &client.ListOptions{
			FieldSelector: fields.OneTermEqualSelector(indexers.GatewayTLSRouteIndex, key),
		}); err != nil {
			return nil, err
		}
		for _, item := range list.Items {
			routeMap[item.UID] = item
		}
	}
	res := &gatewayv1.TLSRouteList{}
	for _, item := range routeMap {
		res.Items = append(res.Items, item)
	}
	slices.SortFunc(res.Items, func(a, b gatewayv1.TLSRoute) int {
		if c := strings.Compare(a.Namespace, b.Namespace); c != 0 {
			return c
		}
		return strings.Compare(a.Name, b.Name)
	})
	return res, nil
}

func (r *gatewayReconciler) getTCPRoutesForGatewayAndListenerSets(ctx context.Context, gwKey string, attachedLS []gatewayv1.ListenerSet) (*gatewayv1alpha2.TCPRouteList, error) {
	if len(attachedLS) == 0 {
		list := &gatewayv1alpha2.TCPRouteList{}
		err := r.Client.List(ctx, list, &client.ListOptions{
			FieldSelector: fields.OneTermEqualSelector(indexers.GatewayTCPRouteIndex, gwKey),
		})
		return list, err
	}
	keys := append([]string{gwKey}, getListenerSetKeys(attachedLS)...)
	routeMap := make(map[types.UID]gatewayv1alpha2.TCPRoute)
	for _, key := range keys {
		list := &gatewayv1alpha2.TCPRouteList{}
		if err := r.Client.List(ctx, list, &client.ListOptions{
			FieldSelector: fields.OneTermEqualSelector(indexers.GatewayTCPRouteIndex, key),
		}); err != nil {
			return nil, err
		}
		for _, item := range list.Items {
			routeMap[item.UID] = item
		}
	}
	res := &gatewayv1alpha2.TCPRouteList{}
	for _, item := range routeMap {
		res.Items = append(res.Items, item)
	}
	slices.SortFunc(res.Items, func(a, b gatewayv1alpha2.TCPRoute) int {
		if c := strings.Compare(a.Namespace, b.Namespace); c != 0 {
			return c
		}
		return strings.Compare(a.Name, b.Name)
	})
	return res, nil
}

func (r *gatewayReconciler) getUDPRoutesForGatewayAndListenerSets(ctx context.Context, gwKey string, attachedLS []gatewayv1.ListenerSet) (*gatewayv1alpha2.UDPRouteList, error) {
	if len(attachedLS) == 0 {
		list := &gatewayv1alpha2.UDPRouteList{}
		err := r.Client.List(ctx, list, &client.ListOptions{
			FieldSelector: fields.OneTermEqualSelector(indexers.GatewayUDPRouteIndex, gwKey),
		})
		return list, err
	}
	keys := append([]string{gwKey}, getListenerSetKeys(attachedLS)...)
	routeMap := make(map[types.UID]gatewayv1alpha2.UDPRoute)
	for _, key := range keys {
		list := &gatewayv1alpha2.UDPRouteList{}
		if err := r.Client.List(ctx, list, &client.ListOptions{
			FieldSelector: fields.OneTermEqualSelector(indexers.GatewayUDPRouteIndex, key),
		}); err != nil {
			return nil, err
		}
		for _, item := range list.Items {
			routeMap[item.UID] = item
		}
	}
	res := &gatewayv1alpha2.UDPRouteList{}
	for _, item := range routeMap {
		res.Items = append(res.Items, item)
	}
	slices.SortFunc(res.Items, func(a, b gatewayv1alpha2.UDPRoute) int {
		if c := strings.Compare(a.Namespace, b.Namespace); c != 0 {
			return c
		}
		return strings.Compare(a.Name, b.Name)
	})
	return res, nil
}

func getListenerSetKeys(attachedLS []gatewayv1.ListenerSet) []string {
	var keys []string
	for _, ls := range attachedLS {
		keys = append(keys, ls.Namespace+"/"+ls.Name)
	}
	return keys
}

func (r *gatewayReconciler) parentIsMatchingListenerSet(parent gatewayv1.ParentReference, namespace string) bool {
	hasMatchingControllerFn := helpers.GatewayHasMatchingControllerFn(context.Background(), r.Client, r.controllerName, r.logger)
	if !helpers.IsListenerSet(parent) {
		return false
	}
	lsNs := helpers.NamespaceDerefOr(parent.Namespace, namespace)
	ls := &gatewayv1.ListenerSet{}
	if err := r.Client.Get(context.Background(), types.NamespacedName{
		Namespace: lsNs,
		Name:      string(parent.Name),
	}, ls); err != nil {
		return false
	}
	gwNs := helpers.NamespaceDerefOr(ls.Spec.ParentRef.Namespace, ls.Namespace)
	gw := &gatewayv1.Gateway{}
	if err := r.Client.Get(context.Background(), types.NamespacedName{
		Namespace: gwNs,
		Name:      string(ls.Spec.ParentRef.Name),
	}, gw); err != nil {
		return false
	}
	return hasMatchingControllerFn(gw) && r.isListenerSetAllowed(context.Background(), gw, ls)
}
