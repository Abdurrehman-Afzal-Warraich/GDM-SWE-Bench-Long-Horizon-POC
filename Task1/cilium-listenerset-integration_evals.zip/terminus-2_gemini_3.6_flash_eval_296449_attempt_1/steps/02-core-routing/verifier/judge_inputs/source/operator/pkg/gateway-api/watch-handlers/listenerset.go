// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

package watchhandlers

import (
	"context"
	"log/slog"

	"k8s.io/apimachinery/pkg/types"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/handler"
	"sigs.k8s.io/controller-runtime/pkg/reconcile"
	gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"

	"github.com/cilium/cilium/operator/pkg/gateway-api/helpers"
	"github.com/cilium/cilium/pkg/logging/logfields"
)

// EnqueueRequestForListenerSet returns an event handler that, when passed a ListenerSet,
// returns reconcile.Requests for its parent Gateway.
func EnqueueRequestForListenerSet(c client.Client, logger *slog.Logger) handler.EventHandler {
	return handler.EnqueueRequestsFromMapFunc(func(ctx context.Context, a client.Object) []reconcile.Request {
		ls, ok := a.(*gatewayv1.ListenerSet)
		if !ok {
			return nil
		}

		parentRef := ls.Spec.ParentRef
		parentNs := helpers.NamespaceDerefOr(parentRef.Namespace, ls.Namespace)
		parentName := string(parentRef.Name)

		logger.DebugContext(ctx,
			"Enqueued Gateway for ListenerSet",
			logfields.K8sNamespace, parentNs,
			logfields.ParentResource, parentName,
			logfields.Resource, ls.GetName(),
		)

		return []reconcile.Request{
			{
				NamespacedName: types.NamespacedName{
					Namespace: parentNs,
					Name:      parentName,
				},
			},
		}
	})
}
