// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

package indexers

import (
	"github.com/cilium/cilium/operator/pkg/gateway-api/helpers"
	"sigs.k8s.io/controller-runtime/pkg/client"
	gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"
)

// IndexListenerSetByParentGateway indexes ListenerSet objects by parent Gateway.
func IndexListenerSetByParentGateway(rawObj client.Object) []string {
	ls, ok := rawObj.(*gatewayv1.ListenerSet)
	if !ok {
		return nil
	}
	parentRef := ls.Spec.ParentRef
	parentNs := helpers.NamespaceDerefOr(parentRef.Namespace, ls.Namespace)
	return []string{parentNs + "/" + string(parentRef.Name)}
}
