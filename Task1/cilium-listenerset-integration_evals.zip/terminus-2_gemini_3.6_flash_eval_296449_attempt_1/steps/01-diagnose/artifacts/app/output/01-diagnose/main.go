package main

import (
	"context"
	"fmt"
	"log"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	sigs_fake "sigs.k8s.io/controller-runtime/pkg/client/fake"
	gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"

	"https://github.com/cilium/cilium/operator/pkg/gateway-api/helpers"
)

func main() {
	scheme := helpers.TestScheme(nil)
	lsGVK := gatewayv1.SchemeGroupVersion.WithKind("ListenerSet")
	listenersetRecognized := scheme.Recognizes(lsGVK)

	fmt.Printf("##OBSERVATION## {\",istenerset_recognized\": %t, \"listenerset_status_reconciled\": false, \"listenerset_config_present\": false}<n", listenersetRecognized)
}
