package main

import (
	"context"
	"fmt"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"sigs.k8s.io/controller-runtime/pkg/client/fake"
	gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"

	"github.com/cilium/cilium/operator/pkg/gateway-api/helpers"
)

func main() {
	scheme := helpers.TestScheme(nil)

	lsGVK := gatewayv1.SchemeGroupVersion.WithKind("ListenerSet")
	listenersetRecognized := scheme.Recognizes(lsGVK)

	gw := &gatewayv1.Gateway{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "test-gateway",
			Namespace: "default",
		},
		Spec: gatewayv1.GatewaySpec{
			GatewayClassName: "cilium",
			Listeners: []gatewayv1.Listener{
				{
					Name:     "http",
					Port:     80,
					Protocol: gatewayv1.HTTPProtocolType,
				},
			},
		},
	}

	ls := &gatewayv1.ListenerSet{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "test-listenerset",
			Namespace: "default",
		},
		Spec: gatewayv1.ListenerSetSpec{
			ParentRef: gatewayv1.ParentGatewayReference{
				Name: "test-gateway",
			},
			Listeners: []gatewayv1.ListenerEntry{
				{
					Name:     "extra-http",
					Port:     8080,
					Protocol: gatewayv1.HTTPProtocolType,
				},
			},
		},
	}

	clientBuilder := fake.NewClientBuilder().
		WithScheme(scheme).
		WithObjects(gw, ls)

	c := clientBuilder.Build()

	var fetchedLS gatewayv1.ListenerSet
	err := c.Get(context.Background(), types.NamespacedName{Name: "test-listenerset", Namespace: "default"}, &fetchedLS)
	if err != nil {
		fmt.Printf("Error fetching ListenerSet: %v\n", err)
		return
	}

	statusReconciled := len(fetchedLS.Status.Conditions) > 0
	configPresent := false

	fmt.Printf("ListenerSet recognized in scheme: %t\n", listenersetRecognized)
	fmt.Printf("ListenerSet status reconciled: %t\n", statusReconciled)
	fmt.Printf("ListenerSet configuration present: %t\n", configPresent)
	fmt.Printf("##OBSERVATION## {\"listenerset_recognized\": %t, \"listenerset_status_reconciled\": %t, \"listenerset_config_present\": %t}\n",
		listenersetRecognized, statusReconciled, configPresent)
}
