#!/usr/bin/env bash
set -euo pipefail
export PATH=$PATH:/usr/local/go/bin
cd /testbed
go run /app/output/01-diagnose/reproduce.go | tee /app/output/01-diagnose/raw_output.txt
