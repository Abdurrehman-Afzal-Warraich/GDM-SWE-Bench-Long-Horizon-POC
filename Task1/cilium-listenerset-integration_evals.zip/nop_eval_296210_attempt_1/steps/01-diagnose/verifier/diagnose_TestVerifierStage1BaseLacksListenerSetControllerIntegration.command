go test -json -count=1 -run ^TestVerifierStage1BaseLacksListenerSetControllerIntegration$ ./operator/pkg/gateway-api
