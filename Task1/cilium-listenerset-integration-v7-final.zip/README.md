# Cilium ListenerSet Stateful Task

Four-stage Harbor 0.8+ repository-engineering task derived from a real Cilium Gateway API feature integration.

## Source boundary

- Repository: `cilium/cilium`
- License: Apache 2.0
- Immutable pre-change commit: `aeb2d1b68e0e0bb36fc48f262bbc75c4903c19e8`
- Go baseline: `1.26.0`

## Stage sequence

1. **Diagnose** — Confirm ListenerSet controller integration is missing (base code registers the GVK but has no reconciliation); produce handoff without modifying production source.
2. **Core routing** — Establish ListenerSet feature baseline across reconciler, route-selection, and configuration translation.
3. **Review integration** — Close route-scoping, parent-identity, namespace-lifecycle, and status gaps.
4. **Failure hardening** — Ensure atomic route-retrieval failure handling and recovery.

Stage 2 defines a feature baseline rather than claiming every later edge case is already solved. Stages 3 and 4 add behavior required only when those cases are revealed.

## Oracle design

The upstream diff is generated during the image build, encrypted, and removed in plaintext before the layer is committed. Only the protected Stage 2 solution private key can decrypt and apply it. Later Oracle stages apply deterministic corrections. Each Oracle solve.sh creates `/logs/agent/oracle.txt` to signal the verifier to skip RewardKit judges.

## Network and integrity

- `allow_internet = true` in task.toml is required by Harbor for verifier-side RewardKit judge API calls.
- The `trajectory_integrity` check (0.10 weight) scans the agent trajectory for forbidden commands (`curl`, `wget`, `git clone/fetch/pull/remote`, `pip install`, `go install/get`, `apt install`); violations cause `valid_trial=0`, `reward=0`, `training_score=0`. This is **supporting detective evidence**, not the sole security boundary — agent-phase isolation and manifest immutability are enforced at the Harbor platform boundary for this single-environment layout (see `metadata.integrity_boundary_note` in task.toml).
- Binary integrity: SHA-256 checksums of go/git/python3 are compared against a verifier-owned manifest at verifier start.

## Protected boundary

During the agent phase, `/tests/` and `/solution/` directories are NOT mounted. The agent sees only `/testbed` (sanitized single-commit worktree). Hidden tests are injected by the verifier at `/tests/hidden/` and copied into the testbed only during verifier execution, then deleted. Oracle private key exists only in `steps/02-core-routing/solution/` which is never mounted for agents.

## Scoring

- Weighted deterministic checks per stage (sum 1.0); behavioral Go tests dominate (0.60-0.65 weight).
- `trajectory_integrity` (0.10 weight) — deterministic gate against network abuse.
- Integrity failure (binary tamper, repository replacement, trajectory violations) → all scores zeroed.
- Official `reward` is strictly binary (1.0 only on a valid all-required pass, else 0.0); a clean no-op earns zero deterministic numerator. RewardKit judges are training signals only and cannot rescue broken behavior.
- Diagnose, Core, and Review gate at `min_reward = 1.0`; Failure hardening is terminal and ungated.

Operator note: run the package through Harbor's Oracle and no-op agents to validate; evaluation outcomes, timings, and control results are recorded in author-only validation records, not in this README.
