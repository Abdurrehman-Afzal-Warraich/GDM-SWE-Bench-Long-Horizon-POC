#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import tomllib
from pathlib import Path

HERE = Path(__file__).resolve().parent
STAGE_CHECK = Path('/tests/stage_check.py')
if not STAGE_CHECK.exists():
    STAGE_CHECK = HERE / 'stage_check.py'

spec = importlib.util.spec_from_file_location('stage_check', STAGE_CHECK)
assert spec and spec.loader
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

assert set(module.CHECK_SPECS) == {'diagnose', 'core', 'review', 'harden'}
for stage, checks in module.CHECK_SPECS.items():
    assert checks
    assert abs(sum(checks.values()) - 1.0) < 1e-9, (stage, checks)
    assert all(weight > 0 for weight in checks.values())
    assert module.BEHAVIOR_CHECK[stage] in checks
    assert module.ARTIFACT_CHECK[stage] in checks
    assert module.INTEGRITY_CHECK[stage] in checks

assert module.STAGE2_TESTS < module.STAGE3_TESTS < module.STAGE4_TESTS

task_candidates = [Path('/task.toml'), HERE.parent / 'task.toml']
TASK_TOML = next((candidate for candidate in task_candidates if candidate.exists()), None)
if TASK_TOML is not None:
    config = tomllib.loads(TASK_TOML.read_text(encoding='utf-8'))
    assert config['multi_step_reward_strategy'] == 'final'
    assert len(config['steps']) == 4
    # F02: the three non-final stages gate at min_reward = 1.0; the terminal
    # hardening stage is ungated.
    gated = {'01-diagnose', '02-core-routing', '03-review-integration'}
    for step in config['steps']:
        if step['name'] in gated:
            assert step.get('min_reward') == 1.0, f"{step['name']} must gate at min_reward = 1.0"
        else:
            assert 'min_reward' not in step, f"terminal step {step['name']} must be ungated"

# Behavioral weight must dominate each stage (>= 0.50)
for stage in module.CHECK_SPECS:
    behavior_weight = module.CHECK_SPECS[stage][module.BEHAVIOR_CHECK[stage]]
    assert behavior_weight >= 0.50, f'{stage} behavior weight {behavior_weight} < 0.50'

# Artifact weight must not dominate (< 0.20 for diagnose, <= 0.15 for others)
diagnose_artifact_weight = module.CHECK_SPECS['diagnose'][module.ARTIFACT_CHECK['diagnose']]
assert diagnose_artifact_weight <= 0.15, f'diagnose artifact weight {diagnose_artifact_weight} > 0.15'

# Judge configuration
if TASK_TOML is not None:
    env = config.get('environment', {}).get('env', {})
    assert env.get('JUDGE_MODEL') == 'gemini/gemini-3.6-flash'
    assert env.get('RUN_LLM_JUDGES') == '1'

# Required judge dimensions
for dimension in ('process', 'validity', 'task_quality', 'merge_readiness'):
    toml_path = HERE / dimension / 'judge.toml'
    assert toml_path.is_file(), f'missing judge config: {toml_path}'

# Required verifier support files
for name in ('fallback_reward.py', 'stage_test.sh', 'stage_judge_inputs.py',
             'run_optional_judges.sh', 'judge_prompt.md', 'merge_readiness_rubric.md'):
    assert (HERE / name).is_file(), f'missing verifier file: {name}'


def checks_for(stage: str, failed: set[str] = frozenset()):
    return [
        {
            'check_id': check_id,
            'weight': weight,
            'passed': check_id not in failed,
            'evidence': {},
        }
        for check_id, weight in module.CHECK_SPECS[stage].items()
    ]


for stage in module.CHECK_SPECS:
    # Full pass with genuine agent contribution → strict binary 1.0.
    complete = module.build_payload(stage, checks_for(stage), False, True)
    assert complete['reward'] == 1.0
    assert complete['binary_reward'] == 1
    assert complete['valid_trial'] == 1
    assert complete['training_score'] == 1.0
    assert complete['deterministic_numerator'] == complete['deterministic_denominator']

    # F02: a clean no-op (behavior fails, no contribution) earns zero official
    # reward AND zero training numerator.
    noop = module.build_payload(stage, checks_for(stage, {module.BEHAVIOR_CHECK[stage]}), False, False)
    assert noop['reward'] == 0.0
    assert noop['binary_reward'] == 0
    assert noop['training_score'] == 0.0
    assert noop['deterministic_numerator'] == 0.0
    assert noop['agent_contributed'] == 0.0

    # F02: missing artifact is NOT a pass → official reward is a hard 0.0, but the
    # deterministic/training numerator retains partial credit for real work done.
    missing_artifact = module.build_payload(
        stage, checks_for(stage, {module.ARTIFACT_CHECK[stage]}), False, True
    )
    assert missing_artifact['reward'] == 0.0
    assert missing_artifact['binary_reward'] == 0
    assert missing_artifact['valid_trial'] == 1
    assert missing_artifact['training_score'] > 0.0

    integrity_failure = module.build_payload(
        stage, checks_for(stage, {module.INTEGRITY_CHECK[stage]}), False, True
    )
    assert integrity_failure['reward'] == 0.0
    assert integrity_failure['valid_trial'] == 0
    assert integrity_failure['training_score'] == 0.0

    infrastructure_failure = module.build_payload(stage, checks_for(stage), True, True)
    assert infrastructure_failure['reward'] == 0.0
    assert infrastructure_failure['valid_trial'] == 0

# Canonical reward.json schema (F09): every field the platform consumes is a
# numeric scalar; no null lambda/N fields that could break result parsing.
_sample = module.build_payload('core', checks_for('core'), False, True)
for _field in ('deterministic_numerator', 'deterministic_denominator',
               'non_deterministic_score_applicable', 'non_deterministic_numerator',
               'non_deterministic_denominator', 'training_score_lambda', 'agent_contributed'):
    assert isinstance(_sample[_field], (int, float)), _field

print('verifier contract self-check passed')


# --- Harbor reward-schema guard -------------------------------------------
# Harbor parses reward.json into VerifierResult.rewards, whose pydantic model
# accepts float/int ONLY. A null in any reward field aborts the step with
# "ValidationError: Input should be a valid number ... input_value=None" and the
# run ends as EXCEPTION with no verifier result. A previous revision emitted
# null for the Oracle's judge fields to express "N/A" and broke the Oracle that
# way, so this invariant is enforced mechanically.
_src = STAGE_CHECK.read_text(encoding='utf-8')
assert '_opt(' not in _src, 'reward fields must not use a null-preserving helper'
assert 'None if is_oracle' not in _src, 'reward fields must never be null, even for Oracle'

_REWARD_FIELDS = (
    'reward', 'binary_reward', 'valid_trial', 'stage_complete',
    'deterministic_score', 'deterministic_numerator', 'deterministic_denominator',
    'non_deterministic_score_applicable', 'non_deterministic_score',
    'non_deterministic_numerator', 'non_deterministic_denominator',
    'training_score_lambda', 'training_score', 'agent_contributed',
)
# The full breakdown must still be produced (for reward-details.json), and every
# one of those fields must be numeric so nothing can emit a null.
for _field in _REWARD_FIELDS:
    assert f"'{_field}':" in _src, f'{_field} must still be computed in the payload'

# The canonical SCORED file publishes only the authoritative reward: the platform
# averages every key it finds there, so a full breakdown made a perfect Oracle
# display as 0.64 and a correct zero no-op as 0.14.
assert "json.dumps({'reward': float(payload['reward'])}" in _src, (
    'reward.json must publish only the authoritative reward'
)

# A CTRF test report must be emitted or the platform reports
# "Unable to parse test results" and marks correct stages FAILED.
assert "'reportFormat': 'CTRF'" in _src, 'verifier must emit a CTRF test report'
assert 'import time' in _src, 'CTRF timestamps require the time module'

print('harbor reward-schema guard passed')
