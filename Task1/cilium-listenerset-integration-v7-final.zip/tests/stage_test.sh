#!/usr/bin/env bash
set -uo pipefail

stage="${1:?stage name required}"
RESULT_DIR="${RESULT_DIR:-/logs/verifier}"
mkdir -p "$RESULT_DIR"

python3 /tests/stage_check.py "$stage" > "$RESULT_DIR/test_output.log" 2>&1
python3 /tests/fallback_reward.py "$RESULT_DIR" "$stage"

git -C /testbed diff --binary > "$RESULT_DIR/patch.diff" 2>/dev/null || true
{
  git -C /testbed diff --name-only
  git -C /testbed diff --cached --name-only
  git -C /testbed ls-files --others --exclude-standard
  git -C /testbed ls-files --deleted
} | sort -u > "$RESULT_DIR/changed_files.txt" 2>/dev/null || true
cp -a /app/output "$RESULT_DIR/agent_output" 2>/dev/null || true

TASK_FAMILY="cilium-listenerset-integration" TASK_STAGE="$stage" \
  python3 /tests/stage_judge_inputs.py || true

if [ -f /logs/agent/oracle.txt ]; then
  printf '%s\n' '{"available":false,"applicable":false,"reason":"oracle run; non-deterministic reward is not applicable","binary_reward_affected":false}' > "$RESULT_DIR/judge_status.json"
elif [ "${RUN_LLM_JUDGES:-0}" = "1" ]; then
  TASK_STAGE="$stage" bash /tests/run_optional_judges.sh "$RESULT_DIR" || true
fi

exit 0
