#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from typing import Any

from verifier_lib import (
    LOGDIR,
    OUTPUT,
    TESTBED,
    base_tree_matches,
    production_tree_unchanged,
    root_commit,
    run_command,
    run_go_suite,
    run_single_go_test,
    scan_trajectory_integrity,
    validate_artifact,
    verify_binary_integrity,
)

CHECK_SPECS: dict[str, dict[str, float]] = {
    'diagnose': {
        'independent_base_probe': 0.60,
        'production_source_unchanged': 0.20,
        'diagnosis_artifact': 0.10,
        'trajectory_integrity': 0.10,
    },
    'core': {
        'listener_set_behavior': 0.60,
        'implementation_artifact': 0.15,
        'repository_integrity': 0.15,
        'trajectory_integrity': 0.10,
    },
    'review': {
        'review_gap_behavior': 0.60,
        'review_artifact': 0.15,
        'cumulative_integrity': 0.15,
        'trajectory_integrity': 0.10,
    },
    'harden': {
        'failure_atomicity_behavior': 0.65,
        'final_artifact': 0.10,
        'cumulative_integrity': 0.15,
        'trajectory_integrity': 0.10,
    },
}

BEHAVIOR_CHECK = {
    'diagnose': 'independent_base_probe',
    'core': 'listener_set_behavior',
    'review': 'review_gap_behavior',
    'harden': 'failure_atomicity_behavior',
}
ARTIFACT_CHECK = {
    'diagnose': 'diagnosis_artifact',
    'core': 'implementation_artifact',
    'review': 'review_artifact',
    'harden': 'final_artifact',
}
INTEGRITY_CHECK = {
    'diagnose': 'production_source_unchanged',
    'core': 'repository_integrity',
    'review': 'cumulative_integrity',
    'harden': 'cumulative_integrity',
}

STAGE2_FILES = {
    'stage2_gateway_harness_test.go': 'operator/pkg/gateway-api/verifier_stage2_harness_test.go',
    'stage2_behavior_test.go': 'operator/pkg/gateway-api/verifier_stage2_behavior_test.go',
}
STAGE2_TESTS = {
    'TestVerifierStage2ListenerSetBaselineReconciles',
    'TestVerifierStage2AllowedListenersPolicies',
    'TestVerifierStage2AllRouteKindsAttachToListenerSet',
    'TestVerifierStage2ReconcileReflectsListenerSetAndRouteChanges',
    'TestVerifierStage2ReferencedSecretStateIsReconciled',
    'TestVerifierStage2ListenerSetCannotValidateInvalidGateway',
}
STAGE3_FILES = {
    **STAGE2_FILES,
    'stage3_behavior_test.go': 'operator/pkg/gateway-api/verifier_stage3_behavior_test.go',
    'stage3_watch_event_test.go': 'operator/pkg/gateway-api/watch-handlers/verifier_stage3_watch_event_test.go',
}
STAGE3_TESTS = STAGE2_TESTS | {
    'TestVerifierStage3ListenerSetOnlyHostnameReachesConfiguration',
    'TestVerifierStage3SameNameGatewayAndListenerSetRemainDistinct',
    'TestVerifierStage3SectionAndPortApplyToEveryRouteKind',
    'TestVerifierStage3SectionNameAppliesToEveryRouteKind',
    'TestVerifierStage3NamespaceLabelTransitionsRequeueGateway',
    'TestVerifierStage3DisallowedListenerSetRouteHasNegativeStatus',
}
STAGE4_FILES = {
    **STAGE3_FILES,
    'stage4_gateway_fault_test.go': 'operator/pkg/gateway-api/verifier_stage4_fault_test.go',
}
STAGE4_TESTS = STAGE3_TESTS | {
    'TestVerifierStage4RouteRetrievalFailuresAreAtomicAndRecover',
    'TestVerifierStage4LateFailureWithMultipleListenerSetsIsAtomic',
}


def check_repository_integrity(stage: str) -> tuple[bool, dict[str, Any], bool]:
    errors: list[str] = []
    evidence: dict[str, Any] = {}

    binary_ok, binary_ev = verify_binary_integrity()
    evidence['binary_integrity'] = binary_ev
    if not binary_ok:
        errors.append('critical toolchain binaries have been tampered with')

    try:
        root = root_commit()
    except Exception as exc:
        return False, {'errors': [str(exc), *errors]}, True

    base_ok, base_ev = base_tree_matches(root)
    evidence['root_commit'] = root
    evidence['base_tree'] = base_ev
    manifest_missing = not bool(base_ev.get('manifest_present'))
    if not base_ok:
        errors.append('immutable base tree does not match verifier manifest')

    commands = {
        'tracked': run_command(
            ['git', 'diff', '--no-ext-diff', '--name-only', root, '--', '.'],
            timeout=120,
            log_name=f'{stage}_changed_tracked',
        ),
        'untracked': run_command(
            ['git', 'ls-files', '--others', '--exclude-standard'],
            timeout=120,
            log_name=f'{stage}_changed_untracked',
        ),
        'diff_check': run_command(
            ['git', 'diff', '--no-ext-diff', '--check', root, '--', '.'],
            timeout=120,
            log_name=f'{stage}_diff_check',
        ),
        'replace_refs': run_command(
            ['git', 'for-each-ref', '--format=%(refname)', 'refs/replace'], timeout=30
        ),
        'remotes': run_command(['git', 'remote'], timeout=30),
        'tags': run_command(['git', 'tag', '--list'], timeout=30),
        'local_config': run_command(
            ['git', 'config', '--local', '--name-only', '--list'], timeout=30
        ),
        'index_flags': run_command(['git', 'ls-files', '-v'], timeout=120),
    }
    infra = manifest_missing or any(result.infrastructure_failure for result in commands.values())

    changed_text = commands['tracked'].stdout + '\n' + commands['untracked'].stdout
    changed = sorted({line.strip() for line in changed_text.splitlines() if line.strip()})
    evidence.update({
        'changed_files': changed,
        'diff_check_returncode': commands['diff_check'].returncode,
        # Whitespace / conflict-marker cleanliness is recorded as a merge-readiness
        # signal only; it is NOT a hard integrity gate (see below).
        'whitespace_clean': commands['diff_check'].returncode == 0,
        'replace_refs': commands['replace_refs'].stdout.splitlines(),
        'remotes': commands['remotes'].stdout.splitlines(),
        'tags': commands['tags'].stdout.splitlines(),
        'local_config': commands['local_config'].stdout.splitlines(),
    })

    # `git diff --check` (trailing-whitespace / conflict markers) is deliberately
    # EXCLUDED from the integrity-failing set: a stray whitespace is a code-quality
    # / merge-readiness issue, not tampering, and must not zero valid_trial or
    # classify a genuine implementation as an integrity violation. It is retained
    # above as recorded evidence (whitespace_clean). Only a real failure to read
    # the candidate diff (tracked/untracked enumeration) blocks integrity here.
    if any(commands[name].returncode != 0 for name in ('tracked', 'untracked')):
        errors.append('unable to validate the complete candidate diff')
    if any(commands[name].returncode != 0 for name in ('replace_refs', 'remotes', 'tags', 'local_config', 'index_flags')):
        errors.append('unable to validate sanitized Git metadata')
    if commands['replace_refs'].stdout.strip() or (TESTBED / '.git/info/grafts').exists():
        errors.append('Git replacement or graft state is forbidden')
    if commands['remotes'].stdout.strip() or commands['tags'].stdout.strip():
        errors.append('sanitized repository must not gain remotes or tags')

    dangerous_config_prefixes = (
        'alias.', 'diff.', 'filter.', 'include.', 'includeif.',
    )
    dangerous_config_keys = {
        'core.attributesfile', 'core.excludesfile', 'core.fsmonitor',
        'core.sparsecheckout', 'core.sparsecheckoutcone',
        'extensions.worktreeconfig',
    }
    local_config = {
        line.strip().lower() for line in commands['local_config'].stdout.splitlines()
        if line.strip()
    }
    dangerous_config = sorted(
        key for key in local_config
        if key in dangerous_config_keys or key.startswith(dangerous_config_prefixes)
    )
    if dangerous_config:
        errors.append('repository-local Git configuration may not alter verifier behavior')

    index_flag_violations = sorted(
        line for line in commands['index_flags'].stdout.splitlines()
        if line and (line[0].islower() or line[0] == 'S')
    )
    if index_flag_violations:
        errors.append('assume-unchanged and skip-worktree index flags are forbidden')

    git_dir = TESTBED / '.git'
    git_metadata_violations: list[str] = []
    if git_dir.is_symlink() or not git_dir.is_dir():
        git_metadata_violations.append('.git must be a real directory')
    for relative in (
        'info/grafts', 'info/attributes', 'info/sparse-checkout',
        'objects/info/alternates', 'commondir', 'shallow',
    ):
        if (git_dir / relative).exists() or (git_dir / relative).is_symlink():
            git_metadata_violations.append(relative)
    if git_metadata_violations:
        errors.append('unsupported mutable Git metadata is present')

    evidence['dangerous_local_config'] = dangerous_config
    evidence['index_flag_violations'] = index_flag_violations
    evidence['git_metadata_violations'] = git_metadata_violations

    forbidden: list[str] = []
    escaped_links: list[str] = []
    linked_files: list[str] = []
    testbed_real = TESTBED.resolve()
    for relative in changed:
        parts = Path(relative).parts
        name = Path(relative).name
        if (
            (parts and parts[0] in {'tests', 'solution'})
            or name.startswith('reward')
            or name.startswith('oracle_upstream_private')
            or name.startswith('verifier_stage')
        ):
            forbidden.append(relative)
        path = TESTBED / relative
        if path.is_symlink():
            try:
                path.resolve(strict=False).relative_to(testbed_real)
            except ValueError:
                escaped_links.append(relative)
        elif path.exists() and path.is_file():
            try:
                if path.stat().st_nlink != 1:
                    linked_files.append(relative)
            except OSError:
                linked_files.append(relative)

    if forbidden:
        errors.append('candidate changed protected or verifier-like paths')
    if escaped_links:
        errors.append('changed symlinks escape the repository')
    if linked_files:
        errors.append('changed files must not be hard linked')
    evidence['forbidden_paths'] = sorted(forbidden)
    evidence['escaped_symlinks'] = sorted(escaped_links)
    evidence['hard_linked_files'] = sorted(linked_files)
    evidence['errors'] = errors
    return not errors, evidence, infra


def check_stage1_probe() -> tuple[bool, dict[str, Any], bool]:
    return run_single_go_test(
        stage='diagnose',
        source_name='stage1_base_behavior_test.go',
        destination='operator/pkg/gateway-api/verifier_stage1_base_test.go',
        package='./operator/pkg/gateway-api',
        expected_test='TestVerifierStage1BaseLacksListenerSetControllerIntegration',
        timeout=1200,
    )


OBSERVATION_MARKER = '##OBSERVATION##'


def parse_reproducer_observation(stdout: str) -> tuple[dict[str, Any], list[str]]:
    """F01: the submitted reproducer must PROVE the missing behavior itself.

    It must emit, on stdout, a typed observation line the verifier independently
    parses. A canned/no-op script that merely exits zero produces no marker and
    is rejected. The required values encode the actual base limitation: the
    ListenerSet API type is recognized, yet its status is never reconciled and no
    ListenerSet-derived configuration is produced.
    """
    lines = [ln for ln in stdout.splitlines() if OBSERVATION_MARKER in ln]
    if not lines:
        return {}, ['reproducer did not emit an ' + OBSERVATION_MARKER + ' proof line; '
                    'an exit-zero or canned script cannot demonstrate the missing behavior']
    raw = lines[-1].split(OBSERVATION_MARKER, 1)[1].strip()
    try:
        obs = json.loads(raw)
    except Exception as exc:
        return {}, [f'reproducer observation is not valid JSON: {exc}']
    if not isinstance(obs, dict):
        return {}, ['reproducer observation must be a JSON object']
    errors: list[str] = []
    required = {
        'listenerset_recognized': True,
        'listenerset_status_reconciled': False,
        'listenerset_config_present': False,
    }
    for key, want in required.items():
        if obs.get(key) is not want:
            errors.append(f'observation must show {key}={str(want).lower()} (the reproduced base limitation)')
    return obs, errors


def _production_changed(changed: Any) -> bool:
    """True iff the agent changed at least one production source file.

    Used to zero the training numerator for a no-op submission at the
    implementation stages (a clean no-op contributes nothing).
    """
    for rel in changed or []:
        if not isinstance(rel, str) or not rel.strip():
            continue
        parts = Path(rel).parts
        name = Path(rel).name
        if parts and parts[0] in {'tests', 'solution'}:
            continue
        if name.endswith('_test.go'):
            continue
        if name.startswith('reward') or name.startswith('verifier_stage') or name.startswith('oracle_upstream_private'):
            continue
        return True
    return False


def check_candidate_reproducer() -> tuple[bool, dict[str, Any], bool]:
    try:
        data = json.loads((OUTPUT / 'handoff.json').read_text(encoding='utf-8'))
        submitted = data.get('reproducer_path', '')
    except Exception as exc:
        return False, {'errors': [str(exc)]}, False

    path = Path(submitted)
    allowed_root = OUTPUT / '01-diagnose'
    try:
        resolved = path.resolve(strict=True)
        resolved.relative_to(allowed_root.resolve())
    except (OSError, ValueError):
        return False, {
            'errors': ['reproducer_path must resolve to an existing file under /app/output/01-diagnose']
        }, False
    if path.is_symlink() or not resolved.is_file() or not os.access(resolved, os.X_OK):
        return False, {'errors': ['reproducer must be an executable regular file, not a symlink']}, False
    if resolved.stat().st_nlink != 1:
        return False, {'errors': ['reproducer must not be a hard link']}, False

    before, before_ev, before_infra = production_tree_unchanged()
    if not before:
        return False, {
            'errors': ['production tree was already modified before reproducer execution'],
            'tree': before_ev,
        }, before_infra

    result = run_command(
        [str(resolved)], timeout=1200, log_name='diagnose_candidate_reproducer'
    )
    after, after_ev, after_infra = production_tree_unchanged()
    observation, obs_errors = parse_reproducer_observation(result.stdout)
    ok = result.returncode == 0 and after and not obs_errors
    errors: list[str] = list(obs_errors)
    if result.returncode != 0:
        errors.append(f'reproducer exited non-zero ({result.returncode})')
    if not after:
        errors.append('reproducer left production source changed')
    return ok, {
        'returncode': result.returncode,
        'tree_after': after_ev,
        'observation': observation,
        'errors': errors,
        'log': str(LOGDIR / 'diagnose_candidate_reproducer.log'),
    }, result.infrastructure_failure or after_infra


def evaluate(stage: str) -> tuple[list[dict[str, Any]], bool, bool]:
    checks: list[dict[str, Any]] = []
    infra_seen = False
    contributed = False

    def add(
        check_id: str,
        result: tuple[bool, dict[str, Any], bool] | tuple[bool, dict[str, Any]],
    ) -> None:
        nonlocal infra_seen
        if len(result) == 2:
            passed, evidence = result
            infra = False
        else:
            passed, evidence, infra = result
        infra_seen = infra_seen or infra
        checks.append({
            'check_id': check_id,
            'weight': CHECK_SPECS[stage][check_id],
            'passed': bool(passed),
            'evidence': evidence,
        })

    if stage == 'diagnose':
        probe_ok, probe_ev, probe_infra = check_stage1_probe()
        repro_ok, repro_ev, repro_infra = check_candidate_reproducer()
        add('independent_base_probe', (
            probe_ok and repro_ok,
            {'independent_probe': probe_ev, 'candidate_reproducer': repro_ev},
            probe_infra or repro_infra,
        ))
        add('production_source_unchanged', production_tree_unchanged())
        add('diagnosis_artifact', validate_artifact('diagnose'))
        # Contribution at Diagnose is a genuine reproducer that proves the gap;
        # a no-op earns no training numerator.
        contributed = bool(repro_ok)
    elif stage == 'core':
        add('listener_set_behavior', run_go_suite(
            stage='core', mapping=STAGE2_FILES, expected_tests=STAGE2_TESTS, timeout=3300
        ))
        add('implementation_artifact', validate_artifact('core'))
        integ = check_repository_integrity('core')
        add('repository_integrity', integ)
        contributed = _production_changed(integ[1].get('changed_files'))
    elif stage == 'review':
        add('review_gap_behavior', run_go_suite(
            stage='review', mapping=STAGE3_FILES, expected_tests=STAGE3_TESTS, timeout=5000
        ))
        add('review_artifact', validate_artifact('review'))
        integ = check_repository_integrity('review')
        add('cumulative_integrity', integ)
        contributed = _production_changed(integ[1].get('changed_files'))
    else:
        add('failure_atomicity_behavior', run_go_suite(
            stage='harden', mapping=STAGE4_FILES, expected_tests=STAGE4_TESTS, timeout=6800
        ))
        add('final_artifact', validate_artifact('harden'))
        integ = check_repository_integrity('harden')
        add('cumulative_integrity', integ)
        contributed = _production_changed(integ[1].get('changed_files'))

    traj_ok, traj_ev = scan_trajectory_integrity()
    add('trajectory_integrity', (traj_ok, traj_ev))
    return checks, infra_seen, contributed


def write_result(payload: dict[str, Any], stage: str) -> None:
    import hashlib
    LOGDIR.mkdir(parents=True, exist_ok=True)
    detailed = LOGDIR / f'{stage}_result.json'
    canonical = LOGDIR / 'reward.json'
    detailed.write_text(json.dumps(payload, indent=2) + '\n', encoding='utf-8')
    # Canonical schema (F09): official binary reward plus the full deterministic /
    # non-deterministic numerator/denominator breakdown and the configured lambda.
    #
    # EVERY field in this file must be a numeric scalar. Harbor parses it into
    # `VerifierResult.rewards`, whose pydantic model accepts only float/int -- a
    # null here aborts the whole step with
    # "ValidationError: Input should be a valid number ... input_value=None"
    # and produces an EXCEPTION with no verifier result at all. An earlier
    # revision emitted null for the Oracle's judge fields to express "N/A" and
    # broke the Oracle exactly that way.
    #
    # Oracle N/A is therefore expressed numerically and out-of-band, not by null:
    #   - `non_deterministic_score_applicable = 0.0` is the machine-readable
    #     "no judge applies" signal, so a 0.0 score cannot be misread as "the
    #     judge scored zero";
    #   - `judge_status.json` records {"applicable": false, "available": false,
    #     "reason": "oracle run; ..."} for the human/reviewer record.
    # Canonical scored surface: ONLY the authoritative binary reward.
    #
    # The platform treats every key in this file as a scored metric and displays
    # their MEAN as the run's reward. With the full 14-field breakdown published
    # here, a perfect Oracle (9 of 14 keys equal to 1) was shown as 0.64 and a
    # correct zero-scoring no-op (2 of 14) as 0.14, neither of which is the
    # actual reward. Diagnostics therefore live in reward-details.json /
    # reward-events.json, which are not part of the scored surface.
    canonical.write_text(
        json.dumps({'reward': float(payload['reward'])}, indent=2, sort_keys=True) + '\n',
        encoding='utf-8',
    )

    events = []
    for i, check in enumerate(payload.get('checks', []), 1):
        events.append({
            'sequence': i,
            'stage': stage,
            'check': check['check_id'],
            'passed': check['passed'],
            'weight': check['weight'],
            'critical': check['check_id'] in (
                BEHAVIOR_CHECK.get(stage, ''),
                ARTIFACT_CHECK.get(stage, ''),
                INTEGRITY_CHECK.get(stage, ''),
                'trajectory_integrity',
            ),
            'failure_reasons': check.get('evidence', {}).get('errors', []) if not check['passed'] else [],
        })
    (LOGDIR / 'reward-events.json').write_text(json.dumps(events, indent=2, sort_keys=True) + '\n', encoding='utf-8')

    details = {
        'stage': stage,
        'checks': {
            check['check_id']: {
                'passed': check['passed'],
                'weight': check['weight'],
                'detail': check.get('evidence', {}),
            }
            for check in payload.get('checks', [])
        },
        'completion_state': payload.get('completion_state', 'unknown'),
    }
    (LOGDIR / 'reward-details.json').write_text(json.dumps(details, indent=2, sort_keys=True) + '\n', encoding='utf-8')

    # CTRF test report. The platform parses a standard test-report artifact to
    # populate per-test results; without one it shows "Unable to parse test
    # results / No individual test results recorded" and marks otherwise-correct
    # stages FAILED. Each deterministic check is reported as one test case, so a
    # reviewer sees exactly which check decided the stage.
    _now_ms = int(time.time() * 1000)
    _ctrf_tests = [
        {
            'name': f"{stage}.{check['check_id']}",
            'status': 'passed' if check['passed'] else 'failed',
            'duration': 0,
            'suite': stage,
            'extra': {'weight': check['weight']},
        }
        for check in payload.get('checks', [])
    ]
    _ctrf = {
        'reportFormat': 'CTRF',
        'specVersion': '0.0.0',
        'results': {
            'tool': {'name': 'cilium-listenerset-integration-verifier'},
            'summary': {
                'tests': len(_ctrf_tests),
                'passed': sum(1 for t in _ctrf_tests if t['status'] == 'passed'),
                'failed': sum(1 for t in _ctrf_tests if t['status'] == 'failed'),
                'pending': 0,
                'skipped': 0,
                'other': 0,
                'start': _now_ms,
                'stop': _now_ms,
            },
            'tests': _ctrf_tests,
        },
    }
    for _name in ('ctrf.json', 'test-results.json', 'ctrf-report.json'):
        (LOGDIR / _name).write_text(
            json.dumps(_ctrf, indent=2, sort_keys=True) + '\n', encoding='utf-8'
        )

    (LOGDIR / 'reward.txt').write_text(
        f"stage={stage} reward={payload['reward']:.4f} binary={payload['binary_reward']} "
        f"training={payload['training_score']:.4f} valid={payload['valid_trial']}\n",
        encoding='utf-8',
    )

    def _sha256(path):
        return hashlib.sha256(path.read_bytes()).hexdigest()

    artifacts = {}
    for name in ('reward.json', 'reward-events.json', 'reward-details.json', 'reward.txt'):
        p = LOGDIR / name
        if p.is_file():
            artifacts[name] = {'sha256': _sha256(p), 'bytes': p.stat().st_size}
    manifest = {
        'schema_version': '1.0',
        'task_family': 'cilium-listenerset-integration',
        'stage': stage,
        'valid_trial': float(payload['valid_trial']),
        'stage_complete': 1.0 if payload.get('binary_reward') == 1 else 0.0,
        'artifacts': artifacts,
    }
    (LOGDIR / 'training_export_manifest.json').write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + '\n', encoding='utf-8'
    )


def build_payload(stage: str, checks: list[dict[str, Any]], infra_seen: bool,
                  contributed: bool) -> dict[str, Any]:
    by_id = {check['check_id']: check for check in checks}
    raw_reward = round(sum(check['weight'] for check in checks if check['passed']), 6)
    d_den = round(sum(check['weight'] for check in checks), 6) or 1.0

    behavior_ok = bool(by_id[BEHAVIOR_CHECK[stage]]['passed'])
    artifact_ok = bool(by_id[ARTIFACT_CHECK[stage]]['passed'])
    integrity_ok = bool(by_id[INTEGRITY_CHECK[stage]]['passed'])
    trajectory_ok = bool(by_id.get('trajectory_integrity', {}).get('passed', True))
    all_pass = behavior_ok and artifact_ok and integrity_ok and trajectory_ok and not infra_seen

    is_oracle = Path('/logs/agent/oracle.txt').is_file()
    contributed = bool(contributed or is_oracle)

    if infra_seen or not integrity_ok or not trajectory_ok:
        valid_trial = 0
        d_num = 0.0
        if infra_seen:
            completion_state = 'infrastructure_failure'
        elif not trajectory_ok:
            completion_state = 'trajectory_integrity_failure'
        else:
            completion_state = 'integrity_failure'
    else:
        valid_trial = 1
        # A clean no-op earns zero deterministic numerator (F02): partial credit
        # requires the agent to have actually contributed the stage's evidence/work.
        d_num = raw_reward if contributed else 0.0
        completion_state = 'passed' if all_pass else 'failed'

    # Official reward is strictly binary (F02): 1.0 only on a valid all-required
    # pass, 0.0 otherwise. Partial progress lives only in deterministic/training.
    reward = 1.0 if (all_pass and valid_trial == 1) else 0.0
    d_score = round(d_num / d_den, 6) if d_den else 0.0
    # Deterministic-only training here; run_optional_judges.sh applies the guide's
    # (D_num + lambda*N_num)/(D_den + lambda*N_den) blend when judges are enabled.
    training_score = d_score

    return {
        'stage': stage,
        'reward': reward,
        'binary_reward': 1 if all_pass else 0,
        'valid_trial': valid_trial,
        'stage_complete': 1.0 if all_pass else 0.0,
        'deterministic_score': d_score,
        'deterministic_numerator': d_num,
        'deterministic_denominator': d_den,
        # F09 / Oracle N/A: expressed numerically, NOT as null. Harbor validates
        # this payload into VerifierResult.rewards (pydantic float/int only), so
        # a null aborts the step with a ValidationError and yields an EXCEPTION
        # with no verifier result -- which is exactly what a previous revision
        # did to the Oracle. `non_deterministic_score_applicable = 0.0` is the
        # machine-readable "no judge applies" signal that keeps a 0.0 score from
        # being misread as a real judge verdict, and judge_status.json carries
        # the explicit {"applicable": false} record for reviewers.
        'non_deterministic_score_applicable': 0.0,
        'non_deterministic_score': 0.0,
        'non_deterministic_numerator': 0.0,
        'non_deterministic_denominator': 0.0,
        'training_score_lambda': 0.0,
        'training_score': training_score,
        'agent_contributed': 1.0 if contributed else 0.0,
        'completion_state': completion_state,
        'checks': checks,
    }


def run(stage: str) -> int:
    if stage not in CHECK_SPECS:
        raise ValueError(f'unknown stage: {stage}')
    LOGDIR.mkdir(parents=True, exist_ok=True)
    checks, infra_seen, contributed = evaluate(stage)
    payload = build_payload(stage, checks, infra_seen, contributed)
    write_result(payload, stage)
    print(json.dumps(payload, indent=2))
    return 0 if payload['binary_reward'] == 1 else 2


def invalid_result(stage: str, error: str) -> dict[str, Any]:
    return {
        'stage': stage,
        'reward': 0.0,
        'binary_reward': 0,
        'valid_trial': 0,
        'stage_complete': 0.0,
        'deterministic_score': 0.0,
        'deterministic_numerator': 0.0,
        'deterministic_denominator': 1.0,
        'non_deterministic_score_applicable': 0.0,
        'non_deterministic_score': 0.0,
        'non_deterministic_numerator': 0.0,
        'non_deterministic_denominator': 0.0,
        'training_score_lambda': 0.0,
        'training_score': 0.0,
        'agent_contributed': 0.0,
        'completion_state': 'verifier_error',
        'checks': [],
        'error': error,
    }


if __name__ == '__main__':
    stage = sys.argv[1] if len(sys.argv) == 2 else 'unknown'
    try:
        exit_code = run(stage)
    except Exception as exc:
        payload = invalid_result(stage, repr(exc))
        write_result(payload, stage)
        print(json.dumps(payload, indent=2))
        exit_code = 2
    raise SystemExit(exit_code)
