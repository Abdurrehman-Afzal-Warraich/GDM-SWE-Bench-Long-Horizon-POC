#!/usr/bin/env bash
set -uo pipefail

RESULT_DIR="${1:-${RESULT_DIR:-/logs/verifier}}"
TESTS_DIR="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SUITE_DIR="$RESULT_DIR/judge_suite"
RUNS_DIR="$RESULT_DIR/judge_runs"
STATUS_FILE="$RESULT_DIR/judge_status.json"
WORKSPACE="${JUDGE_WORKSPACE:-/testbed}"
STAGE="${TASK_STAGE:-unknown}"
[ -d "$WORKSPACE" ] || {
  WORKSPACE="/tmp/repo-engineering-judge-workspace"
  mkdir -p "$WORKSPACE"
}

write_status() {
  local reason="$1"
  python3 -S - "$STATUS_FILE" "$reason" "$STAGE" <<'PY'
import hashlib, json, sys
from pathlib import Path
Path(sys.argv[1]).write_text(json.dumps({
    "available": False,
    "stage": sys.argv[3],
    "reason": sys.argv[2],
    "binary_reward_affected": False,
}, indent=2, sort_keys=True) + "\n", encoding="utf-8")
PY
}

[ -f "$RESULT_DIR/judge_inputs/trajectory.json" ] || {
  write_status "trajectory unavailable; semantic review was not run"
  exit 0
}
[ -f "$RESULT_DIR/judge_inputs/instruction.md" ] || {
  write_status "stage instruction unavailable; semantic review was not run"
  exit 0
}
[ -n "${GEMINI_API_KEY:-}" ] || {
  write_status "GEMINI_API_KEY unavailable; semantic review was not run"
  exit 0
}
command -v rewardkit >/dev/null 2>&1 || {
  write_status "rewardkit unavailable; semantic review was not run"
  exit 0
}

repeats="${JUDGE_REPEATS:-2}"
case "$repeats" in
  ''|*[!0-9]*) repeats=2 ;;
esac
[ "$repeats" -ge 1 ] || repeats=1
[ "$repeats" -le 3 ] || repeats=3

timeout_sec="${JUDGE_TIMEOUT_SEC:-300}"
case "$timeout_sec" in
  ''|*[!0-9]*) timeout_sec=300 ;;
esac
[ "$timeout_sec" -ge 30 ] || timeout_sec=30
[ "$timeout_sec" -le 900 ] || timeout_sec=900

# Stage-aware dimension selection:
#   - process and validity run at every stage.
#   - task_quality runs at diagnosis, at final hardening, and at any
#     intermediate stage whose deterministic binary_reward is below 1.0.
#   - merge_readiness runs only at final hardening.
dimensions=(process validity)
case "$STAGE" in
  01-diagnose|diagnose) dimensions+=(task_quality) ;;
  04-failure-hardening|harden) dimensions+=(merge_readiness task_quality) ;;
  *)
    deterministic_failed="$(python3 -S - "$RESULT_DIR/reward.json" <<'PY'
import json, sys
try:
    reward = json.load(open(sys.argv[1], encoding="utf-8"))
    print("1" if float(reward.get("binary_reward", 0.0) or 0.0) < 1.0 else "0")
except Exception:
    print("1")
PY
)"
    [ "$deterministic_failed" = "1" ] && dimensions+=(task_quality)
    ;;
esac

rm -rf "$SUITE_DIR" "$RUNS_DIR"
mkdir -p "$SUITE_DIR" "$RUNS_DIR"
cp "$TESTS_DIR/judge_prompt.md" "$SUITE_DIR/judge_prompt.md"
for dimension in "${dimensions[@]}"; do
  mkdir -p "$SUITE_DIR/$dimension"
  cp "$TESTS_DIR/$dimension/judge.toml" "$SUITE_DIR/$dimension/judge.toml"
done

successful=0
for index in $(seq 1 "$repeats"); do
  run_dir="$RUNS_DIR/repeat-$index"
  mkdir -p "$run_dir"
  if timeout --signal=TERM --kill-after=15s "${timeout_sec}s" \
      rewardkit "$SUITE_DIR" --workspace "$WORKSPACE" --output "$run_dir/reward.json" \
      > "$run_dir/rewardkit.log" 2>&1; then
    successful=$((successful + 1))
  fi
done

[ "$successful" -gt 0 ] || {
  reason="all RewardKit judge calls failed; inspect judge_runs"
  if grep -Eqi 'name resolution|temporary failure|cannot connect|connection (refused|timed out)|network is unreachable' "$RUNS_DIR"/repeat-*/rewardkit.log 2>/dev/null; then
    reason="judge provider is unreachable; verify task allow_internet, Docker DNS, proxy, and firewall settings"
  elif grep -Eqi '401|403|unauthori[sz]ed|permission denied|invalid.*api.*key|api.*key.*invalid' "$RUNS_DIR"/repeat-*/rewardkit.log 2>/dev/null; then
    reason="judge provider rejected GEMINI_API_KEY; verify or rotate the key"
  elif grep -Eqi '404|model.*not found|unknown model|unsupported model' "$RUNS_DIR"/repeat-*/rewardkit.log 2>/dev/null; then
    reason="configured judge model is unavailable to this key or provider"
  elif grep -Eqi 'timed out|timeout|terminated' "$RUNS_DIR"/repeat-*/rewardkit.log 2>/dev/null; then
    reason="all RewardKit judge calls exceeded the bounded timeout"
  fi
  write_status "$reason"
  exit 0
}

selected="$(IFS=,; echo "${dimensions[*]}")"
python3 -S - "$RESULT_DIR" "$successful" "$repeats" "$STAGE" "$selected" <<'PY'
import hashlib, json, math, os, sys
from pathlib import Path

out = Path(sys.argv[1])

def load(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}

dimensions = ("process", "merge_readiness", "validity", "task_quality")
selected = tuple(item for item in sys.argv[5].split(",") if item)
values = {name: [] for name in dimensions}
successful_runs = []
for run in sorted((out / "judge_runs").glob("repeat-*")):
    payload = load(run / "reward.json")
    if not payload:
        continue
    successful_runs.append(run.name)
    for name in dimensions:
        value = payload.get(name)
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            values[name].append(max(0.0, min(1.0, float(value))))

averages = {name: round(sum(items) / len(items), 4) for name, items in values.items() if items}
spreads = {name: round(max(items) - min(items), 4) for name, items in values.items() if len(items) > 1}
reward_path = out / "reward.json"
reward = load(reward_path)
binary = float(reward.get("binary_reward", reward.get("reward", 0.0)) or 0.0)

# Deterministic breakdown from stage_check.py (F09 canonical schema).
d_num = float(reward.get("deterministic_numerator", reward.get("deterministic_score", 0.0)) or 0.0)
d_den = float(reward.get("deterministic_denominator", 1.0) or 1.0)
d_score = round(d_num / d_den, 6) if d_den else 0.0

# F05: read the lambda the task actually exports (NONDETERMINISTIC_LAMBDA).
try:
    parsed_lambda = float(os.environ.get("NONDETERMINISTIC_LAMBDA", os.environ.get("LAMBDA", "0")) or 0.0)
    lam = parsed_lambda if math.isfinite(parsed_lambda) and parsed_lambda >= 0.0 else 0.0
except ValueError:
    lam = 0.0

# Blend rubric = process + validity on eligible stages, plus merge_readiness only
# after a final valid deterministic pass. task_quality is author QC, never blended.
BLEND_WEIGHTS = {"process": 0.50, "validity": 0.25, "merge_readiness": 0.25}
process = averages.get("process", 0.0)
validity = averages.get("validity", 0.0)
merge = averages.get("merge_readiness", 0.0) if binary >= 1.0 else 0.0
merged = {"process": process, "validity": validity, "merge_readiness": merge}

applicable = [d for d in ("process", "validity") if d in selected]
if "merge_readiness" in selected and binary >= 1.0:
    applicable.append("merge_readiness")

# F05: blend only a COMPLETE judge set - every configured repeat succeeded and
# every applicable blend dimension is present. Otherwise mark N unavailable and
# fall back to the deterministic score.
complete = (int(sys.argv[2]) == int(sys.argv[3])) and bool(applicable) and all(d in averages for d in applicable)
n_den = sum(BLEND_WEIGHTS[d] for d in applicable)
n_num = sum(BLEND_WEIGHTS[d] * merged[d] for d in applicable)
n_score = round(n_num / n_den, 6) if n_den else 0.0

if complete and n_den:
    training = round((d_num + lam * n_num) / (d_den + lam * n_den), 6)
    nd_applicable = 1.0
else:
    training, n_num, n_den, n_score, nd_applicable = d_score, 0.0, 0.0, 0.0, 0.0

reward.update({
    "judge_available": 1.0,
    "training_score": training,
    "training_score_lambda": lam,
    "non_deterministic_score": n_score,
    "non_deterministic_numerator": n_num,
    "non_deterministic_denominator": n_den,
    "non_deterministic_score_applicable": nd_applicable,
    "process_judge": process,
    "process_judge_applicable": 1.0 if "process" in selected else 0.0,
    "merge_readiness_judge": merge,
    "merge_readiness_judge_applicable": 1.0 if ("merge_readiness" in selected and binary >= 1.0) else 0.0,
    "validity_review": validity,
    "validity_review_applicable": 1.0 if "validity" in selected else 0.0,
    "task_quality_audit": averages.get("task_quality", 0.0),
    "task_quality_audit_applicable": 1.0 if "task_quality" in selected else 0.0,
    "judge_disagreement": max(spreads.values(), default=0.0),
    "judge_set_complete": 1.0 if complete else 0.0,
})
reward.pop("research_score", None)
reward.pop("rubric_score", None)
if "merge_readiness" in selected and binary >= 1.0:
    reward["merge_ready_score"] = merge
else:
    reward.pop("merge_ready_score", None)
reward_path.write_text(json.dumps(reward, indent=2, sort_keys=True) + "\n", encoding="utf-8")

summary = {
    "available": True,
    "stage": sys.argv[4],
    "judge_model": os.environ.get("JUDGE_MODEL", "gemini/gemini-3.6-flash"),
    "selected_dimensions": selected,
    "attempted_runs": int(sys.argv[3]),
    "successful_run_count": int(sys.argv[2]),
    "successful_runs": successful_runs,
    "dimension_means": averages,
    "dimension_spreads": spreads,
    "judge_set_complete": bool(complete),
    "binary_reward_affected": False,
    "notes": [
        "process and validity run at every eligible stage; task_quality is author QC and is not blended",
        "merge readiness runs only at final hardening and is zero unless deterministic binary success holds",
        "an applicability value of zero means a judge dimension was not selected; it is not a failed review",
        "training_score = (D_num + NONDETERMINISTIC_LAMBDA * N_num) / (D_den + NONDETERMINISTIC_LAMBDA * N_den); blended only for a complete judge set, else training_score = deterministic_score",
    ],
}
(out / "judge_summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
(out / "judge_status.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")

manifest_path = out / "training_export_manifest.json"
manifest = load(manifest_path)
artifact_manifest = manifest.setdefault("artifacts", {})
for artifact_name in ("reward.json", "judge_summary.json", "judge_status.json"):
    artifact_path = out / artifact_name
    if artifact_path.is_file():
        artifact_manifest[artifact_name] = {
            "sha256": hashlib.sha256(artifact_path.read_bytes()).hexdigest(),
            "bytes": artifact_path.stat().st_size,
        }
manifest.update({
    "judge_available": True,
    "judge_model": summary["judge_model"],
    "judge_selected_dimensions": selected,
    "judge_dimension_means": averages,
    "judge_artifacts": ["judge_summary.json", "judge_runs/", "judge_inputs/"],
})
manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
PY

exit 0
