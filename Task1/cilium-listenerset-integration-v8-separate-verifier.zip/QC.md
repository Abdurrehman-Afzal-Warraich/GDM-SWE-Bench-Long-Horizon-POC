# QC / Author Notes — Cilium ListenerSet Task (author-only, not solver-facing)

This file holds grading-mechanism, Oracle-design, integrity, and calibration
material that must NOT live in the solver-facing `README.md`. It is package
documentation for authors/reviewers only.

## Oracle design

The upstream diff is generated during the image build, encrypted, and removed in
plaintext before the layer is committed. Only the protected Stage 2 solution key
can decrypt and apply it. Later Oracle stages apply deterministic corrections.
Each Oracle `solve.sh` creates `/logs/agent/oracle.txt` to signal the verifier to
skip RewardKit judges.

## Protected boundary

During the agent phase, `/tests/` and `/solution/` are not mounted; the agent sees
only `/testbed` (sanitized single-commit worktree). Hidden tests are verifier-owned
and are run against a frozen, verifier-reconstructed copy of the candidate state in
the separate verifier environment (see `metadata` in `task.toml`), never against a
live agent-writable tree. The Oracle private key lives only under
`steps/02-core-routing/solution/`, which is never mounted for agents.

## Scoring (grading internals)

- Weighted deterministic checks per stage (sum 1.0); behavioral Go tests dominate
  (0.60–0.65 weight).
- `trajectory_integrity` (0.10 weight) is supporting detective evidence over the
  agent command stream; the enforced boundary is the agent's no-network isolation.
- Binary integrity: SHA-256 checksums of go/git/python3 vs a verifier-owned manifest.
- Integrity failure (binary tamper, repository replacement, trajectory violation) →
  `valid_trial=0`, all scores zeroed.
- Official pass = every required check passed AND `valid_trial==1`; `reward`,
  `binary_reward` and `stage_complete` all derive from that single predicate.
- A clean no-op earns zero deterministic numerator.
- Diagnose, Core, and Review gate at `min_reward = 1.0`; Failure hardening is
  terminal and ungated.
- Whitespace / conflict-marker cleanliness (`git diff --check`) is recorded as a
  merge-readiness signal (`whitespace_clean`), NOT a hard integrity gate.

## Validation / calibration (author-only)

Run the package through Harbor's Oracle and no-op agents plus frontier and control
runs. Evaluation outcomes, timings, checksums, and control results are recorded in
author-side validation records, never in `README.md`.
