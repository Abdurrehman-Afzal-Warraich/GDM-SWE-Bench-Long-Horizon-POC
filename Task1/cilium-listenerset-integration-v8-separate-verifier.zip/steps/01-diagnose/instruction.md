# Stage 1: Diagnose Missing ListenerSet Integration

The repository is at `/testbed`. The ListenerSet API type is available at the supplied revision, but ListenerSets do not participate in Gateway reconciliation.

## Task

- Create an executable, deterministic reproducer under `/app/output/01-diagnose/`.
- Demonstrate one concrete missing behavior, such as absent ListenerSet status, attachment, or generated configuration.
- Capture the command result and raw output under `/app/output/01-diagnose/`.
- Identify the affected controller boundaries, impacted Route kinds, preserved behavior, and deferred work.
- Do not modify production source files.

Type registration alone is not evidence of controller integration. The verifier runs an independent behavioral probe **and re-runs your reproducer**; prose is supporting evidence only.

### Reproducer proof contract (required)

Your reproducer must itself prove the missing behavior — an executable that merely exits zero is rejected. When run, it must print, on stdout, a single typed observation line the verifier parses:

```
##OBSERVATION## {"listenerset_recognized": true, "listenerset_status_reconciled": false, "listenerset_config_present": false}
```

The three booleans must reflect what your reproducer actually observed against the base revision: the ListenerSet type is recognized, yet after reconciliation its status is untouched and no ListenerSet-derived configuration is produced. A reproducer that emits no such line, or whose values do not encode this base limitation, fails Stage 1.

## Output

Write identical core findings to `/app/output/handoff.json` and `/app/output/01-diagnose/diagnosis.json`:

```json
{
  "schema_version": 1,
  "stage": "01-diagnose",
  "base_limitation_reproduced": true,
  "production_source_unchanged": true,
  "resource_kind": "ListenerSet",
  "missing_behavior": "string",
  "observed_outcome": "string",
  "root_cause_boundaries": ["string"],
  "affected_route_types": ["HTTPRoute", "GRPCRoute", "TLSRoute", "TCPRoute", "UDPRoute"],
  "preserved_invariants": ["string"],
  "deferred_work": ["string"],
  "reproducer_path": "/app/output/01-diagnose/reproduce.sh",
  "evidence_files": ["absolute path"]
}
```
