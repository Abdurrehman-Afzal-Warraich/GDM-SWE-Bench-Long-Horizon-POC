// SPDX-License-Identifier: Apache-2.0
package gateway_api

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"regexp"
	"strings"
	"testing"

	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	ctrl "sigs.k8s.io/controller-runtime"
	"sigs.k8s.io/controller-runtime/pkg/client"
	gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"
	gatewayv1alpha2 "sigs.k8s.io/gateway-api/apis/v1alpha2"
)

func verifierRouteListKind(list client.ObjectList) string {
	switch list.(type) {
	case *gatewayv1.HTTPRouteList:
		return "HTTPRoute"
	case *gatewayv1.GRPCRouteList:
		return "GRPCRoute"
	case *gatewayv1.TLSRouteList:
		return "TLSRoute"
	case *gatewayv1alpha2.TCPRouteList:
		return "TCPRoute"
	case *gatewayv1alpha2.UDPRouteList:
		return "UDPRoute"
	default:
		return ""
	}
}

type verifierFaultClient struct {
	client.Client
	targetKind     string
	failOnRelevant int
	relevantSeen   int
	failOnAnyRoute int
	allRouteSeen   int
	failedKind     string
	cause          error
	enabled        bool
}

func (c *verifierFaultClient) List(ctx context.Context, list client.ObjectList, opts ...client.ListOption) error {
	kind := verifierRouteListKind(list)
	if c.enabled && kind != "" {
		c.allRouteSeen++
		if c.failOnAnyRoute > 0 && c.allRouteSeen == c.failOnAnyRoute {
			c.failedKind = kind
			return c.cause
		}
		if c.targetKind == kind {
			c.relevantSeen++
			if c.failOnRelevant > 0 && c.relevantSeen == c.failOnRelevant {
				c.failedKind = kind
				return c.cause
			}
		}
	}
	return c.Client.List(ctx, list, opts...)
}

func verifierStage4Base(t *testing.T, listenerSets int) client.Client {
	t.Helper()
	fromAll := gatewayv1.NamespacesFromAll
	objects := []client.Object{verifierGatewayClass(), verifierGateway("ns", "gw", &fromAll)}
	objects = append(objects, &corev1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: "ns"}})
	for i := 0; i < listenerSets; i++ {
		objects = append(objects, verifierListenerSet("ns", fmt.Sprintf("set-%d", i), "ns", "gw", []gatewayv1.ListenerEntry{{
			Name: gatewayv1.SectionName(fmt.Sprintf("extra-%d", i)), Port: gatewayv1.PortNumber(8080 + i), Protocol: gatewayv1.HTTPProtocolType,
		}}))
	}
	return verifierClient(objects...)
}

func verifierChangeGatewayPort(t *testing.T, c client.Client, port gatewayv1.PortNumber) {
	t.Helper()
	gateway := &gatewayv1.Gateway{}
	key := types.NamespacedName{Namespace: "ns", Name: "gw"}
	if err := c.Get(t.Context(), key, gateway); err != nil {
		t.Fatal(err)
	}
	gateway.Spec.Listeners[0].Port = port
	if err := c.Update(t.Context(), gateway); err != nil {
		t.Fatal(err)
	}
}

func verifierRunReconcile(t *testing.T, c client.Client) error {
	t.Helper()
	r := &gatewayReconciler{Client: c, Scheme: c.Scheme(), translator: verifierTranslator(), logger: slog.Default(), controllerName: defaultControllerName}
	_, err := r.Reconcile(t.Context(), ctrl.Request{NamespacedName: types.NamespacedName{Namespace: "ns", Name: "gw"}})
	return err
}

func verifierContainsIdentifier(message, identifier string) bool {
	pattern := `(^|[^a-z0-9])` + regexp.QuoteMeta(strings.ToLower(identifier)) + `([^a-z0-9]|$)`
	return regexp.MustCompile(pattern).MatchString(strings.ToLower(message))
}

func verifierErrorIdentifies(t *testing.T, err error, routeKind, namespace string, listenerSets ...string) {
	t.Helper()
	message := err.Error()
	if !verifierContainsIdentifier(message, routeKind) {
		t.Fatalf("error does not identify Route kind %s: %v", routeKind, err)
	}
	if !verifierContainsIdentifier(message, namespace) {
		t.Fatalf("error does not identify ListenerSet namespace %s: %v", namespace, err)
	}
	for _, name := range listenerSets {
		if !verifierContainsIdentifier(message, name) {
			t.Fatalf("error does not identify affected ListenerSet %s: %v", name, err)
		}
	}
}

func TestVerifierStage4RouteRetrievalFailuresAreAtomicAndRecover(t *testing.T) {
	routeKinds := []string{"HTTPRoute", "GRPCRoute", "TLSRoute", "TCPRoute", "UDPRoute"}
	for _, routeKind := range routeKinds {
		t.Run(routeKind, func(t *testing.T) {
			base := verifierStage4Base(t, 1)
			if err := verifierRunReconcile(t, base); err != nil {
				t.Fatalf("initial valid reconciliation failed: %v", err)
			}
			before := verifierCECSpec(t, base, "ns", "gw")
			verifierChangeGatewayPort(t, base, 81)

			cause := errors.New("injected route retrieval failure")
			fault := &verifierFaultClient{Client: base, targetKind: routeKind, failOnRelevant: 1, cause: cause, enabled: true}
			err := verifierRunReconcile(t, fault)
			if err == nil || !errors.Is(err, cause) {
				t.Fatalf("reconciliation did not preserve the injected %s failure: %v", routeKind, err)
			}
			verifierErrorIdentifies(t, err, routeKind, "ns", "set-0")
			after := verifierCECSpec(t, base, "ns", "gw")
			if string(before) != string(after) {
				t.Fatal("failed reconciliation replaced the previous valid configuration")
			}

			fault.enabled = false
			fault.relevantSeen = 0
			fault.allRouteSeen = 0
			if err := verifierRunReconcile(t, fault); err != nil {
				t.Fatalf("recovery failed: %v", err)
			}
			recovered := verifierCECSpec(t, base, "ns", "gw")
			if string(recovered) == string(before) {
				t.Fatal("successful retry did not publish the changed desired configuration")
			}
		})
	}
}

func TestVerifierStage4LateFailureWithMultipleListenerSetsIsAtomic(t *testing.T) {
	base := verifierStage4Base(t, 2)
	if err := verifierRunReconcile(t, base); err != nil {
		t.Fatalf("initial valid reconciliation failed: %v", err)
	}
	before := verifierCECSpec(t, base, "ns", "gw")
	verifierChangeGatewayPort(t, base, 81)

	cause := errors.New("injected late route retrieval failure")
	// The first Route-list operation succeeds and a later required operation
	// fails. No index name or per-ListenerSet query count is assumed.
	fault := &verifierFaultClient{Client: base, failOnAnyRoute: 2, cause: cause, enabled: true}
	err := verifierRunReconcile(t, fault)
	if err == nil || !errors.Is(err, cause) {
		t.Fatalf("late retrieval failure was not propagated: %v", err)
	}
	if fault.allRouteSeen < 2 || fault.failedKind == "" {
		t.Fatal("fault was not injected after an earlier Route retrieval succeeded")
	}
	verifierErrorIdentifies(t, err, fault.failedKind, "ns", "set-0", "set-1")
	if got := verifierCECSpec(t, base, "ns", "gw"); string(got) != string(before) {
		t.Fatal("partial desired state was published after a late failure")
	}
}
