# Verifier-Owned Go Tests

These files are copied into the relevant repository packages only while the verifier runs, then removed.

They test behavior and public task contracts rather than Oracle filenames, patch text, exact changed-file counts, candidate test names, or candidate-authored logs.
