// SPDX-License-Identifier: Apache-2.0
package gateway_api

import (
	"bytes"
	"fmt"
	"testing"

	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"sigs.k8s.io/controller-runtime/pkg/client"
	gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"
	gatewayv1alpha2 "sigs.k8s.io/gateway-api/apis/v1alpha2"
)

func verifierService(namespace, name string, port int32) *corev1.Service {
	return &corev1.Service{
		ObjectMeta: metav1.ObjectMeta{Name: name, Namespace: namespace},
		Spec:       corev1.ServiceSpec{Ports: []corev1.ServicePort{{Name: "backend", Port: port}}},
	}
}

func verifierHTTPRoute(namespace, name string, parent gatewayv1.ParentReference, hostname gatewayv1.Hostname, path, backend string, port gatewayv1.PortNumber) *gatewayv1.HTTPRoute {
	pathType := gatewayv1.PathMatchPathPrefix
	spec := gatewayv1.HTTPRouteSpec{
		CommonRouteSpec: gatewayv1.CommonRouteSpec{ParentRefs: []gatewayv1.ParentReference{parent}},
		Rules: []gatewayv1.HTTPRouteRule{{
			Matches:     []gatewayv1.HTTPRouteMatch{{Path: &gatewayv1.HTTPPathMatch{Type: &pathType, Value: &path}}},
			BackendRefs: []gatewayv1.HTTPBackendRef{{BackendRef: gatewayv1.BackendRef{BackendObjectReference: gatewayv1.BackendObjectReference{Name: gatewayv1.ObjectName(backend), Port: &port}}}},
		}},
	}
	if hostname != "" {
		spec.Hostnames = []gatewayv1.Hostname{hostname}
	}
	return &gatewayv1.HTTPRoute{
		ObjectMeta: metav1.ObjectMeta{Name: name, Namespace: namespace},
		Spec:       spec,
	}
}

func verifierRouteParentCondition(parents []gatewayv1.RouteParentStatus, parentName string, parentKind gatewayv1.Kind) (metav1.ConditionStatus, bool) {
	for _, parent := range parents {
		kind := gatewayv1.Kind("Gateway")
		if parent.ParentRef.Kind != nil {
			kind = *parent.ParentRef.Kind
		}
		if string(parent.ParentRef.Name) != parentName || kind != parentKind {
			continue
		}
		for _, condition := range parent.Conditions {
			if condition.Type == string(gatewayv1.RouteConditionAccepted) {
				return condition.Status, true
			}
		}
		return metav1.ConditionUnknown, true
	}
	return metav1.ConditionUnknown, false
}

func TestVerifierStage3ListenerSetOnlyHostnameReachesConfiguration(t *testing.T) {
	fromAll := gatewayv1.NamespacesFromAll
	gatewayHost := gatewayv1.Hostname("gateway.stage3.example")
	listenerSetHost := gatewayv1.Hostname("listenerset.stage3.example")
	listenerSetKind := gatewayv1.Kind("ListenerSet")
	backendPort := gatewayv1.PortNumber(8080)
	path := "/stage3-listenerset-only"

	gateway := verifierGateway("ns", "gw", &fromAll)
	gateway.Spec.Listeners[0].Hostname = &gatewayHost
	listenerSet := verifierListenerSet("ns", "set", "ns", "gw", []gatewayv1.ListenerEntry{{Name: "extra", Port: 8080, Protocol: gatewayv1.HTTPProtocolType, Hostname: &listenerSetHost}})
	route := verifierHTTPRoute("ns", "route", gatewayv1.ParentReference{Kind: &listenerSetKind, Name: "set"}, listenerSetHost, path, "backend", backendPort)
	c := verifierClient(
		&corev1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: "ns"}}, verifierGatewayClass(), gateway, listenerSet,
		route, verifierService("ns", "backend", 8080),
	)
	if err := verifierReconcile(t, c, "ns", "gw"); err != nil {
		t.Fatalf("reconcile failed: %v", err)
	}
	spec := verifierCECSpec(t, c, "ns", "gw")
	if !bytes.Contains(spec, []byte(path)) || !bytes.Contains(spec, []byte("backend")) {
		t.Fatalf("ListenerSet-only hostname Route was absent from generated configuration: %s", spec)
	}
}

func TestVerifierStage3SameNameGatewayAndListenerSetRemainDistinct(t *testing.T) {
	fromAll := gatewayv1.NamespacesFromAll
	gatewayHost := gatewayv1.Hostname("gateway.identity.example")
	listenerSetHost := gatewayv1.Hostname("listenerset.identity.example")
	listenerSetKind := gatewayv1.Kind("ListenerSet")
	section := gatewayv1.SectionName("extra")
	listenerPort := gatewayv1.PortNumber(8080)
	path := "/same-name-listenerset-parent"

	gateway := verifierGateway("ns", "shared", &fromAll)
	gateway.Spec.Listeners[0].Hostname = &gatewayHost
	listenerSet := verifierListenerSet("ns", "shared", "ns", "shared", []gatewayv1.ListenerEntry{{Name: section, Port: listenerPort, Protocol: gatewayv1.HTTPProtocolType, Hostname: &listenerSetHost}})
	parent := gatewayv1.ParentReference{Kind: &listenerSetKind, Name: "shared", SectionName: &section, Port: &listenerPort}
	route := verifierHTTPRoute("ns", "route", parent, listenerSetHost, path, "identity-backend", listenerPort)
	c := verifierClient(
		&corev1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: "ns"}}, verifierGatewayClass(), gateway, listenerSet,
		route, verifierService("ns", "identity-backend", 8080),
	)
	if err := verifierReconcile(t, c, "ns", "shared"); err != nil {
		t.Fatalf("reconcile failed: %v", err)
	}
	actual := &gatewayv1.HTTPRoute{}
	if err := c.Get(t.Context(), types.NamespacedName{Namespace: "ns", Name: "route"}, actual); err != nil {
		t.Fatal(err)
	}
	status, found := verifierRouteParentCondition(actual.Status.Parents, "shared", listenerSetKind)
	if !found || status != metav1.ConditionTrue {
		t.Fatalf("same-name ListenerSet parent status was not independently accepted: found=%v status=%s", found, status)
	}
	if spec := verifierCECSpec(t, c, "ns", "shared"); !bytes.Contains(spec, []byte(path)) {
		t.Fatalf("same-name ListenerSet Route did not reach its listener: %s", spec)
	}
}

func TestVerifierStage3SectionAndPortApplyToEveryRouteKind(t *testing.T) {
	fromAll := gatewayv1.NamespacesFromAll
	listenerSetKind := gatewayv1.Kind("ListenerSet")
	tlsMode := gatewayv1.TLSModePassthrough
	listeners := []gatewayv1.ListenerEntry{
		{Name: "http", Port: 8080, Protocol: gatewayv1.HTTPProtocolType},
		{Name: "grpc", Port: 8081, Protocol: gatewayv1.HTTPProtocolType},
		{Name: "tls", Port: 8443, Protocol: gatewayv1.TLSProtocolType, TLS: &gatewayv1.ListenerTLSConfig{Mode: &tlsMode}},
		{Name: "tcp", Port: 9000, Protocol: gatewayv1.TCPProtocolType},
		{Name: "udp", Port: 9001, Protocol: gatewayv1.UDPProtocolType},
	}
	listenerSet := verifierListenerSet("ns", "set", "ns", "gw", listeners)

	objects := []client.Object{
		&corev1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: "ns"}}, verifierGatewayClass(), verifierGateway("ns", "gw", &fromAll), listenerSet,
	}
	badPort := gatewayv1.PortNumber(9999)
	backendPort := gatewayv1.PortNumber(8080)

	httpSection := gatewayv1.SectionName("http")
	httpGoodPath := "/http-good-port"
	httpBadPath := "/http-bad-port"
	objects = append(objects,
		verifierHTTPRoute("ns", "http-good", gatewayv1.ParentReference{Kind: &listenerSetKind, Name: "set", SectionName: &httpSection, Port: &backendPort}, "", httpGoodPath, "http-good-backend", backendPort),
		verifierHTTPRoute("ns", "http-bad", gatewayv1.ParentReference{Kind: &listenerSetKind, Name: "set", SectionName: &httpSection, Port: &badPort}, "", httpBadPath, "http-bad-backend", backendPort),
		verifierService("ns", "http-good-backend", 8080), verifierService("ns", "http-bad-backend", 8080),
	)

	grpcSection := gatewayv1.SectionName("grpc")
	grpcPort := gatewayv1.PortNumber(8081)
	grpcGood := &gatewayv1.GRPCRoute{ObjectMeta: metav1.ObjectMeta{Name: "grpc-good", Namespace: "ns"}, Spec: gatewayv1.GRPCRouteSpec{
		CommonRouteSpec: gatewayv1.CommonRouteSpec{ParentRefs: []gatewayv1.ParentReference{{Kind: &listenerSetKind, Name: "set", SectionName: &grpcSection, Port: &grpcPort}}},
		Rules:           []gatewayv1.GRPCRouteRule{{BackendRefs: []gatewayv1.GRPCBackendRef{{BackendRef: gatewayv1.BackendRef{BackendObjectReference: gatewayv1.BackendObjectReference{Name: "grpc-good-backend", Port: &grpcPort}}}}}},
	}}
	grpcBad := grpcGood.DeepCopy()
	grpcBad.Name = "grpc-bad"
	grpcBad.Spec.ParentRefs[0].Port = &badPort
	grpcBad.Spec.Rules[0].BackendRefs[0].Name = "grpc-bad-backend"
	objects = append(objects, grpcGood, grpcBad, verifierService("ns", "grpc-good-backend", 8081), verifierService("ns", "grpc-bad-backend", 8081))

	tlsSection := gatewayv1.SectionName("tls")
	tlsPort := gatewayv1.PortNumber(8443)
	tlsGood := &gatewayv1.TLSRoute{ObjectMeta: metav1.ObjectMeta{Name: "tls-good", Namespace: "ns"}, Spec: gatewayv1.TLSRouteSpec{
		CommonRouteSpec: gatewayv1.CommonRouteSpec{ParentRefs: []gatewayv1.ParentReference{{Kind: &listenerSetKind, Name: "set", SectionName: &tlsSection, Port: &tlsPort}}},
		Rules:           []gatewayv1.TLSRouteRule{{BackendRefs: []gatewayv1.BackendRef{{BackendObjectReference: gatewayv1.BackendObjectReference{Name: "tls-good-backend", Port: &tlsPort}}}}},
	}}
	tlsBad := tlsGood.DeepCopy()
	tlsBad.Name = "tls-bad"
	tlsBad.Spec.ParentRefs[0].Port = &badPort
	tlsBad.Spec.Rules[0].BackendRefs[0].Name = "tls-bad-backend"
	objects = append(objects, tlsGood, tlsBad, verifierService("ns", "tls-good-backend", 8443), verifierService("ns", "tls-bad-backend", 8443))

	tcpSection := gatewayv1.SectionName("tcp")
	tcpPort := gatewayv1.PortNumber(9000)
	tcpGood := &gatewayv1alpha2.TCPRoute{ObjectMeta: metav1.ObjectMeta{Name: "tcp-good", Namespace: "ns"}, Spec: gatewayv1alpha2.TCPRouteSpec{
		CommonRouteSpec: gatewayv1.CommonRouteSpec{ParentRefs: []gatewayv1.ParentReference{{Kind: &listenerSetKind, Name: "set", SectionName: &tcpSection, Port: &tcpPort}}},
		Rules:           []gatewayv1alpha2.TCPRouteRule{{BackendRefs: []gatewayv1.BackendRef{{BackendObjectReference: gatewayv1.BackendObjectReference{Name: "tcp-good-backend", Port: &tcpPort}}}}},
	}}
	tcpBad := tcpGood.DeepCopy()
	tcpBad.Name = "tcp-bad"
	tcpBad.Spec.ParentRefs[0].Port = &badPort
	tcpBad.Spec.Rules[0].BackendRefs[0].Name = "tcp-bad-backend"
	objects = append(objects, tcpGood, tcpBad, verifierService("ns", "tcp-good-backend", 9000), verifierService("ns", "tcp-bad-backend", 9000))

	udpSection := gatewayv1.SectionName("udp")
	udpPort := gatewayv1.PortNumber(9001)
	udpGood := &gatewayv1alpha2.UDPRoute{ObjectMeta: metav1.ObjectMeta{Name: "udp-good", Namespace: "ns"}, Spec: gatewayv1alpha2.UDPRouteSpec{
		CommonRouteSpec: gatewayv1.CommonRouteSpec{ParentRefs: []gatewayv1.ParentReference{{Kind: &listenerSetKind, Name: "set", SectionName: &udpSection, Port: &udpPort}}},
		Rules:           []gatewayv1alpha2.UDPRouteRule{{BackendRefs: []gatewayv1.BackendRef{{BackendObjectReference: gatewayv1.BackendObjectReference{Name: "udp-good-backend", Port: &udpPort}}}}},
	}}
	udpBad := udpGood.DeepCopy()
	udpBad.Name = "udp-bad"
	udpBad.Spec.ParentRefs[0].Port = &badPort
	udpBad.Spec.Rules[0].BackendRefs[0].Name = "udp-bad-backend"
	objects = append(objects, udpGood, udpBad, verifierService("ns", "udp-good-backend", 9001), verifierService("ns", "udp-bad-backend", 9001))

	c := verifierClient(objects...)
	if err := verifierReconcile(t, c, "ns", "gw"); err != nil {
		t.Fatalf("reconcile failed: %v", err)
	}
	spec := verifierGeneratedConfig(t, c, "ns", "gw")
	for _, kind := range []string{"http", "grpc", "tls", "tcp", "udp"} {
		good := []byte(fmt.Sprintf("%s-good-backend", kind))
		bad := []byte(fmt.Sprintf("%s-bad-backend", kind))
		if !bytes.Contains(spec, good) {
			t.Errorf("matching %s Route backend missing from configuration", kind)
		}
		if bytes.Contains(spec, bad) {
			t.Errorf("mismatched-port %s Route backend reached configuration", kind)
		}
	}
}

func TestVerifierStage3SectionNameAppliesToEveryRouteKind(t *testing.T) {
	fromAll := gatewayv1.NamespacesFromAll
	listenerSetKind := gatewayv1.Kind("ListenerSet")
	tlsMode := gatewayv1.TLSModePassthrough
	listenerSet := verifierListenerSet("ns", "set", "ns", "gw", []gatewayv1.ListenerEntry{
		{Name: "http", Port: 8080, Protocol: gatewayv1.HTTPProtocolType},
		{Name: "grpc", Port: 8081, Protocol: gatewayv1.HTTPProtocolType},
		{Name: "tls", Port: 8443, Protocol: gatewayv1.TLSProtocolType, TLS: &gatewayv1.ListenerTLSConfig{Mode: &tlsMode}},
		{Name: "tcp", Port: 9000, Protocol: gatewayv1.TCPProtocolType},
		{Name: "udp", Port: 9001, Protocol: gatewayv1.UDPProtocolType},
	})
	wrongSection := gatewayv1.SectionName("not-a-listener")
	objects := []client.Object{
		&corev1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: "ns"}},
		verifierGatewayClass(), verifierGateway("ns", "gw", &fromAll), listenerSet,
	}

	httpPort := gatewayv1.PortNumber(8080)
	objects = append(objects,
		verifierHTTPRoute("ns", "http-section-bad", gatewayv1.ParentReference{Kind: &listenerSetKind, Name: "set", SectionName: &wrongSection, Port: &httpPort}, "", "/http-section-bad", "http-section-bad-backend", httpPort),
		verifierService("ns", "http-section-bad-backend", 8080),
	)

	grpcPort := gatewayv1.PortNumber(8081)
	objects = append(objects,
		&gatewayv1.GRPCRoute{ObjectMeta: metav1.ObjectMeta{Name: "grpc-section-bad", Namespace: "ns"}, Spec: gatewayv1.GRPCRouteSpec{
			CommonRouteSpec: gatewayv1.CommonRouteSpec{ParentRefs: []gatewayv1.ParentReference{{Kind: &listenerSetKind, Name: "set", SectionName: &wrongSection, Port: &grpcPort}}},
			Rules:           []gatewayv1.GRPCRouteRule{{BackendRefs: []gatewayv1.GRPCBackendRef{{BackendRef: gatewayv1.BackendRef{BackendObjectReference: gatewayv1.BackendObjectReference{Name: "grpc-section-bad-backend", Port: &grpcPort}}}}}},
		}},
		verifierService("ns", "grpc-section-bad-backend", 8081),
	)

	tlsPort := gatewayv1.PortNumber(8443)
	objects = append(objects,
		&gatewayv1.TLSRoute{ObjectMeta: metav1.ObjectMeta{Name: "tls-section-bad", Namespace: "ns"}, Spec: gatewayv1.TLSRouteSpec{
			CommonRouteSpec: gatewayv1.CommonRouteSpec{ParentRefs: []gatewayv1.ParentReference{{Kind: &listenerSetKind, Name: "set", SectionName: &wrongSection, Port: &tlsPort}}},
			Rules:           []gatewayv1.TLSRouteRule{{BackendRefs: []gatewayv1.BackendRef{{BackendObjectReference: gatewayv1.BackendObjectReference{Name: "tls-section-bad-backend", Port: &tlsPort}}}}},
		}},
		verifierService("ns", "tls-section-bad-backend", 8443),
	)

	tcpPort := gatewayv1.PortNumber(9000)
	objects = append(objects,
		&gatewayv1alpha2.TCPRoute{ObjectMeta: metav1.ObjectMeta{Name: "tcp-section-bad", Namespace: "ns"}, Spec: gatewayv1alpha2.TCPRouteSpec{
			CommonRouteSpec: gatewayv1.CommonRouteSpec{ParentRefs: []gatewayv1.ParentReference{{Kind: &listenerSetKind, Name: "set", SectionName: &wrongSection, Port: &tcpPort}}},
			Rules:           []gatewayv1alpha2.TCPRouteRule{{BackendRefs: []gatewayv1.BackendRef{{BackendObjectReference: gatewayv1.BackendObjectReference{Name: "tcp-section-bad-backend", Port: &tcpPort}}}}},
		}},
		verifierService("ns", "tcp-section-bad-backend", 9000),
	)

	udpPort := gatewayv1.PortNumber(9001)
	objects = append(objects,
		&gatewayv1alpha2.UDPRoute{ObjectMeta: metav1.ObjectMeta{Name: "udp-section-bad", Namespace: "ns"}, Spec: gatewayv1alpha2.UDPRouteSpec{
			CommonRouteSpec: gatewayv1.CommonRouteSpec{ParentRefs: []gatewayv1.ParentReference{{Kind: &listenerSetKind, Name: "set", SectionName: &wrongSection, Port: &udpPort}}},
			Rules:           []gatewayv1alpha2.UDPRouteRule{{BackendRefs: []gatewayv1.BackendRef{{BackendObjectReference: gatewayv1.BackendObjectReference{Name: "udp-section-bad-backend", Port: &udpPort}}}}},
		}},
		verifierService("ns", "udp-section-bad-backend", 9001),
	)

	c := verifierClient(objects...)
	if err := verifierReconcile(t, c, "ns", "gw"); err != nil {
		t.Fatalf("reconcile failed: %v", err)
	}
	spec := verifierGeneratedConfig(t, c, "ns", "gw")
	for _, kind := range []string{"http", "grpc", "tls", "tcp", "udp"} {
		if bytes.Contains(spec, []byte(kind+"-section-bad-backend")) {
			t.Errorf("mismatched-section %s Route reached generated configuration", kind)
		}
	}
}

func TestVerifierStage3DisallowedListenerSetRouteHasNegativeStatus(t *testing.T) {
	fromNone := gatewayv1.NamespacesFromNone
	listenerSetKind := gatewayv1.Kind("ListenerSet")
	gateway := verifierGateway("ns", "gw", &fromNone)
	listenerSet := verifierListenerSet("ns", "set", "ns", "gw", []gatewayv1.ListenerEntry{{Name: "extra", Port: 8080, Protocol: gatewayv1.HTTPProtocolType}})
	route := &gatewayv1.HTTPRoute{ObjectMeta: metav1.ObjectMeta{Name: "route", Namespace: "ns"}, Spec: gatewayv1.HTTPRouteSpec{
		CommonRouteSpec: gatewayv1.CommonRouteSpec{ParentRefs: []gatewayv1.ParentReference{{Kind: &listenerSetKind, Name: "set"}}}, Rules: []gatewayv1.HTTPRouteRule{{}},
	}}
	c := verifierClient(&corev1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: "ns"}}, verifierGatewayClass(), gateway, listenerSet, route)
	_ = verifierReconcile(t, c, "ns", "gw")
	actual := &gatewayv1.HTTPRoute{}
	if err := c.Get(t.Context(), types.NamespacedName{Namespace: "ns", Name: "route"}, actual); err != nil {
		t.Fatal(err)
	}
	status, found := verifierRouteParentCondition(actual.Status.Parents, "set", listenerSetKind)
	if !found || status != metav1.ConditionFalse {
		t.Fatalf("disallowed ListenerSet parent must have Accepted=False; found=%v status=%s", found, status)
	}
}
