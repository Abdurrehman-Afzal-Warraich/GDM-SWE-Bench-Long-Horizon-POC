// SPDX-License-Identifier: Apache-2.0
package gateway_api

import (
	"bytes"
	"context"
	"encoding/json"
	"log/slog"
	"testing"

	corev1 "k8s.io/api/core/v1"
	discoveryv1 "k8s.io/api/discovery/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	ctrl "sigs.k8s.io/controller-runtime"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/client/fake"
	gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"
	gatewayv1alpha2 "sigs.k8s.io/gateway-api/apis/v1alpha2"

	"github.com/cilium/cilium/operator/pkg/gateway-api/helpers"
	"github.com/cilium/cilium/operator/pkg/model/translation"
	gatewayApiTranslation "github.com/cilium/cilium/operator/pkg/model/translation/gateway-api"
	ciliumv2 "github.com/cilium/cilium/pkg/k8s/apis/cilium.io/v2"
	"github.com/cilium/cilium/pkg/shortener"
)

// verifierListAllClient removes field selectors before delegating to the fake
// client. This lets the tests exercise reconciliation behavior without
// requiring any particular candidate index name or indexer helper.
// Label selectors and other list options are preserved so AllowedListeners
// namespace-selector policies still evaluate correctly.
type verifierListAllClient struct{ client.Client }

func (c *verifierListAllClient) List(ctx context.Context, list client.ObjectList, opts ...client.ListOption) error {
	cleaned := make([]client.ListOption, 0, len(opts))
	for _, opt := range opts {
		switch o := opt.(type) {
		case client.MatchingFields, client.MatchingFieldsSelector:
			continue
		case *client.ListOptions:
			cp := *o
			cp.FieldSelector = nil
			cleaned = append(cleaned, &cp)
		default:
			cleaned = append(cleaned, opt)
		}
	}
	return c.Client.List(ctx, list, cleaned...)
}

func verifierTranslator() translation.Translator {
	cec := translation.NewCECTranslator(translation.Config{
		SecretsNamespace:          "cilium-secrets",
		RouteConfig:               translation.RouteConfig{HostNameSuffixMatch: true},
		ListenerConfig:            translation.ListenerConfig{StreamIdleTimeoutSeconds: 300},
		ClusterConfig:             translation.ClusterConfig{IdleTimeoutSeconds: 60},
		OriginalIPDetectionConfig: translation.OriginalIPDetectionConfig{UseRemoteAddress: true},
	})
	return gatewayApiTranslation.NewTranslator(cec, translation.Config{
		ServiceConfig:             translation.ServiceConfig{ExternalTrafficPolicy: string(corev1.ServiceExternalTrafficPolicyCluster)},
		OriginalIPDetectionConfig: translation.OriginalIPDetectionConfig{UseRemoteAddress: true},
	})
}

func verifierClient(objects ...client.Object) client.Client {
	scheme := helpers.TestScheme(helpers.AllOptionalKinds)
	base := fake.NewClientBuilder().
		WithScheme(scheme).
		WithObjects(objects...).
		WithStatusSubresource(
			&corev1.Service{}, &corev1.Namespace{},
			&gatewayv1.Gateway{}, &gatewayv1.GatewayClass{}, &gatewayv1.ListenerSet{},
			&gatewayv1.HTTPRoute{}, &gatewayv1.GRPCRoute{}, &gatewayv1.TLSRoute{},
			&gatewayv1alpha2.TCPRoute{}, &gatewayv1alpha2.UDPRoute{},
		).
		Build()
	return &verifierListAllClient{Client: base}
}

func verifierReconcile(t *testing.T, c client.Client, namespace, name string) error {
	t.Helper()
	r := &gatewayReconciler{
		Client: c, Scheme: c.Scheme(), translator: verifierTranslator(),
		logger: slog.Default(), controllerName: defaultControllerName,
	}
	_, err := r.Reconcile(t.Context(), ctrl.Request{NamespacedName: types.NamespacedName{Namespace: namespace, Name: name}})
	return err
}

func verifierConditionStatus(conditions []metav1.Condition, conditionType string) metav1.ConditionStatus {
	for _, condition := range conditions {
		if condition.Type == conditionType {
			return condition.Status
		}
	}
	return metav1.ConditionUnknown
}

func verifierParentAccepted(parents []gatewayv1.RouteParentStatus, parentName string, parentKind gatewayv1.Kind) bool {
	for _, parent := range parents {
		kind := gatewayv1.Kind("Gateway")
		if parent.ParentRef.Kind != nil {
			kind = *parent.ParentRef.Kind
		}
		if string(parent.ParentRef.Name) != parentName || kind != parentKind {
			continue
		}
		return verifierConditionStatus(parent.Conditions, string(gatewayv1.RouteConditionAccepted)) == metav1.ConditionTrue
	}
	return false
}

func verifierCECSpec(t *testing.T, c client.Client, namespace, gatewayName string) []byte {
	t.Helper()
	obj := &ciliumv2.CiliumEnvoyConfig{}
	name := shortener.ShortenK8sResourceName(gatewayApiTranslation.CiliumGatewayPrefix + gatewayName)
	if err := c.Get(t.Context(), types.NamespacedName{Namespace: namespace, Name: name}, obj); err != nil {
		t.Fatal(err)
	}
	data, err := json.Marshal(obj.Spec)
	if err != nil {
		t.Fatal(err)
	}
	return data
}

// verifierGeneratedConfig returns L7 CEC evidence plus L4 EndpointSlice backend
// annotations. TCP/UDP backends are programmed via EndpointSlices rather than
// CEC, so section/port attachment checks must consult both surfaces.
func verifierGeneratedConfig(t *testing.T, c client.Client, namespace, gatewayName string) []byte {
	t.Helper()
	var buf bytes.Buffer
	buf.Write(verifierCECSpec(t, c, namespace, gatewayName))
	epsList := &discoveryv1.EndpointSliceList{}
	if err := c.List(t.Context(), epsList); err != nil {
		t.Fatal(err)
	}
	for _, eps := range epsList.Items {
		if ann, ok := eps.Annotations["gateway.cilium.io/backend-service"]; ok {
			buf.WriteByte('\n')
			buf.WriteString(ann)
		}
	}
	return buf.Bytes()
}
