// SPDX-License-Identifier: Apache-2.0
package gateway_api

import (
	"bytes"
	"context"
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"math/big"
	"testing"
	"time"

	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"sigs.k8s.io/controller-runtime/pkg/client"
	gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"
	gatewayv1alpha2 "sigs.k8s.io/gateway-api/apis/v1alpha2"
)

func verifierGatewayClass() *gatewayv1.GatewayClass {
	return &gatewayv1.GatewayClass{
		ObjectMeta: metav1.ObjectMeta{Name: "class"},
		Spec:       gatewayv1.GatewayClassSpec{ControllerName: gatewayv1.GatewayController(defaultControllerName)},
	}
}

func verifierGateway(namespace, name string, from *gatewayv1.FromNamespaces) *gatewayv1.Gateway {
	host := gatewayv1.Hostname("direct.example")
	return &gatewayv1.Gateway{
		ObjectMeta: metav1.ObjectMeta{Name: name, Namespace: namespace},
		Spec: gatewayv1.GatewaySpec{
			GatewayClassName: "class",
			AllowedListeners: &gatewayv1.AllowedListeners{Namespaces: &gatewayv1.ListenerNamespaces{From: from}},
			Listeners:        []gatewayv1.Listener{{Name: "direct", Port: 80, Protocol: gatewayv1.HTTPProtocolType, Hostname: &host}},
		},
	}
}

func verifierListenerSet(namespace, name, gatewayNamespace, gatewayName string, listeners []gatewayv1.ListenerEntry) *gatewayv1.ListenerSet {
	ref := gatewayv1.ParentGatewayReference{Name: gatewayv1.ObjectName(gatewayName)}
	if gatewayNamespace != namespace {
		ns := gatewayv1.Namespace(gatewayNamespace)
		ref.Namespace = &ns
	}
	return &gatewayv1.ListenerSet{
		ObjectMeta: metav1.ObjectMeta{Name: name, Namespace: namespace},
		Spec:       gatewayv1.ListenerSetSpec{ParentRef: ref, Listeners: listeners},
	}
}

func verifierListenerSetAccepted(t *testing.T, c clientReader, namespace, name string) bool {
	t.Helper()
	obj := &gatewayv1.ListenerSet{}
	if err := c.Get(t.Context(), types.NamespacedName{Namespace: namespace, Name: name}, obj); err != nil {
		t.Fatal(err)
	}
	return verifierConditionStatus(obj.Status.Conditions, string(gatewayv1.ListenerSetConditionAccepted)) == metav1.ConditionTrue
}

type clientReader interface {
	Get(context.Context, client.ObjectKey, client.Object, ...client.GetOption) error
}

func TestVerifierStage2ListenerSetBaselineReconciles(t *testing.T) {
	fromAll := gatewayv1.NamespacesFromAll
	listenerHost := gatewayv1.Hostname("listenerset-baseline.example")
	listenerSetKind := gatewayv1.Kind("ListenerSet")

	gateway := verifierGateway("ns", "gw", &fromAll)
	listenerSet := verifierListenerSet("ns", "set", "ns", "gw", []gatewayv1.ListenerEntry{{
		Name: "extra", Port: 8080, Protocol: gatewayv1.HTTPProtocolType, Hostname: &listenerHost,
	}})
	// No Route hostname is supplied here. ListenerSet-only hostname intersection
	// is intentionally reserved for Stage 3.
	route := &gatewayv1.HTTPRoute{
		ObjectMeta: metav1.ObjectMeta{Name: "route", Namespace: "ns"},
		Spec: gatewayv1.HTTPRouteSpec{
			CommonRouteSpec: gatewayv1.CommonRouteSpec{ParentRefs: []gatewayv1.ParentReference{{Kind: &listenerSetKind, Name: "set"}}},
			Rules:           []gatewayv1.HTTPRouteRule{{}},
		},
	}
	c := verifierClient(
		&corev1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: "ns"}},
		verifierGatewayClass(), gateway, listenerSet, route,
	)
	if err := verifierReconcile(t, c, "ns", "gw"); err != nil {
		t.Fatalf("reconcile failed: %v", err)
	}

	actualGateway := &gatewayv1.Gateway{}
	if err := c.Get(t.Context(), types.NamespacedName{Namespace: "ns", Name: "gw"}, actualGateway); err != nil {
		t.Fatal(err)
	}
	if verifierConditionStatus(actualGateway.Status.Conditions, string(gatewayv1.GatewayConditionAccepted)) != metav1.ConditionTrue {
		t.Fatal("Gateway was not accepted")
	}
	if !verifierListenerSetAccepted(t, c, "ns", "set") {
		t.Fatal("ListenerSet was not accepted")
	}
	actualRoute := &gatewayv1.HTTPRoute{}
	if err := c.Get(t.Context(), types.NamespacedName{Namespace: "ns", Name: "route"}, actualRoute); err != nil {
		t.Fatal(err)
	}
	if !verifierParentAccepted(actualRoute.Status.Parents, "set", listenerSetKind) {
		t.Fatal("ListenerSet parent Route was not accepted")
	}
	if spec := verifierCECSpec(t, c, "ns", "gw"); !bytes.Contains(spec, []byte(listenerHost)) {
		t.Fatalf("generated configuration does not contain ListenerSet listener: %s", spec)
	}
}

func TestVerifierStage2AllowedListenersPolicies(t *testing.T) {
	fromNone := gatewayv1.NamespacesFromNone
	fromAll := gatewayv1.NamespacesFromAll
	fromSame := gatewayv1.NamespacesFromSame
	fromSelector := gatewayv1.NamespacesFromSelector

	tests := []struct {
		name                 string
		from                 *gatewayv1.FromNamespaces
		selector             *metav1.LabelSelector
		gatewayNamespace     string
		listenerSetNamespace string
		namespaceLabels      map[string]string
		want                 bool
	}{
		{name: "none", from: &fromNone, gatewayNamespace: "gw", listenerSetNamespace: "team", want: false},
		{name: "all", from: &fromAll, gatewayNamespace: "gw", listenerSetNamespace: "team", want: true},
		{name: "same-accept", from: &fromSame, gatewayNamespace: "gw", listenerSetNamespace: "gw", want: true},
		{name: "same-reject", from: &fromSame, gatewayNamespace: "gw", listenerSetNamespace: "team", want: false},
		{name: "selector-accept", from: &fromSelector, selector: &metav1.LabelSelector{MatchLabels: map[string]string{"team": "infra"}}, gatewayNamespace: "gw", listenerSetNamespace: "team", namespaceLabels: map[string]string{"team": "infra"}, want: true},
		{name: "selector-reject", from: &fromSelector, selector: &metav1.LabelSelector{MatchLabels: map[string]string{"team": "infra"}}, gatewayNamespace: "gw", listenerSetNamespace: "team", namespaceLabels: map[string]string{"team": "app"}, want: false},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			gateway := verifierGateway(tc.gatewayNamespace, "gw", tc.from)
			gateway.Spec.AllowedListeners.Namespaces.Selector = tc.selector
			listenerSet := verifierListenerSet(tc.listenerSetNamespace, "set", tc.gatewayNamespace, "gw", []gatewayv1.ListenerEntry{{
				Name: "extra", Port: 8080, Protocol: gatewayv1.HTTPProtocolType,
			}})
			objects := []client.Object{verifierGatewayClass(), gateway, listenerSet}
			if tc.gatewayNamespace == tc.listenerSetNamespace {
				objects = append(objects, &corev1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: tc.gatewayNamespace, Labels: tc.namespaceLabels}})
			} else {
				objects = append(objects,
					&corev1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: tc.gatewayNamespace}},
					&corev1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: tc.listenerSetNamespace, Labels: tc.namespaceLabels}},
				)
			}
			c := verifierClient(objects...)
			if err := verifierReconcile(t, c, tc.gatewayNamespace, "gw"); err != nil && tc.want {
				t.Fatalf("reconcile failed: %v", err)
			}
			if got := verifierListenerSetAccepted(t, c, tc.listenerSetNamespace, "set"); got != tc.want {
				t.Fatalf("accepted=%v want=%v", got, tc.want)
			}
		})
	}
}

func TestVerifierStage2AllRouteKindsAttachToListenerSet(t *testing.T) {
	fromAll := gatewayv1.NamespacesFromAll
	listenerSetKind := gatewayv1.Kind("ListenerSet")
	tlsMode := gatewayv1.TLSModePassthrough
	parent := gatewayv1.ParentReference{Kind: &listenerSetKind, Name: "set"}
	common := gatewayv1.CommonRouteSpec{ParentRefs: []gatewayv1.ParentReference{parent}}

	listenerSet := verifierListenerSet("ns", "set", "ns", "gw", []gatewayv1.ListenerEntry{
		{Name: "http", Port: 8080, Protocol: gatewayv1.HTTPProtocolType},
		{Name: "grpc", Port: 8081, Protocol: gatewayv1.HTTPProtocolType},
		{Name: "tls", Port: 8443, Protocol: gatewayv1.TLSProtocolType, TLS: &gatewayv1.ListenerTLSConfig{Mode: &tlsMode}},
		{Name: "tcp", Port: 9000, Protocol: gatewayv1.TCPProtocolType},
		{Name: "udp", Port: 9001, Protocol: gatewayv1.UDPProtocolType},
	})
	httpRoute := &gatewayv1.HTTPRoute{ObjectMeta: metav1.ObjectMeta{Name: "http", Namespace: "ns"}, Spec: gatewayv1.HTTPRouteSpec{CommonRouteSpec: common, Rules: []gatewayv1.HTTPRouteRule{{}}}}
	grpcRoute := &gatewayv1.GRPCRoute{ObjectMeta: metav1.ObjectMeta{Name: "grpc", Namespace: "ns"}, Spec: gatewayv1.GRPCRouteSpec{CommonRouteSpec: common, Rules: []gatewayv1.GRPCRouteRule{{}}}}
	tlsRoute := &gatewayv1.TLSRoute{ObjectMeta: metav1.ObjectMeta{Name: "tls", Namespace: "ns"}, Spec: gatewayv1.TLSRouteSpec{CommonRouteSpec: common, Rules: []gatewayv1.TLSRouteRule{{}}}}
	tcpRoute := &gatewayv1alpha2.TCPRoute{ObjectMeta: metav1.ObjectMeta{Name: "tcp", Namespace: "ns"}, Spec: gatewayv1alpha2.TCPRouteSpec{CommonRouteSpec: common, Rules: []gatewayv1alpha2.TCPRouteRule{{}}}}
	udpRoute := &gatewayv1alpha2.UDPRoute{ObjectMeta: metav1.ObjectMeta{Name: "udp", Namespace: "ns"}, Spec: gatewayv1alpha2.UDPRouteSpec{CommonRouteSpec: common, Rules: []gatewayv1alpha2.UDPRouteRule{{}}}}

	c := verifierClient(
		&corev1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: "ns"}},
		verifierGatewayClass(), verifierGateway("ns", "gw", &fromAll), listenerSet,
		httpRoute, grpcRoute, tlsRoute, tcpRoute, udpRoute,
	)
	if err := verifierReconcile(t, c, "ns", "gw"); err != nil {
		t.Fatalf("reconcile failed: %v", err)
	}

	checks := []struct {
		name string
		read func() []gatewayv1.RouteParentStatus
	}{
		{"HTTPRoute", func() []gatewayv1.RouteParentStatus {
			obj := &gatewayv1.HTTPRoute{}
			if err := c.Get(t.Context(), types.NamespacedName{Namespace: "ns", Name: "http"}, obj); err != nil {
				t.Fatal(err)
			}
			return obj.Status.Parents
		}},
		{"GRPCRoute", func() []gatewayv1.RouteParentStatus {
			obj := &gatewayv1.GRPCRoute{}
			if err := c.Get(t.Context(), types.NamespacedName{Namespace: "ns", Name: "grpc"}, obj); err != nil {
				t.Fatal(err)
			}
			return obj.Status.Parents
		}},
		{"TLSRoute", func() []gatewayv1.RouteParentStatus {
			obj := &gatewayv1.TLSRoute{}
			if err := c.Get(t.Context(), types.NamespacedName{Namespace: "ns", Name: "tls"}, obj); err != nil {
				t.Fatal(err)
			}
			return obj.Status.Parents
		}},
		{"TCPRoute", func() []gatewayv1.RouteParentStatus {
			obj := &gatewayv1alpha2.TCPRoute{}
			if err := c.Get(t.Context(), types.NamespacedName{Namespace: "ns", Name: "tcp"}, obj); err != nil {
				t.Fatal(err)
			}
			return obj.Status.Parents
		}},
		{"UDPRoute", func() []gatewayv1.RouteParentStatus {
			obj := &gatewayv1alpha2.UDPRoute{}
			if err := c.Get(t.Context(), types.NamespacedName{Namespace: "ns", Name: "udp"}, obj); err != nil {
				t.Fatal(err)
			}
			return obj.Status.Parents
		}},
	}
	for _, check := range checks {
		t.Run(check.name, func(t *testing.T) {
			if !verifierParentAccepted(check.read(), "set", listenerSetKind) {
				t.Fatalf("%s was not accepted through ListenerSet parent", check.name)
			}
		})
	}
}

func TestVerifierStage2ReconcileReflectsListenerSetAndRouteChanges(t *testing.T) {
	fromAll := gatewayv1.NamespacesFromAll
	listenerSetKind := gatewayv1.Kind("ListenerSet")
	backendPort := gatewayv1.PortNumber(8080)
	path := "/before"
	pathType := gatewayv1.PathMatchPathPrefix
	listenerSet := verifierListenerSet("ns", "set", "ns", "gw", []gatewayv1.ListenerEntry{{
		Name: "extra", Port: 8080, Protocol: gatewayv1.HTTPProtocolType,
	}})
	route := &gatewayv1.HTTPRoute{
		ObjectMeta: metav1.ObjectMeta{Name: "route", Namespace: "ns"},
		Spec: gatewayv1.HTTPRouteSpec{
			CommonRouteSpec: gatewayv1.CommonRouteSpec{ParentRefs: []gatewayv1.ParentReference{{Kind: &listenerSetKind, Name: "set"}}},
			Rules: []gatewayv1.HTTPRouteRule{{
				Matches: []gatewayv1.HTTPRouteMatch{{Path: &gatewayv1.HTTPPathMatch{Type: &pathType, Value: &path}}},
				BackendRefs: []gatewayv1.HTTPBackendRef{{BackendRef: gatewayv1.BackendRef{BackendObjectReference: gatewayv1.BackendObjectReference{
					Name: "before-backend", Port: &backendPort,
				}}}},
			}},
		},
	}
	c := verifierClient(
		&corev1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: "ns"}},
		verifierGatewayClass(), verifierGateway("ns", "gw", &fromAll), listenerSet, route,
		&corev1.Service{ObjectMeta: metav1.ObjectMeta{Name: "before-backend", Namespace: "ns"}, Spec: corev1.ServiceSpec{Ports: []corev1.ServicePort{{Port: 8080}}}},
		&corev1.Service{ObjectMeta: metav1.ObjectMeta{Name: "after-backend", Namespace: "ns"}, Spec: corev1.ServiceSpec{Ports: []corev1.ServicePort{{Port: 8080}}}},
	)
	if err := verifierReconcile(t, c, "ns", "gw"); err != nil {
		t.Fatalf("initial reconciliation failed: %v", err)
	}
	before := verifierCECSpec(t, c, "ns", "gw")
	if !bytes.Contains(before, []byte("before-backend")) {
		t.Fatalf("initial Route backend missing from configuration: %s", before)
	}

	actualSet := &gatewayv1.ListenerSet{}
	if err := c.Get(t.Context(), types.NamespacedName{Namespace: "ns", Name: "set"}, actualSet); err != nil {
		t.Fatal(err)
	}
	actualSet.Spec.Listeners[0].Port = 8082
	if err := c.Update(t.Context(), actualSet); err != nil {
		t.Fatal(err)
	}
	actualRoute := &gatewayv1.HTTPRoute{}
	if err := c.Get(t.Context(), types.NamespacedName{Namespace: "ns", Name: "route"}, actualRoute); err != nil {
		t.Fatal(err)
	}
	actualRoute.Spec.Rules[0].BackendRefs[0].Name = "after-backend"
	if err := c.Update(t.Context(), actualRoute); err != nil {
		t.Fatal(err)
	}

	if err := verifierReconcile(t, c, "ns", "gw"); err != nil {
		t.Fatalf("reconciliation after input changes failed: %v", err)
	}
	after := verifierCECSpec(t, c, "ns", "gw")
	if bytes.Equal(before, after) || !bytes.Contains(after, []byte("after-backend")) || bytes.Contains(after, []byte("before-backend")) {
		t.Fatalf("reconciliation did not reflect ListenerSet and Route changes: %s", after)
	}
}

func verifierTLSSecret(t *testing.T, namespace, name string) *corev1.Secret {
	t.Helper()
	key, err := rsa.GenerateKey(rand.Reader, 1024)
	if err != nil {
		t.Fatal(err)
	}
	template := &x509.Certificate{
		SerialNumber: big.NewInt(1), Subject: pkix.Name{CommonName: "listenerset.example"},
		NotBefore: time.Now().Add(-time.Hour), NotAfter: time.Now().Add(time.Hour),
		KeyUsage:    x509.KeyUsageDigitalSignature | x509.KeyUsageKeyEncipherment,
		ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		DNSNames:    []string{"listenerset.example"},
	}
	der, err := x509.CreateCertificate(rand.Reader, template, template, &key.PublicKey, key)
	if err != nil {
		t.Fatal(err)
	}
	cert := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der})
	privateKey := pem.EncodeToMemory(&pem.Block{Type: "RSA PRIVATE KEY", Bytes: x509.MarshalPKCS1PrivateKey(key)})
	return &corev1.Secret{
		ObjectMeta: metav1.ObjectMeta{Name: name, Namespace: namespace}, Type: corev1.SecretTypeTLS,
		Data: map[string][]byte{corev1.TLSCertKey: cert, corev1.TLSPrivateKeyKey: privateKey},
	}
}

func TestVerifierStage2ReferencedSecretStateIsReconciled(t *testing.T) {
	fromAll := gatewayv1.NamespacesFromAll
	tlsMode := gatewayv1.TLSModeTerminate
	secretKind := gatewayv1.Kind("Secret")
	host := gatewayv1.Hostname("listenerset.example")
	listenerSet := verifierListenerSet("ns", "set", "ns", "gw", []gatewayv1.ListenerEntry{{
		Name: "https", Port: 8443, Protocol: gatewayv1.HTTPSProtocolType, Hostname: &host,
		TLS: &gatewayv1.ListenerTLSConfig{Mode: &tlsMode, CertificateRefs: []gatewayv1.SecretObjectReference{{Kind: &secretKind, Name: "cert"}}},
	}})
	secret := verifierTLSSecret(t, "ns", "cert")
	c := verifierClient(
		&corev1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: "ns"}},
		verifierGatewayClass(), verifierGateway("ns", "gw", &fromAll), listenerSet, secret,
	)
	if err := verifierReconcile(t, c, "ns", "gw"); err != nil {
		t.Fatalf("reconcile with valid Secret failed: %v", err)
	}
	if !verifierListenerSetAccepted(t, c, "ns", "set") {
		t.Fatal("ListenerSet with valid Secret was not accepted")
	}

	if err := c.Delete(t.Context(), secret); err != nil {
		t.Fatal(err)
	}
	_ = verifierReconcile(t, c, "ns", "gw")
	actual := &gatewayv1.ListenerSet{}
	if err := c.Get(t.Context(), types.NamespacedName{Namespace: "ns", Name: "set"}, actual); err != nil {
		t.Fatal(err)
	}
	resolved := metav1.ConditionUnknown
	for _, listener := range actual.Status.Listeners {
		if listener.Name == "https" {
			resolved = verifierConditionStatus(listener.Conditions, string(gatewayv1.ListenerConditionResolvedRefs))
		}
	}
	if resolved == metav1.ConditionTrue {
		t.Fatal("ListenerSet remained resolved after its referenced Secret was removed")
	}
}

func TestVerifierStage2ListenerSetCannotValidateInvalidGateway(t *testing.T) {
	fromAll := gatewayv1.NamespacesFromAll
	invalidKind := gatewayv1.Kind("InvalidRoute")
	gateway := verifierGateway("ns", "gw", &fromAll)
	gateway.Spec.Listeners[0].AllowedRoutes = &gatewayv1.AllowedRoutes{Kinds: []gatewayv1.RouteGroupKind{{Kind: invalidKind}}}
	listenerSet := verifierListenerSet("ns", "set", "ns", "gw", []gatewayv1.ListenerEntry{{Name: "extra", Port: 8080, Protocol: gatewayv1.HTTPProtocolType}})
	c := verifierClient(&corev1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: "ns"}}, verifierGatewayClass(), gateway, listenerSet)
	_ = verifierReconcile(t, c, "ns", "gw")
	actual := &gatewayv1.Gateway{}
	if err := c.Get(t.Context(), types.NamespacedName{Namespace: "ns", Name: "gw"}, actual); err != nil {
		t.Fatal(err)
	}
	if verifierConditionStatus(actual.Status.Conditions, string(gatewayv1.GatewayConditionAccepted)) == metav1.ConditionTrue ||
		verifierConditionStatus(actual.Status.Conditions, string(gatewayv1.GatewayConditionProgrammed)) == metav1.ConditionTrue {
		t.Fatal("ListenerSet made an invalid Gateway accepted or programmed")
	}
}
