// SPDX-License-Identifier: Apache-2.0
package watchhandlers

import (
	"log/slog"
	"testing"
	"time"

	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/client-go/util/workqueue"
	"sigs.k8s.io/controller-runtime/pkg/client/fake"
	"sigs.k8s.io/controller-runtime/pkg/event"
	"sigs.k8s.io/controller-runtime/pkg/reconcile"
	gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"

	"github.com/cilium/cilium/operator/pkg/gateway-api/helpers"
)

func verifierQueueContains(t *testing.T, q workqueue.TypedRateLimitingInterface[reconcile.Request], want types.NamespacedName) bool {
	t.Helper()
	deadline := time.Now().Add(time.Second)
	for time.Now().Before(deadline) {
		if q.Len() == 0 {
			time.Sleep(time.Millisecond)
			continue
		}
		item, shutdown := q.Get()
		if shutdown {
			return false
		}
		q.Done(item)
		if item.NamespacedName == want {
			return true
		}
	}
	return false
}

func TestVerifierStage3NamespaceLabelTransitionsRequeueGateway(t *testing.T) {
	fromSelector := gatewayv1.NamespacesFromSelector
	gateway := &gatewayv1.Gateway{
		ObjectMeta: metav1.ObjectMeta{Name: "gw", Namespace: "gw-ns"},
		Spec: gatewayv1.GatewaySpec{
			AllowedListeners: &gatewayv1.AllowedListeners{Namespaces: &gatewayv1.ListenerNamespaces{
				From: &fromSelector, Selector: &metav1.LabelSelector{MatchLabels: map[string]string{"team": "infra"}},
			}},
		},
	}
	oldNamespace := &corev1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: "team-ns", Labels: map[string]string{"team": "app"}}}
	matchingNamespace := oldNamespace.DeepCopy()
	matchingNamespace.Labels["team"] = "infra"
	detachedNamespace := matchingNamespace.DeepCopy()
	detachedNamespace.Labels["team"] = "app"

	c := fake.NewClientBuilder().WithScheme(helpers.TestScheme(helpers.AllOptionalKinds)).WithObjects(gateway).Build()
	handler := EnqueueRequestForAllowedNamespace(c, slog.Default())
	want := types.NamespacedName{Namespace: "gw-ns", Name: "gw"}

	qAttach := workqueue.NewTypedRateLimitingQueue(workqueue.DefaultTypedControllerRateLimiter[reconcile.Request]())
	defer qAttach.ShutDown()
	handler.Update(t.Context(), event.UpdateEvent{ObjectOld: oldNamespace, ObjectNew: matchingNamespace}, qAttach)
	if !verifierQueueContains(t, qAttach, want) {
		t.Fatal("label addition did not enqueue the affected Gateway")
	}

	qDetach := workqueue.NewTypedRateLimitingQueue(workqueue.DefaultTypedControllerRateLimiter[reconcile.Request]())
	defer qDetach.ShutDown()
	handler.Update(t.Context(), event.UpdateEvent{ObjectOld: matchingNamespace, ObjectNew: detachedNamespace}, qDetach)
	if !verifierQueueContains(t, qDetach, want) {
		t.Fatal("label removal did not enqueue the affected Gateway")
	}

	unrelatedOld := &corev1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: "other-ns", Labels: map[string]string{"team": "app"}}}
	unrelatedNew := unrelatedOld.DeepCopy()
	unrelatedNew.Labels["team"] = "other"
	qUnrelated := workqueue.NewTypedRateLimitingQueue(workqueue.DefaultTypedControllerRateLimiter[reconcile.Request]())
	defer qUnrelated.ShutDown()
	handler.Update(t.Context(), event.UpdateEvent{ObjectOld: unrelatedOld, ObjectNew: unrelatedNew}, qUnrelated)
	if qUnrelated.Len() != 0 {
		t.Fatal("unrelated namespace update enqueued the Gateway")
	}
}
