#!/usr/bin/env python3
"""Guarantee numeric reward and temporal artifacts after verifier failure."""

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    result = Path(sys.argv[1])
    stage = sys.argv[2]
    result.mkdir(parents=True, exist_ok=True)
    reward_path = result / "reward.json"
    if not reward_path.is_file():
        reward_path.write_text(
            json.dumps(
                {
                    "reward": 0.0,
                    "binary_reward": 0.0,
                    "training_score": 0.0,
                    "valid_trial": 0.0,
                    "stage_complete": 0.0,
                    "critical_checks_passed": 0.0,
                },
                indent=2,
                sort_keys=True,
            )
            + "\n",
            encoding="utf-8",
        )
    events_path = result / "reward-events.json"
    if not events_path.is_file():
        events_path.write_text(
            json.dumps(
                [
                    {
                        "sequence": 1,
                        "stage": stage,
                        "check": "verifier_execution",
                        "passed": False,
                        "weight": 0.0,
                        "critical": True,
                        "failure_reasons": ["verifier did not emit complete reward artifacts"],
                    }
                ],
                indent=2,
                sort_keys=True,
            )
            + "\n",
            encoding="utf-8",
        )
    manifest_path = result / "training_export_manifest.json"
    if not manifest_path.is_file():
        manifest_path.write_text(
            json.dumps(
                {
                    "schema_version": "1.0",
                    "task_family": "cilium-listenerset-integration",
                    "stage": stage,
                    "valid_trial": 0.0,
                    "stage_complete": 0.0,
                    "fallback": True,
                    "artifacts": {
                        reward_path.name: {
                            "sha256": sha256(reward_path),
                            "bytes": reward_path.stat().st_size,
                        },
                        events_path.name: {
                            "sha256": sha256(events_path),
                            "bytes": events_path.stat().st_size,
                        },
                    },
                },
                indent=2,
                sort_keys=True,
            )
            + "\n",
            encoding="utf-8",
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
