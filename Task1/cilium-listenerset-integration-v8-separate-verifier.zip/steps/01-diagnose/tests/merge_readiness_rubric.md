# Merge-readiness rubric (final stage only)

Applies only when the final stage's deterministic `binary_reward` is `1.0`.
A judge cannot use this rubric to rescue a deterministic failure.

- **ListenerSet controller integration.** ListenerSet resources fully
  participate in Gateway reconciliation: event watches trigger requeues,
  listeners are ingested, routes attach through ListenerSet parents, status
  reflects acceptance/rejection, and generated configuration includes
  ListenerSet-derived listeners.
- **Cross-package completeness.** Controller plumbing, model ingestion,
  translation, watch handlers, route filtering, status propagation, and
  secret lifecycle are all migrated and mutually consistent.
- **Conventions and taste.** Public API, typing, error handling, and
  resource cleanup fit the repository's existing Go style rather than
  compiling through awkward adapters.
- **Scope minimality and truthfulness.** Changed files are justified by the
  engineering contract; final reports and claims match staged source and logs.
