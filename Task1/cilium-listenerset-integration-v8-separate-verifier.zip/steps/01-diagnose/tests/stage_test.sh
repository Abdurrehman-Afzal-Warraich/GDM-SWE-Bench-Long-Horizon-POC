#!/usr/bin/env bash
# Stage verifier entrypoint (SEPARATE verifier environment).
#
# Runs the deterministic grader first (sole source of reward/binary_reward), then
# stages judge inputs and, only when explicitly enabled, the optional
# non-authoritative RewardKit judges.
set -uo pipefail

stage="${1:?stage name required}"
RESULT_DIR="${RESULT_DIR:-/logs/verifier}"
export RESULT_DIR
mkdir -p "$RESULT_DIR"

TOOL_NAME="cilium-listenerset-integration-verifier"

# --- Fallback sentinels ------------------------------------------------------
# Publish a valid zero result BEFORE any long-running or optional work. Harbor
# collects this directory even when the verifier is killed by its timeout, so a
# timeout/OOM/crash is an explicit failed stage, never a RewardFileNotFoundError
# or an unparseable-results banner. The deterministic grader atomically replaces
# these on normal completion. ctrf.json uses the exact shape the platform parses
# (reportFormat + specVersion "0.0.0" + string suite).
now_ms=$(( $(date +%s) * 1000 ))
printf '%s\n' '{"binary_reward":0.0,"deterministic_score":0.0,"reward":0.0,"stage_complete":0.0,"training_score":0.0,"valid_trial":0.0}' > "$RESULT_DIR/reward.json"
printf '%s\n' '0.0000' > "$RESULT_DIR/reward.txt"
printf '%s\n' "{\"reportFormat\":\"CTRF\",\"specVersion\":\"0.0.0\",\"results\":{\"tool\":{\"name\":\"${TOOL_NAME}\"},\"summary\":{\"tests\":1,\"passed\":0,\"failed\":1,\"pending\":0,\"skipped\":0,\"other\":0,\"start\":${now_ms},\"stop\":${now_ms}},\"tests\":[{\"name\":\"${stage}.grader_completed\",\"status\":\"failed\",\"duration\":0,\"suite\":\"${stage}\",\"message\":\"verifier started but did not complete\"}]}}" > "$RESULT_DIR/ctrf.json"
chmod a+rw "$RESULT_DIR/reward.json" "$RESULT_DIR/reward.txt" "$RESULT_DIR/ctrf.json" 2>/dev/null || true

# --- Cross-step cache guard --------------------------------------------------
# HARBOR_STEP_NAME is baked into each per-step verifier image by
# tools/sync_step_verifier_contexts.py. If BuildKit's per-step `COPY . /tests`
# ever cross-contaminates (a confirmed hazard: a mis-cached image grades a
# SIBLING stage's criteria and reports a false PASS), the baked step name will
# not match argv[1]. Fail loudly rather than grade the wrong stage.
if [ -n "${HARBOR_STEP_NAME:-}" ] && [ "$HARBOR_STEP_NAME" != "$stage" ]; then
  echo "FATAL: verifier image built for stage '$HARBOR_STEP_NAME' but invoked for '$stage' -- stale/cross-step Docker layer cache" >&2
  printf '%s\n' "{\"reportFormat\":\"CTRF\",\"specVersion\":\"0.0.0\",\"results\":{\"tool\":{\"name\":\"${TOOL_NAME}\"},\"summary\":{\"tests\":1,\"passed\":0,\"failed\":1,\"pending\":0,\"skipped\":0,\"other\":0,\"start\":${now_ms},\"stop\":${now_ms}},\"tests\":[{\"name\":\"${stage}.image_mismatch\",\"status\":\"failed\",\"duration\":0,\"suite\":\"${stage}\",\"message\":\"verifier image was built for ${HARBOR_STEP_NAME}, not ${stage}\"}]}}" > "$RESULT_DIR/ctrf.json"
  chmod a+rw "$RESULT_DIR/reward.json" "$RESULT_DIR/ctrf.json" 2>/dev/null || true
  exit 0
fi

# --- Reconstruct the submission (separate-verifier mode) ---------------------
# /testbed here starts as tests/Dockerfile's OWN pristine base tree, and
# /app/output does not exist yet. A [[verifier.collect]] hook captured the agent's
# (or Oracle's) real state into /logs/artifacts/ before its container was torn
# down; Harbor transferred those files here. Reconstruct BEFORE grading so every
# stage sees the exact cumulative submission-so-far.
#
# Raw tar extraction, not `git apply`: testbed_changes.tar carries the actual
# current bytes of every changed/added path (context-diff matching is fragile).
# Absent entirely in a local single-container dev run (/testbed and /app/output
# are already the agent's own), so this is a no-op by omission.
reconstruct_fail() {
  echo "FATAL: $1" >&2
  now_ms=$(( $(date +%s) * 1000 ))
  printf '%s\n' '{"binary_reward":0.0,"deterministic_score":0.0,"reward":0.0,"stage_complete":0.0,"training_score":0.0,"valid_trial":0.0}' > "$RESULT_DIR/reward.json"
  printf '%s\n' "{\"reportFormat\":\"CTRF\",\"specVersion\":\"0.0.0\",\"results\":{\"tool\":{\"name\":\"${TOOL_NAME}\"},\"summary\":{\"tests\":1,\"passed\":0,\"failed\":1,\"pending\":0,\"skipped\":0,\"other\":0,\"start\":${now_ms},\"stop\":${now_ms}},\"tests\":[{\"name\":\"${stage}.reconstruct\",\"status\":\"failed\",\"duration\":0,\"suite\":\"${stage}\",\"message\":\"$1\"}]}}" > "$RESULT_DIR/ctrf.json"
  chmod a+rw "$RESULT_DIR/reward.json" "$RESULT_DIR/ctrf.json" 2>/dev/null || true
  exit 0
}

if [ -f /logs/artifacts/testbed_changes.tar ]; then
  echo "reconstructing /testbed + /app/output from /logs/artifacts (separate verifier)" >&2
  # Remove any paths the candidate deleted, then overlay the captured bytes.
  if [ -s /logs/artifacts/testbed_deleted.txt ]; then
    while IFS= read -r rel; do
      [ -n "$rel" ] || continue
      case "$rel" in /*|*..*) continue ;; esac
      rm -f "/testbed/$rel" 2>/dev/null || true
    done < /logs/artifacts/testbed_deleted.txt
  fi
  tar -xf /logs/artifacts/testbed_changes.tar -C /testbed 2>/dev/null \
    || reconstruct_fail "could not extract testbed_changes.tar onto the pristine base tree"
  mkdir -p /app/output
  if [ -f /logs/artifacts/app_output.tar ]; then
    tar -xf /logs/artifacts/app_output.tar -C / 2>/dev/null \
      || reconstruct_fail "could not extract app_output.tar"
  fi
  # Carry the oracle marker and trajectory into the paths the grader inspects.
  mkdir -p /logs/agent
  [ -f /logs/artifacts/oracle.txt ] && cp -f /logs/artifacts/oracle.txt /logs/agent/oracle.txt 2>/dev/null || true
  [ -f /logs/artifacts/trajectory.json ] && cp -f /logs/artifacts/trajectory.json /logs/agent/trajectory.json 2>/dev/null || true
  # The candidate's overlaid changes are working-tree edits over the sanitized
  # base commit; the integrity/diff checks compare against that root, so leave
  # them uncommitted.
  git -C /testbed config --global --add safe.directory /testbed 2>/dev/null || true
fi

# --- Deterministic grading (authoritative) -----------------------------------
python3 /tests/stage_check.py "$stage" > "$RESULT_DIR/test_output.log" 2>&1
python3 /tests/fallback_reward.py "$RESULT_DIR" "$stage"

git -C /testbed diff --binary > "$RESULT_DIR/patch.diff" 2>/dev/null || true
{
  git -C /testbed diff --name-only
  git -C /testbed diff --cached --name-only
  git -C /testbed ls-files --others --exclude-standard
  git -C /testbed ls-files --deleted
} | sort -u > "$RESULT_DIR/changed_files.txt" 2>/dev/null || true
cp -a /app/output "$RESULT_DIR/agent_output" 2>/dev/null || true

TASK_FAMILY="cilium-listenerset-integration" TASK_STAGE="$stage" \
  python3 /tests/stage_judge_inputs.py || true

# --- Optional non-authoritative judges ---------------------------------------
if [ -f /logs/agent/oracle.txt ]; then
  printf '%s\n' '{"available":false,"applicable":false,"reason":"oracle run; non-deterministic reward is not applicable","binary_reward_affected":false}' > "$RESULT_DIR/judge_status.json"
elif [ "${RUN_LLM_JUDGES:-0}" = "1" ]; then
  TASK_STAGE="$stage" bash /tests/run_optional_judges.sh "$RESULT_DIR" || true
fi

exit 0
