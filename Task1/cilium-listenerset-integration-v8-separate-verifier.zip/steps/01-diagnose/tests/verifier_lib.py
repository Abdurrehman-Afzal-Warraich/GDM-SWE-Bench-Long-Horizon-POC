from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import tempfile
import time
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

TESTBED = Path('/testbed')
OUTPUT = Path('/app/output')
LOGDIR = Path(os.environ.get('RESULT_DIR', '/logs/verifier'))
HIDDEN = Path('/tests/hidden')
ROUTE_TYPES = {'HTTPRoute', 'GRPCRoute', 'TLSRoute', 'TCPRoute', 'UDPRoute'}
INFRA_PATTERNS = (
    'no space left on device', 'cannot allocate memory', 'signal: killed',
    'exec format error', 'permission denied: \'go\'', 'go: command not found',
    'temporary failure in name resolution', 'could not resolve host',
    'network is unreachable', 'tls handshake timeout', 'i/o timeout',
)

@dataclass
class CommandResult:
    command: list[str]
    returncode: int
    stdout: str
    stderr: str
    duration_sec: float
    infrastructure_failure: bool

    @property
    def combined(self) -> str:
        return self.stdout + ('\n' if self.stdout and self.stderr else '') + self.stderr


def run_command(command: list[str], *, cwd: Path = TESTBED, timeout: int = 1800,
                env: dict[str, str] | None = None, log_name: str | None = None) -> CommandResult:
    safe_env = {
        'PATH': os.environ.get('PATH', '/usr/local/go/bin:/usr/local/bin:/usr/bin:/bin'),
        'HOME': '/tmp/verifier-home',
        'GOTOOLCHAIN': 'local',
        'GONOSUMDB': '*',
        'GOPROXY': 'off',
        'GOSUMDB': 'off',
        'CGO_ENABLED': os.environ.get('CGO_ENABLED', '1'),
        'LANG': 'C.UTF-8',
        'LC_ALL': 'C.UTF-8',
        'GIT_NO_REPLACE_OBJECTS': '1',
    }
    if env:
        safe_env.update(env)
    Path(safe_env['HOME']).mkdir(parents=True, exist_ok=True)
    start = time.monotonic()
    try:
        proc = subprocess.run(command, cwd=cwd, env=safe_env, text=True,
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                              timeout=timeout, check=False)
        rc, out, err = proc.returncode, proc.stdout, proc.stderr
    except subprocess.TimeoutExpired as exc:
        rc = 124
        out = exc.stdout or ''
        err = (exc.stderr or '') + f'\nverifier timeout after {timeout}s'
    duration = time.monotonic() - start
    combined = (out + '\n' + err).lower()
    infra = rc != 0 and any(pattern in combined for pattern in INFRA_PATTERNS)
    result = CommandResult(command, rc, out, err, duration, infra)
    if log_name:
        LOGDIR.mkdir(parents=True, exist_ok=True)
        (LOGDIR/f'{log_name}.command').write_text(' '.join(command)+'\n', encoding='utf-8')
        (LOGDIR/f'{log_name}.log').write_text(result.combined, encoding='utf-8')
        (LOGDIR/f'{log_name}.meta.json').write_text(json.dumps({
            'returncode': rc, 'duration_sec': round(duration, 3),
            'infrastructure_failure': infra,
        }, indent=2)+'\n', encoding='utf-8')
    return result


def read_json(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(data, dict):
        raise ValueError(f'{path} must contain a JSON object')
    return data


def validate_output_file(value: Any, allowed_root: Path, label: str) -> list[str]:
    if not isinstance(value, str) or not value.startswith('/'):
        return [f'{label} must be an absolute path']
    path = Path(value)
    if path.is_symlink():
        return [f'{label} must not be a symlink']
    try:
        resolved = path.resolve(strict=True)
        resolved.relative_to(allowed_root.resolve(strict=True))
    except (OSError, ValueError):
        return [f'{label} must resolve under {allowed_root}']
    if not resolved.is_file():
        return [f'{label} must be a regular file']
    try:
        if resolved.stat().st_nlink != 1:
            return [f'{label} must not be a hard link']
    except OSError as exc:
        return [f'{label} could not be inspected: {exc}']
    return []


def validate_commands(items: Any, allowed_root: Path) -> list[str]:
    errors: list[str] = []
    if not isinstance(items, list) or not items:
        return ['commands_run must be a non-empty array']
    for i, item in enumerate(items):
        if not isinstance(item, dict):
            errors.append(f'commands_run[{i}] must be an object')
            continue
        cmd = item.get('command')
        code = item.get('exit_code')
        if not isinstance(cmd, str) or not cmd.strip():
            errors.append(f'commands_run[{i}].command must be non-empty')
        if not isinstance(code, int) or code != 0:
            errors.append(f'commands_run[{i}].exit_code must be 0')
        errors.extend(validate_output_file(
            item.get('output_file'), allowed_root, f'commands_run[{i}].output_file'
        ))
    return errors



def validate_string_list(value: Any, label: str, *, min_items: int = 0) -> list[str]:
    if not isinstance(value, list) or len(value) < min_items:
        return [f'{label} must contain at least {min_items} entries']
    errors: list[str] = []
    for i, item in enumerate(value):
        if not isinstance(item, str) or not item.strip():
            errors.append(f'{label}[{i}] must be a non-empty string')
    return errors

def validate_artifact(stage: str) -> tuple[bool, dict[str, Any]]:
    paths = {
        'diagnose': OUTPUT/'handoff.json',
        'core': OUTPUT/'02-core/implementation.json',
        'review': OUTPUT/'03-review/review_response.json',
        'harden': OUTPUT/'04-hardening/final_report.json',
    }
    expected_stage = {
        'diagnose': '01-diagnose', 'core': '02-core-routing',
        'review': '03-review-integration', 'harden': '04-failure-hardening',
    }
    path = paths[stage]
    errors: list[str] = []
    try:
        data = read_json(path)
    except Exception as exc:
        return False, {'path': str(path), 'errors': [str(exc)]}
    if data.get('schema_version') != 1:
        errors.append('schema_version must be 1')
    if data.get('stage') != expected_stage[stage]:
        errors.append(f'stage must be {expected_stage[stage]}')

    if stage == 'diagnose':
        for key, value in {
            'base_limitation_reproduced': True,
            'production_source_unchanged': True,
            'resource_kind': 'ListenerSet',
        }.items():
            if data.get(key) != value:
                errors.append(f'{key} must be {value!r}')
        for key in ('missing_behavior', 'observed_outcome', 'reproducer_path'):
            if not isinstance(data.get(key), str) or not data[key].strip():
                errors.append(f'{key} must be non-empty')
        errors.extend(validate_string_list(data.get('root_cause_boundaries'), 'root_cause_boundaries', min_items=1))
        errors.extend(validate_string_list(data.get('preserved_invariants'), 'preserved_invariants', min_items=1))
        errors.extend(validate_string_list(data.get('deferred_work'), 'deferred_work', min_items=1))
        if not ROUTE_TYPES.issubset(set(data.get('affected_route_types', []))):
            errors.append('affected_route_types must include all five supported Route kinds')
        evidence = data.get('evidence_files')
        if not isinstance(evidence, list) or not evidence:
            errors.append('evidence_files must be non-empty')
        else:
            for i, item in enumerate(evidence):
                errors.extend(validate_output_file(
                    item, OUTPUT/'01-diagnose', f'evidence_files[{i}]'
                ))
        twin = OUTPUT/'01-diagnose/diagnosis.json'
        if not twin.is_file():
            errors.append('diagnosis.json is missing')
        else:
            try:
                twin_data = read_json(twin)
                for key in (
                    'schema_version', 'stage', 'base_limitation_reproduced',
                    'production_source_unchanged', 'resource_kind', 'missing_behavior',
                    'observed_outcome', 'root_cause_boundaries', 'affected_route_types',
                    'preserved_invariants', 'deferred_work', 'reproducer_path',
                    'evidence_files',
                ):
                    if twin_data.get(key) != data.get(key):
                        errors.append(f'diagnosis.json and handoff.json disagree on {key}')
            except Exception as exc:
                errors.append(str(exc))
    elif stage == 'core':
        if data.get('stage1_handoff_consumed') is not True:
            errors.append('stage1_handoff_consumed must be true')
        if not ROUTE_TYPES.issubset(set(data.get('implemented_route_types', []))):
            errors.append('implemented_route_types must include all five supported Route kinds')
        errors.extend(validate_string_list(data.get('behaviors_verified'), 'behaviors_verified', min_items=1))
        errors.extend(validate_string_list(data.get('known_deferred_work'), 'known_deferred_work'))
        errors.extend(validate_string_list(data.get('risks'), 'risks'))
        errors.extend(validate_commands(data.get('commands_run'), OUTPUT/'02-core'))
        changed = data.get('changed_files')
        if not isinstance(changed, list) or not changed:
            errors.append('changed_files must be non-empty')
        else:
            for item in changed:
                if not isinstance(item, str) or item.startswith('/') or '..' in Path(item).parts:
                    errors.append(f'invalid repository-relative changed file: {item!r}')
    elif stage == 'review':
        if not ROUTE_TYPES.issubset(set(data.get('route_types_verified', []))):
            errors.append('route_types_verified must include all five supported Route kinds')
        transitions = set(data.get('namespace_transitions_verified', []))
        if not {'attach', 'detach'}.issubset(transitions):
            errors.append('namespace_transitions_verified must include attach and detach')
        items = data.get('feedback_items')
        if not isinstance(items, list) or len(items) < 5:
            errors.append('feedback_items must contain at least five entries')
        else:
            for i, item in enumerate(items):
                if not isinstance(item, dict):
                    errors.append(f'feedback_items[{i}] must be an object')
                    continue
                for key in ('id', 'resolution'):
                    if not isinstance(item.get(key), str) or not item[key].strip():
                        errors.append(f'feedback_items[{i}].{key} must be non-empty')
                errors.extend(validate_string_list(
                    item.get('verification'), f'feedback_items[{i}].verification', min_items=1
                ))
                if not isinstance(item.get('residual_risk'), str):
                    errors.append(f'feedback_items[{i}].residual_risk must be a string')
        errors.extend(validate_commands(data.get('commands_run'), OUTPUT/'03-review'))
    else:
        required_faults = {'first-query-failure', 'late-query-failure', 'multi-listenerset-failure', 'successful-recovery'}
        if not required_faults.issubset(set(data.get('fault_cases_addressed', []))):
            errors.append('fault_cases_addressed is incomplete')
        if not ROUTE_TYPES.issubset(set(data.get('route_types_covered', []))):
            errors.append('route_types_covered must include all five supported Route kinds')
        if data.get('fail_before_publish') is not True:
            errors.append('fail_before_publish must be true')
        errors.extend(validate_string_list(data.get('remaining_risks'), 'remaining_risks'))
        errors.extend(validate_commands(data.get('commands_run'), OUTPUT/'04-hardening'))

    return not errors, {'path': str(path), 'errors': errors}


def verify_binary_integrity() -> tuple[bool, dict[str, Any]]:
    """Check that critical toolchain binaries have not been tampered with."""
    checksums_path = Path('/opt/verifier/binary_checksums.txt')
    if not checksums_path.is_file():
        return False, {'errors': ['binary checksum manifest missing']}
    errors: list[str] = []
    verified: dict[str, str] = {}
    for line in checksums_path.read_text(encoding='utf-8').splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split(None, 1)
        if len(parts) != 2:
            continue
        expected_hash, binary_path = parts
        result = run_command(['sha256sum', binary_path], timeout=30)
        if result.returncode != 0:
            errors.append(f'cannot compute hash of {binary_path}')
            continue
        actual_hash = result.stdout.split()[0] if result.stdout else ''
        if actual_hash != expected_hash:
            errors.append(f'{binary_path} has been modified (expected {expected_hash[:12]}..., got {actual_hash[:12]}...)')
        verified[binary_path] = 'ok' if actual_hash == expected_hash else 'tampered'
    return not errors, {'verified': verified, 'errors': errors}


def root_commit() -> str:
    result = run_command(['git', 'rev-list', '--max-parents=0', 'HEAD'], timeout=30)
    roots = [line for line in result.stdout.splitlines() if line.strip()]
    if result.returncode != 0 or len(roots) != 1:
        raise RuntimeError('unable to resolve exactly one immutable repository root commit')
    return roots[0]


def base_tree_matches(root: str) -> tuple[bool, dict[str, Any]]:
    expected_path = Path('/opt/verifier/base_tree')
    if not expected_path.is_file():
        return False, {
            'manifest_present': False,
            'errors': ['missing verifier-owned base tree manifest'],
        }
    expected = expected_path.read_text(encoding='utf-8').strip()
    actual_result = run_command(['git', 'rev-parse', f'{root}^{{tree}}'], timeout=30)
    actual = actual_result.stdout.strip()
    return actual_result.returncode == 0 and bool(expected) and actual == expected, {
        'manifest_present': True,
        'expected_tree': expected,
        'actual_tree': actual,
        'returncode': actual_result.returncode,
    }


def production_tree_unchanged() -> tuple[bool, dict[str, Any], bool]:
    try:
        root = root_commit()
    except Exception as exc:
        return False, {'errors': [str(exc)]}, True
    base_ok, base_ev = base_tree_matches(root)
    diff = run_command(
        ['git', 'diff', '--no-ext-diff', '--quiet', root, '--', '.'], timeout=120
    )
    untracked = run_command(['git', 'ls-files', '--others', '--exclude-standard'], timeout=120)
    index_flags = run_command(['git', 'ls-files', '-v'], timeout=120)
    index_flag_violations = sorted(
        line for line in index_flags.stdout.splitlines()
        if line and (line[0].islower() or line[0] == 'S')
    )
    # Diagnose forbids modifying PRODUCTION source, not adding a throwaway probe.
    # Reproducing a Go controller gap needs an in-package *_test.go to reach
    # unexported symbols -- exactly the technique the Oracle uses (it just cleans
    # its probe up afterward). New untracked test files are therefore tolerated
    # here: they cannot alter production behaviour (Go excludes _test.go from the
    # built binary) and the scoring probe is verifier-owned, so they enable no
    # cheating. Any change to a TRACKED production file is still caught by the
    # `git diff --quiet` check above.
    untracked_files = [line.strip() for line in untracked.stdout.splitlines() if line.strip()]
    ignored_untracked_tests = sorted(f for f in untracked_files if f.endswith('_test.go'))
    disallowed_untracked = sorted(f for f in untracked_files if not f.endswith('_test.go'))
    infra = (
        not bool(base_ev.get('manifest_present'))
        or diff.infrastructure_failure
        or untracked.infrastructure_failure
        or index_flags.infrastructure_failure
    )
    clean = (
        base_ok
        and diff.returncode == 0
        and untracked.returncode == 0
        and index_flags.returncode == 0
        and not disallowed_untracked
        and not index_flag_violations
    )
    return clean, {
        'root_commit': root,
        'base_tree': base_ev,
        'diff_exit_code': diff.returncode,
        'untracked_returncode': untracked.returncode,
        'untracked': untracked_files,
        'ignored_untracked_tests': ignored_untracked_tests,
        'disallowed_untracked': disallowed_untracked,
        'index_flag_violations': index_flag_violations,
    }, infra


@contextmanager
def injected_files(mapping: dict[str, str]):
    created: list[Path] = []
    try:
        for source_name, destination in mapping.items():
            source = HIDDEN/source_name
            dest = TESTBED/destination
            if not source.is_file():
                raise FileNotFoundError(source)
            if dest.exists():
                raise RuntimeError(f'hidden-test destination already exists: {dest}')
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, dest)
            created.append(dest)
        yield
    finally:
        for path in created:
            path.unlink(missing_ok=True)


def parse_go_json(output: str) -> dict[str, Any]:
    passed: set[str] = set()
    failed: set[str] = set()
    packages_failed: set[str] = set()
    events = 0
    for line in output.splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if not isinstance(event, dict):
            continue
        events += 1
        action = event.get('Action')
        test = event.get('Test')
        package = event.get('Package')
        if test and action == 'pass':
            passed.add(test)
        elif test and action == 'fail':
            failed.add(test)
        elif not test and package and action == 'fail':
            packages_failed.add(package)
    return {
        'events': events,
        'passed_tests': sorted(passed),
        'failed_tests': sorted(failed),
        'failed_packages': sorted(packages_failed),
    }


def run_go_suite(*, stage: str, mapping: dict[str, str], expected_tests: Iterable[str], timeout: int) -> tuple[bool, dict[str, Any], bool]:
    command = [
        'go', 'test', '-json', '-count=1',
        './operator/pkg/gateway-api/...',
        './operator/pkg/model/ingestion/...',
        './operator/pkg/model/translation/gateway-api/...',
    ]
    with injected_files(mapping):
        result = run_command(command, timeout=timeout, log_name=f'{stage}_go_suite')
    parsed = parse_go_json(result.stdout)
    expected = set(expected_tests)
    passed = set(parsed['passed_tests'])
    missing = sorted(expected - passed)
    ok = result.returncode == 0 and parsed['events'] > 0 and not missing and not parsed['failed_tests'] and not parsed['failed_packages']
    evidence = {
        'returncode': result.returncode,
        'duration_sec': round(result.duration_sec, 3),
        'expected_tests': sorted(expected),
        'missing_expected_tests': missing,
        **parsed,
        'log': str(LOGDIR/f'{stage}_go_suite.log'),
    }
    return ok, evidence, result.infrastructure_failure


def run_single_go_test(*, stage: str, source_name: str, destination: str,
                       package: str, expected_test: str, timeout: int = 900) -> tuple[bool, dict[str, Any], bool]:
    command = ['go', 'test', '-json', '-count=1', '-run', f'^{re.escape(expected_test)}$', package]
    with injected_files({source_name: destination}):
        result = run_command(command, timeout=timeout, log_name=f'{stage}_{expected_test}')
    parsed = parse_go_json(result.stdout)
    ok = result.returncode == 0 and expected_test in parsed['passed_tests'] and not parsed['failed_tests'] and not parsed['failed_packages']
    return ok, {'returncode': result.returncode, **parsed, 'log': str(LOGDIR/f'{stage}_{expected_test}.log')}, result.infrastructure_failure


def scan_trajectory_integrity() -> tuple[bool, dict[str, Any]]:
    """Deterministic trajectory scanner: fails agent if forbidden network/install commands detected."""
    candidates = [
        Path('/logs/agent/trajectory.json'),
        Path('/logs/artifacts/trajectory.json'),
        Path('/logs/trajectory.json'),
        Path('/app/trajectory.json'),
    ]
    trajectory = next((p for p in candidates if p.is_file()), None)
    if trajectory is None:
        if Path('/logs/agent/oracle.txt').is_file():
            return True, {'trajectory': 'not available (oracle run)', 'commands_audited': 0, 'violations': []}
        return True, {'trajectory': 'not available', 'commands_audited': 0, 'violations': []}

    forbidden = re.compile(
        r'^\s*(?:curl|wget|git\s+(?:clone|fetch|pull|remote|reflog)|'
        r'pip\s+install|go\s+(?:install|get)|apt(?:-get)?\s+install)\b',
        re.I | re.M,
    )
    try:
        payload = json.loads(trajectory.read_text(encoding='utf-8', errors='replace'))
    except Exception as exc:
        return False, {'trajectory': str(trajectory), 'error': repr(exc)}

    commands: list[str] = []

    def walk(node: Any) -> None:
        if isinstance(node, dict):
            for key in ('command', 'cmd', 'shell_command', 'text'):
                val = node.get(key)
                if isinstance(val, str) and val.strip():
                    commands.append(val)
            for val in node.values():
                walk(val)
        elif isinstance(node, list):
            for item in node:
                walk(item)

    walk(payload)
    violations = sorted({cmd.strip() for cmd in commands if forbidden.search(cmd)})
    return not violations, {
        'trajectory': str(trajectory),
        'commands_audited': len(commands),
        'violations': violations,
    }
