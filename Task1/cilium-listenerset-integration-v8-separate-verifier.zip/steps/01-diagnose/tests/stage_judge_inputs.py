#!/usr/bin/env python3
"""Stage bounded, post-run evidence for optional semantic judges."""

from __future__ import annotations

import json
import os
import shutil
from pathlib import Path


RESULT = Path(os.environ.get("RESULT_DIR", "/logs/verifier"))
TESTBED = Path(os.environ.get("TESTBED_DIR", "/testbed"))
OUTPUT = Path(os.environ.get("OUTPUT_DIR", "/app/output"))
TESTS = Path(__file__).resolve().parent
DEST = RESULT / "judge_inputs"


def copy_file(source: Path, destination: Path) -> None:
    if source.is_file() and not source.is_symlink():
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)


def find_trajectory() -> Path | None:
    candidates = [
        os.environ.get("TRAJECTORY_PATH", ""),
        "/logs/agent/trajectory.json",
        "/logs/artifacts/trajectory.json",
        "/logs/trajectory.json",
        "/app/trajectory.json",
        "/logs/agent/terminus_2.pane",
        "/logs/agent/claude-code.txt",
    ]
    for candidate in candidates:
        path = Path(candidate) if candidate else None
        if path and path.is_file():
            return path
    return None


def instruction_from_trajectory(path: Path) -> str:
    try:
        payload = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return ""
    strings: list[str] = []

    def walk(value: object) -> None:
        if isinstance(value, str):
            strings.append(value)
        elif isinstance(value, dict):
            for child in value.values():
                walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)

    walk(payload)
    for text in strings:
        marker = "Task Description:"
        if marker not in text:
            continue
        task = text.split(marker, 1)[1]
        for ending in ("\n\nCurrent terminal state:", "\nCurrent terminal state:"):
            if ending in task:
                task = task.split(ending, 1)[0]
                break
        if task.strip():
            return task.strip() + "\n"
    return ""


def copy_changed_sources() -> dict[str, object]:
    copied: list[str] = []
    skipped: list[str] = []
    total = 0
    changed_file = RESULT / "changed_files.txt"
    if not changed_file.is_file():
        return {"copied": copied, "skipped": skipped, "bytes": total}
    for raw in changed_file.read_text(encoding="utf-8", errors="replace").splitlines():
        rel = Path(raw.strip())
        if not raw.strip() or rel.is_absolute() or ".." in rel.parts:
            continue
        source = TESTBED / rel
        if source.is_symlink():
            skipped.append(str(rel) + ":symlink")
            continue
        try:
            size = source.stat().st_size
        except OSError:
            skipped.append(str(rel))
            continue
        if size > 524_288 or total + size > 4_194_304:
            skipped.append(str(rel))
            continue
        data = source.read_bytes()
        if b"\0" in data:
            skipped.append(str(rel))
            continue
        copy_file(source, DEST / "source" / rel)
        copied.append(str(rel))
        total += size
    return {"copied": copied, "skipped": skipped, "bytes": total}


def copy_agent_output() -> dict[str, object]:
    """Copy bounded regular files only; never follow agent-created links."""
    copied: list[str] = []
    skipped: list[str] = []
    total = 0
    if not OUTPUT.is_dir() or OUTPUT.is_symlink():
        return {"copied": copied, "skipped": skipped, "bytes": total}
    for root, dirs, files in os.walk(OUTPUT, followlinks=False):
        root_path = Path(root)
        linked_dirs = [name for name in dirs if (root_path / name).is_symlink()]
        for name in linked_dirs:
            skipped.append(str((root_path / name).relative_to(OUTPUT)) + ":symlink")
        dirs[:] = [name for name in dirs if name not in linked_dirs]
        for name in files:
            source = root_path / name
            rel = source.relative_to(OUTPUT)
            if source.is_symlink():
                skipped.append(str(rel) + ":symlink")
                continue
            try:
                source_stat = source.stat()
                size = source_stat.st_size
            except OSError:
                skipped.append(str(rel) + ":unreadable")
                continue
            if source_stat.st_nlink > 1:
                skipped.append(str(rel) + ":hardlink")
                continue
            if size > 524_288 or total + size > 4_194_304:
                skipped.append(str(rel) + ":size")
                continue
            copy_file(source, DEST / "agent_output" / rel)
            copied.append(str(rel))
            total += size
    return {"copied": copied, "skipped": skipped, "bytes": total}


_STAGE_INSTRUCTION_DIRS = {
    "diagnose": "01-diagnose",
    "core": "02-core-routing",
    "review": "03-review-integration",
    "harden": "04-failure-hardening",
}


def main() -> int:
    shutil.rmtree(DEST, ignore_errors=True)
    DEST.mkdir(parents=True)
    for name in (
        "reward.json",
        "reward-details.json",
        "reward-events.json",
        "reward.txt",
        "test_output.log",
        "patch.diff",
        "changed_files.txt",
        "training_export_manifest.json",
    ):
        copy_file(RESULT / name, DEST / name)
    output_manifest = copy_agent_output()
    copy_file(TESTS / "judge_prompt.md", DEST / "judge_prompt.md")
    copy_file(TESTS / "merge_readiness_rubric.md", DEST / "merge_readiness_rubric.md")

    trajectory = find_trajectory()
    if trajectory:
        copy_file(trajectory, DEST / "trajectory.json")
    stage = os.environ.get("TASK_STAGE", "unknown")
    stage_dir = _STAGE_INSTRUCTION_DIRS.get(stage, stage if stage[:2].isdigit() else "")
    instruction_candidates = [
        Path(os.environ.get("TASK_INSTRUCTION_PATH", "")),
        TESTS.parent / "steps" / stage_dir / "instruction.md" if stage_dir else Path(""),
        Path("/task/instruction.md"),
        Path("/instruction.md"),
        TESTS.parent / "instruction.md",
    ]
    instruction = next((path for path in instruction_candidates if str(path) and path.is_file()), None)
    if instruction:
        copy_file(instruction, DEST / "instruction.md")
    elif trajectory:
        extracted = instruction_from_trajectory(trajectory)
        if extracted:
            (DEST / "instruction.md").write_text(extracted, encoding="utf-8")

    source_manifest = copy_changed_sources()
    reward = {}
    reward_details = {}
    try:
        reward = json.loads((RESULT / "reward.json").read_text(encoding="utf-8"))
    except Exception:
        pass
    try:
        reward_details = json.loads(
            (RESULT / "reward-details.json").read_text(encoding="utf-8")
        )
    except Exception:
        pass
    deterministic_failures = {
        name: {
            "detail": check.get("detail"),
            "failure_reasons": check.get("failure_reasons", []),
            "requirements": check.get("requirements"),
            "failed_requirements": check.get("failed_requirements", []),
        }
        for name, check in reward_details.get("checks", {}).items()
        if isinstance(check, dict) and not check.get("passed")
    }
    context = {
        "task_family": os.environ.get("TASK_FAMILY", "cilium-listenerset-integration"),
        "stage": os.environ.get("TASK_STAGE", "unknown"),
        "deterministic_binary_reward": reward.get("binary_reward", reward.get("reward", 0.0)),
        "deterministic_training_score": reward.get("training_score", 0.0),
        "deterministic_failures": deterministic_failures,
        "deterministic_failure_policy": (
            "The binary outcome is immutable, but these machine-generated reasons "
            "must be independently classified from supplied evidence as a model miss, "
            "prompt ambiguity, verifier defect, environment/build issue, timeout, "
            "contamination, or invalid shortcut."
        ),
        "judge_role": (
            "independent failure-classification and quality review; never a binary "
            "reward override"
        ),
        "source_snapshot": source_manifest,
        "agent_output_snapshot": output_manifest,
        "instruction_available": (DEST / "instruction.md").is_file(),
    }
    (DEST / "judge_context.json").write_text(
        json.dumps(context, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (RESULT / "judge_status.json").write_text(
        json.dumps(
            {
                "available": False,
                "reason": "not requested; set RUN_LLM_JUDGES=1 and provide GEMINI_API_KEY to the verifier",
                "binary_reward_affected": False,
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
