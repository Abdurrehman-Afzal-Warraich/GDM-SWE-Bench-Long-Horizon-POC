# Deterministic Verifier Design

Each stage uses a promotion threshold of `0.6`; deterministic checks still report their full weighted result.

## Authority

1. Verifier-owned executable behavior tests using Kubernetes API objects and the repository's existing reconciliation entrypoint.
2. Repository regression tests executed with the verifier-owned Go binary and offline environment.
3. Typed stage artifacts as supporting evidence only.

The hidden suites do not require a PR-added helper name, indexer function name, private data type, source string, error wording, changed-file count, or Oracle patch shape. Existing reconciliation and already-registered event-handler entrypoints may be invoked as stable repository behavior, but no candidate-introduced helper, index, private type, or patch structure is required. The candidate is free to organize all new implementation details differently behind those existing entrypoints.

## Stage 1

- Confirm that the vendored API recognizes ListenerSet.
- Independently demonstrate that the base controller does not apply ListenerSet status or ListenerSet-derived configuration.
- Execute the submitted reproducer from its required output directory.
- Confirm the repository remains unchanged.
- Validate both diagnosis artifacts and their evidence files.

## Stage 2

Verifier-owned reconciliation tests cover:

- all `allowedListeners` modes;
- ListenerSet status and generated configuration;
- all five Route kinds attaching through ListenerSet parents without Stage 3 section, port, or hostname edge cases;
- referenced-Secret state on reconciliation;
- independence of Gateway validity from ListenerSet validity;
- the affected repository regression scope.

API type registration alone is not scored because it is already present at the base revision. Stage 3 edge cases are not Stage 2 blockers.

## Stage 3

Cumulative Stage 2 tests plus verifier-owned tests cover:

- a Route whose hostname matches only its ListenerSet listener;
- same-name Gateway and ListenerSet parent identity;
- section-name and port constraints across all five Route kinds, checked independently through generated configuration;
- namespace label attach and detach events through the registered namespace event handler;
- an explicit negative Route status for a ListenerSet rejected by `allowedListeners`;
- the affected repository regression scope.

## Stage 4

Cumulative Stage 2 and 3 tests plus an injected-client suite cover:

- every supported Route-list type;
- early and later retrieval failures;
- multiple ListenerSets;
- preservation of the original error through wrapping, plus semantic Route-kind and affected-ListenerSet identifiers without requiring exact message text;
- unchanged previously published configuration;
- successful retry after fault removal.

Fault injection is based on requested Kubernetes list types, not private index names or a per-ListenerSet query shape.

## False-result controls

- Hidden tests are copied only for verifier execution and removed afterward.
- Exact expected hidden test names must appear as passed in structured `go test -json` output.
- Zero-test, compile-only, cached-log, and candidate-wrapper passes are rejected.
- Committed, staged, unstaged, and untracked changes are included in integrity checks.
- Infrastructure failures produce an invalid zero rather than a candidate failure or promotable partial score.
- Artifact prose cannot rescue failed executable behavior; a missing handoff is capped below the stage promotion threshold.
