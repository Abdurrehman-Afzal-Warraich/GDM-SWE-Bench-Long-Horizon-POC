# Stage 1 Oracle

Runs a verifier-style temporary Go test against the immutable base, proves that ListenerSet is not registered in the all-optional Gateway API scheme, removes the temporary test, and writes the typed diagnosis handoff.

The production tree remains unchanged.
