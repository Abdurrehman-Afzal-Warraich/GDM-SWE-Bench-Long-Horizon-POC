#!/usr/bin/env bash
set -euo pipefail

TESTBED=/testbed
OUT=/app/output/01-diagnose
HANDOFF=/app/output/handoff.json
PROBE="$TESTBED/operator/pkg/gateway-api/oracle_stage1_behavior_test.go"
mkdir -p "$OUT" /logs/agent
touch /logs/agent/oracle.txt
cd "$TESTBED"

before_status="$OUT/git-status-before.txt"
after_status="$OUT/git-status-after.txt"
git status --porcelain=v1 --untracked-files=all > "$before_status"
if [ -s "$before_status" ]; then
  echo "Stage 1 Oracle requires the untouched base worktree" >&2
  cat "$before_status" >&2
  exit 1
fi

cat > "$OUT/reproduce.sh" <<'REPRO'
#!/usr/bin/env bash
set -euo pipefail
TESTBED=/testbed
OUT=/app/output/01-diagnose
PROBE="$TESTBED/operator/pkg/gateway-api/oracle_stage1_behavior_test.go"
cleanup() { rm -f "$PROBE"; }
trap cleanup EXIT INT TERM
cat > "$PROBE" <<'GOEOF'
// SPDX-License-Identifier: Apache-2.0
package gateway_api

import (
	"context"
	"encoding/json"
	"log/slog"
	"strings"
	"testing"

	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	ctrl "sigs.k8s.io/controller-runtime"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/client/fake"
	gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"

	"github.com/cilium/cilium/operator/pkg/gateway-api/helpers"
	"github.com/cilium/cilium/operator/pkg/model/translation"
	gatewayApiTranslation "github.com/cilium/cilium/operator/pkg/model/translation/gateway-api"
	ciliumv2 "github.com/cilium/cilium/pkg/k8s/apis/cilium.io/v2"
	"github.com/cilium/cilium/pkg/shortener"
)

type verifierStage1ListAllClient struct{ client.Client }

func (c *verifierStage1ListAllClient) List(ctx context.Context, list client.ObjectList, _ ...client.ListOption) error {
	return c.Client.List(ctx, list)
}

func verifierStage1Translator() translation.Translator {
	cec := translation.NewCECTranslator(translation.Config{
		SecretsNamespace:          "cilium-secrets",
		RouteConfig:               translation.RouteConfig{HostNameSuffixMatch: true},
		ListenerConfig:            translation.ListenerConfig{StreamIdleTimeoutSeconds: 300},
		ClusterConfig:             translation.ClusterConfig{IdleTimeoutSeconds: 60},
		OriginalIPDetectionConfig: translation.OriginalIPDetectionConfig{UseRemoteAddress: true},
	})
	return gatewayApiTranslation.NewTranslator(cec, translation.Config{
		ServiceConfig:             translation.ServiceConfig{ExternalTrafficPolicy: string(corev1.ServiceExternalTrafficPolicyCluster)},
		OriginalIPDetectionConfig: translation.OriginalIPDetectionConfig{UseRemoteAddress: true},
	})
}

func TestVerifierStage1BaseLacksListenerSetControllerIntegration(t *testing.T) {
	scheme := helpers.TestScheme(helpers.AllOptionalKinds)
	gvk := gatewayv1.SchemeGroupVersion.WithKind("ListenerSet")
	if !scheme.Recognizes(gvk) {
		t.Fatalf("test precondition failed: vendored Gateway API must register %s", gvk)
	}

	fromAll := gatewayv1.NamespacesFromAll
	directHost := gatewayv1.Hostname("direct.stage1.example")
	listenerSetHost := gatewayv1.Hostname("listenerset.stage1.example")
	listenerSetKind := gatewayv1.Kind("ListenerSet")

	objects := []client.Object{
		&corev1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: "ns"}},
		&gatewayv1.GatewayClass{
			ObjectMeta: metav1.ObjectMeta{Name: "class"},
			Spec:       gatewayv1.GatewayClassSpec{ControllerName: gatewayv1.GatewayController(defaultControllerName)},
		},
		&gatewayv1.Gateway{
			ObjectMeta: metav1.ObjectMeta{Name: "gw", Namespace: "ns"},
			Spec: gatewayv1.GatewaySpec{
				GatewayClassName: "class",
				AllowedListeners: &gatewayv1.AllowedListeners{Namespaces: &gatewayv1.ListenerNamespaces{From: &fromAll}},
				Listeners:        []gatewayv1.Listener{{Name: "direct", Port: 80, Protocol: gatewayv1.HTTPProtocolType, Hostname: &directHost}},
			},
		},
		&gatewayv1.ListenerSet{
			ObjectMeta: metav1.ObjectMeta{Name: "set", Namespace: "ns"},
			Spec: gatewayv1.ListenerSetSpec{
				ParentRef: gatewayv1.ParentGatewayReference{Name: "gw"},
				Listeners: []gatewayv1.ListenerEntry{{Name: "extra", Port: 8080, Protocol: gatewayv1.HTTPProtocolType, Hostname: &listenerSetHost}},
			},
		},
		&gatewayv1.HTTPRoute{
			ObjectMeta: metav1.ObjectMeta{Name: "route", Namespace: "ns"},
			Spec: gatewayv1.HTTPRouteSpec{
				CommonRouteSpec: gatewayv1.CommonRouteSpec{ParentRefs: []gatewayv1.ParentReference{{Kind: &listenerSetKind, Name: "set"}}},
				Hostnames:       []gatewayv1.Hostname{listenerSetHost},
				Rules:           []gatewayv1.HTTPRouteRule{{}},
			},
		},
	}

	base := fake.NewClientBuilder().
		WithScheme(scheme).
		WithObjects(objects...).
		WithStatusSubresource(&corev1.Service{}, &corev1.Namespace{}, &gatewayv1.Gateway{}, &gatewayv1.GatewayClass{}, &gatewayv1.ListenerSet{}, &gatewayv1.HTTPRoute{}).
		Build()
	c := &verifierStage1ListAllClient{Client: base}
	r := &gatewayReconciler{Client: c, Scheme: scheme, translator: verifierStage1Translator(), logger: slog.Default(), controllerName: defaultControllerName}

	if _, err := r.Reconcile(t.Context(), ctrl.Request{NamespacedName: types.NamespacedName{Namespace: "ns", Name: "gw"}}); err != nil {
		t.Fatalf("base Gateway reconciliation failed: %v", err)
	}

	actualSet := &gatewayv1.ListenerSet{}
	if err := c.Get(t.Context(), types.NamespacedName{Namespace: "ns", Name: "set"}, actualSet); err != nil {
		t.Fatal(err)
	}
	if len(actualSet.Status.Conditions) != 0 || len(actualSet.Status.Listeners) != 0 {
		t.Fatalf("base unexpectedly reconciled ListenerSet status: %#v", actualSet.Status)
	}

	cec := &ciliumv2.CiliumEnvoyConfig{}
	cecName := shortener.ShortenK8sResourceName(gatewayApiTranslation.CiliumGatewayPrefix + "gw")
	if err := c.Get(t.Context(), types.NamespacedName{Namespace: "ns", Name: cecName}, cec); err != nil {
		t.Fatal(err)
	}
	encoded, err := json.Marshal(cec.Spec)
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(string(encoded), string(listenerSetHost)) {
		t.Fatalf("base unexpectedly included ListenerSet-derived configuration: %s", encoded)
	}
}
GOEOF

gofmt -w "$PROBE"
cd "$TESTBED"
GOPROXY=off GOSUMDB=off GOTOOLCHAIN=local go test -json -count=1 \
  -run '^TestVerifierStage1BaseLacksListenerSetControllerIntegration$' \
  ./operator/pkg/gateway-api 2>&1 | tee "$OUT/reproducer.log"

# Emit the typed observation the verifier independently parses (F01): the probe
# passing proves the base recognizes the ListenerSet type yet never reconciles
# its status and produces no ListenerSet-derived configuration.
if grep '"Test":"TestVerifierStage1BaseLacksListenerSetControllerIntegration"' "$OUT/reproducer.log" | grep -q '"Action":"pass"'; then
  echo '##OBSERVATION## {"listenerset_recognized": true, "listenerset_status_reconciled": false, "listenerset_config_present": false}'
else
  echo "reproducer probe did not demonstrate the base limitation" >&2
  exit 1
fi
REPRO
chmod 0755 "$OUT/reproduce.sh"
"$OUT/reproduce.sh"

git status --porcelain=v1 --untracked-files=all > "$after_status"
if [ -s "$after_status" ]; then
  echo "Stage 1 Oracle left repository changes behind" >&2
  cat "$after_status" >&2
  exit 1
fi

python3 - <<'PYJSON'
import json
from pathlib import Path
payload = {
    "schema_version": 1,
    "stage": "01-diagnose",
    "base_limitation_reproduced": True,
    "production_source_unchanged": True,
    "resource_kind": "ListenerSet",
    "missing_behavior": "ListenerSet resources do not participate in Gateway reconciliation at the base revision.",
    "observed_outcome": "The API type is recognized, but ListenerSet status remains untouched and ListenerSet-derived configuration is absent.",
    "root_cause_boundaries": [
        "Gateway controller event and reconciliation integration",
        "ListenerSet attachment, route selection, status, and configuration generation",
    ],
    "affected_route_types": ["HTTPRoute", "GRPCRoute", "TLSRoute", "TCPRoute", "UDPRoute"],
    "preserved_invariants": [
        "Existing direct-Gateway routing and status behavior",
        "Existing GAMMA behavior",
    ],
    "deferred_work": [
        "Implement ListenerSet participation in Gateway reconciliation",
        "Add regression coverage for attachment, routing, status, and failure behavior",
    ],
    "reproducer_path": "/app/output/01-diagnose/reproduce.sh",
    "evidence_files": [
        "/app/output/01-diagnose/reproducer.log",
        "/app/output/01-diagnose/git-status-before.txt",
        "/app/output/01-diagnose/git-status-after.txt"
    ]
}
for target in [Path("/app/output/handoff.json"), Path("/app/output/01-diagnose/diagnosis.json")]:
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
PYJSON

echo "Stage 1 Oracle completed"
