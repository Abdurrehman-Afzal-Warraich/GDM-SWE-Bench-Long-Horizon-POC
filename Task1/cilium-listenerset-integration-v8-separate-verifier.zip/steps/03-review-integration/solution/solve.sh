#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TESTBED=/testbed
OUT=/app/output/03-review
mkdir -p "$OUT/logs" /logs/agent
touch /logs/agent/oracle.txt

[ -r /app/output/02-core/implementation.json ] || {
  echo "missing Stage 2 implementation report" >&2
  exit 1
}

python3 - <<'PY'
import json
from pathlib import Path
p = Path('/app/output/02-core/implementation.json')
data = json.loads(p.read_text(encoding='utf-8'))
if data.get('stage') != '02-core-routing':
    raise SystemExit('invalid Stage 2 implementation report')
required = {'HTTPRoute', 'GRPCRoute', 'TLSRoute', 'TCPRoute', 'UDPRoute'}
if set(data.get('implemented_route_types', [])) != required:
    raise SystemExit('Stage 2 implementation report does not cover all supported Route kinds')
PY

cd "$TESTBED"
python3 "$SCRIPT_DIR/apply_review_fixes.py"
gofmt -w \
  operator/pkg/gateway-api/gateway_reconcile.go \
  operator/pkg/gateway-api/helpers/routes.go \
  operator/pkg/gateway-api/helpers/routes_listenerset_identity_test.go \
  operator/pkg/gateway-api/watch-handlers/namespaces.go \
  operator/pkg/gateway-api/watch-handlers/namespaces_listenerset_test.go \
  operator/pkg/model/ingestion/gateway.go \
  operator/pkg/model/ingestion/gateway_listenerset_parentref_test.go

git diff --check

run_logged() {
  local name="$1"
  shift
  local log="$OUT/logs/$name.log"
  printf '%q ' "$@" > "$OUT/logs/$name.command"
  printf '\n' >> "$OUT/logs/$name.command"
  set +e
  "$@" >"$log" 2>&1
  local rc=$?
  set -e
  printf '%s\n' "$rc" > "$OUT/logs/$name.exit_code"
  cat "$log"
  [ "$rc" -eq 0 ]
}

run_logged helper_identity_test \
  go test ./operator/pkg/gateway-api/helpers \
    -run '^TestIsParentAttachableDistinguishesSameNameListenerSet$' \
    -count=1
run_logged namespace_transition_test \
  go test ./operator/pkg/gateway-api/watch-handlers \
    -run '^TestGatewayAllowsListenerSetNamespaceSelectorTransitions$' \
    -count=1
run_logged parent_port_test \
  go test ./operator/pkg/model/ingestion \
    -run '^TestListenerWithContextHonorsParentPort$' \
    -count=1
run_logged gateway_api_tests \
  go test ./operator/pkg/gateway-api/... -count=1
run_logged model_tests \
  go test ./operator/pkg/model/ingestion/... ./operator/pkg/model/translation/gateway-api/... -count=1

git add \
  operator/pkg/gateway-api/gateway_reconcile.go \
  operator/pkg/gateway-api/helpers/routes.go \
  operator/pkg/gateway-api/helpers/routes_listenerset_identity_test.go \
  operator/pkg/gateway-api/watch-handlers/namespaces.go \
  operator/pkg/gateway-api/watch-handlers/namespaces_listenerset_test.go \
  operator/pkg/model/ingestion/gateway.go \
  operator/pkg/model/ingestion/gateway_listenerset_parentref_test.go

git config user.name "Tier 2 Oracle"
git config user.email "oracle@invalid"
if ! git diff --cached --quiet; then
  git commit -m "gatewayapi: close ListenerSet review gaps"
fi

python3 - <<'PY'
import json
from pathlib import Path

out = Path('/app/output/03-review')
commands = []
for name in [
    'helper_identity_test',
    'namespace_transition_test',
    'parent_port_test',
    'gateway_api_tests',
    'model_tests',
]:
    commands.append({
        'command': (out / 'logs' / f'{name}.command').read_text().strip(),
        'exit_code': int((out / 'logs' / f'{name}.exit_code').read_text().strip()),
        'output_file': str(out / 'logs' / f'{name}.log'),
    })

payload = {
    'schema_version': 1,
    'stage': '03-review-integration',
    'feedback_items': [
        {
            'id': 'parent-aware-ingestion',
            'resolution': 'Preserve accepted Route candidates until source-aware listener filtering applies ownership, hostname, section, port, and namespace rules.',
            'verification': ['Gateway API package tests', 'model ingestion and translation tests'],
            'residual_risk': 'Controller-level hidden fixtures remain authoritative for full generated configuration.',
        },
        {
            'id': 'same-name-parent-identity',
            'resolution': 'A ListenerSet parent cannot match a same-name Gateway solely by namespace and name.',
            'verification': ['TestIsParentAttachableDistinguishesSameNameListenerSet'],
            'residual_risk': '',
        },
        {
            'id': 'parent-port-consistency',
            'resolution': 'Parent section and port constraints are evaluated together at the source-aware listener boundary for every Route kind.',
            'verification': ['TestListenerWithContextHonorsParentPort', 'model ingestion tests'],
            'residual_risk': '',
        },
        {
            'id': 'allowedlisteners-namespace-events',
            'resolution': 'Namespace events map Gateways whose allowedListeners policy changes attachment for the updated namespace.',
            'verification': ['TestGatewayAllowsListenerSetNamespaceSelectorTransitions', 'Gateway API package tests'],
            'residual_risk': 'The hidden verifier remains authoritative for the full workqueue-to-published-state transition.',
        },
        {
            'id': 'disallowed-listenerset-route-status',
            'resolution': 'A Route through a ListenerSet that is not permitted by the parent Gateway is not reported as accepted.',
            'verification': ['Gateway API package tests'],
            'residual_risk': '',
        },
    ],
    'route_types_verified': [
        'HTTPRoute', 'GRPCRoute', 'TLSRoute', 'TCPRoute', 'UDPRoute'
    ],
    'namespace_transitions_verified': ['attach', 'detach'],
    'commands_run': commands,
}
(out / 'review_response.json').write_text(json.dumps(payload, indent=2) + '\n', encoding='utf-8')
PY

echo "Stage 3 Oracle completed"
