# Stage 3 Oracle

Applies one valid set of review corrections on top of the upstream baseline:

- keeps accepted Route candidates until source-aware listener filtering;
- distinguishes same-name Gateway and ListenerSet parents;
- applies section-name and port matching consistently;
- maps `allowedListeners` namespace-label transitions to the parent Gateway;
- rejects Route status through a ListenerSet that is not permitted to attach;
- adds focused identity, port, and namespace-transition tests.
