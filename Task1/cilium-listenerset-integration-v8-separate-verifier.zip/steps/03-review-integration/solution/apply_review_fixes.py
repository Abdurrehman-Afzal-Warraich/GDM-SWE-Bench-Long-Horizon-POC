#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path

ROOT = Path('/testbed')


def replace_once(path: Path, old: str, new: str, marker: str) -> None:
    text = path.read_text(encoding='utf-8')
    if old not in text:
        if new in text:
            return
        raise SystemExit(f'{path}: neither expected old nor new form found for {marker!r}')
    count = text.count(old)
    if count != 1:
        raise SystemExit(f'{path}: expected one replacement for {marker!r}, found {count}')
    path.write_text(text.replace(old, new, 1), encoding='utf-8')


# Keep all ListenerSets that reference the Gateway available for route-status
# reconciliation. Only allowed ListenerSets contribute merged listeners and are
# passed to data-plane attachment checks.
reconcile = ROOT / 'operator/pkg/gateway-api/gateway_reconcile.go'
replace_once(
    reconcile,
    '''	mergedListeners, attachedListenerSets, err := r.resolveAllowedListeners(ctx, scopedLog, gw)
''',
    '''	mergedListeners, attachedListenerSets, relatedListenerSets, err := r.resolveAllowedListeners(ctx, scopedLog, gw)
''',
    'relatedListenerSets reconcile result',
)
replace_once(
    reconcile,
    '''	if helpers.HasListenerSetSupport(r.Client.Scheme()) {
		for _, ls := range attachedListenerSets {
''',
    '''	if helpers.HasListenerSetSupport(r.Client.Scheme()) {
		for _, ls := range relatedListenerSets {
''',
    'route status collection across related ListenerSets',
)
replace_once(
    reconcile,
    ''') ([]ingestion.ListenerWithContext, []gatewayv1.ListenerSet, error) {
''',
    ''') ([]ingestion.ListenerWithContext, []gatewayv1.ListenerSet, []gatewayv1.ListenerSet, error) {
''',
    'resolveAllowedListeners related set return type',
)
replace_once(
    reconcile,
    '''		return merged, nil, nil
''',
    '''		return merged, nil, nil, nil
''',
    'resolveAllowedListeners no-support return',
)
replace_once(
    reconcile,
    '''		return nil, nil, fmt.Errorf("failed to list ListenerSets: %w", err)
''',
    '''		return nil, nil, nil, fmt.Errorf("failed to list ListenerSets: %w", err)
''',
    'resolveAllowedListeners list-error return',
)
replace_once(
    reconcile,
    '''	return merged, attachedSets, nil
''',
    '''	return merged, attachedSets, lsList.Items, nil
''',
    'resolveAllowedListeners related set return',
)

# Preserve routes accepted through either the Gateway or an attached
# ListenerSet. Exact listener ownership, hostname, section, port, and namespace
# filtering remains source-aware in the merged-listener ingestion path.
reconcile = ROOT / 'operator/pkg/gateway-api/gateway_reconcile.go'
replace_once(
    reconcile,
    '''	var filtered []gatewayv1.HTTPRoute
	allListenerHostNames := routechecks.GetAllListenerHostNames(gw.Spec.Listeners)
	for _, route := range routes {
		if helpers.IsParentAttachable(ctx, gw, &route, route.Status.Parents, attachedListenerSets) && isAllowed(gw, &route, namespaceLabels) && len(computeHosts(gw, route.Spec.Hostnames, allListenerHostNames)) > 0 {
			filtered = append(filtered, route)
		}
	}
''',
    '''	var filtered []gatewayv1.HTTPRoute
	for _, route := range routes {
		if helpers.IsParentAttachable(ctx, gw, &route, route.Status.Parents, attachedListenerSets) {
			filtered = append(filtered, route)
		}
	}
''',
    'ListenerSet-aware HTTP parent acceptance',
)
replace_once(
    reconcile,
    '''	var filtered []gatewayv1.GRPCRoute
	allListenerHostNames := routechecks.GetAllListenerHostNames(gw.Spec.Listeners)

	for _, route := range routes {
		if helpers.IsParentAttachable(ctx, gw, &route, route.Status.Parents, attachedListenerSets) && isAllowed(gw, &route, namespaceLabels) && len(computeHosts(gw, route.Spec.Hostnames, allListenerHostNames)) > 0 {
			filtered = append(filtered, route)
		}
	}
''',
    '''	var filtered []gatewayv1.GRPCRoute
	for _, route := range routes {
		if helpers.IsParentAttachable(ctx, gw, &route, route.Status.Parents, attachedListenerSets) {
			filtered = append(filtered, route)
		}
	}
''',
    'ListenerSet-aware GRPC parent acceptance',
)
replace_once(
    reconcile,
    '''	var filtered []gatewayv1.TLSRoute
	for _, route := range routes {
		if helpers.IsParentAttachable(ctx, gw, &route, route.Status.Parents, attachedListenerSets) && isAllowed(gw, &route, namespaceLabels) &&
			len(computeHosts(gw, route.Spec.Hostnames, nil)) > 0 {
			filtered = append(filtered, route)
		}
	}
''',
    '''	var filtered []gatewayv1.TLSRoute
	for _, route := range routes {
		if helpers.IsParentAttachable(ctx, gw, &route, route.Status.Parents, attachedListenerSets) {
			filtered = append(filtered, route)
		}
	}
''',
    'ListenerSet-aware TLS parent acceptance',
)
replace_once(
    reconcile,
    '''	var filtered []gatewayv1alpha2.TCPRoute
	for _, route := range routes {
		if helpers.IsParentAttachable(ctx, gw, &route, route.Status.Parents, attachedListenerSets) && isAllowed(gw, &route, namespaceLabels) {
			filtered = append(filtered, route)
		}
	}
''',
    '''	var filtered []gatewayv1alpha2.TCPRoute
	for _, route := range routes {
		if helpers.IsParentAttachable(ctx, gw, &route, route.Status.Parents, attachedListenerSets) {
			filtered = append(filtered, route)
		}
	}
''',
    'ListenerSet-aware TCP parent acceptance',
)
replace_once(
    reconcile,
    '''	var filtered []gatewayv1alpha2.UDPRoute
	for _, route := range routes {
		if helpers.IsParentAttachable(ctx, gw, &route, route.Status.Parents, attachedListenerSets) && isAllowed(gw, &route, namespaceLabels) {
			filtered = append(filtered, route)
		}
	}
''',
    '''	var filtered []gatewayv1alpha2.UDPRoute
	for _, route := range routes {
		if helpers.IsParentAttachable(ctx, gw, &route, route.Status.Parents, attachedListenerSets) {
			filtered = append(filtered, route)
		}
	}
''',
    'ListenerSet-aware UDP parent acceptance',
)


# ParentReference port constraints must be enforced together with section names
# for every Route type using ListenerWithContext.
ingestion = ROOT / 'operator/pkg/model/ingestion/gateway.go'
replace_once(
    ingestion,
    '''\tfor _, parent := range parentRefs {
\t\tif parentRefMatchesSource(parent, l.Source, routeNamespace) {
\t\t\tif parent.SectionName != nil && string(*parent.SectionName) != string(l.Listener.Name) {
\t\t\t\t// We didn't find a listener yet that matches the section name
\t\t\t\tcontinue
\t\t\t}
\t\t\treturn true
\t\t}
\t}
''',
    '''\tfor _, parent := range parentRefs {
\t\tif parentRefMatchesSource(parent, l.Source, routeNamespace) {
\t\t\tif parent.SectionName != nil && string(*parent.SectionName) != string(l.Listener.Name) {
\t\t\t\tcontinue
\t\t\t}
\t\t\tif parent.Port != nil && *parent.Port != l.Listener.Port {
\t\t\t\tcontinue
\t\t\t}
\t\t\treturn true
\t\t}
\t}
''',
    'parent.Port != nil && *parent.Port != l.Listener.Port',
)

# ListenerSet status must not be initialized as accepted when the parent
# Gateway does not permit that ListenerSet to attach.
replace_once(
    reconcile,
    '''\tgwNN := helpers.ListenerSetParentGateway(ls)\n\tgw := &gatewayv1.Gateway{}\n\tif err := r.Client.Get(ctx, *gwNN, gw); err != nil {\n\t\treturn nil\n\t}\n\n\thasMatchingControllerFn := helpers.GatewayHasMatchingControllerFn(ctx, r.Client, r.controllerName, r.logger)\n\tif !hasMatchingControllerFn(gw) {\n\t\treturn nil\n\t}\n\n\tsetInitialRouteConditions(input, parent)\n''',
    '''\tgwNN := helpers.ListenerSetParentGateway(ls)\n\tif gwNN == nil {\n\t\treturn nil\n\t}\n\n\tgw := &gatewayv1.Gateway{}\n\tif err := r.Client.Get(ctx, *gwNN, gw); err != nil {\n\t\treturn nil\n\t}\n\n\thasMatchingControllerFn := helpers.GatewayHasMatchingControllerFn(ctx, r.Client, r.controllerName, r.logger)\n\tif !hasMatchingControllerFn(gw) {\n\t\treturn nil\n\t}\n\n\tif !isListenerSetAllowed(ctx, r.Client, gw, ls, r.logger) {\n\t\tinput.SetParentCondition(parent, metav1.Condition{\n\t\t\tType:    string(gatewayv1.RouteConditionAccepted),\n\t\t\tStatus:  metav1.ConditionFalse,\n\t\t\tReason:  string(gatewayv1.RouteReasonNoMatchingParent),\n\t\t\tMessage: "ListenerSet is not permitted by the parent Gateway",\n\t\t})\n\t\treturn nil\n\t}\n\n\tsetInitialRouteConditions(input, parent)\n''',
    'ListenerSet is not permitted by the parent Gateway',
)

# A ListenerSet ParentReference with the same namespace/name as the Gateway is
# not the Gateway. Preserve direct matching for Gateway and GAMMA Service
# parents while forcing ListenerSet references through attachedListenerSets.
routes = ROOT / 'operator/pkg/gateway-api/helpers/routes.go'
replace_once(
    routes,
    '''\t\tif parentNS == reconcileParent.GetNamespace() && parentName == reconcileParent.GetName() {\n\t\t\tmatched = true\n\t\t} else if IsListenerSet(rps.ParentRef) {\n''',
    '''\t\tif !IsListenerSet(rps.ParentRef) && parentNS == reconcileParent.GetNamespace() && parentName == reconcileParent.GetName() {\n\t\t\tmatched = true\n\t\t} else if IsListenerSet(rps.ParentRef) {\n''',
    '!IsListenerSet(rps.ParentRef) && parentNS',
)

# Namespace update events must requeue Gateways whose allowedListeners policy
# could attach or detach ListenerSets in the changed namespace.
namespaces = ROOT / 'operator/pkg/gateway-api/watch-handlers/namespaces.go'
replace_once(
    namespaces,
    '''\tcorev1 "k8s.io/api/core/v1"\n\t"k8s.io/apimachinery/pkg/types"\n''',
    '''\tcorev1 "k8s.io/api/core/v1"\n\tmetav1 "k8s.io/apimachinery/pkg/apis/meta/v1"\n\t"k8s.io/apimachinery/pkg/labels"\n\t"k8s.io/apimachinery/pkg/types"\n''',
    '"k8s.io/apimachinery/pkg/labels"',
)
replace_once(
    namespaces,
    '''\tfor _, gw := range gwList.Items {\n\t\tgwNN := client.ObjectKey{Namespace: gw.GetNamespace(), Name: gw.GetName()}\n\t\tfor _, l := range gw.Spec.Listeners {\n''',
    '''\tfor _, gw := range gwList.Items {\n\t\tgwNN := client.ObjectKey{Namespace: gw.GetNamespace(), Name: gw.GetName()}\n\t\tif gatewayAllowsListenerSetNamespace(ns, &gw, scopedLog) {\n\t\t\tgateways = append(gateways, gwNN)\n\t\t}\n\t\tfor _, l := range gw.Spec.Listeners {\n''',
    'gatewayAllowsListenerSetNamespace(ns, &gw, scopedLog)',
)
replace_once(
    namespaces,
    '''\treturn gateways\n}\n\nfunc addGatewayIfNamespaceMatches(\n''',
    '''\treturn gateways\n}\n\nfunc gatewayAllowsListenerSetNamespace(ns client.Object, gw *gatewayv1.Gateway, scopedLog *slog.Logger) bool {\n\tif gw.Spec.AllowedListeners == nil || gw.Spec.AllowedListeners.Namespaces == nil || gw.Spec.AllowedListeners.Namespaces.From == nil {\n\t\treturn false\n\t}\n\n\tallowed := gw.Spec.AllowedListeners.Namespaces\n\tswitch *allowed.From {\n\tcase gatewayv1.NamespacesFromAll:\n\t\treturn true\n\tcase gatewayv1.NamespacesFromSame:\n\t\treturn ns.GetName() == gw.GetNamespace()\n\tcase gatewayv1.NamespacesFromNone:\n\t\treturn false\n\tcase gatewayv1.NamespacesFromSelector:\n\t\tif allowed.Selector == nil {\n\t\t\tscopedLog.Warn("AllowedListeners namespace set to Selector but no selector specified", logfields.Gateway, gw.GetName())\n\t\t\treturn false\n\t\t}\n\t\tselector, err := metav1.LabelSelectorAsSelector(allowed.Selector)\n\t\tif err != nil {\n\t\t\tscopedLog.Warn("Unable to parse AllowedListeners namespace selector", logfields.Gateway, gw.GetName(), logfields.Error, err)\n\t\t\treturn false\n\t\t}\n\t\treturn selector.Matches(labels.Set(ns.GetLabels()))\n\tdefault:\n\t\treturn false\n\t}\n}\n\nfunc addGatewayIfNamespaceMatches(\n''',
    'func gatewayAllowsListenerSetNamespace(',
)

# Add a focused regression for same-name, different-kind parent identity.
test_path = ROOT / 'operator/pkg/gateway-api/helpers/routes_listenerset_identity_test.go'
if not test_path.exists():
    test_path.write_text('''// SPDX-License-Identifier: Apache-2.0\n// Copyright Authors of Cilium\n\npackage helpers\n\nimport (\n\t"context"\n\t"testing"\n\n\tmetav1 "k8s.io/apimachinery/pkg/apis/meta/v1"\n\t"k8s.io/utils/ptr"\n\tgatewayv1 "sigs.k8s.io/gateway-api/apis/v1"\n)\n\nfunc TestIsParentAttachableDistinguishesSameNameListenerSet(t *testing.T) {\n\tgw := &gatewayv1.Gateway{ObjectMeta: metav1.ObjectMeta{Name: "shared", Namespace: "default"}}\n\troute := &gatewayv1.HTTPRoute{ObjectMeta: metav1.ObjectMeta{Name: "route", Namespace: "default"}}\n\tparent := gatewayv1.RouteParentStatus{\n\t\tParentRef: gatewayv1.ParentReference{\n\t\t\tGroup: ptr.To(gatewayv1.Group(gatewayv1.SchemeGroupVersion.Group)),\n\t\t\tKind:  ptr.To(gatewayv1.Kind("ListenerSet")),\n\t\t\tName:  gatewayv1.ObjectName("shared"),\n\t\t},\n\t\tConditions: []metav1.Condition{{\n\t\t\tType: string(gatewayv1.RouteConditionAccepted), Status: metav1.ConditionTrue,\n\t\t}},\n\t}\n\n\tif IsParentAttachable(context.Background(), gw, route, []gatewayv1.RouteParentStatus{parent}, nil) {\n\t\tt.Fatal("ListenerSet parent must not match a same-name Gateway")\n\t}\n\n\tls := gatewayv1.ListenerSet{ObjectMeta: metav1.ObjectMeta{Name: "shared", Namespace: "default"}}\n\tif !IsParentAttachable(context.Background(), gw, route, []gatewayv1.RouteParentStatus{parent}, []gatewayv1.ListenerSet{ls}) {\n\t\tt.Fatal("accepted route should match the attached same-name ListenerSet")\n\t}\n}\n''', encoding='utf-8')


# Verify namespace selector transitions without tying the task to a controller
# implementation shape.
namespace_test = ROOT / 'operator/pkg/gateway-api/watch-handlers/namespaces_listenerset_test.go'
if not namespace_test.exists():
    namespace_test.write_text('''// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

package watchhandlers

import (
    "log/slog"
    "testing"

    corev1 "k8s.io/api/core/v1"
    metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
    gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"
)

func TestGatewayAllowsListenerSetNamespaceSelectorTransitions(t *testing.T) {
    from := gatewayv1.NamespacesFromSelector
    gw := &gatewayv1.Gateway{
        ObjectMeta: metav1.ObjectMeta{Name: "gateway", Namespace: "gateway-ns"},
        Spec: gatewayv1.GatewaySpec{
            AllowedListeners: &gatewayv1.AllowedListeners{
                Namespaces: &gatewayv1.ListenerNamespaces{
                    From: &from,
                    Selector: &metav1.LabelSelector{MatchLabels: map[string]string{"team": "infra"}},
                },
            },
        },
    }
    ns := &corev1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: "app-ns", Labels: map[string]string{"team": "app"}}}

    if gatewayAllowsListenerSetNamespace(ns, gw, slog.Default()) {
        t.Fatal("non-matching namespace must not attach")
    }
    ns.Labels["team"] = "infra"
    if !gatewayAllowsListenerSetNamespace(ns, gw, slog.Default()) {
        t.Fatal("matching label must attach")
    }
    ns.Labels["team"] = "app"
    if gatewayAllowsListenerSetNamespace(ns, gw, slog.Default()) {
        t.Fatal("removing the matching label must detach")
    }
}
''', encoding='utf-8')

# Verify parent port isolation at the source-aware listener boundary.
port_test = ROOT / 'operator/pkg/model/ingestion/gateway_listenerset_parentref_test.go'
if not port_test.exists():
    port_test.write_text('''// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

package ingestion

import (
    "testing"

    metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
    gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"

    "github.com/cilium/cilium/operator/pkg/model"
)

func TestListenerWithContextHonorsParentPort(t *testing.T) {
    kind := gatewayv1.Kind("ListenerSet")
    matchingPort := gatewayv1.PortNumber(8080)
    wrongPort := gatewayv1.PortNumber(9090)
    listener := ListenerWithContext{
        Listener: gatewayv1.Listener{Name: "http", Port: matchingPort},
        Source: model.FullyQualifiedResource{Name: "set", Namespace: "default", Kind: "ListenerSet"},
    }
    route := gatewayv1.HTTPRoute{
        ObjectMeta: metav1.ObjectMeta{Name: "route", Namespace: "default"},
        Spec: gatewayv1.HTTPRouteSpec{CommonRouteSpec: gatewayv1.CommonRouteSpec{
            ParentRefs: []gatewayv1.ParentReference{{Kind: &kind, Name: "set", Port: &wrongPort}},
        }},
    }

    if got := listener.FilterHTTPRoutes([]gatewayv1.HTTPRoute{route}); len(got) != 0 {
        t.Fatal("route with a different parent port must not attach")
    }
    route.Spec.ParentRefs[0].Port = &matchingPort
    if got := listener.FilterHTTPRoutes([]gatewayv1.HTTPRoute{route}); len(got) != 1 {
        t.Fatal("route with the matching parent port must attach")
    }
}
''', encoding='utf-8')
