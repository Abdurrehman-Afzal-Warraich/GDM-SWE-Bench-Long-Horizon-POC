# Stage 3: Close Review Gaps

The repository and prior artifacts persist. Review identified these remaining cases:

1. A Route may be excluded when its hostname matches only its referenced ListenerSet.
2. A Gateway and ListenerSet sharing a namespace and name must remain distinct parents.
3. Section-name and port matching must be consistent across every supported Route kind.
4. Namespace-label changes affecting `allowedListeners` must requeue the parent Gateway on attach and detach label transitions (watch events fire) without requiring another Gateway or Route edit.
5. Route status must agree with whether its referenced ListenerSet is permitted to attach.

## Task

Fix these cases while preserving direct-Gateway, GAMMA, `allowedRoutes`, and unrelated namespace behavior. Focused regression coverage for both namespace-label transition directions is helpful guidance, not a separate scored deliverable.

Command output files must be regular files under `/app/output/03-review/`.

## Output

Write `/app/output/03-review/review_response.json`:

```json
{
  "schema_version": 1,
  "stage": "03-review-integration",
  "feedback_items": [{"id": "string", "resolution": "string", "verification": ["string"], "residual_risk": "string"}],
  "route_types_verified": ["HTTPRoute", "GRPCRoute", "TLSRoute", "TCPRoute", "UDPRoute"],
  "namespace_transitions_verified": ["attach", "detach"],
  "commands_run": [{"command": "string", "exit_code": 0, "output_file": "absolute path"}]
}
```
