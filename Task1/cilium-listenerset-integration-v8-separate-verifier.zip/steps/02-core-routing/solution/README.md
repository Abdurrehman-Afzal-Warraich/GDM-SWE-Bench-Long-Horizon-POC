# Stage 2 Oracle — Standard SWE-Bench Materialization

This solution uses the standard SWE-bench oracle-materialization pattern:
the reference implementation is applied from a protected, encrypted artifact
so the verifier can confirm the task is solvable. The agent never sees this
directory; it must independently derive the implementation from the
Stage 2 instruction alone.

## Engineering Computation Performed

`solve.sh` executes six verifiable engineering steps after materialization:

1. **Handoff validation** — confirms Stage 1 diagnosis contract is satisfied.
2. **Patch integrity** — SHA-256 checksum of decrypted diff matches build-time manifest.
3. **Compilation** — `go build` on the full Gateway API and model packages.
4. **Static analysis** — `go vet` on the same packages, checking for correctness issues.
5. **Test execution** — `go test` runs the upstream unit and integration suites.
6. **Evidence derivation** — `implementation.json` is generated from actual test logs and
   the real `git apply --numstat` output, not from pre-computed data.

The private key is protected; real agent runs never receive it.
