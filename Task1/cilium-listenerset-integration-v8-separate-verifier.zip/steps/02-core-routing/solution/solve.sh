#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PRIVATE_KEY="$SCRIPT_DIR/oracle_upstream_private.pem"
TESTBED=/testbed
OUT=/app/output/02-core
PATCH=/tmp/oracle-upstream-pr.diff
PASSPHRASE=/tmp/oracle-upstream-passphrase.bin
mkdir -p "$OUT" /logs/agent
touch /logs/agent/oracle.txt

cleanup() {
  rm -f "$PATCH" "$PASSPHRASE"
}
trap cleanup EXIT INT TERM

[ -r "$PRIVATE_KEY" ] || { echo "missing protected Oracle private key" >&2; exit 1; }
[ -r /opt/oracle/upstream-pr.diff.enc ] || { echo "missing encrypted upstream PR payload" >&2; exit 1; }
[ -r /opt/oracle/upstream-passphrase.enc ] || { echo "missing encrypted upstream passphrase" >&2; exit 1; }
[ -r /app/output/handoff.json ] || { echo "missing Stage 1 handoff" >&2; exit 1; }

python3 - <<'PY'
import json
from pathlib import Path
p = Path('/app/output/handoff.json')
data = json.loads(p.read_text(encoding='utf-8'))
required = {
    'schema_version': 1,
    'stage': '01-diagnose',
    'base_limitation_reproduced': True,
    'production_source_unchanged': True,
    'resource_kind': 'ListenerSet',
}
for key, expected in required.items():
    if data.get(key) != expected:
        raise SystemExit(f'invalid Stage 1 handoff field {key}: {data.get(key)!r}')
PY

openssl pkeyutl -decrypt \
  -inkey "$PRIVATE_KEY" \
  -in /opt/oracle/upstream-passphrase.enc \
  -out "$PASSPHRASE" \
  -pkeyopt rsa_padding_mode:oaep \
  -pkeyopt rsa_oaep_md:sha256

openssl enc -d -aes-256-cbc -pbkdf2 -iter 250000 \
  -in /opt/oracle/upstream-pr.diff.enc \
  -out "$PATCH" \
  -pass file:"$PASSPHRASE"

expected_sha="$(tr -d '[:space:]' < /opt/oracle/upstream-pr.diff.sha256)"
actual_sha="$(sha256sum "$PATCH" | awk '{print $1}')"
[ "$actual_sha" = "$expected_sha" ] || {
  echo "upstream patch checksum mismatch" >&2
  exit 1
}

base_commit="$(tr -d '[:space:]' < /opt/oracle/base_commit)"
[ "$base_commit" = "aeb2d1b68e0e0bb36fc48f262bbc75c4903c19e8" ]

cd "$TESTBED"
mkdir -p "$OUT/logs"

# Capture the upstream change manifest before applying it.
git apply --numstat "$PATCH" | awk '{print $3}' | sort -u > "$OUT/changed-files.txt"
[ "$(wc -l < "$OUT/changed-files.txt")" -eq 97 ] || {
  echo "unexpected upstream changed-file count" >&2
  exit 1
}

if git apply --check "$PATCH"; then
  git apply --index "$PATCH"
  git diff --cached --check
  git config user.name "Tier 2 Oracle"
  git config user.email "oracle@invalid"
  git commit -m "gatewayapi: incorporate upstream ListenerSet support"
elif git apply --reverse --check "$PATCH"; then
  echo "upstream PR is already applied; continuing validation" >&2
else
  echo "upstream PR patch does not apply cleanly to the persistent worktree" >&2
  exit 1
fi

run_logged() {
  local name="$1"
  shift
  local log="$OUT/logs/$name.log"
  printf '%q ' "$@" > "$OUT/logs/$name.command"
  printf '\n' >> "$OUT/logs/$name.command"
  set +e
  "$@" >"$log" 2>&1
  local rc=$?
  set -e
  printf '%s\n' "$rc" > "$OUT/logs/$name.exit_code"
  cat "$log"
  [ "$rc" -eq 0 ]
}

run_logged go_build_gateway \
  go build ./operator/pkg/gateway-api/...
run_logged go_build_model \
  go build ./operator/pkg/model/ingestion/... ./operator/pkg/model/translation/gateway-api/...
run_logged go_vet_gateway \
  go vet ./operator/pkg/gateway-api/...
run_logged go_vet_model \
  go vet ./operator/pkg/model/ingestion/... ./operator/pkg/model/translation/gateway-api/...
run_logged gateway_api_tests \
  go test ./operator/pkg/gateway-api/... -count=1
run_logged model_tests \
  go test ./operator/pkg/model/ingestion/... ./operator/pkg/model/translation/gateway-api/... -count=1

python3 - <<'PY'
import json
from pathlib import Path

out = Path('/app/output/02-core')
changed = [line for line in (out / 'changed-files.txt').read_text().splitlines() if line]
commands = []
for name in ['go_build_gateway', 'go_build_model', 'go_vet_gateway', 'go_vet_model', 'gateway_api_tests', 'model_tests']:
    command = (out / 'logs' / f'{name}.command').read_text().strip()
    exit_code = int((out / 'logs' / f'{name}.exit_code').read_text().strip())
    commands.append({
        'command': command,
        'exit_code': exit_code,
        'output_file': str(out / 'logs' / f'{name}.log'),
    })

payload = {
    'schema_version': 1,
    'stage': '02-core-routing',
    'stage1_handoff_consumed': True,
    'implemented_route_types': [
        'HTTPRoute', 'GRPCRoute', 'TLSRoute', 'TCPRoute', 'UDPRoute'
    ],
    'behaviors_verified': [
        'ListenerSet resources participate in Gateway reconciliation',
        'allowedListeners controls which ListenerSets contribute listeners',
        'All supported Route kinds can reference ListenerSets',
        'ListenerSet status, referenced Secrets, and generated configuration are integrated',
        'Direct Gateway validity remains independent from ListenerSet validity',
        'Focused Gateway API and model packages pass their tests',
    ],
    'commands_run': commands,
    'changed_files': changed,
    'known_deferred_work': [
        'Respond to Stage 3 review cases not closed by the upstream merge',
        'Harden partial route retrieval failures when Stage 4 evidence is revealed',
    ],
    'risks': [
        'Namespace event mapping must be checked against allowedListeners selector transitions',
        'Pre-ingestion route filtering must not discard ListenerSet-only routes',
        'Route collection failures must not permit partial publication',
    ],
}
(out / 'implementation.json').write_text(json.dumps(payload, indent=2) + '\n', encoding='utf-8')
PY

echo "Stage 2 Oracle completed"
