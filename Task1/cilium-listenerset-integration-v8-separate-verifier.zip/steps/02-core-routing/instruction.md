# Stage 2: Implement the ListenerSet Baseline

The repository and Stage 1 handoff persist.

## Task

Add production ListenerSet support with these outcomes:

- ListenerSets can extend a parent Gateway.
- The Gateway's `allowedListeners` policy controls attachment.
- Attached listeners participate in status, conflict reporting, referenced-Secret handling, and generated configuration.
- HTTPRoute, GRPCRoute, TLSRoute, TCPRoute, and UDPRoute can use ListenerSet parent references.
- Reconciliation after ListenerSet, relevant Route, or referenced Secret changes reflects the new state.
- A ListenerSet does not make an otherwise invalid Gateway accepted or programmed.
- Existing direct-Gateway and GAMMA behavior remains unchanged.

Add focused regression coverage and run the relevant repository tests. Parent references without section-name or port constraints are sufficient for this baseline; later stages introduce additional matching cases.

Command output files must be regular files under `/app/output/02-core/`.

## Output

Write `/app/output/02-core/implementation.json`:

```json
{
  "schema_version": 1,
  "stage": "02-core-routing",
  "stage1_handoff_consumed": true,
  "implemented_route_types": ["HTTPRoute", "GRPCRoute", "TLSRoute", "TCPRoute", "UDPRoute"],
  "behaviors_verified": ["string"],
  "commands_run": [{"command": "string", "exit_code": 0, "output_file": "absolute path"}],
  "changed_files": ["repository-relative path"],
  "known_deferred_work": ["string"],
  "risks": ["string"]
}
```
