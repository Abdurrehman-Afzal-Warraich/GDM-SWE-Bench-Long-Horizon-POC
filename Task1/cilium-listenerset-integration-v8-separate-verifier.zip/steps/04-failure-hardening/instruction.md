# Stage 4: Fail Safely on Route Retrieval Errors

The repository and prior artifacts persist. A failed Route retrieval is not an empty result.

## Task

When reconciliation retrieves Route data used to construct a Gateway state that includes attached ListenerSets, ensure that any retrieval error:

- fails reconciliation before a new desired state is published;
- identifies the ListenerSet and Route kind;
- leaves the previous valid configuration unchanged;
- allows a later complete retry to recover normally;
- behaves consistently for all five Route kinds and multiple ListenerSets;
- preserves all earlier-stage behavior.

Add focused regression coverage for error propagation. The verifier will inject early, late, multi-ListenerSet, and recovery faults.

Command output files must be regular files under `/app/output/04-hardening/`.

## Output

Write `/app/output/04-hardening/final_report.json`:

```json
{
  "schema_version": 1,
  "stage": "04-failure-hardening",
  "fault_cases_addressed": ["first-query-failure", "late-query-failure", "multi-listenerset-failure", "successful-recovery"],
  "route_types_covered": ["HTTPRoute", "GRPCRoute", "TLSRoute", "TCPRoute", "UDPRoute"],
  "fail_before_publish": true,
  "commands_run": [{"command": "string", "exit_code": 0, "output_file": "absolute path"}],
  "remaining_risks": ["string"]
}
```
