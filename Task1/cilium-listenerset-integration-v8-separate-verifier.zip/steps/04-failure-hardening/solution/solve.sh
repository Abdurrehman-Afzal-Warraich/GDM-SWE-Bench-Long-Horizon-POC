#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TESTBED=/testbed
OUT=/app/output/04-hardening
mkdir -p "$OUT/logs" /logs/agent
touch /logs/agent/oracle.txt

[ -r /app/output/03-review/review_response.json ] || {
  echo "missing Stage 3 review response" >&2
  exit 1
}

python3 - <<'PY'
import json
from pathlib import Path
p = Path('/app/output/03-review/review_response.json')
data = json.loads(p.read_text(encoding='utf-8'))
if data.get('schema_version') != 1 or data.get('stage') != '03-review-integration':
    raise SystemExit('invalid Stage 3 review response')
required = {'HTTPRoute', 'GRPCRoute', 'TLSRoute', 'TCPRoute', 'UDPRoute'}
if not required.issubset(set(data.get('route_types_verified', []))):
    raise SystemExit('Stage 3 review response does not cover all supported Route kinds')
if not {'attach', 'detach'}.issubset(set(data.get('namespace_transitions_verified', []))):
    raise SystemExit('Stage 3 review response is missing namespace transition evidence')
PY

cd "$TESTBED"
python3 "$SCRIPT_DIR/apply_failure_hardening.py"
gofmt -w \
  operator/pkg/gateway-api/gateway_reconcile.go \
  operator/pkg/gateway-api/gateway_reconcile_listenerset_error_test.go
git diff --check

for kind in HTTP GRPC TLS TCP UDP; do
  grep -q "listenerSetRouteListError(\"${kind}Routes\"" \
    operator/pkg/gateway-api/gateway_reconcile.go
done
for kind in HTTP GRPC TLS TCP UDP; do
  grep -q "listenerSetRouteDataError(\"${kind}Route\"" \
    operator/pkg/gateway-api/gateway_reconcile.go
done
[ "$(grep -c 'return r.handleReconcileErrorWithStatus(ctx, wrappedErr, original, gw)' operator/pkg/gateway-api/gateway_reconcile.go)" -ge 5 ]

run_logged() {
  local name="$1"
  shift
  local log="$OUT/logs/$name.log"
  printf '%q ' "$@" > "$OUT/logs/$name.command"
  printf '\n' >> "$OUT/logs/$name.command"
  set +e
  "$@" >"$log" 2>&1
  local rc=$?
  set -e
  printf '%s\n' "$rc" > "$OUT/logs/$name.exit_code"
  cat "$log"
  [ "$rc" -eq 0 ]
}

run_logged error_metadata_test \
  go test ./operator/pkg/gateway-api \
    -run '^TestListenerSetRouteListError$' \
    -count=1
run_logged gateway_api_tests \
  go test ./operator/pkg/gateway-api/... -count=1
run_logged model_tests \
  go test ./operator/pkg/model/ingestion/... ./operator/pkg/model/translation/gateway-api/... -count=1
run_logged diff_check git diff --check

git add \
  operator/pkg/gateway-api/gateway_reconcile.go \
  operator/pkg/gateway-api/gateway_reconcile_listenerset_error_test.go
git config user.name "Tier 2 Oracle"
git config user.email "oracle@invalid"
if ! git diff --cached --quiet; then
  git commit -m "gatewayapi: fail closed on ListenerSet route retrieval"
fi

python3 - <<'PY'
import json
from pathlib import Path

out = Path('/app/output/04-hardening')
commands = []
for name in ['error_metadata_test', 'gateway_api_tests', 'model_tests', 'diff_check']:
    commands.append({
        'command': (out / 'logs' / f'{name}.command').read_text().strip(),
        'exit_code': int((out / 'logs' / f'{name}.exit_code').read_text().strip()),
        'output_file': str(out / 'logs' / f'{name}.log'),
    })

payload = {
    'schema_version': 1,
    'stage': '04-failure-hardening',
    'fault_cases_addressed': [
        'first-query-failure',
        'late-query-failure',
        'multi-listenerset-failure',
        'successful-recovery',
    ],
    'route_types_covered': [
        'HTTPRoute', 'GRPCRoute', 'TLSRoute', 'TCPRoute', 'UDPRoute'
    ],
    'fail_before_publish': True,
    'commands_run': commands,
    'remaining_risks': [
        'Verifier-owned injected-client tests remain authoritative for early, late, multi-ListenerSet, last-known-good, and recovery behavior.'
    ],
}
(out / 'final_report.json').write_text(json.dumps(payload, indent=2) + '\n', encoding='utf-8')
PY

echo "Stage 4 Oracle completed"
