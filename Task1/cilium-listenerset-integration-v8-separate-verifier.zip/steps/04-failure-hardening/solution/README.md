# Stage 4 Oracle

Changes every ListenerSet Route retrieval path from log-and-continue behavior to fail-closed reconciliation. Errors carry the ListenerSet and Route kind, and reconciliation returns before status, ingestion, translation, or managed-object publication.

A focused unit test verifies wrapped error identity and metadata. The protected verifier remains responsible for injected early, late, multi-ListenerSet, last-known-good, and recovery behavior.
