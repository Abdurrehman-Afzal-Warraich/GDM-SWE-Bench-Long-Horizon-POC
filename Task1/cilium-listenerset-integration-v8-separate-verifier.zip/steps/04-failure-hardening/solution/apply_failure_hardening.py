#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path

ROOT = Path('/testbed')
path = ROOT / 'operator/pkg/gateway-api/gateway_reconcile.go'
text = path.read_text(encoding='utf-8')


def replace_once(old: str, new: str, marker: str) -> None:
    global text
    if marker in text:
        return
    count = text.count(old)
    if count != 1:
        raise SystemExit(f'expected one replacement for {marker!r}, found {count}')
    text = text.replace(old, new, 1)



# Any required Route data query can make ListenerSet-derived desired state
# incomplete. Preserve the cause and identify the affected Route kind and all
# attached ListenerSets before returning.
replace_once(
    '''\thttpRouteList := &gatewayv1.HTTPRouteList{}\n\tif err := r.Client.List(ctx, httpRouteList, &client.ListOptions{\n\t\tFieldSelector: fields.OneTermEqualSelector(indexers.GatewayHTTPRouteIndex, client.ObjectKeyFromObject(original).String()),\n\t}); err != nil {\n\t\tscopedLog.ErrorContext(ctx, "Unable to list HTTPRoutes", logfields.Error, err)\n\t\treturn r.handleReconcileErrorWithStatus(ctx, err, original, gw)\n\t}\n''',
    '''\thttpRouteList := &gatewayv1.HTTPRouteList{}\n\tif err := r.Client.List(ctx, httpRouteList, &client.ListOptions{\n\t\tFieldSelector: fields.OneTermEqualSelector(indexers.GatewayHTTPRouteIndex, client.ObjectKeyFromObject(original).String()),\n\t}); err != nil {\n\t\twrappedErr := listenerSetRouteDataError("HTTPRoute", attachedListenerSets, err)\n\t\tscopedLog.ErrorContext(ctx, "Unable to list HTTPRoutes", logfields.Error, wrappedErr)\n\t\treturn r.handleReconcileErrorWithStatus(ctx, wrappedErr, original, gw)\n\t}\n''',
    'listenerSetRouteDataError("HTTPRoute"',
)

replace_once(
    '''\tgrpcRouteList := &gatewayv1.GRPCRouteList{}\n\tif err := r.Client.List(ctx, grpcRouteList, &client.ListOptions{\n\t\tFieldSelector: fields.OneTermEqualSelector(indexers.GatewayGRPCRouteIndex, client.ObjectKeyFromObject(original).String()),\n\t}); err != nil {\n\t\tscopedLog.ErrorContext(ctx, "Unable to list GRPCRoutes", logfields.Error, err)\n\t\treturn r.handleReconcileErrorWithStatus(ctx, err, original, gw)\n\t}\n''',
    '''\tgrpcRouteList := &gatewayv1.GRPCRouteList{}\n\tif err := r.Client.List(ctx, grpcRouteList, &client.ListOptions{\n\t\tFieldSelector: fields.OneTermEqualSelector(indexers.GatewayGRPCRouteIndex, client.ObjectKeyFromObject(original).String()),\n\t}); err != nil {\n\t\twrappedErr := listenerSetRouteDataError("GRPCRoute", attachedListenerSets, err)\n\t\tscopedLog.ErrorContext(ctx, "Unable to list GRPCRoutes", logfields.Error, wrappedErr)\n\t\treturn r.handleReconcileErrorWithStatus(ctx, wrappedErr, original, gw)\n\t}\n''',
    'listenerSetRouteDataError("GRPCRoute"',
)

replace_once(
    '''\ttlsRouteList := &gatewayv1.TLSRouteList{}\n\tif helpers.HasTLSRouteSupport(r.Client.Scheme()) {\n\t\tif err := r.Client.List(ctx, tlsRouteList, &client.ListOptions{\n\t\t\tFieldSelector: fields.OneTermEqualSelector(indexers.GatewayTLSRouteIndex, client.ObjectKeyFromObject(original).String()),\n\t\t}); err != nil {\n\t\t\tscopedLog.ErrorContext(ctx, "Unable to list TLSRoutes", logfields.Error, err)\n\t\t\treturn r.handleReconcileErrorWithStatus(ctx, err, original, gw)\n\t\t}\n\t}\n''',
    '''\ttlsRouteList := &gatewayv1.TLSRouteList{}\n\tif helpers.HasTLSRouteSupport(r.Client.Scheme()) {\n\t\tif err := r.Client.List(ctx, tlsRouteList, &client.ListOptions{\n\t\t\tFieldSelector: fields.OneTermEqualSelector(indexers.GatewayTLSRouteIndex, client.ObjectKeyFromObject(original).String()),\n\t\t}); err != nil {\n\t\t\twrappedErr := listenerSetRouteDataError("TLSRoute", attachedListenerSets, err)\n\t\t\tscopedLog.ErrorContext(ctx, "Unable to list TLSRoutes", logfields.Error, wrappedErr)\n\t\t\treturn r.handleReconcileErrorWithStatus(ctx, wrappedErr, original, gw)\n\t\t}\n\t}\n''',
    'listenerSetRouteDataError("TLSRoute"',
)

replace_once(
    '''\ttcpRouteList := &gatewayv1alpha2.TCPRouteList{}\n\tif helpers.HasTCPRouteSupport(r.Client.Scheme()) {\n\t\tif err := r.Client.List(ctx, tcpRouteList, &client.ListOptions{\n\t\t\tFieldSelector: fields.OneTermEqualSelector(indexers.GatewayTCPRouteIndex, client.ObjectKeyFromObject(original).String()),\n\t\t}); err != nil {\n\t\t\tscopedLog.ErrorContext(ctx, "Unable to list TCPRoutes", logfields.Error, err)\n\t\t\treturn r.handleReconcileErrorWithStatus(ctx, err, original, gw)\n\t\t}\n\t}\n''',
    '''\ttcpRouteList := &gatewayv1alpha2.TCPRouteList{}\n\tif helpers.HasTCPRouteSupport(r.Client.Scheme()) {\n\t\tif err := r.Client.List(ctx, tcpRouteList, &client.ListOptions{\n\t\t\tFieldSelector: fields.OneTermEqualSelector(indexers.GatewayTCPRouteIndex, client.ObjectKeyFromObject(original).String()),\n\t\t}); err != nil {\n\t\t\twrappedErr := listenerSetRouteDataError("TCPRoute", attachedListenerSets, err)\n\t\t\tscopedLog.ErrorContext(ctx, "Unable to list TCPRoutes", logfields.Error, wrappedErr)\n\t\t\treturn r.handleReconcileErrorWithStatus(ctx, wrappedErr, original, gw)\n\t\t}\n\t}\n''',
    'listenerSetRouteDataError("TCPRoute"',
)

replace_once(
    '''\tudpRouteList := &gatewayv1alpha2.UDPRouteList{}\n\tif helpers.HasUDPRouteSupport(r.Client.Scheme()) {\n\t\tif err := r.Client.List(ctx, udpRouteList, &client.ListOptions{\n\t\t\tFieldSelector: fields.OneTermEqualSelector(indexers.GatewayUDPRouteIndex, client.ObjectKeyFromObject(original).String()),\n\t\t}); err != nil {\n\t\t\tscopedLog.ErrorContext(ctx, "Unable to list UDPRoutes", logfields.Error, err)\n\t\t\treturn r.handleReconcileErrorWithStatus(ctx, err, original, gw)\n\t\t}\n\t}\n''',
    '''\tudpRouteList := &gatewayv1alpha2.UDPRouteList{}\n\tif helpers.HasUDPRouteSupport(r.Client.Scheme()) {\n\t\tif err := r.Client.List(ctx, udpRouteList, &client.ListOptions{\n\t\t\tFieldSelector: fields.OneTermEqualSelector(indexers.GatewayUDPRouteIndex, client.ObjectKeyFromObject(original).String()),\n\t\t}); err != nil {\n\t\t\twrappedErr := listenerSetRouteDataError("UDPRoute", attachedListenerSets, err)\n\t\t\tscopedLog.ErrorContext(ctx, "Unable to list UDPRoutes", logfields.Error, wrappedErr)\n\t\t\treturn r.handleReconcileErrorWithStatus(ctx, wrappedErr, original, gw)\n\t\t}\n\t}\n''',
    'listenerSetRouteDataError("UDPRoute"',
)

replace_once(
    '''\t\t\tlsHTTPRoutes := &gatewayv1.HTTPRouteList{}\n\t\t\tif err := r.Client.List(ctx, lsHTTPRoutes, &client.ListOptions{\n\t\t\t\tFieldSelector: fields.OneTermEqualSelector(indexers.HTTPRouteListenerSetIndex, lsKey),\n\t\t\t}); err != nil {\n\t\t\t\tscopedLog.ErrorContext(ctx, "Unable to list HTTPRoutes for ListenerSet",\n\t\t\t\t\tlogfields.Error, err,\n\t\t\t\t\tlogfields.Resource, lsKey)\n\t\t\t} else {\n\t\t\t\thttpRouteList.Items = append(httpRouteList.Items, lsHTTPRoutes.Items...)\n\t\t\t}\n''',
    '''\t\t\tlsHTTPRoutes := &gatewayv1.HTTPRouteList{}\n\t\t\tif err := r.Client.List(ctx, lsHTTPRoutes, &client.ListOptions{\n\t\t\t\tFieldSelector: fields.OneTermEqualSelector(indexers.HTTPRouteListenerSetIndex, lsKey),\n\t\t\t}); err != nil {\n\t\t\t\twrappedErr := listenerSetRouteListError("HTTPRoutes", lsKey, err)\n\t\t\t\tscopedLog.ErrorContext(ctx, "Unable to list HTTPRoutes for ListenerSet",\n\t\t\t\t\tlogfields.Error, wrappedErr,\n\t\t\t\t\tlogfields.Resource, lsKey)\n\t\t\t\treturn r.handleReconcileErrorWithStatus(ctx, wrappedErr, original, gw)\n\t\t\t}\n\t\t\thttpRouteList.Items = append(httpRouteList.Items, lsHTTPRoutes.Items...)\n''',
    'listenerSetRouteListError("HTTPRoutes"',
)

replace_once(
    '''\t\t\tlsGRPCRoutes := &gatewayv1.GRPCRouteList{}\n\t\t\tif err := r.Client.List(ctx, lsGRPCRoutes, &client.ListOptions{\n\t\t\t\tFieldSelector: fields.OneTermEqualSelector(indexers.GRPCRouteListenerSetIndex, lsKey),\n\t\t\t}); err != nil {\n\t\t\t\tscopedLog.ErrorContext(ctx, "Unable to list GRPCRoutes for ListenerSet",\n\t\t\t\t\tlogfields.Error, err,\n\t\t\t\t\tlogfields.Resource, lsKey)\n\t\t\t} else {\n\t\t\t\tgrpcRouteList.Items = append(grpcRouteList.Items, lsGRPCRoutes.Items...)\n\t\t\t}\n''',
    '''\t\t\tlsGRPCRoutes := &gatewayv1.GRPCRouteList{}\n\t\t\tif err := r.Client.List(ctx, lsGRPCRoutes, &client.ListOptions{\n\t\t\t\tFieldSelector: fields.OneTermEqualSelector(indexers.GRPCRouteListenerSetIndex, lsKey),\n\t\t\t}); err != nil {\n\t\t\t\twrappedErr := listenerSetRouteListError("GRPCRoutes", lsKey, err)\n\t\t\t\tscopedLog.ErrorContext(ctx, "Unable to list GRPCRoutes for ListenerSet",\n\t\t\t\t\tlogfields.Error, wrappedErr,\n\t\t\t\t\tlogfields.Resource, lsKey)\n\t\t\t\treturn r.handleReconcileErrorWithStatus(ctx, wrappedErr, original, gw)\n\t\t\t}\n\t\t\tgrpcRouteList.Items = append(grpcRouteList.Items, lsGRPCRoutes.Items...)\n''',
    'listenerSetRouteListError("GRPCRoutes"',
)

replace_once(
    '''\t\t\t\tlsTLSRoutes := &gatewayv1.TLSRouteList{}\n\t\t\t\tif err := r.Client.List(ctx, lsTLSRoutes, &client.ListOptions{\n\t\t\t\t\tFieldSelector: fields.OneTermEqualSelector(indexers.TLSRouteListenerSetIndex, lsKey),\n\t\t\t\t}); err != nil {\n\t\t\t\t\tscopedLog.ErrorContext(ctx, "Unable to list TLSRoutes for ListenerSet",\n\t\t\t\t\t\tlogfields.Error, err,\n\t\t\t\t\t\tlogfields.Resource, lsKey)\n\t\t\t\t} else {\n\t\t\t\t\ttlsRouteList.Items = append(tlsRouteList.Items, lsTLSRoutes.Items...)\n\t\t\t\t}\n''',
    '''\t\t\t\tlsTLSRoutes := &gatewayv1.TLSRouteList{}\n\t\t\t\tif err := r.Client.List(ctx, lsTLSRoutes, &client.ListOptions{\n\t\t\t\t\tFieldSelector: fields.OneTermEqualSelector(indexers.TLSRouteListenerSetIndex, lsKey),\n\t\t\t\t}); err != nil {\n\t\t\t\t\twrappedErr := listenerSetRouteListError("TLSRoutes", lsKey, err)\n\t\t\t\t\tscopedLog.ErrorContext(ctx, "Unable to list TLSRoutes for ListenerSet",\n\t\t\t\t\t\tlogfields.Error, wrappedErr,\n\t\t\t\t\t\tlogfields.Resource, lsKey)\n\t\t\t\t\treturn r.handleReconcileErrorWithStatus(ctx, wrappedErr, original, gw)\n\t\t\t\t}\n\t\t\t\ttlsRouteList.Items = append(tlsRouteList.Items, lsTLSRoutes.Items...)\n''',
    'listenerSetRouteListError("TLSRoutes"',
)

replace_once(
    '''\t\t\t\tlsTCPRoutes := &gatewayv1alpha2.TCPRouteList{}\n\t\t\t\tif err := r.Client.List(ctx, lsTCPRoutes, &client.ListOptions{\n\t\t\t\t\tFieldSelector: fields.OneTermEqualSelector(indexers.TCPRouteListenerSetIndex, lsKey),\n\t\t\t\t}); err != nil {\n\t\t\t\t\tscopedLog.ErrorContext(ctx, "Unable to list TCPRoutes for ListenerSet",\n\t\t\t\t\t\tlogfields.Error, err,\n\t\t\t\t\t\tlogfields.Resource, lsKey)\n\t\t\t\t} else {\n\t\t\t\t\ttcpRouteList.Items = append(tcpRouteList.Items, lsTCPRoutes.Items...)\n\t\t\t\t}\n''',
    '''\t\t\t\tlsTCPRoutes := &gatewayv1alpha2.TCPRouteList{}\n\t\t\t\tif err := r.Client.List(ctx, lsTCPRoutes, &client.ListOptions{\n\t\t\t\t\tFieldSelector: fields.OneTermEqualSelector(indexers.TCPRouteListenerSetIndex, lsKey),\n\t\t\t\t}); err != nil {\n\t\t\t\t\twrappedErr := listenerSetRouteListError("TCPRoutes", lsKey, err)\n\t\t\t\t\tscopedLog.ErrorContext(ctx, "Unable to list TCPRoutes for ListenerSet",\n\t\t\t\t\t\tlogfields.Error, wrappedErr,\n\t\t\t\t\t\tlogfields.Resource, lsKey)\n\t\t\t\t\treturn r.handleReconcileErrorWithStatus(ctx, wrappedErr, original, gw)\n\t\t\t\t}\n\t\t\t\ttcpRouteList.Items = append(tcpRouteList.Items, lsTCPRoutes.Items...)\n''',
    'listenerSetRouteListError("TCPRoutes"',
)

replace_once(
    '''\t\t\t\tlsUDPRoutes := &gatewayv1alpha2.UDPRouteList{}\n\t\t\t\tif err := r.Client.List(ctx, lsUDPRoutes, &client.ListOptions{\n\t\t\t\t\tFieldSelector: fields.OneTermEqualSelector(indexers.UDPRouteListenerSetIndex, lsKey),\n\t\t\t\t}); err != nil {\n\t\t\t\t\tscopedLog.ErrorContext(ctx, "Unable to list UDPRoutes for ListenerSet",\n\t\t\t\t\t\tlogfields.Error, err,\n\t\t\t\t\t\tlogfields.Resource, lsKey)\n\t\t\t\t} else {\n\t\t\t\t\tudpRouteList.Items = append(udpRouteList.Items, lsUDPRoutes.Items...)\n\t\t\t\t}\n''',
    '''\t\t\t\tlsUDPRoutes := &gatewayv1alpha2.UDPRouteList{}\n\t\t\t\tif err := r.Client.List(ctx, lsUDPRoutes, &client.ListOptions{\n\t\t\t\t\tFieldSelector: fields.OneTermEqualSelector(indexers.UDPRouteListenerSetIndex, lsKey),\n\t\t\t\t}); err != nil {\n\t\t\t\t\twrappedErr := listenerSetRouteListError("UDPRoutes", lsKey, err)\n\t\t\t\t\tscopedLog.ErrorContext(ctx, "Unable to list UDPRoutes for ListenerSet",\n\t\t\t\t\t\tlogfields.Error, wrappedErr,\n\t\t\t\t\t\tlogfields.Resource, lsKey)\n\t\t\t\t\treturn r.handleReconcileErrorWithStatus(ctx, wrappedErr, original, gw)\n\t\t\t\t}\n\t\t\t\tudpRouteList.Items = append(udpRouteList.Items, lsUDPRoutes.Items...)\n''',
    'listenerSetRouteListError("UDPRoutes"',
)

if 'func listenerSetRouteDataError(' not in text:
    text += '''

func listenerSetRouteDataError(routeKind string, listenerSets []gatewayv1.ListenerSet, err error) error {
    if len(listenerSets) == 0 {
        return err
    }
    keys := make([]string, 0, len(listenerSets))
    for i := range listenerSets {
        keys = append(keys, client.ObjectKeyFromObject(&listenerSets[i]).String())
    }
    return fmt.Errorf("unable to retrieve %s data required by ListenerSets %v: %w", routeKind, keys, err)
}
'''

if 'func listenerSetRouteListError(' not in text:
    text += '''

func listenerSetRouteListError(routeKind, listenerSet string, err error) error {
    return fmt.Errorf("unable to list %s for ListenerSet %s: %w", routeKind, listenerSet, err)
}
'''

path.write_text(text, encoding='utf-8')

test_path = ROOT / 'operator/pkg/gateway-api/gateway_reconcile_listenerset_error_test.go'
if not test_path.exists():
    test_path.write_text('''// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

package gateway_api

import (
    "errors"
    "strings"
    "testing"

    metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
    gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"
)

func TestListenerSetRouteListError(t *testing.T) {
    cause := errors.New("temporary list failure")
    err := listenerSetRouteListError("TLSRoutes", "team/listeners", cause)
    if !errors.Is(err, cause) {
        t.Fatal("wrapped error must preserve the original cause")
    }
    message := err.Error()
    if !strings.Contains(message, "TLSRoutes") || !strings.Contains(message, "team/listeners") {
        t.Fatalf("error must identify Route kind and ListenerSet: %s", message)
    }

    sets := []gatewayv1.ListenerSet{
        {ObjectMeta: metav1.ObjectMeta{Name: "one", Namespace: "team"}},
        {ObjectMeta: metav1.ObjectMeta{Name: "two", Namespace: "team"}},
    }
    err = listenerSetRouteDataError("TLSRoute", sets, cause)
    if !errors.Is(err, cause) {
        t.Fatal("Route data error must preserve the original cause")
    }
    message = err.Error()
    for _, token := range []string{"TLSRoute", "team/one", "team/two"} {
        if !strings.Contains(message, token) {
            t.Fatalf("Route data error must identify %s: %s", token, message)
        }
    }
}
''', encoding='utf-8')
