# Cilium ListenerSet Stateful Task

Four-stage repository-engineering task derived from a real Cilium Gateway API
feature integration. The base revision registers the Gateway API `ListenerSet`
type but never lets ListenerSets participate in Gateway reconciliation; the task
is to design and implement that integration across four persistent stages.

## Source boundary

- Repository: `cilium/cilium`
- License: Apache 2.0
- Immutable pre-change commit: `aeb2d1b68e0e0bb36fc48f262bbc75c4903c19e8`
- Go baseline: `1.26.0`

## Stage sequence

1. **Diagnose** — Confirm ListenerSet controller integration is missing (the GVK is
   registered but never reconciled) and produce a handoff, without modifying
   production source.
2. **Core routing** — Establish the ListenerSet feature baseline across the
   reconciler, route selection, and configuration translation.
3. **Review integration** — Close route-scoping, parent-identity,
   namespace-lifecycle, and status gaps.
4. **Failure hardening** — Ensure atomic route-retrieval failure handling and
   recovery.

Stage 2 defines a feature baseline rather than claiming every later edge case is
already solved. Stages 3 and 4 add behavior required only when those cases are
revealed.

## Attempting the task

Each stage delivers its own briefing in `steps/<stage>/instruction.md` and a typed
handoff to the next stage. Work only inside the repository at `/testbed` and write
stage outputs under `/app/output/<stage>/` as each instruction describes.
