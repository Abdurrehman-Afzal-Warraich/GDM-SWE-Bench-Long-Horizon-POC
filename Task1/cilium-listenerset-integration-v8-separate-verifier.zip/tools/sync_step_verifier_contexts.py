#!/usr/bin/env python3
"""Mirror tests/ into every steps/<step>/tests/ directory (separate-verifier builds).

Harbor resolves a SEPARATE verifier's Docker build context PER STEP: it uses
steps/<step>/tests/ when that directory exists, and it always exists (it holds
that step's test.sh, required by the multi-step layout). Docker `COPY . /tests`
therefore only sees what is physically inside steps/<step>/tests/ at build time,
so each step's tests/ must contain the WHOLE verifier package -- not just test.sh.

tests/ stays the single source of truth; this script mirrors it into every step's
tests/, preserving that step's own test.sh (the one file that legitimately differs).

Two cache-hazard mitigations (a confirmed BuildKit footgun can make a per-step
`COPY . /tests` deliver a SIBLING step's bytes -> a false PASS grading the wrong
stage): (1) inject `ENV HARBOR_STEP_NAME=<step>` immediately before `COPY . /tests`
so the layer's cache key differs by instruction text; (2) append a heredoc
`RUN cat > /tests/test.sh` that rewrites test.sh from bytes embedded in the
Dockerfile itself, so the one per-step file never depends on COPY. stage_test.sh's
HARBOR_STEP_NAME cross-check is the third, independent net.

Usage: `python tools/sync_step_verifier_contexts.py` mirrors; `--check` exits
non-zero if any mirror is stale (used by the pack step / self-test).
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

TASK_ROOT = Path(__file__).resolve().parent.parent
TESTS_DIR = TASK_ROOT / "tests"
STEPS_DIR = TASK_ROOT / "steps"

PRESERVE = {"test.sh"}
IGNORE_DIRS = {"__pycache__", ".pytest_cache"}

_COPY_TESTS_LINE = "COPY . /tests"
_HEREDOC_DELIM = "HARBOR_STEP_TEST_SH_EOF"


def _skip(rel: Path) -> bool:
    return bool(rel.parts) and (
        rel.parts[0] in PRESERVE or bool(IGNORE_DIRS & set(rel.parts)) or rel.suffix == ".pyc"
    )


def _strip_previous_template(src_text: str) -> str:
    src_text = re.sub(r"\nENV HARBOR_STEP_NAME=\S+\n(?=COPY \. /tests\n)", "\n", src_text)
    src_text = re.sub(
        rf"\nRUN cat > /tests/test\.sh <<'{_HEREDOC_DELIM}'\n.*?\n{_HEREDOC_DELIM}\nRUN chmod 0755 /tests/test\.sh\n",
        "\n",
        src_text,
        flags=re.DOTALL,
    )
    return src_text


def _templated_dockerfile(src_text: str, step_name: str, test_sh_text: str) -> str:
    src_text = _strip_previous_template(src_text)
    assert _COPY_TESTS_LINE in src_text, (
        "tests/Dockerfile no longer contains 'COPY . /tests' -- update the insertion point"
    )
    assert _HEREDOC_DELIM not in test_sh_text, (
        f"steps/{step_name}/tests/test.sh contains the heredoc delimiter {_HEREDOC_DELIM!r}"
    )
    env_marker = f"ENV HARBOR_STEP_NAME={step_name}\n"
    rewrite_block = (
        f"RUN cat > /tests/test.sh <<'{_HEREDOC_DELIM}'\n"
        f"{test_sh_text}"
        + ("\n" if not test_sh_text.endswith("\n") else "")
        + f"{_HEREDOC_DELIM}\n"
        "RUN chmod 0755 /tests/test.sh\n"
    )
    return src_text.replace(
        _COPY_TESTS_LINE, env_marker + _COPY_TESTS_LINE + "\n" + rewrite_block, 1
    )


def _rendered_bytes(src: Path, rel: Path, step_name: str) -> bytes:
    if rel == Path("Dockerfile"):
        test_sh_text = (STEPS_DIR / step_name / "tests" / "test.sh").read_text(encoding="utf-8")
        return _templated_dockerfile(src.read_text(encoding="utf-8"), step_name, test_sh_text).encode("utf-8")
    return src.read_bytes()


def sync_one(step_dir: Path, *, check: bool) -> list[str]:
    dest = step_dir / "tests"
    dest.mkdir(parents=True, exist_ok=True)
    step_name = step_dir.name
    drift: list[str] = []
    for src in sorted(TESTS_DIR.rglob("*")):
        rel = src.relative_to(TESTS_DIR)
        if _skip(rel):
            continue
        target = dest / rel
        if src.is_dir():
            if not check:
                target.mkdir(parents=True, exist_ok=True)
            continue
        rendered = _rendered_bytes(src, rel, step_name)
        if not target.is_file() or target.read_bytes() != rendered:
            drift.append(str(rel))
            if not check:
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(rendered)
    # Remove stale files (present in a mirror but gone from tests/), except the
    # preserved per-step test.sh and bytecode caches.
    mirrored = {
        rel for rel in (p.relative_to(TESTS_DIR) for p in TESTS_DIR.rglob("*") if p.is_file())
        if not _skip(rel)
    }
    for existing in sorted(dest.rglob("*")):
        if not existing.is_file():
            continue
        rel = existing.relative_to(dest)
        if rel.parts and (rel.parts[0] in PRESERVE or bool(IGNORE_DIRS & set(rel.parts)) or rel.suffix == ".pyc"):
            continue
        if rel not in mirrored:
            drift.append(f"stale:{rel}")
            if not check:
                existing.unlink()
    return drift


def main() -> int:
    check = "--check" in sys.argv[1:]
    if not (TESTS_DIR / "Dockerfile").is_file():
        print("FATAL: tests/Dockerfile is missing; separate-verifier layout requires it", file=sys.stderr)
        return 2
    steps = sorted(d for d in STEPS_DIR.iterdir() if d.is_dir() and (d / "tests").is_dir())
    any_drift = False
    for step in steps:
        drift = sync_one(step, check=check)
        if drift:
            any_drift = True
            verb = "STALE" if check else "synced"
            print(f"{verb} {step.name}: {', '.join(drift[:8])}{' ...' if len(drift) > 8 else ''}")
    if check and any_drift:
        print("FATAL: per-step verifier mirrors are stale; run tools/sync_step_verifier_contexts.py", file=sys.stderr)
        return 1
    print("per-step verifier contexts are in sync" if not any_drift else "per-step verifier contexts updated")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
