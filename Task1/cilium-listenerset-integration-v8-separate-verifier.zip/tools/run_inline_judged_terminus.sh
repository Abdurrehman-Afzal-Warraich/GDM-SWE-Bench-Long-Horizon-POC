#!/usr/bin/env bash
set -euo pipefail

die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

[ "$#" -eq 1 ] || die "usage: run_inline_judged_terminus.sh JOB_NAME"

JOB_NAME="$1"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TASK_PATH="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd)"
REPO_ROOT="$(CDPATH= cd -- "$SCRIPT_DIR/../../.." && pwd)"
JOBS_DIR="${HARBOR_JOBS_DIR:-./jobs}"
AGENT_MODEL="${AGENT_MODEL:-gemini/gemini-3.6-flash}"
JUDGE_REPEATS="${JUDGE_REPEATS:-2}"
JUDGE_TIMEOUT_SEC="${JUDGE_TIMEOUT_SEC:-300}"

[ -n "${GEMINI_API_KEY:-}" ] || die "GEMINI_API_KEY is not exported"
[ -f "$TASK_PATH/task.toml" ] || die "task not found: $TASK_PATH"
[ ! -e "$JOBS_DIR/$JOB_NAME" ] || die "job already exists; choose a fresh JOB_NAME"

if [ -n "${HARBOR_BIN:-}" ]; then
  [ -x "$HARBOR_BIN" ] || die "HARBOR_BIN is not executable: $HARBOR_BIN"
elif [ -x "$REPO_ROOT/.venv/bin/harbor" ]; then
  HARBOR_BIN="$REPO_ROOT/.venv/bin/harbor"
elif [ -x /root/.local/bin/harbor ]; then
  HARBOR_BIN=/root/.local/bin/harbor
else
  HARBOR_BIN="$(command -v harbor || true)"
  [ -n "$HARBOR_BIN" ] || die "harbor is not available (checked \$HARBOR_BIN, .venv/bin/harbor, /root/.local/bin/harbor, PATH)"
fi

"$HARBOR_BIN" run --help 2>&1 | grep -q -- '--ve' \
  || die "'$HARBOR_BIN' does not expose --ve/--verifier-env; it cannot run a staged Tier 2 task with inline judges"

case "$JUDGE_REPEATS" in 1|2|3) ;; *) die "JUDGE_REPEATS must be 1, 2, or 3" ;; esac
case "$JUDGE_TIMEOUT_SEC" in ''|*[!0-9]*) die "JUDGE_TIMEOUT_SEC must be an integer" ;; esac

exec "$HARBOR_BIN" run \
  -p "$TASK_PATH" \
  -a terminus-2 \
  -m "$AGENT_MODEL" \
  -e docker \
  --jobs-dir "$JOBS_DIR" \
  --job-name "$JOB_NAME" \
  --yes \
  --ve RUN_LLM_JUDGES=1 \
  --ve "GEMINI_API_KEY=${GEMINI_API_KEY}" \
  --ve "JUDGE_REPEATS=${JUDGE_REPEATS}" \
  --ve "JUDGE_TIMEOUT_SEC=${JUDGE_TIMEOUT_SEC}"
