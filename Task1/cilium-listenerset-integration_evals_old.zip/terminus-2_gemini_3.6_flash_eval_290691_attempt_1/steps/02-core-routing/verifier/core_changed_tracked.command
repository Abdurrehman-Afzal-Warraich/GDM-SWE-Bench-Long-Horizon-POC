git diff --no-ext-diff --name-only bc83bf17e523636627fd49f72affc25d93e88ba0 -- .
