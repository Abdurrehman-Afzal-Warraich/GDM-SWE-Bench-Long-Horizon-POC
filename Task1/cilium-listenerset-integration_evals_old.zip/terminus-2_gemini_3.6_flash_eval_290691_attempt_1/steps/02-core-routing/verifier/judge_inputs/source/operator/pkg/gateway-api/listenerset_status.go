// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

package gateway_api

import (
"context"
"time"

corev1 "k8s.io/api/core/v1"
metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
"k8s.io/apimachinery/pkg/labels"
"k8s.io/apimachinery/pkg/types"
"sigs.k8s.io/controller-runtime/pkg/client"
gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"

"github.com/cilium/cilium/operator/pkg/gateway-api/helpers"
)

func isListenerSetAllowed(ctx context.Context, c client.Client, gw *gatewayv1.Gateway, ls *gatewayv1.ListenerSet, namespaceLabels helpers.NamespaceLabelIndex) bool {
if gw.Spec.AllowedListeners == nil || gw.Spec.AllowedListeners.Namespaces == nil || gw.Spec.AllowedListeners.Namespaces.From == nil {
return false
}

from := *gw.Spec.AllowedListeners.Namespaces.From
switch from {
case gatewayv1.FromNamespaces("None"):
return false
case gatewayv1.FromNamespaces("Same"):
return ls.Namespace == gw.Namespace
case gatewayv1.FromNamespaces("All"):
return true
case gatewayv1.FromNamespaces("Selector"):
if gw.Spec.AllowedListeners.Namespaces.Selector == nil {
return false
}
selector, err := metav1.LabelSelectorAsSelector(gw.Spec.AllowedListeners.Namespaces.Selector)
if err != nil {
return false
}
nsLabels, ok := namespaceLabels[ls.Namespace]
if !ok {
ns := &corev1.Namespace{}
if err := c.Get(ctx, types.NamespacedName{Name: ls.Namespace}, ns); err != nil {
return false
}
nsLabels = ns.Labels
}
return selector.Matches(labels.Set(nsLabels))
}
return false
}

func (r *gatewayReconciler) updateListenerSetStatus(ctx context.Context, ls *gatewayv1.ListenerSet, allowed bool, gwAccepted bool, gwProgrammed bool, routeCounts map[string]int32) error {
orig := ls.DeepCopy()

var acceptedCond, programmedCond metav1.Condition
now := metav1.NewTime(time.Now())

if !allowed {
acceptedCond = metav1.Condition{
Type:               string(gatewayv1.ListenerSetConditionAccepted),
Status:             metav1.ConditionFalse,
Reason:             "NotAllowedByGateway",
Message:            "ListenerSet namespace is not allowed by Gateway allowedListeners policy",
ObservedGeneration: ls.GetGeneration(),
LastTransitionTime: now,
}
programmedCond = metav1.Condition{
Type:               string(gatewayv1.ListenerSetConditionProgrammed),
Status:             metav1.ConditionFalse,
Reason:             "NotAllowedByGateway",
Message:            "ListenerSet is not allowed by Gateway",
ObservedGeneration: ls.GetGeneration(),
LastTransitionTime: now,
}
} else if !gwAccepted {
acceptedCond = metav1.Condition{
Type:               string(gatewayv1.ListenerSetConditionAccepted),
Status:             metav1.ConditionFalse,
Reason:             "InvalidGateway",
Message:            "Parent Gateway is not accepted",
ObservedGeneration: ls.GetGeneration(),
LastTransitionTime: now,
}
programmedCond = metav1.Condition{
Type:               string(gatewayv1.ListenerSetConditionProgrammed),
Status:             metav1.ConditionFalse,
Reason:             "InvalidGateway",
Message:            "Parent Gateway is not accepted",
ObservedGeneration: ls.GetGeneration(),
LastTransitionTime: now,
}
} else {
acceptedCond = metav1.Condition{
Type:               string(gatewayv1.ListenerSetConditionAccepted),
Status:             metav1.ConditionTrue,
Reason:             "Accepted",
Message:            "ListenerSet accepted by parent Gateway",
ObservedGeneration: ls.GetGeneration(),
LastTransitionTime: now,
}
if gwProgrammed {
programmedCond = metav1.Condition{
Type:               string(gatewayv1.ListenerSetConditionProgrammed),
Status:             metav1.ConditionTrue,
Reason:             "Programmed",
Message:            "ListenerSet programmed",
ObservedGeneration: ls.GetGeneration(),
LastTransitionTime: now,
}
} else {
programmedCond = metav1.Condition{
Type:               string(gatewayv1.ListenerSetConditionProgrammed),
Status:             metav1.ConditionFalse,
Reason:             "Pending",
Message:            "Waiting for parent Gateway to be programmed",
ObservedGeneration: ls.GetGeneration(),
LastTransitionTime: now,
}
}
}

ls.Status.Conditions = merge(ls.Status.Conditions, acceptedCond, programmedCond)

var listenerStatuses []gatewayv1.ListenerEntryStatus
for _, entry := range ls.Spec.Listeners {
attached := routeCounts[string(entry.Name)]
les := gatewayv1.ListenerEntryStatus{
Name:           entry.Name,
AttachedRoutes: attached,
SupportedKinds: []gatewayv1.RouteGroupKind{
{Group: (*gatewayv1.Group)(&gatewayv1.GroupVersion.Group), Kind: "HTTPRoute"},
{Group: (*gatewayv1.Group)(&gatewayv1.GroupVersion.Group), Kind: "GRPCRoute"},
{Group: (*gatewayv1.Group)(&gatewayv1.GroupVersion.Group), Kind: "TLSRoute"},
{Group: (*gatewayv1.Group)(&gatewayv1.GroupVersion.Group), Kind: "TCPRoute"},
{Group: (*gatewayv1.Group)(&gatewayv1.GroupVersion.Group), Kind: "UDPRoute"},
},
}
if allowed && gwAccepted {
les.Conditions = []metav1.Condition{
{
Type:               string(gatewayv1.ListenerConditionAccepted),
Status:             metav1.ConditionTrue,
Reason:             "Accepted",
Message:            "Listener entry accepted",
ObservedGeneration: ls.GetGeneration(),
LastTransitionTime: now,
},
{
Type:               string(gatewayv1.ListenerConditionProgrammed),
Status:             metav1.ConditionTrue,
Reason:             "Programmed",
Message:            "Listener entry programmed",
ObservedGeneration: ls.GetGeneration(),
LastTransitionTime: now,
},
{
Type:               string(gatewayv1.ListenerConditionResolvedRefs),
Status:             metav1.ConditionTrue,
Reason:             "ResolvedRefs",
Message:            "Resolved references",
ObservedGeneration: ls.GetGeneration(),
LastTransitionTime: now,
},
{
Type:               string(gatewayv1.ListenerConditionConflicted),
Status:             metav1.ConditionFalse,
Reason:             "NoConflicts",
Message:            "No conflicts detected",
ObservedGeneration: ls.GetGeneration(),
LastTransitionTime: now,
},
}
} else {
les.Conditions = []metav1.Condition{
{
Type:               string(gatewayv1.ListenerConditionAccepted),
Status:             metav1.ConditionFalse,
Reason:             "NotAllowedByGateway",
Message:            "Listener entry not allowed",
ObservedGeneration: ls.GetGeneration(),
LastTransitionTime: now,
},
}
}
listenerStatuses = append(listenerStatuses, les)
}
ls.Status.Listeners = listenerStatuses

return r.Client.Status().Patch(ctx, ls, client.MergeFrom(orig))
}
