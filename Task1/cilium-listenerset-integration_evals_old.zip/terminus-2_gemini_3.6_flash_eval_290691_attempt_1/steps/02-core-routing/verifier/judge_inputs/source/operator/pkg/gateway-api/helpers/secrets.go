// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

package helpers

import (
"context"
"log/slog"

"k8s.io/apimachinery/pkg/types"
"sigs.k8s.io/controller-runtime/pkg/client"
gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"

"github.com/cilium/cilium/pkg/logging/logfields"
)

func GetGatewaysForSecret(ctx context.Context, c client.Client, obj client.Object, logger *slog.Logger) []*gatewayv1.Gateway {
scopedLog := logger.With(
logfields.Resource, obj.GetName(),
)

gwList := &gatewayv1.GatewayList{}
if err := c.List(ctx, gwList); err != nil {
scopedLog.WarnContext(ctx, "Unable to list Gateways", logfields.Error, err)
return nil
}

gwMap := make(map[types.NamespacedName]*gatewayv1.Gateway)
for i := range gwList.Items {
gw := &gwList.Items[i]
for _, l := range gw.Spec.Listeners {
if l.TLS == nil {
continue
}

for _, cert := range l.TLS.CertificateRefs {
if !IsSecret(cert) {
continue
}
ns := NamespaceDerefOr(cert.Namespace, gw.GetNamespace())
if string(cert.Name) == obj.GetName() && ns == obj.GetNamespace() {
gwMap[types.NamespacedName{Namespace: gw.Namespace, Name: gw.Name}] = gw
}
}
}
}

lsList := &gatewayv1.ListenerSetList{}
if err := c.List(ctx, lsList); err == nil {
for _, ls := range lsList.Items {
for _, l := range ls.Spec.Listeners {
if l.TLS == nil {
continue
}
for _, cert := range l.TLS.CertificateRefs {
if !IsSecret(cert) {
continue
}
ns := NamespaceDerefOr(cert.Namespace, ls.GetNamespace())
if string(cert.Name) == obj.GetName() && ns == obj.GetNamespace() {
parent := ls.Spec.ParentRef
gwNs := NamespaceDerefOr(parent.Namespace, ls.Namespace)
gwKey := types.NamespacedName{Namespace: gwNs, Name: string(parent.Name)}
if gw, exists := gwMap[gwKey]; exists {
gwMap[gwKey] = gw
} else {
parentGW := &gatewayv1.Gateway{}
if err := c.Get(ctx, gwKey, parentGW); err == nil {
gwMap[gwKey] = parentGW
}
}
}
}
}
}
}

var gateways []*gatewayv1.Gateway
for _, gw := range gwMap {
gateways = append(gateways, gw)
}
return gateways
}
