// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

package watchhandlers

import (
"context"
"log/slog"

"k8s.io/apimachinery/pkg/types"
"sigs.k8s.io/controller-runtime/pkg/client"
"sigs.k8s.io/controller-runtime/pkg/handler"
"sigs.k8s.io/controller-runtime/pkg/reconcile"
gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"

"github.com/cilium/cilium/operator/pkg/gateway-api/helpers"
)

// EnqueueRequestForOwningListenerSet returns an event handler for any changes with ListenerSet.
// It maps the ListenerSet to a reconcile request for its parent Gateway.
func EnqueueRequestForOwningListenerSet(c client.Client, logger *slog.Logger) handler.EventHandler {
return handler.EnqueueRequestsFromMapFunc(func(ctx context.Context, obj client.Object) []reconcile.Request {
ls, ok := obj.(*gatewayv1.ListenerSet)
if !ok {
return nil
}
parent := ls.Spec.ParentRef
if (parent.Group == nil || string(*parent.Group) == gatewayv1.GroupName) &&
(parent.Kind == nil || string(*parent.Kind) == "Gateway") {
ns := helpers.NamespaceDerefOr(parent.Namespace, ls.Namespace)
return []reconcile.Request{
{
NamespacedName: types.NamespacedName{
Namespace: ns,
Name:      string(parent.Name),
},
},
}
}
return nil
})
}
