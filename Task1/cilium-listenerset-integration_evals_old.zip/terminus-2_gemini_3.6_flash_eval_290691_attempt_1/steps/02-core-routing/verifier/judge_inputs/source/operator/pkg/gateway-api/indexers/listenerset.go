// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

package indexers

import (
"k8s.io/apimachinery/pkg/types"
"sigs.k8s.io/controller-runtime/pkg/client"
gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"

"github.com/cilium/cilium/operator/pkg/gateway-api/helpers"
)

// IndexListenerSetByGateway indexes ListenerSets by their parent Gateway full name (`namespace/name`).
func IndexListenerSetByGateway(rawObj client.Object) []string {
ls, ok := rawObj.(*gatewayv1.ListenerSet)
if !ok {
return nil
}
parent := ls.Spec.ParentRef
if (parent.Group == nil || string(*parent.Group) == gatewayv1.GroupName) &&
(parent.Kind == nil || string(*parent.Kind) == "Gateway") {
ns := helpers.NamespaceDerefOr(parent.Namespace, ls.Namespace)
return []string{
types.NamespacedName{
Namespace: ns,
Name:      string(parent.Name),
}.String(),
}
}
return nil
}
