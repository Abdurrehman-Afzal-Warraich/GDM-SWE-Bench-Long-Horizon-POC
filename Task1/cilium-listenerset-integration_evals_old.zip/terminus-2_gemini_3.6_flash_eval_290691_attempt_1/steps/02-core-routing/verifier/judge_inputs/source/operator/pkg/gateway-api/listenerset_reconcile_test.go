// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

package gateway_api

import (
	"context"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	ctrl "sigs.k8s.io/controller-runtime"
	"sigs.k8s.io/controller-runtime/pkg/client/fake"
	gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"
	gatewayv1alpha2 "sigs.k8s.io/gateway-api/apis/v1alpha2"

	"github.com/cilium/cilium/operator/pkg/gateway-api/helpers"
	"github.com/cilium/cilium/operator/pkg/gateway-api/indexers"

	"github.com/cilium/cilium/operator/pkg/model/translation"
	gatewayApiTranslation "github.com/cilium/cilium/operator/pkg/model/translation/gateway-api"
	ciliumv2 "github.com/cilium/cilium/pkg/k8s/apis/cilium.io/v2"
	"k8s.io/apimachinery/pkg/api/meta"
	"log/slog"
)

func Test_ListenerSet_Reconciliation(t *testing.T) {
	scheme := helpers.TestScheme(helpers.AllOptionalKinds)

	gwc := &gatewayv1.GatewayClass{
		ObjectMeta: metav1.ObjectMeta{Name: "cilium"},
		Spec:       gatewayv1.GatewayClassSpec{ControllerName: "io.cilium/gateway-controller"},
	}

	sameFrom := gatewayv1.FromNamespaces("Same")
	noneFrom := gatewayv1.FromNamespaces("None")

	gw := &gatewayv1.Gateway{
		ObjectMeta: metav1.ObjectMeta{Name: "test-gw", Namespace: "default"},
		Spec: gatewayv1.GatewaySpec{
			GatewayClassName: "cilium",
			AllowedListeners: &gatewayv1.AllowedListeners{
				Namespaces: &gatewayv1.ListenerNamespaces{
					From: &sameFrom,
				},
			},
			Listeners: []gatewayv1.Listener{
				{
					Name:     "http",
					Port:     80,
					Protocol: gatewayv1.HTTPProtocolType,
				},
			},
		},
	}

	ls := &gatewayv1.ListenerSet{
		ObjectMeta: metav1.ObjectMeta{Name: "test-ls", Namespace: "default"},
		Spec: gatewayv1.ListenerSetSpec{
			ParentRef: gatewayv1.ParentGatewayReference{
				Name: "test-gw",
			},
			Listeners: []gatewayv1.ListenerEntry{
				{
					Name:     "ls-http",
					Port:     8080,
					Protocol: gatewayv1.HTTPProtocolType,
				},
			},
		},
	}

	lsKind := gatewayv1.Kind("ListenerSet")
	route := &gatewayv1.HTTPRoute{
		ObjectMeta: metav1.ObjectMeta{Name: "ls-route", Namespace: "default"},
		Spec: gatewayv1.HTTPRouteSpec{
			CommonRouteSpec: gatewayv1.CommonRouteSpec{
				ParentRefs: []gatewayv1.ParentReference{
					{
						Kind: &lsKind,
						Name: "test-ls",
					},
				},
			},
			Rules: []gatewayv1.HTTPRouteRule{
				{
					BackendRefs: []gatewayv1.HTTPBackendRef{
						{
							BackendRef: gatewayv1.BackendRef{
								BackendObjectReference: gatewayv1.BackendObjectReference{
									Name: "test-svc",
									Port: ptrToPort(8080),
								},
							},
						},
					},
				},
			},
		},
	}

	svc := &corev1.Service{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "test-gw-service",
			Namespace: "default",
			Labels: map[string]string{
				owningGatewayLabel: "test-gw",
			},
		},
		Spec: corev1.ServiceSpec{
			Type: corev1.ServiceTypeLoadBalancer,
		},
		Status: corev1.ServiceStatus{
			LoadBalancer: corev1.LoadBalancerStatus{
				Ingress: []corev1.LoadBalancerIngress{{IP: "1.2.3.4"}},
			},
		},
	}

	backendSvc := &corev1.Service{
		ObjectMeta: metav1.ObjectMeta{Name: "test-svc", Namespace: "default"},
		Spec:       corev1.ServiceSpec{Type: corev1.ServiceTypeClusterIP},
	}

	ns := &corev1.Namespace{
		ObjectMeta: metav1.ObjectMeta{Name: "default"},
	}

	c := fake.NewClientBuilder().
		WithScheme(scheme).
		WithObjects(gwc, gw, ls, route, svc, backendSvc, ns).
		WithStatusSubresource(gw, ls, route).
		WithIndex(&gatewayv1.ListenerSet{}, indexers.GatewayListenerSetIndex, indexers.IndexListenerSetByGateway).
		WithIndex(&gatewayv1.HTTPRoute{}, indexers.GatewayHTTPRouteIndex, indexers.IndexHTTPRouteByGateway).
		WithIndex(&gatewayv1.GRPCRoute{}, indexers.GatewayGRPCRouteIndex, indexers.IndexGRPCRouteByGateway).
		WithIndex(&gatewayv1.TLSRoute{}, indexers.GatewayTLSRouteIndex, indexers.IndexTLSRouteByGateway).
		WithIndex(&gatewayv1alpha2.TCPRoute{}, indexers.GatewayTCPRouteIndex, indexers.IndexTCPRouteByGateway).
		WithIndex(&gatewayv1alpha2.UDPRoute{}, indexers.GatewayUDPRouteIndex, indexers.IndexUDPRouteByGateway).
		Build()

	cfg := translation.Config{}
	cecTranslator := translation.NewCECTranslator(cfg)
	translator := gatewayApiTranslation.NewTranslator(cecTranslator, cfg)

	r := &gatewayReconciler{
		Client:         c,
		Scheme:         scheme,
		translator:     translator,
		logger:         slog.Default(),
		controllerName: "io.cilium/gateway-controller",
	}

	res, err := r.Reconcile(context.Background(), ctrl.Request{
		NamespacedName: types.NamespacedName{Name: "test-gw", Namespace: "default"},
	})
	require.NoError(t, err)
	assert.Equal(t, ctrl.Result{}, res)

	var fetchedLS gatewayv1.ListenerSet
	err = c.Get(context.Background(), types.NamespacedName{Name: "test-ls", Namespace: "default"}, &fetchedLS)
	require.NoError(t, err)

	assert.NotEmpty(t, fetchedLS.Status.Conditions)
	acceptedCond := meta.FindStatusCondition(fetchedLS.Status.Conditions, string(gatewayv1.ListenerSetConditionAccepted))
	require.NotNil(t, acceptedCond)
	assert.Equal(t, metav1.ConditionTrue, acceptedCond.Status)

	var fetchedGW gatewayv1.Gateway
	err = c.Get(context.Background(), types.NamespacedName{Name: "test-gw", Namespace: "default"}, &fetchedGW)
	require.NoError(t, err)
	require.NotNil(t, fetchedGW.Status.AttachedListenerSets)
	assert.Equal(t, int32(1), *fetchedGW.Status.AttachedListenerSets)

	var cecList ciliumv2.CiliumEnvoyConfigList
	err = c.List(context.Background(), &cecList)
	require.NoError(t, err)
	assert.NotEmpty(t, cecList.Items)

	// Test AllowedListeners = None disables attachment
	err = c.Get(context.Background(), types.NamespacedName{Name: "test-gw", Namespace: "default"}, gw)
	require.NoError(t, err)
	gw.Spec.AllowedListeners.Namespaces.From = &noneFrom
	err = c.Update(context.Background(), gw)
	require.NoError(t, err)

	_, err = r.Reconcile(context.Background(), ctrl.Request{
		NamespacedName: types.NamespacedName{Name: "test-gw", Namespace: "default"},
	})
	require.NoError(t, err)

	err = c.Get(context.Background(), types.NamespacedName{Name: "test-ls", Namespace: "default"}, &fetchedLS)
	require.NoError(t, err)
	acceptedCond = meta.FindStatusCondition(fetchedLS.Status.Conditions, string(gatewayv1.ListenerSetConditionAccepted))
	require.NotNil(t, acceptedCond)
	assert.Equal(t, metav1.ConditionFalse, acceptedCond.Status)

	err = c.Get(context.Background(), types.NamespacedName{Name: "test-gw", Namespace: "default"}, &fetchedGW)
	require.NoError(t, err)
	assert.Nil(t, fetchedGW.Status.AttachedListenerSets)
}

func ptrToPort(p int) *gatewayv1.PortNumber {
	pn := gatewayv1.PortNumber(p)
	return &pn
}
