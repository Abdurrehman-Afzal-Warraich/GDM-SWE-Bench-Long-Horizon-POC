#!/usr/bin/env bash
set -euo pipefail

export PATH=$PATH:/usr/local/go/bin
cd /testbed

OUTPUT=$(go run /app/output/01-diagnose/reproduce.go 2>&1)

echo "$OUTPUT" | tee /app/output/01-diagnose/reproducer.log
