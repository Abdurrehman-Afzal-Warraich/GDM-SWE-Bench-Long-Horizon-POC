package main

import (
"context"
"fmt"

metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
"k8s.io/apimachinery/pkg/runtime"
"k8s.io/apimachinery/pkg/types"
"sigs.k8s.io/controller-runtime/pkg/client/fake"
gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"

ciliumv2 "github.com/cilium/cilium/pkg/k8s/apis/cilium.io/v2"
)

func main() {
scheme := runtime.NewScheme()
_ = gatewayv1.AddToScheme(scheme)
_ = ciliumv2.AddToScheme(scheme)

gvk := gatewayv1.SchemeGroupVersion.WithKind("ListenerSet")
recognized := scheme.Recognizes(gvk)

ls := &gatewayv1.ListenerSet{
TypeMeta: metav1.TypeMeta{
APIVersion: gatewayv1.SchemeGroupVersion.String(),
Kind:       "ListenerSet",
},
ObjectMeta: metav1.ObjectMeta{
Name:      "test-ls",
Namespace: "default",
},
Spec: gatewayv1.ListenerSetSpec{
ParentRef: gatewayv1.ParentGatewayReference{
Name: "test-gw",
},
Listeners: []gatewayv1.ListenerEntry{
{
Name:     "ls-listener",
Port:     8080,
Protocol: gatewayv1.HTTPProtocolType,
},
},
},
}

client := fake.NewClientBuilder().WithScheme(scheme).WithObjects(ls).Build()

var fetchedLS gatewayv1.ListenerSet
err := client.Get(context.Background(), types.NamespacedName{Name: "test-ls", Namespace: "default"}, &fetchedLS)
if err != nil {
recognized = false
}

statusReconciled := len(fetchedLS.Status.Conditions) > 0
var cecList ciliumv2.CiliumEnvoyConfigList
_ = client.List(context.Background(), &cecList)
configPresent := len(cecList.Items) > 0

fmt.Printf("##OBSERVATION## {\"listenerset_recognized\": %t, \"listenerset_status_reconciled\": %t, \"listenerset_config_present\": %t}\n", recognized, statusReconciled, configPresent)
}
