git diff --no-ext-diff --check 71328f49069f32ce82133fa00e87f6a542a0a213 -- .
