#!/bin/bash

echo "=== Checking Kubernetes 1.35 Adaptation Gap ==="

GAP_FOUND=0

echo "--- Checking go.mod for k8s.io v0.35.0 / v1.35.0 ---"
if grep -q "k8s.io/api v0.35.0" go.mod || grep -q "k8s.io/kubernetes v1.35.0" go.mod; then
  echo "k8s.io v0.35.0/v1.35.0 found in go.mod."
else
  echo "GAP DETECTED: go.mod still targets k8s.io 0.34.1 / 1.34.1"
  GAP_FOUND=1
fi

echo "--- Checking generated informers for ToListWatcherWithWatchListSemantics ---"
if grep -rn "ToListWatcherWithWatchListSemantics" staging/src/volcano.sh/apis/pkg/client/informers/ >/dev/null 2>&1; then
  echo "ToListWatcherWithWatchListSemantics found in informers."
else
  echo "GAP DETECTED: Informers lack ToListWatcherWithWatchListSemantics"
  GAP_FOUND=1
fi

echo "--- Checking volumebinding package for passiveAssumeCache ---"
if grep -rn "passiveAssumeCache" pkg/scheduler/capabilities/volumebinding/ >/dev/null 2>&1; then
  echo "passiveAssumeCache found in volumebinding."
else
  echo "GAP DETECTED: passiveAssumeCache wiring absent from volumebinding package"
  GAP_FOUND=1
fi

if [ $GAP_FOUND -ne 0 ]; then
  echo "=== Concrete evidence of Kubernetes 1.35 adaptation gap identified ==="
  exit 1
fi

exit 0
