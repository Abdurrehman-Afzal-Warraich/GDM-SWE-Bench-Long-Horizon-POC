#!/usr/bin/env bash
set -uo pipefail
cd /testbed
echo "== go.mod kubernetes pins =="
grep -E 'k8s.io/(api|client-go|apimachinery) v0' go.mod || true
if grep -q 'k8s.io/api v0.35.0' go.mod; then
  echo "ERROR: already at v0.35"
  exit 0
fi
echo "GAP: module pins still target v0.34.x (Kubernetes 1.34), not v0.35.x (1.35)"
echo "== scheduler framework import split =="
grep -n 'k8s.io/kubernetes/pkg/scheduler/framework' pkg/scheduler/plugins/predicates/predicates.go | head -3 || true
grep -n 'k8s.io/kube-scheduler/framework' pkg/scheduler/plugins/predicates/predicates.go | head -3 || true
echo "GAP: mixed internal kubernetes scheduler imports remain"
echo "== WatchList wrapper absent =="
path=staging/src/volcano.sh/apis/pkg/client/informers/externalversions/batch/v1alpha1/job.go
if [ -f "$path" ] && grep -q ToListWatcherWithWatchListSemantics "$path"; then
  echo "unexpected: WatchList wrapper already present"
else
  echo "GAP: informer WatchList wrapper not generated yet"
fi
exit 1
