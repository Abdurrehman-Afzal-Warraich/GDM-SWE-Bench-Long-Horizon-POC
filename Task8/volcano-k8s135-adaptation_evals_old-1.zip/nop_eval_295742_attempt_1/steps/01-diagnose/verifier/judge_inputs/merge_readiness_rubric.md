# Merge-readiness rubric — Volcano Kubernetes 1.35 adaptation

The executable verdict is already final. A terminal reviewer evaluates the six
standard dimensions declared in `merge_readiness/judge.toml`: repository
conventions, focused change, maintainability, architecture, useful tests and no
patch bloat. Record a failure only when it supports a concrete change-request
comment on a file or hunk.
