#!/usr/bin/env bash
set -e

echo "=== Stage 01: Kubernetes 1.35 Adaptation Gap Diagnosis ==="
ERRORS=0

echo "[1] Checking go.mod for Kubernetes 1.35 module pins..."
if grep -q "k8s.io/client-go v0.35" go.mod || grep -q "k8s.io/kubernetes v1.35" go.mod; then
    echo "  [OK] Kubernetes 1.35 module pins found in go.mod."
else
    echo "  [FAIL] go.mod still targets Kubernetes 1.34 module pins instead of v0.35.0 / v1.35.0."
    ERRORS=$((ERRORS + 1))
fi

echo "[2] Checking generated informers for ToListWatcherWithWatchListSemantics interface..."
if grep -rn "ToListWatcherWithWatchListSemantics" staging/src/volcano.sh/apis/pkg/client/informers/ >/dev/null 2>&1; then
    echo "  [OK] ToListWatcherWithWatchListSemantics found in generated informers."
else
    echo "  [FAIL] Generated informers in staging/src/volcano.sh/apis/pkg/client/informers lack ToListWatcherWithWatchListSemantics required for k8s 0.35.0 client-go watchlist support."
    ERRORS=$((ERRORS + 1))
fi

echo "[3] Checking volumebinding package for passiveAssumeCache wiring..."
if grep -rn "passiveAssumeCache" pkg/scheduler/capabilities/volumebinding/ >/dev/null 2>&1; then
    echo "  [OK] passiveAssumeCache wiring found in volumebinding."
else
    echo "  [FAIL] passiveAssumeCache wiring is absent from pkg/scheduler/capabilities/volumebinding."
    ERRORS=$((ERRORS + 1))
fi

if [ $ERRORS -gt 0 ]; then
    echo "Concrete evidence of Kubernetes 1.35 adaptation gap found ($ERRORS error(s))."
    exit 1
else
    echo "All checks passed."
    exit 0
fi
