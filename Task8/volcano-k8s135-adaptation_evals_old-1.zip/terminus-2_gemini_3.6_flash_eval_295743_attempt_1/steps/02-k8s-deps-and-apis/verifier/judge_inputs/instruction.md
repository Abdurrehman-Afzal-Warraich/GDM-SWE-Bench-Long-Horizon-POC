# Stage 02 — bump Kubernetes deps and regenerate APIs

Work in `/testbed`. Prior diagnosis persists in `/app/output`; this stage receives
a fresh briefing plus the handoff.

Upgrade Volcano to Kubernetes 1.35 module pins and refresh the generated client,
informer, and apply-configuration artifacts under `staging/src/volcano.sh/apis`.
Scope includes root `go.mod`, `go.sum`, CRDs, Makefile/hack scripts, README,
license metadata, and installer manifests touched by the dependency bump.

Exclude `.github/workflows` from your edits.

**Code generation:** `k8s.io/code-generator v0.35.0` is pinned in `go.mod` and already
present in the module cache, so you can build and run the generators without any network
fetch. Invoke them directly from the cache with
`go run k8s.io/code-generator/cmd/{client-gen,informer-gen,lister-gen,applyconfiguration-gen,deepcopy-gen}`
(after bumping the module pins and running `go mod download`). Note that the repository's
legacy `hack/` scripts (`generate-groups.sh`, `generate-internal-groups.sh`,
`update-codegen.sh`) invoke `go install`/`go get` to fetch the generators — **do not run
those install/get steps**: `go install`, `go get`, `curl`, `wget`, and other fetches are
rejected by the integrity policy. Reading or `grep`-ing those scripts to understand the
codegen flow is fine; only *executing* an install/get is a violation. Regeneration is
optional if you edit the generated trees directly; the pinned generators are provided so
the intended `go run` codegen path is fully available. After bumping the module pins,
reconcile **both** `go.sum` files (root and `staging/src/volcano.sh/apis/go.sum`) with
`go mod tidy` / `go mod download` (allowed, cache-backed) so the standalone `apis` module
builds; do **not** use `go get`/`go install`, which the integrity policy rejects.

Write `/app/output/02-k8s-deps-and-apis/implementation.json` with non-empty
`dependency_bump`, `codegen_scope`, `watchlist_handling`, and `packages_touched`
(array). Update `/app/output/handoff.json` with non-empty `stage`, `summary`, and
`next_steps` (array). Each artifact is capped at 256 KiB. These report and handoff artifacts are
scored into `training_score` only; they are not part of the critical check set and do
not gate stage promotion (`binary_reward`). The build, hidden-test, and vet gates decide
official pass/fail.

The verifier will run `go build` on `volcano.sh/apis/...` plus injected contract tests.
It expects `k8s.io/api v0.35.0` (and related module pins) in `go.mod`, WatchList wrapper
helpers (including `ToListWatcherWithWatchListSemantics`) anywhere in the generated informer tree, and a fake-clientset WatchList opt-out
hook anywhere under the versioned clientset package tree.
