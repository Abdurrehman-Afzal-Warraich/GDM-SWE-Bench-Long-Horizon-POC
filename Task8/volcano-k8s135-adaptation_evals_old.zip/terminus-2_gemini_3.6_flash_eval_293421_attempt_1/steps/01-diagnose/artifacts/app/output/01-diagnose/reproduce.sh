#!/usr/bin/env bash
echo "=== K8s 1.35 Adaptation Gap Reproduction ==="
FAIL=0
grep -q "k8s.io/api v0.35" go.mod || { echo "[GAP] go.mod lacks k8s.io/* v0.35.0"; FAIL=1; }
grep -rn "ToListWatcherWithWatchListSemantics" pkg/ staging/ >/dev/null 2>&1 || { echo "[GAP] informers lack ToListWatcherWithWatchListSemantics"; FAIL=1; }
grep -rn "passiveAssumeCache" pkg/ staging/ >/dev/null 2>&1 || { echo "[GAP] volumebinding lacks passiveAssumeCache"; FAIL=1; }
[ $FAIL -ne 0 ] && exit 1 || exit 0
