# Stage 03 — migrate scheduler framework imports

Work in `/testbed`. Stages 01–02 artifacts and code changes persist; you receive a
fresh briefing plus the handoff.

Migrate scheduler, agentscheduler, and vendored queue code from internal
`k8s.io/kubernetes/pkg/scheduler/framework` imports to `k8s.io/kube-scheduler/framework`.
Update DRA-related feature-gate field renames in scheduler and agentscheduler caches
(for example `EnableDeviceTaintRules`, `EnableDRAConsumableCapacity`).

Scope: `pkg/scheduler/plugins`, `pkg/scheduler/framework`, `pkg/scheduler/cache`,
`pkg/scheduler/capabilities/volumebinding`, `pkg/agentscheduler`,
`third_party/kubernetes/pkg/scheduler/backend/queue`, plus related helpers listed
in the stage patch footprint.

Write `/app/output/03-scheduler-framework/review_response.json` with non-empty
`framework_migration`, `dra_renames`, `packages_touched` (array), and
`verification_performed` (array). Refresh `/app/output/handoff.json`. This
`review_response.json` and the handoff are scored into `training_score` only; they are
not part of the critical check set and do not gate stage promotion (`binary_reward`).
The scheduler build, hidden-test, and vet gates decide official pass/fail.

**Verification:** the grader runs `go build` on scheduler packages, plus injected
contract tests filtered to this stage's hidden test names. Checks require
`k8s.io/kube-scheduler/framework` imports somewhere under `pkg/scheduler/plugins/`,
DRA field renames (`EnableDeviceTaintRules`, `EnableDRAConsumableCapacity`) in cache
and plugin packages, and a successful scheduler package build. Production packages are
typechecked by `go build`; `go vet` runs on production `.go` files under
`./pkg/scheduler/...` and `./pkg/agentscheduler/...` (upstream `_test.go` files are excluded).
