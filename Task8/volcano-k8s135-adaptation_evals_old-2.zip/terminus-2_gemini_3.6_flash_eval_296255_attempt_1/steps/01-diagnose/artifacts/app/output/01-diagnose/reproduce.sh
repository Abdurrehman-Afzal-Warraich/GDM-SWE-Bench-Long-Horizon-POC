#!/usr/bin/env bash
set -e
echo "=== Stage 01: Kubernetes 1.35 Adaptation Gap Reproducer ==="
echo "1. Checking k8s module pins in go.mod..."
if grep -q "k8s.io/api v0.34" go.mod; then
    echo "GAP DETECTED: go.mod uses k8s v0.34.1 pins instead of v0.35.0"
fi
echo "2. Checking generated informers for ToListWatcherWithWatchListSemantics..."
if ! grep -rn "ToListWatcherWithWatchListSemantics" staging/src/volcano.sh/apis/pkg/client/informers/ >/dev/null 2>&1; then
    echo "GAP DETECTED: Informers lack ToListWatcherWithWatchListSemantics"
fi
echo "3. Checking volumebinding package for passiveAssumeCache..."
if ! grep -rn "passiveAssumeCache" pkg/scheduler/capabilities/volumebinding/ >/dev/null 2>&1; then
    echo "GAP DETECTED: volumebinding package lacks passiveAssumeCache wiring"
fi
echo "Kubernetes 1.35 adaptation gap confirmed."
exit 1
