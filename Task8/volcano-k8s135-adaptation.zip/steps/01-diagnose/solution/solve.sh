#!/usr/bin/env bash
# Oracle, stage 01 — diagnosis only (no production edits).
set -euo pipefail

OUT=/app/output
STAGE=01-diagnose
STAGE_OUT="$OUT/$STAGE"
mkdir -p "$STAGE_OUT"
cd /testbed

cat > "$STAGE_OUT/reproduce.sh" <<'REPRO'
#!/usr/bin/env bash
set -uo pipefail
cd /testbed
echo "== go.mod kubernetes pins =="
grep -E 'k8s.io/(api|client-go|apimachinery) v0' go.mod || true
if grep -q 'k8s.io/api v0.35.0' go.mod; then
  echo "ERROR: already at v0.35"
  exit 0
fi
echo "GAP: module pins still target v0.34.x (Kubernetes 1.34), not v0.35.x (1.35)"
echo "== scheduler framework import split =="
grep -n 'k8s.io/kubernetes/pkg/scheduler/framework' pkg/scheduler/plugins/predicates/predicates.go | head -3 || true
grep -n 'k8s.io/kube-scheduler/framework' pkg/scheduler/plugins/predicates/predicates.go | head -3 || true
echo "GAP: mixed internal kubernetes scheduler imports remain"
echo "== WatchList wrapper absent =="
path=staging/src/volcano.sh/apis/pkg/client/informers/externalversions/batch/v1alpha1/job.go
if [ -f "$path" ] && grep -q ToListWatcherWithWatchListSemantics "$path"; then
  echo "unexpected: WatchList wrapper already present"
else
  echo "GAP: informer WatchList wrapper not generated yet"
fi
exit 1
REPRO
chmod +x "$STAGE_OUT/reproduce.sh"
bash "$STAGE_OUT/reproduce.sh" >/tmp/repro.out 2>&1 || true

python3 - <<'PY'
import json
from pathlib import Path

out = Path("/app/output")
stage_out = out / "01-diagnose"
(stage_out / "diagnosis.json").write_text(json.dumps({
    "missing_capabilities": [
        "Kubernetes 1.35 module pins (k8s.io/* v0.35.0)",
        "Informer WatchList semantics wrapper in generated clients",
        "Unified kube-scheduler framework imports across scheduler plugins",
        "passiveAssumeCache volume-binding refactor",
    ],
    "affected_packages": [
        "go.mod",
        "staging/src/volcano.sh/apis/pkg/client/informers",
        "pkg/scheduler/plugins/predicates",
        "pkg/scheduler/capabilities/volumebinding",
    ],
    "reproducer": "/app/output/01-diagnose/reproduce.sh",
    "root_cause": (
        "Volcano base targets Kubernetes 1.34 modules and still imports internal "
        "kubernetes scheduler framework paths that moved to k8s.io/kube-scheduler/framework "
        "for Kubernetes 1.35."
    ),
}, indent=2) + "\n", encoding="utf-8")

(out / "handoff.json").write_text(json.dumps({
    "stage": "01-diagnose",
    "summary": (
        "Base go.mod remains on k8s v0.34.x, informers lack WatchList wrappers, "
        "scheduler code still mixes kubernetes/pkg scheduler imports, and volume "
        "binding lacks passiveAssumeCache."
    ),
    "next_steps": [
        "Bump go.mod/go.sum and regenerate staging/apis client/informer artifacts.",
        "Migrate scheduler and agentscheduler plugins to k8s.io/kube-scheduler/framework.",
        "Land passiveAssumeCache volume-binding changes and refresh installer Dockerfiles.",
    ],
}, indent=2) + "\n", encoding="utf-8")
PY

echo "stage 01 complete"
