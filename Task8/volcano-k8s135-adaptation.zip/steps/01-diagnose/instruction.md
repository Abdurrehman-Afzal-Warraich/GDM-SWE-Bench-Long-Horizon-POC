# Stage 01 — diagnose the k8s 1.35 adaptation gap

Work in `/testbed`. The repository and `/app/output` persist; the next stage receives
fresh context and your handoff.

Volcano at this base commit still targets Kubernetes 1.34 module pins and mixes
internal `k8s.io/kubernetes/pkg/scheduler/framework` imports with newer scheduler
API surfaces. Investigate the dependency/codegen gap and the scheduler-framework
migration work still required for Kubernetes 1.35.

Create these bounded outputs (each at most 256 KiB):

- `/app/output/01-diagnose/reproduce.sh`: runs from `/testbed`, prints concrete
  evidence of the gap, and exits non-zero.
- `/app/output/01-diagnose/diagnosis.json`: object with non-empty
  `missing_capabilities` (array), `affected_packages` (array), `reproducer`
  (string), and `root_cause` (string).
- `/app/output/handoff.json`: object with non-empty `stage` (string), `summary`
  (string), and `next_steps` (array).

Do not modify production code in this stage. The verifier compiles independent
gap probes and executes your reproducer; those executable results determine stage
success. Report and handoff shape are non-critical training signals.

The verifier checks that `go.mod` still lacks `k8s.io/* v0.35.0`, informers lack
`ToListWatcherWithWatchListSemantics`, and `passive_assume_cache.go` is absent.
