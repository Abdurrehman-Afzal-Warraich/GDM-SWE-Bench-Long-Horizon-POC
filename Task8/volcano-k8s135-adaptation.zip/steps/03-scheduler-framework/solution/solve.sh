#!/usr/bin/env bash
# Oracle, stage 03.
set -euo pipefail

OUT=/app/output
STAGE=03-scheduler-framework
STAGE_OUT="$OUT/$STAGE"
BUILD_PKGS=(
  ./pkg/scheduler/...
  ./pkg/agentscheduler/...
  ./third_party/kubernetes/pkg/scheduler/backend/queue/...
)
TEST_PKGS=(./verifierprobe/...)
mkdir -p "$STAGE_OUT"
cd /testbed

git apply --whitespace=nowarn /solution/golden.patch
git add -A
git -c user.email=a@b.c -c user.name=oracle commit -q -m 'stage03: scheduler framework migration'

echo "== build =="
go build "${BUILD_PKGS[@]}"

python3 - <<'PY'
import json, subprocess
from pathlib import Path

changed = subprocess.check_output(
    ["git", "diff", "--name-only", "HEAD~1", "HEAD"], text=True
).splitlines()
changed = sorted({line.strip() for line in changed if line.strip()})
packages = sorted({str(Path(p).parent) for p in changed})
stage_out = Path("/app/output/03-scheduler-framework")
out = Path("/app/output")

(stage_out / "review_response.json").write_text(json.dumps({
    "framework_migration": (
        "Scheduler, agentscheduler, third_party queue, and volumebinding code now import "
        "k8s.io/kube-scheduler/framework instead of k8s.io/kubernetes/pkg/scheduler/framework."
    ),
    "dra_renames": (
        "Updated DRA plugin feature structs to EnableDeviceTaintRules, "
        "EnableDRAConsumableCapacity, and EnableDRAPartitionableDevices."
    ),
    "packages_touched": packages,
    "verification_performed": [
        "go build ./pkg/scheduler/... ./pkg/agentscheduler/... ./third_party/kubernetes/pkg/scheduler/backend/queue/...",
    ],
}, indent=2) + "\n", encoding="utf-8")

(out / "handoff.json").write_text(json.dumps({
    "stage": "03-scheduler-framework",
    "summary": f"Scheduler framework and volumebinding imports migrated across {len(changed)} files; build/vet/test pass.",
    "next_steps": [
        "Refresh installer Dockerfiles for Go 1.25/Kubernetes 1.35.",
        "Run cumulative volumebinding tests and merge-head equivalence proof.",
    ],
}, indent=2) + "\n", encoding="utf-8")
PY

echo "stage 03 complete"
