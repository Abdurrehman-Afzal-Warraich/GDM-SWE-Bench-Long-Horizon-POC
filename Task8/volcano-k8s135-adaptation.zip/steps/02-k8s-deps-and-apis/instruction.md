# Stage 02 — bump Kubernetes deps and regenerate APIs

Work in `/testbed`. Prior diagnosis persists in `/app/output`; this stage receives
a fresh briefing plus the handoff.

Upgrade Volcano to Kubernetes 1.35 module pins and refresh the generated client,
informer, and apply-configuration artifacts under `staging/src/volcano.sh/apis`.
Scope includes root `go.mod`, `go.sum`, CRDs, Makefile/hack scripts, README,
license metadata, and installer manifests touched by the dependency bump.

Exclude `.github/workflows` from your edits.

Write `/app/output/02-k8s-deps-and-apis/implementation.json` with non-empty
`dependency_bump`, `codegen_scope`, `watchlist_handling`, and `packages_touched`
(array). Update `/app/output/handoff.json` with non-empty `stage`, `summary`, and
`next_steps` (array). Each artifact is capped at 256 KiB.

The verifier will run `go build` on `volcano.sh/apis/...` plus injected contract tests.
It expects `k8s.io/api v0.35.0` (and related module pins) in `go.mod`, WatchList wrapper
helpers (including `ToListWatcherWithWatchListSemantics`) anywhere in the generated informer tree, and a fake-clientset WatchList opt-out
hook anywhere under the versioned clientset package tree.
