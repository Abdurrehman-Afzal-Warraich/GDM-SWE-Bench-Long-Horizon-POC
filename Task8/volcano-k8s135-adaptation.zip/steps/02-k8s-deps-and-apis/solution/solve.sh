#!/usr/bin/env bash
# Oracle, stage 02.
set -euo pipefail

OUT=/app/output
STAGE=02-k8s-deps-and-apis
STAGE_OUT="$OUT/$STAGE"
PKGS=(volcano.sh/apis/...)
mkdir -p "$STAGE_OUT"
cd /testbed

git apply --whitespace=nowarn /solution/golden.patch
git add -A
git -c user.email=a@b.c -c user.name=oracle commit -q -m 'stage02: k8s 1.35 deps and apis'

echo "== build =="
go build "${PKGS[@]}"
echo "== vet =="
go vet "${PKGS[@]}"
echo "== test =="
go test -count=1 volcano.sh/apis/...

python3 - <<'PY'
import json, subprocess
from pathlib import Path

changed = subprocess.check_output(
    ["git", "show", "--pretty=format:", "--name-only", "HEAD"],
    text=True,
).splitlines()
changed = sorted({line.strip() for line in changed if line.strip()})
packages = sorted({str(Path(p).parent) for p in changed})
stage_out = Path("/app/output/02-k8s-deps-and-apis")
out = Path("/app/output")

(stage_out / "implementation.json").write_text(json.dumps({
    "dependency_bump": "Pinned k8s.io/* modules to v0.35.0 and refreshed go.sum replace directives.",
    "codegen_scope": "Regenerated volcano.sh/apis clientset, informers, and applyconfiguration artifacts.",
    "watchlist_handling": (
        "Wrapped informer ListWatch constructors with ToListWatcherWithWatchListSemantics "
        "and added IsWatchListSemanticsUnSupported on the fake clientset."
    ),
    "packages_touched": packages,
    "files_changed": len(changed),
}, indent=2) + "\n", encoding="utf-8")

(out / "handoff.json").write_text(json.dumps({
    "stage": "02-k8s-deps-and-apis",
    "summary": f"Kubernetes modules bumped to v0.35.0 across {len(changed)} files; apis build and tests pass.",
    "next_steps": [
        "Migrate scheduler plugins and caches to k8s.io/kube-scheduler/framework.",
        "Apply DRA feature-gate field renames in scheduler and agentscheduler caches.",
        "Finish passiveAssumeCache volume-binding refactor and installer Dockerfiles.",
    ],
}, indent=2) + "\n", encoding="utf-8")
PY

echo "stage 02 complete"
