# Stage 04 — installer hardening and closure

Work in `/testbed`. All prior stages persist; you receive a fresh briefing plus the
handoff.

Close the Kubernetes 1.35 adaptation by updating installer Dockerfiles to Go 1.25
and re-running cumulative scheduler/volumebinding verification. Volume-binding
production code (including `passiveAssumeCache`) should already be present from stage 03.

Scope for this stage's patch footprint: `installer/dockerfile/*/Dockerfile` only.

Write `/app/output/04-volume-binding-harden/final_report.json` with non-empty
`feature_summary`, `volume_binding`, `verification_performed` (array),
`residual_risks` (array), and `packages_touched` (array).

Write `/app/output/04-volume-binding-harden/implementation_closure_proof.json` with:
- `base_commit`: `7ea02f980af2e1bcfaabf9b107370c4775bd0dfa`
- `feature_complete`: `true`
- `packages_touched`: array with at least two package paths you changed cumulatively
- `verification_performed`: non-empty array of commands you ran (e.g. `go build`, `go test`)

Set `/app/output/handoff.json` with `merge_ready: true`, plus `stage`, `summary`, and
`next_steps` (non-empty array — include the exact string `Task complete.` even though
this is the terminal stage).

**Verification:** the grader runs full volume-binding and scheduler entrypoint builds,
replays the cumulative hidden contract-test corpus from an isolated `/tmp/verifier-corpus`
module (the live `/testbed` tree is not mutated), checks all five installer Dockerfiles
reference Go 1.25, validates behavioral closure via your
`implementation_closure_proof.json` plus presence of critical implementation paths
(`passive_assume_cache.go`, updated `go.mod`, installer Dockerfiles), and runs `go vet`
on production `.go` files under `./pkg/scheduler/capabilities/volumebinding/...` only
(upstream `_test.go` files are excluded). Hidden tests
require volume-binding packages to build and reference `passiveAssumeCache` / `NewVolumeBinder`;
implementation may live in any file under `pkg/scheduler/capabilities/volumebinding/`.
