# long-horizon/volcano-k8s135-adaptation

Tier-2 stateful Go task: adapt Volcano to Kubernetes 1.35 across dependencies,
generated APIs, scheduler framework imports, and volume binding.

## Four-stage horizon

```mermaid
flowchart LR
  D[01 diagnose] --> P[02 deps and apis]
  P --> F[03 scheduler framework]
  F --> H[04 volume binding harden]
```

| Stage | Dispatch key | Capability | Critical gate |
| --- | --- | --- | --- |
| `01-diagnose` | `diagnose` | Executable proof of k8s 1.35 gap | gap probes + reproducer |
| `02-k8s-deps-and-apis` | `deps` | go.mod v0.35 + regenerated apis | apis build + hidden tests + vet |
| `03-scheduler-framework` | `framework` | kube-scheduler/framework migration | scheduler build + hidden tests + vet |
| `04-volume-binding-harden` | `harden` | passiveAssumeCache + dockerfiles | cumulative corpus + behavioral closure + Go 1.25 installers |

## Scope and provenance

Three disjoint production patches cover **184 files**:

- **146** dependency/codegen/CRD files (stage 02)
- **33** scheduler/agentscheduler/queue/volumebinding files (stage 03)
- **5** installer Dockerfile files (stage 04)

Author-only merge-head reference hashes live in `environment/merge_reference_manifest.json`
for pack-gate provenance checks only; they are **not** copied into the agent runtime image.
Dockerfile build context is `environment/` on data-os/Daytona, so oracle patches are not copied at build time.

## Visibility map

| Path / artifact | Agent | Verifier | Oracle | Author-only |
| --- | --- | --- | --- | --- |
| `/testbed` | read/write | read-only grade target | mutated by solve.sh | — |
| `/tests`, `/solution` | must not read | mounted at grade time | used by oracle agent | — |
| `/tests/hidden` | never visible | copied to `/tmp/verifier-corpus` at grade time | never injected into `/testbed` | source in package |
| `/app/output` | write handoffs/reports | read artifacts | write artifacts | — |
| `environment/merge_reference_manifest.json` | not in image | not mounted | not used at runtime | pack-gate merge proof |
| `calibration_summary.json`, `VALIDATION_EVIDENCE.md` | not in image | not mounted | — | author evidence |

`.github/workflows` are excluded from agent scope.

## Grading

Hidden tests live under `tests/hidden/<stage>/` and run from an isolated
`/tmp/verifier-corpus` Go module at grade time (`TESTBED_DIR=/testbed`); the live
workspace is not mutated. Twelve contract test functions grow cumulatively (4 + 5 + 3).
Executable `go build` and hidden `go test` dominate each stage (≥50% weight). Report/handoff
JSON shape is disclosed in `tests/contracts/artifacts.schema.json` and
`tests/contracts/requirement_map.json`.

Stage dispatch from step `tests/test.sh`:

```bash
exec bash /tests/stage_test.sh diagnose   # stage 01
exec bash /tests/stage_test.sh deps       # stage 02
exec bash /tests/stage_test.sh framework  # stage 03
exec bash /tests/stage_test.sh harden     # stage 04
```

## Validation

Interactive calibration (recommended before Oracle):

```bash
harbor task start-env -p "./Task8/volcano-k8s135-adaptation" --env docker --all --interactive
```

Host-side package contract tests:

```bash
python -m pytest -q tests/test_package_contract.py tests/test_reward_contract.py
```

Full Oracle:

```bash
harbor run -p "./Task8/volcano-k8s135-adaptation" -a oracle --job-name volcano-k8s135-oracle
```

See `calibration_summary.json` for oracle/noop calibration notes and frontier eval status.
