/*
Copyright 2026 The Volcano Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package verifierprobe

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

func testbedRoot(t *testing.T) string {
	t.Helper()
	if root := os.Getenv("TESTBED_DIR"); root != "" {
		return root
	}
	wd, err := os.Getwd()
	if err != nil {
		t.Fatalf("getwd: %v", err)
	}
	dir := wd
	for {
		if _, err := os.Stat(filepath.Join(dir, "go.mod")); err == nil {
			return dir
		}
		parent := filepath.Dir(dir)
		if parent == dir {
			t.Fatal("could not locate testbed root (go.mod)")
		}
		dir = parent
	}
}

func runGo(t *testing.T, root string, args ...string) (string, error) {
	t.Helper()
	cmd := exec.Command("go", args...)
	cmd.Dir = root
	cmd.Env = append(os.Environ(), "GOWORK=off", "CGO_ENABLED=0")
	out, err := cmd.CombinedOutput()
	return string(out), err
}

func packageGoFiles(t *testing.T, root string, relDir string) []string {
	t.Helper()
	dir := filepath.Join(root, relDir)
	var files []string
	err := filepath.WalkDir(dir, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if d.IsDir() || !strings.HasSuffix(path, ".go") || strings.HasSuffix(path, "_test.go") {
			return nil
		}
		files = append(files, path)
		return nil
	})
	if err != nil {
		t.Fatalf("walk %s: %v", relDir, err)
	}
	return files
}

func packageContains(t *testing.T, root, relDir, needle string) bool {
	t.Helper()
	for _, path := range packageGoFiles(t, root, relDir) {
		data, err := os.ReadFile(path)
		if err != nil {
			t.Fatalf("read %s: %v", path, err)
		}
		if strings.Contains(string(data), needle) {
			return true
		}
	}
	return false
}

func TestGoModPinsK8sV035(t *testing.T) {
	root := testbedRoot(t)
	data, err := os.ReadFile(filepath.Join(root, "go.mod"))
	if err != nil {
		t.Fatalf("read go.mod: %v", err)
	}
	text := string(data)
	for _, dep := range []string{
		"k8s.io/api v0.35.0",
		"k8s.io/apimachinery v0.35.0",
		"k8s.io/client-go v0.35.0",
	} {
		if !strings.Contains(text, dep) {
			t.Fatalf("go.mod missing %s", dep)
		}
	}
}

func TestApisModuleBuilds(t *testing.T) {
	root := testbedRoot(t)
	out, err := runGo(t, root, "build", "volcano.sh/apis/...")
	if err != nil {
		t.Fatalf("apis build: %v\n%s", err, out)
	}
}

func TestInformerWatchListWrapperPresent(t *testing.T) {
	root := testbedRoot(t)
	rel := filepath.Join("staging", "src", "volcano.sh", "apis", "pkg", "client", "informers")
	if !packageContains(t, root, rel, "ToListWatcherWithWatchListSemantics") {
		t.Fatal("generated informers missing WatchList wrapper helper")
	}
}

func TestFakeClientsetWatchListOptOutPresent(t *testing.T) {
	root := testbedRoot(t)
	rel := filepath.Join("staging", "src", "volcano.sh", "apis", "pkg", "client", "clientset")
	if !packageContains(t, root, rel, "IsWatchListSemanticsUnSupported") {
		t.Fatal("fake clientset missing WatchList opt-out hook")
	}
}
