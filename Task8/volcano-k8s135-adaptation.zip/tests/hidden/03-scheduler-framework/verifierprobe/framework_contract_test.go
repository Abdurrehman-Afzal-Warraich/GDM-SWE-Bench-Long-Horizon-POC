/*
Copyright 2026 The Volcano Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package verifierprobe

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

func TestSchedulerPackagesBuild(t *testing.T) {
	root := testbedRoot(t)
	cmd := exec.Command("go", "build", "./pkg/scheduler/...", "./pkg/agentscheduler/...", "./third_party/kubernetes/pkg/scheduler/backend/queue/...")
	cmd.Dir = root
	cmd.Env = append(os.Environ(), "GOWORK=off", "CGO_ENABLED=0")
	out, err := cmd.CombinedOutput()
	if err != nil {
		t.Fatalf("scheduler build: %v\n%s", err, out)
	}
}

func TestPredicatesImportsKubeSchedulerFramework(t *testing.T) {
	root := testbedRoot(t)
	dir := filepath.Join(root, "pkg", "scheduler", "plugins")
	found := false
	_ = filepath.WalkDir(dir, func(path string, d os.DirEntry, err error) error {
		if err != nil || d.IsDir() || !strings.HasSuffix(path, ".go") {
			return nil
		}
		data, readErr := os.ReadFile(path)
		if readErr != nil {
			return readErr
		}
		if strings.Contains(string(data), "k8s.io/kube-scheduler/framework") {
			found = true
			return filepath.SkipAll
		}
		return nil
	})
	if !found {
		t.Fatal("scheduler plugins must import k8s.io/kube-scheduler/framework")
	}
}

func TestPredicatesUsesRenamedDRAFeatureFields(t *testing.T) {
	root := testbedRoot(t)
	dir := filepath.Join(root, "pkg", "scheduler", "plugins")
	hasNew := false
	hasDeprecated := false
	_ = filepath.WalkDir(dir, func(path string, d os.DirEntry, err error) error {
		if err != nil || d.IsDir() || !strings.HasSuffix(path, ".go") {
			return nil
		}
		data, readErr := os.ReadFile(path)
		if readErr != nil {
			return readErr
		}
		text := string(data)
		if strings.Contains(text, "EnableDRAConsumableCapacity") {
			hasNew = true
		}
		if strings.Contains(text, "EnableConsumableCapacity:") {
			hasDeprecated = true
		}
		return nil
	})
	if !hasNew {
		t.Fatal("scheduler plugins missing EnableDRAConsumableCapacity rename")
	}
	if hasDeprecated {
		t.Fatal("scheduler plugins still use deprecated EnableConsumableCapacity field")
	}
}
