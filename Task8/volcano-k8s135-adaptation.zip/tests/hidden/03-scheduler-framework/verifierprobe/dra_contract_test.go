/*
Copyright 2026 The Volcano Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package verifierprobe

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func schedulerTreeContains(t *testing.T, root, relDir, needle string) bool {
	t.Helper()
	dir := filepath.Join(root, relDir)
	found := false
	_ = filepath.WalkDir(dir, func(path string, d os.DirEntry, err error) error {
		if err != nil || d.IsDir() || !strings.HasSuffix(path, ".go") {
			return nil
		}
		data, readErr := os.ReadFile(path)
		if readErr != nil {
			return readErr
		}
		if strings.Contains(string(data), needle) {
			found = true
			return filepath.SkipAll
		}
		return nil
	})
	return found
}

func TestSchedulerCacheUsesDRADeviceTaintRulesField(t *testing.T) {
	root := testbedRoot(t)
	if !schedulerTreeContains(t, root, filepath.Join("pkg", "scheduler", "cache"), "EnableDeviceTaintRules") {
		t.Fatal("scheduler cache package missing EnableDeviceTaintRules rename")
	}
}

func TestAgentSchedulerCacheUsesDRADeviceTaintRulesField(t *testing.T) {
	root := testbedRoot(t)
	if !schedulerTreeContains(t, root, filepath.Join("pkg", "agentscheduler", "cache"), "EnableDeviceTaintRules") {
		t.Fatal("agentscheduler cache package missing EnableDeviceTaintRules rename")
	}
}
