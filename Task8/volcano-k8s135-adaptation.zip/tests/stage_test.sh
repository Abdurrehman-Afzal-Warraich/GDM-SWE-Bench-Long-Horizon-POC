#!/usr/bin/env bash
# Stage verifier entrypoint. Runs the deterministic grader first (sole source of
# reward/binary_reward), then stages judge inputs and, only when explicitly
# enabled, the optional non-authoritative RewardKit judges.
set -uo pipefail

stage="${1:?stage name required}"
RESULT_DIR="${RESULT_DIR:-/logs/verifier}"
export RESULT_DIR
mkdir -p "$RESULT_DIR"

# Publish a valid zero result BEFORE starting any long-running or optional work.
# Harbor collects this directory even when the verifier is terminated by its
# timeout. The deterministic grader atomically replaces these sentinels on normal
# completion; until then a timeout/OOM/crash is an explicit failed stage, never a
# RewardFileNotFoundError.
fallback_now_ms=$(( $(date +%s) * 1000 ))
printf '%s\n' '{"binary_reward":0.0,"deterministic_score":0.0,"reward":0.0,"stage_complete":0.0,"training_score":0.0,"valid_trial":0.0}' > "$RESULT_DIR/reward.json"
printf '%s\n' '0.0000' > "$RESULT_DIR/reward.txt"
printf '%s\n' "{\"results\":{\"tool\":{\"name\":\"volcano-k8s135-verifier\"},\"summary\":{\"tests\":1,\"passed\":0,\"failed\":1,\"pending\":0,\"skipped\":0,\"other\":0,\"start\":${fallback_now_ms},\"stop\":${fallback_now_ms}},\"tests\":[{\"name\":\"grader_completed\",\"status\":\"failed\",\"duration\":0,\"suite\":\"${stage} :: harness\",\"message\":\"verifier started but did not complete\"}]}}" > "$RESULT_DIR/ctrf.json"
chmod a+rw "$RESULT_DIR/reward.json" "$RESULT_DIR/reward.txt" "$RESULT_DIR/ctrf.json" 2>/dev/null || true

# `tee`, not a plain redirect: Harbor captures this script's stdout as the
# verifier's test output, and sending the grader's whole report only to a log file
# left that capture empty.
python3 /tests/stage_check.py --stage "$stage" 2>&1 | tee "$RESULT_DIR/test_output.log"

# A crashed grader must never silently mean "no reward key". This post-run guard
# covers an unexpected deletion of the early sentinel. The fallback carries
# the core key set the grader writes (score_formula.REWARD_JSON_CORE_KEYS), so a
# crashed stage and a graded stage are the same shape to whatever reads them.
# non_deterministic_score is absent here for the same reason it is absent from an
# unjudged stage: no judge ran, so there is no score to report.
if [ ! -f "$RESULT_DIR/reward.json" ]; then
  printf '%s\n' '{"binary_reward":0.0,"deterministic_score":0.0,"reward":0.0,"stage_complete":0.0,"training_score":0.0,"valid_trial":0.0}' > "$RESULT_DIR/reward.json"
fi
if [ ! -s "$RESULT_DIR/reward.txt" ]; then
  printf '%s\n' '0.0000' > "$RESULT_DIR/reward.txt"
fi

# Likewise for the per-test report Harbor renders: a stage with no ctrf.json is
# displayed as "unable to parse test results" no matter what the reward says, so a
# crashed grader must still say, in that format, that the stage did not pass.
if [ ! -f "$RESULT_DIR/ctrf.json" ]; then
  now_ms=$(( $(date +%s) * 1000 ))
  printf '%s\n' "{\"results\":{\"tool\":{\"name\":\"volcano-k8s135-verifier\"},\"summary\":{\"tests\":1,\"passed\":0,\"failed\":1,\"pending\":0,\"skipped\":0,\"other\":0,\"start\":${now_ms},\"stop\":${now_ms}},\"tests\":[{\"name\":\"grader_completed\",\"status\":\"failed\",\"duration\":0,\"suite\":\"${stage} :: harness\",\"message\":\"stage_check.py did not produce a report\"}]}}" > "$RESULT_DIR/ctrf.json"
fi

# Capture the agent's work for review. `git diff` alone would show only unstaged
# edits, so an agent that staged or committed its work would appear to have changed
# nothing: the diff is taken against the sanitized base commit instead, which covers
# committed, staged and unstaged changes alike. Untracked source files are appended
# separately (a diff against the base cannot see them), size-capped and restricted to
# source/config suffixes so a stray build artefact cannot bloat the artefact. Nothing
# here mutates the agent's index - the tree carries into the next stage untouched.
base="$(git -C /testbed rev-list --max-parents=0 HEAD 2>/dev/null | tail -1)"
if [ -n "$base" ]; then
  git -C /testbed diff --binary "$base" > "$RESULT_DIR/patch.diff" 2>/dev/null || true
else
  git -C /testbed diff --binary > "$RESULT_DIR/patch.diff" 2>/dev/null || true
fi
git -C /testbed ls-files --others --exclude-standard 2>/dev/null | while IFS= read -r f; do
  case "$f" in
    *.go|*.ini|*.tmpl|*.yml|*.yaml|*.md|*.json|*.sh|*.sql) ;;
    *) continue ;;
  esac
  size=$(stat -c %s "/testbed/$f" 2>/dev/null || echo 0)
  [ "$size" -le 524288 ] || continue
  git -C /testbed diff --binary --no-index -- /dev/null "$f" >> "$RESULT_DIR/patch.diff" 2>/dev/null || true
done
{
  git -C /testbed diff --name-only
  git -C /testbed diff --cached --name-only
  [ -n "$base" ] && git -C /testbed diff --name-only "$base"
  git -C /testbed ls-files --others --exclude-standard
  git -C /testbed ls-files --deleted
} 2>/dev/null | sort -u > "$RESULT_DIR/changed_files.txt" || true
{
  echo "# base commit: ${base:-unknown}"
  echo "# git log:"
  git -C /testbed log --oneline --max-count=50 2>/dev/null
  echo "# git status --porcelain:"
  git -C /testbed status --porcelain 2>/dev/null
} > "$RESULT_DIR/repo_state.txt" 2>/dev/null || true
cp -a /app/output "$RESULT_DIR/agent_output" 2>/dev/null || true

if [ -f /logs/agent/oracle.txt ] || [ "${TRUSTED_ORACLE:-0}" = "1" ]; then
  python3 -S - "$RESULT_DIR/judge_status.json" "$stage" <<'PY'
import json, sys
from pathlib import Path
Path(sys.argv[1]).write_text(json.dumps({
    "available": False,
    "applicable": False,
    "stage": sys.argv[2],
    "reason": "trusted Oracle: RewardKit skipped; non-deterministic reward is N/A",
    "binary_reward_affected": False,
}, indent=2, sort_keys=True) + "\n", encoding="utf-8")
PY
else
  if [ -f /tests/stage_judge_inputs.py ]; then
    TASK_FAMILY="volcano-k8s135-adaptation-tier2" TASK_STAGE="$stage" \
      python3 /tests/stage_judge_inputs.py || true
  fi
  if [ "${RUN_LLM_JUDGES:-0}" = "1" ] && [ -f /tests/run_optional_judges.sh ]; then
    TASK_STAGE="$stage" bash /tests/run_optional_judges.sh "$RESULT_DIR" || true
  fi
fi

# The verifier runs as root inside the container; make every emitted artifact
# world-writable so the host-side harness (running as a normal user) can copy,
# overwrite, or aggregate them (e.g. reward-events.json) without EACCES.
chmod -R a+rwX "$RESULT_DIR" 2>/dev/null || true
exit 0
