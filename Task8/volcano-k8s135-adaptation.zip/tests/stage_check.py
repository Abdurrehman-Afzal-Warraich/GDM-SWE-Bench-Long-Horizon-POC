#!/usr/bin/env python3
"""Deterministic stage grader for long-horizon/volcano-k8s135-adaptation."""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from score_formula import (  # noqa: E402
    binary_outcome,
    calculate_training_score,
    clamp01,
    deterministic_components,
    parse_lambda,
)

TESTBED = Path(os.environ.get("TESTBED_DIR", "/testbed"))
OUTPUT = Path(os.environ.get("AGENT_OUTPUT_DIR", "/app/output"))
AGENT_LOGS = Path(os.environ.get("AGENT_LOGS_DIR", "/logs/agent"))
HIDDEN_ROOT = Path(os.environ.get("HIDDEN_TESTS_DIR", "/tests/hidden"))
RESULT_DIR = Path(os.environ.get("RESULT_DIR", "/logs/verifier"))

STAGES = [
    "01-diagnose",
    "02-k8s-deps-and-apis",
    "03-scheduler-framework",
    "04-volume-binding-harden",
]

STAGE_KEYS = {
    "diagnose": "01-diagnose",
    "deps": "02-k8s-deps-and-apis",
    "framework": "03-scheduler-framework",
    "harden": "04-volume-binding-harden",
}

SCHEDULER_PACKAGES = [
    "./pkg/scheduler/...",
    "./pkg/agentscheduler/...",
    "./third_party/kubernetes/pkg/scheduler/backend/queue/...",
]

STAGE_PKGS = {
    "02-k8s-deps-and-apis": ["volcano.sh/apis/..."],
    "03-scheduler-framework": ["volcano.sh/apis/...", *SCHEDULER_PACKAGES],
    "04-volume-binding-harden": ["volcano.sh/apis/...", *SCHEDULER_PACKAGES],
}

CORPUS_BASE = Path("/tmp/verifier-corpus")
CTRF_TOOL_NAME = "volcano-k8s135-verifier"
_CTRF_GO_RUNS: list[str] = []

CRITICAL_IMPLEMENTATION_PATHS = [
    "go.mod",
    "staging/src/volcano.sh/apis/go.mod",
    "pkg/scheduler/capabilities/volumebinding/passive_assume_cache.go",
    "pkg/scheduler/capabilities/volumebinding/volume_binding.go",
    "installer/dockerfile/scheduler/Dockerfile",
    "installer/dockerfile/agent/Dockerfile",
    "installer/dockerfile/controller-manager/Dockerfile",
    "installer/dockerfile/webhook-manager/Dockerfile",
    "installer/dockerfile/agent-scheduler/Dockerfile",
]

STAGE_BUILD = {
    "02-k8s-deps-and-apis": ["volcano.sh/apis/..."],
    "03-scheduler-framework": SCHEDULER_PACKAGES,
    "04-volume-binding-harden": [
        "./pkg/scheduler/capabilities/volumebinding/...",
        "./cmd/scheduler/...",
    ],
}

STAGE_VET = {
    "02-k8s-deps-and-apis": ["volcano.sh/apis/..."],
    "03-scheduler-framework": [
        "./pkg/scheduler/...",
        "./pkg/agentscheduler/...",
    ],
    "04-volume-binding-harden": [
        "./pkg/scheduler/capabilities/volumebinding/...",
    ],
}

DIAGNOSE_WEIGHTS = {
    "base_gap_observed": 0.25,
    "reproducer_present": 0.05,
    "reproducer_runs": 0.20,
    "reproducer_demonstrates_gap": 0.25,
    "diagnosis_report": 0.20,
    "handoff": 0.05,
}

DEPS_WEIGHTS = {
    "build_clean": 0.20,
    "hidden_tests_pass": 0.45,
    "vet_clean": 0.15,
    "implementation_report": 0.15,
    "handoff": 0.05,
}

FRAMEWORK_WEIGHTS = {
    "build_clean": 0.20,
    "hidden_tests_pass": 0.50,
    "vet_clean": 0.15,
    "review_report": 0.10,
    "handoff": 0.05,
}

HARDEN_WEIGHTS = {
    "full_build": 0.15,
    "hidden_tests_pass": 0.40,
    "vet_clean": 0.12,
    "volumebinding_tests": 0.12,
    "installer_go125": 0.08,
    "implementation_closure": 0.08,
    "final_report": 0.03,
    "merge_ready": 0.02,
}

WEIGHTS = {
    "01-diagnose": DIAGNOSE_WEIGHTS,
    "02-k8s-deps-and-apis": DEPS_WEIGHTS,
    "03-scheduler-framework": FRAMEWORK_WEIGHTS,
    "04-volume-binding-harden": HARDEN_WEIGHTS,
}

CRITICAL_CHECKS = {
    "01-diagnose": [
        "base_gap_observed",
        "reproducer_present",
        "reproducer_runs",
        "reproducer_demonstrates_gap",
    ],
    "02-k8s-deps-and-apis": ["build_clean", "hidden_tests_pass", "vet_clean"],
    "03-scheduler-framework": ["build_clean", "hidden_tests_pass", "vet_clean"],
    "04-volume-binding-harden": [
        "full_build",
        "hidden_tests_pass",
        "vet_clean",
        "volumebinding_tests",
        "installer_go125",
        "implementation_closure",
    ],
}

LEAK_PATTERNS = [
    r"\b(?:cat|less|more|head|tail)\b[^|;&\n]*\s/(?:tests|solution)\b",
    r"\b(?:cp|rsync|install)\b[^|;&\n]*\s/(?:tests|solution)\b",
    r"\bgit\s+(?:remote|fetch|clone|pull|ls-remote)\b",
    r"\bpulls?/5000\b",
]

NONLOCAL_EGRESS = re.compile(
    r"\b(?:curl|wget|nc|ncat|telnet|ssh|scp|sftp)\b[^\n]*"
    r"(?!.*(?:127\.0\.0\.1|localhost|::1|0\.0\.0\.0))"
    r"(?:https?://|[a-z0-9-]+\.[a-z]{2,})",
    re.IGNORECASE,
)

FORBIDDEN_COMMANDS = re.compile(
    r"\b(?:curl|wget|git\s+(?:clone|fetch|pull|remote|ls-remote)|"
    r"pip\s+install|go\s+(?:install|get)|apt(?:-get)?\s+install)\b",
    re.IGNORECASE,
)

INSTALLER_DOCKERFILES = [
    "installer/dockerfile/agent-scheduler/Dockerfile",
    "installer/dockerfile/agent/Dockerfile",
    "installer/dockerfile/controller-manager/Dockerfile",
    "installer/dockerfile/scheduler/Dockerfile",
    "installer/dockerfile/webhook-manager/Dockerfile",
]

HANDOFF_FIELDS = {"stage": str, "summary": str, "next_steps": list}
MAX_ARTIFACT_BYTES = 256 * 1024

ARTIFACT_SCHEMAS: dict[str, dict[str, object]] = {
    "01-diagnose": {
        "file": "diagnosis.json",
        "fields": {
            "missing_capabilities": list,
            "affected_packages": list,
            "reproducer": str,
            "root_cause": str,
        },
    },
    "02-k8s-deps-and-apis": {
        "file": "implementation.json",
        "fields": {
            "dependency_bump": str,
            "codegen_scope": str,
            "watchlist_handling": str,
            "packages_touched": list,
        },
    },
    "03-scheduler-framework": {
        "file": "review_response.json",
        "fields": {
            "framework_migration": str,
            "dra_renames": str,
            "packages_touched": list,
            "verification_performed": list,
        },
    },
    "04-volume-binding-harden": {
        "file": "final_report.json",
        "fields": {
            "feature_summary": str,
            "volume_binding": str,
            "verification_performed": list,
            "residual_risks": list,
            "packages_touched": list,
        },
    },
}

TRUSTED_DIRS = [
    "/opt/verifier-venv/bin",
    "/usr/local/go/bin",
    "/usr/local/sbin",
    "/usr/local/bin",
    "/usr/sbin",
    "/usr/bin",
    "/sbin",
    "/bin",
]


def artifact_schema_document() -> dict:
    type_names = {str: "string", list: "array", dict: "object", bool: "boolean"}

    def properties(fields: dict) -> dict:
        out = {}
        for key, want in fields.items():
            entry: dict[str, object] = {"type": type_names[want]}
            if want is str:
                entry["minLength"] = 1
            elif want is list:
                entry["minItems"] = 1
            out[key] = entry
        return out

    stages = {}
    for stage, spec in ARTIFACT_SCHEMAS.items():
        fields = spec["fields"]
        stages[stage] = {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "title": f"{stage} :: /app/output/{stage}/{spec['file']}",
            "type": "object",
            "additionalProperties": True,
            "required": sorted(fields),
            "properties": properties(fields),
        }
    return {
        "maxBytes": MAX_ARTIFACT_BYTES,
        "handoff": {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "title": "/app/output/handoff.json",
            "type": "object",
            "additionalProperties": True,
            "required": sorted(HANDOFF_FIELDS),
            "properties": properties(HANDOFF_FIELDS),
        },
        "stageReports": stages,
    }


def resolve_stage(name: str) -> str:
    return STAGE_KEYS.get(name, name)


def in_container() -> bool:
    return Path("/testbed").is_dir() and Path("/opt/verifier-venv").is_dir()


def trusted_path() -> str:
    dirs = list(TRUSTED_DIRS)
    extra = os.environ.get("VERIFIER_EXTRA_PATH", "")
    if extra and not in_container():
        dirs = [d for d in extra.split(":") if d] + dirs
    return ":".join(dirs)


def hardened_env() -> dict[str, str]:
    env = {
        "PATH": trusted_path(),
        "HOME": os.environ.get("HOME", "/root"),
        "LANG": "C.UTF-8",
        "GOWORK": "off",
        "GOTOOLCHAIN": "local",
        "GOFLAGS": "",
        "GOPROXY": "off",
        "CGO_ENABLED": "0",
    }
    if in_container():
        env.update({"GOPATH": "/go", "GOMODCACHE": "/go/pkg/mod", "GOCACHE": "/gocache", "TESTBED_DIR": str(TESTBED)})
    else:
        for key in ("GOPATH", "GOMODCACHE", "GOCACHE"):
            if os.environ.get(key):
                env[key] = os.environ[key]
    return env


def run(cmd: list[str], *, cwd: Path = TESTBED, timeout: int = 900) -> tuple[int, str]:
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(cwd),
            env=hardened_env(),
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return 124, f"TIMEOUT: {' '.join(cmd)}"
    except (OSError, ValueError) as exc:
        return 127, f"EXEC FAILED: {exc}"
    return proc.returncode, (proc.stdout or "") + (proc.stderr or "")


def tail(text: str, limit: int = 3000) -> str:
    return text if len(text) <= limit else text[-limit:]


def atomic_write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    temporary.write_text(content, encoding="utf-8")
    os.replace(temporary, path)


def stages_upto(stage: str) -> list[str]:
    idx = STAGES.index(stage)
    return [s for s in STAGES[1 : idx + 1]]


def prepare_hidden_corpus(stages: list[str]) -> Path:
    root = CORPUS_BASE / f"run-{os.getpid()}"
    shutil.rmtree(root, ignore_errors=True)
    probe = root / "verifierprobe"
    probe.mkdir(parents=True)
    for st in stages:
        src_dir = HIDDEN_ROOT / st / "verifierprobe"
        if not src_dir.is_dir():
            continue
        for src in sorted(src_dir.glob("*.go")):
            shutil.copy2(src, probe / src.name)
    (root / "go.mod").write_text("module verifiercorpus\n\ngo 1.25.0\n", encoding="utf-8")
    return root


def cleanup_hidden_corpus(root: Path | None) -> None:
    if root is not None:
        shutil.rmtree(root, ignore_errors=True)


def run_hidden_tests(
    stages: list[str],
    *,
    timeout: int = 2400,
    verbose: bool = False,
    run_pattern: str | None = None,
) -> tuple[bool, str, str, Path | None]:
    corpus = prepare_hidden_corpus(stages)
    args = ["test", "-count=1", "-p=2"]
    if run_pattern:
        args.extend(["-run", run_pattern])
    if verbose:
        args.append("-v")
    args.append("./verifierprobe/...")
    env = hardened_env()
    env["TESTBED_DIR"] = str(TESTBED)
    try:
        proc = subprocess.run(
            ["go", *args],
            cwd=str(corpus),
            env=env,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return False, "TIMEOUT running hidden corpus", "", corpus
    raw = (proc.stdout or "") + (proc.stderr or "")
    if run_pattern and re.search(r"testing:\s+warning:\s+no tests to run", raw, re.IGNORECASE):
        return False, "zero tests matched the required hidden run pattern", raw, corpus
    if run_pattern and proc.returncode == 0 and not re.search(r"^\s*--- PASS:", raw, re.MULTILINE):
        return False, "go test exited 0 but no hidden tests reported PASS", raw, corpus
    ok = proc.returncode == 0
    return ok, summarize_go(raw, 4000), raw, corpus


def hidden_corpus_size(stages: list[str]) -> int:
    return sum(
        len(list((HIDDEN_ROOT / st).rglob("*_test.go")))
        for st in stages
        if (HIDDEN_ROOT / st).is_dir()
    )


def summarize_go(out: str, limit: int = 2500) -> str:
    kept = [
        line
        for line in (out or "").splitlines()
        if line.startswith(("--- FAIL", "FAIL", "ok  ", "panic:", "# "))
        or "undefined:" in line
        or "Error:" in line
    ]
    return tail("\n".join(kept) if kept else (out or ""), limit)


def go_cmd(args: list[str], timeout: int) -> tuple[int, str]:
    return run(["go", *args], timeout=timeout)


def go_build(pkgs: list[str], timeout: int = 1500) -> tuple[bool, str]:
    rc, out = go_cmd(["build", *pkgs], timeout)
    return rc == 0, summarize_go(out)


def go_vet_production(stage: str, timeout: int = 1200) -> tuple[bool, str]:
    """Vet production code only.

    The apis module is vetted at import-path granularity with ``-tests=false``.
    Scheduler packages use ``go list .GoFiles`` because Go 1.25 still analyzes
    upstream *_test.go when vetting ``./pkg/scheduler/...`` even with ``-tests=false``.
    """
    targets = STAGE_VET[stage]
    if stage == "02-k8s-deps-and-apis":
        rc, out = go_cmd(["vet", "-tests=false", *targets], timeout)
        return rc == 0, "ok" if rc == 0 else summarize_go(out, 2000)

    rc, out = go_cmd(["list", "-f", "{{if .GoFiles}}{{.ImportPath}}{{end}}", *targets], 120)
    if rc != 0:
        return False, summarize_go(out, 2000)
    packages = [line.strip() for line in out.splitlines() if line.strip()]
    if not packages:
        return False, "no production packages matched vet targets"
    for pkg in packages:
        rc_files, files_out = go_cmd(
            ["list", "-f", "{{range .GoFiles}}{{$.Dir}}/{{.}} {{end}}", pkg],
            120,
        )
        if rc_files != 0:
            return False, summarize_go(files_out, 2000)
        files = files_out.strip().split()
        if not files:
            continue
        rc_vet, vet_out = go_cmd(["vet", *files], timeout)
        if rc_vet != 0:
            detail = summarize_go(vet_out, 2000)
            return False, f"{pkg}: {detail}" if detail else pkg
    return True, "ok"


STAGE_TEST = {
    "02-k8s-deps-and-apis": ["./verifierprobe/..."],
    "03-scheduler-framework": ["./verifierprobe/..."],
    "04-volume-binding-harden": ["./verifierprobe/..."],
}


def go_test(pkgs: list[str], timeout: int = 2400, verbose: bool = False, run_pattern: str | None = None) -> tuple[bool, str, str]:
    args = ["test", "-count=1", "-p=2"]
    if run_pattern:
        args.extend(["-run", run_pattern])
    if verbose:
        args.append("-v")
    args.extend(pkgs)
    rc, out = go_cmd(args, timeout)
    raw = out or ""
    if run_pattern and re.search(r"testing:\s+warning:\s+no tests to run", raw, re.IGNORECASE):
        return False, "zero tests matched the required hidden run pattern", raw
    if run_pattern and rc == 0 and not re.search(r"^\s*--- PASS:", raw, re.MULTILINE):
        return False, "go test exited 0 but no hidden tests reported PASS", raw
    return rc == 0, summarize_go(raw, 4000), raw


def hidden_run_pattern(stages: list[str]) -> str | None:
    expected = expected_graded_tests(stages)
    if not expected:
        return None
    return "^(" + "|".join(sorted(expected)) + ")$"


def expected_graded_tests(stages: list[str]) -> set[str]:
    names: set[str] = set()
    for st in stages:
        root = HIDDEN_ROOT / st
        if not root.is_dir():
            continue
        for src in sorted(root.rglob("*_test.go")):
            try:
                text = src.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            names.update(re.findall(r"^func (Test[A-Za-z0-9_]*)\s*\(", text, re.MULTILINE))
    names.discard("TestMain")
    return names


def graded_tests_all_ran(stages: list[str], out: str) -> tuple[bool, str]:
    expected = expected_graded_tests(stages)
    if not expected:
        return True, "no graded test functions expected"
    passed = set(re.findall(r"^\s*--- PASS: (Test[A-Za-z0-9_]+)", out, re.MULTILINE))
    missing = sorted(expected - passed)
    if not missing:
        return True, f"all {len(expected)} graded test functions ran and passed"
    return False, f"{len(missing)} of {len(expected)} graded test functions did not pass: {missing[:8]}"


def load_json(path: Path) -> tuple[dict | None, str]:
    if not path.is_file():
        return None, f"missing {path}"
    if path.stat().st_size > MAX_ARTIFACT_BYTES:
        return None, f"{path} exceeds {MAX_ARTIFACT_BYTES} bytes"
    try:
        data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except (json.JSONDecodeError, OSError) as exc:
        return None, f"unparseable {path}: {exc}"
    if not isinstance(data, dict):
        return None, f"{path} is not a JSON object"
    return data, "ok"


def json_contract(path: Path, required: dict[str, type | tuple[type, ...]]) -> tuple[bool, str]:
    data, note = load_json(path)
    if data is None:
        return False, note
    problems = []
    for key, want in required.items():
        if key not in data:
            problems.append(f"missing key '{key}'")
            continue
        value = data[key]
        if not isinstance(value, want):
            problems.append(f"'{key}' has wrong type {type(value).__name__}")
        elif isinstance(value, str) and not value.strip():
            problems.append(f"'{key}' is empty")
        elif isinstance(value, list) and not value:
            problems.append(f"'{key}' is an empty list")
    return (not problems), ("; ".join(problems) if problems else "ok")


def stage_report_contract(stage: str) -> tuple[bool, str]:
    spec = ARTIFACT_SCHEMAS[stage]
    return json_contract(OUTPUT / stage / str(spec["file"]), dict(spec["fields"]))


def handoff_contract() -> tuple[bool, str]:
    return json_contract(OUTPUT / "handoff.json", HANDOFF_FIELDS)


def strip_shell_comments(line: str) -> str:
    if line.lstrip().startswith("#"):
        return ""
    if "#" not in line:
        return line
    out: list[str] = []
    quote: str | None = None
    for ch in line:
        if quote:
            out.append(ch)
            if ch == quote:
                quote = None
            continue
        if ch in {"'", '"'}:
            quote = ch
            out.append(ch)
            continue
        if ch == "#":
            break
        out.append(ch)
    return "".join(out)


def trajectory_command_lines(text: str) -> list[str]:
    lines: list[str] = []
    for raw in text.splitlines():
        cleaned = strip_shell_comments(raw).strip()
        if cleaned:
            lines.append(cleaned)
    return lines


def split_keystrokes_blob(keystrokes: str) -> list[str]:
    lines: list[str] = []
    for raw in keystrokes.splitlines():
        cleaned = strip_shell_comments(raw).strip()
        if cleaned:
            lines.append(cleaned)
    return lines


def keystrokes_from_command_objects(commands: object) -> list[str]:
    if not isinstance(commands, list):
        return []
    lines: list[str] = []
    for cmd in commands:
        if not isinstance(cmd, dict):
            continue
        keystrokes = cmd.get("keystrokes")
        if isinstance(keystrokes, str) and keystrokes.strip():
            lines.extend(split_keystrokes_blob(keystrokes))
    return lines


def keystrokes_from_atif_step(step: dict) -> list[str]:
    lines: list[str] = []
    for tool_call in step.get("tool_calls") or []:
        if not isinstance(tool_call, dict):
            continue
        arguments = tool_call.get("arguments")
        if not isinstance(arguments, dict):
            continue
        keystrokes = arguments.get("keystrokes")
        if isinstance(keystrokes, str) and keystrokes.strip():
            lines.extend(split_keystrokes_blob(keystrokes))

    message = step.get("message")
    if isinstance(message, dict):
        lines.extend(keystrokes_from_command_objects(message.get("commands")))
    elif isinstance(message, str):
        stripped = message.strip()
        if stripped.startswith("{"):
            try:
                payload = json.loads(stripped)
            except json.JSONDecodeError:
                payload = None
            if isinstance(payload, dict) and payload.get("commands"):
                lines.extend(keystrokes_from_command_objects(payload.get("commands")))
    return lines


def extract_atif_command_lines(payload: dict) -> list[str]:
    steps = payload.get("steps")
    if not isinstance(steps, list):
        return []
    lines: list[str] = []
    for step in steps:
        if not isinstance(step, dict):
            continue
        if step.get("source") == "user":
            continue
        lines.extend(keystrokes_from_atif_step(step))
    return lines


def try_parse_atif_command_lines(path: Path, text: str) -> list[str] | None:
    if path.name != "trajectory.json" and '"steps"' not in text[:8192]:
        return None
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        return None
    if not isinstance(payload, dict) or not isinstance(payload.get("steps"), list):
        return None
    return extract_atif_command_lines(payload)


def should_scan_plain_command_file(path: Path) -> bool:
    if path.suffix in {".sh", ".bash"}:
        return True
    if path.name in {"oracle.txt", "reproduce.sh", "reproducer.sh", "repro.sh", "commands.log", "terminal.log"}:
        return True
    if path.suffix in {".log", ".txt"} and "agent" in path.parts:
        return True
    return False


def collect_executed_command_lines() -> list[str]:
    lines: list[str] = []
    for base in (AGENT_LOGS, OUTPUT):
        if not base.is_dir():
            continue
        for path in sorted(base.rglob("*")):
            if not path.is_file() or path.stat().st_size > 8 << 20:
                continue
            try:
                text = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            atif_lines = try_parse_atif_command_lines(path, text)
            if atif_lines is not None:
                lines.extend(atif_lines)
                continue
            if should_scan_plain_command_file(path):
                lines.extend(trajectory_command_lines(text))
    return lines


def container_start_epoch() -> float | None:
    try:
        stat_fields = Path("/proc/1/stat").read_text(encoding="utf-8").split()
        starttime = int(stat_fields[21])
        uptime = float(Path("/proc/uptime").read_text(encoding="utf-8").split()[0])
        clock_ticks = os.sysconf("SC_CLK_TCK")
        return time.time() - uptime + (starttime / clock_ticks)
    except (OSError, ValueError, IndexError):
        return None


def verify_ctime_anchor(paths: list[str], slack_sec: float = 5.0) -> tuple[bool, dict]:
    if not in_container():
        return True, {"skipped": "ctime anchor enforced only in container runs"}
    start = container_start_epoch()
    if start is None:
        return True, {"skipped": "container start anchor unavailable"}
    violations: list[str] = []
    checked: dict[str, str] = {}
    for rel in paths:
        path = Path(rel)
        if not path.is_file():
            continue
        ctime = path.stat().st_ctime
        checked[str(path)] = "ok"
        if ctime > start + slack_sec:
            violations.append(f"{path} ctime {ctime:.0f} after container start {start:.0f}")
            checked[str(path)] = "post-start"
    return not violations, {
        "container_start_epoch": start,
        "checked": checked,
        "violations": violations,
        "slack_sec": slack_sec,
    }


def verify_binary_integrity() -> tuple[bool, dict]:
    manifest = Path("/opt/verifier-binary-checksums.txt")
    if not manifest.is_file():
        return True, {"skipped": "checksum manifest absent in local/dev runs"}
    errors: list[str] = []
    verified: dict[str, str] = {}
    for line in manifest.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split(None, 1)
        if len(parts) != 2:
            continue
        expected, binary = parts
        rc, out = run(["sha256sum", binary], timeout=30)
        if rc != 0:
            errors.append(f"cannot hash {binary}")
            continue
        actual = out.split()[0] if out.split() else ""
        if actual != expected:
            errors.append(f"{binary} modified")
        verified[binary] = "ok" if actual == expected else "tampered"
    return not errors, {"verified": verified, "errors": errors}


def integrity(stage: str) -> tuple[bool, dict]:
    findings: list[str] = []
    executed_lines = collect_executed_command_lines()
    executed_blob = "\n".join(executed_lines)
    for pattern in LEAK_PATTERNS:
        match = re.search(pattern, executed_blob, re.IGNORECASE)
        if match:
            findings.append(f"reference-solution leakage: {match.group(0)[:120]}")
    for line in executed_lines:
        if FORBIDDEN_COMMANDS.search(line):
            findings.append(f"forbidden command: {line[:120]}")
            break
        if NONLOCAL_EGRESS.search(line):
            findings.append(f"non-local egress attempt: {line[:120]}")
            break
    rc, out = run(["git", "-C", str(TESTBED), "remote", "-v"], timeout=120)
    if rc == 0 and out.strip():
        findings.append(f"git remote present: {out.strip()[:120]}")
    binary_ok, binary_ev = verify_binary_integrity()
    if not binary_ok:
        findings.append("toolchain binary integrity failed")
    ctime_ok, ctime_ev = verify_ctime_anchor(
        ["/usr/local/go/bin/go", "/usr/bin/go", "/bin/bash", "/usr/bin/bash"]
    )
    if not ctime_ok:
        findings.append(f"toolchain ctime anchor failed: {'; '.join(ctime_ev.get('violations', [])[:2])}")
    ok = not findings
    return ok, {
        "passed": ok,
        "findings": findings,
        "binary_integrity": binary_ev,
        "ctime_anchor": ctime_ev,
        "notes": [],
        "detail": "clean" if ok else "; ".join(findings[:5]),
    }


def installer_images_use_go125() -> tuple[bool, str]:
    missing: list[str] = []
    for rel in INSTALLER_DOCKERFILES:
        path = TESTBED / rel
        if not path.is_file():
            missing.append(rel)
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        if "1.25" not in text:
            missing.append(f"{rel} missing Go 1.25")
    if missing:
        return False, "; ".join(missing[:5])
    return True, f"all {len(INSTALLER_DOCKERFILES)} installer Dockerfiles reference Go 1.25"


def verify_implementation_closure_artifact() -> tuple[bool, str]:
    proof_path = OUTPUT / "04-volume-binding-harden" / "implementation_closure_proof.json"
    data, note = load_json(proof_path)
    if data is None:
        return False, note
    for field in ("base_commit", "feature_complete", "packages_touched", "verification_performed"):
        if field not in data:
            return False, f"proof missing required field '{field}'"
    if str(data.get("base_commit")) != "7ea02f980af2e1bcfaabf9b107370c4775bd0dfa":
        return False, "proof base_commit does not match task base"
    if data.get("feature_complete") is not True:
        return False, "proof feature_complete must be true"
    packages = data.get("packages_touched")
    verification = data.get("verification_performed")
    if not isinstance(packages, list) or len(packages) < 2:
        return False, "proof packages_touched must be an array with at least 2 entries"
    if not isinstance(verification, list) or len(verification) < 1:
        return False, "proof verification_performed must be a non-empty array"
    missing_paths: list[str] = []
    for rel in CRITICAL_IMPLEMENTATION_PATHS:
        if not (TESTBED / rel).is_file():
            missing_paths.append(rel)
    if missing_paths:
        return False, f"critical implementation paths missing: {missing_paths[:5]}"
    return True, (
        f"behavioral closure: {len(CRITICAL_IMPLEMENTATION_PATHS)} critical paths present; "
        f"{len(packages)} packages reported"
    )


def base_gap_observed() -> tuple[bool, str]:
    probe_root = TESTBED / "verifierprobe"
    observed: list[str] = []
    problems: list[str] = []
    try:
        gomod = (TESTBED / "go.mod").read_text(encoding="utf-8", errors="replace")
        if "k8s.io/api v0.35.0" in gomod:
            problems.append("go.mod already pins k8s v0.35")
        else:
            observed.append("k8s_version")
        informer = TESTBED / "staging/src/volcano.sh/apis/pkg/client/informers/externalversions/batch/v1alpha1/job.go"
        if informer.is_file() and "ToListWatcherWithWatchListSemantics" in informer.read_text(encoding="utf-8", errors="replace"):
            problems.append("WatchList wrapper already present")
        else:
            observed.append("watchlist")
        passive = TESTBED / "pkg/scheduler/capabilities/volumebinding/passive_assume_cache.go"
        if passive.is_file():
            problems.append("passiveAssumeCache already present")
        else:
            observed.append("passive_cache")
        pkg = probe_root / "legacy"
        pkg.mkdir(parents=True, exist_ok=True)
        (pkg / "probe.go").write_text(
            'package legacy\n\nimport k8sframework "k8s.io/kubernetes/pkg/scheduler/framework"\n\n'
            "var _ k8sframework.NodeInfo\n",
            encoding="utf-8",
        )
        rc, out = go_cmd(["build", "./verifierprobe/legacy"], 900)
        if rc == 0 or "k8s.io/kubernetes/pkg/scheduler/framework" in out:
            observed.append("legacy_framework_imports")
        else:
            problems.append(f"legacy framework probe inconclusive: {tail(out, 240)}")
    except OSError as exc:
        problems.append(f"probe setup failed: {exc}")
    finally:
        shutil.rmtree(probe_root, ignore_errors=True)
    if problems:
        return False, "; ".join(problems)
    if len(observed) < 3:
        return False, f"insufficient gaps observed: {observed}"
    return True, f"base still lacks k8s 1.35 adaptation: {observed}"


def find_reproducer() -> Path | None:
    root = OUTPUT / "01-diagnose"
    if not root.is_dir():
        return None
    for name in ("reproduce.sh", "reproducer.sh", "repro.sh"):
        candidate = root / name
        if candidate.is_file():
            return candidate
    for candidate in sorted(root.rglob("*")):
        if candidate.is_file() and candidate.suffix in {".sh", ".bash"}:
            return candidate
    return None


def diagnose() -> dict:
    checks: dict[str, dict] = {}
    ok, note = base_gap_observed()
    checks["base_gap_observed"] = {"passed": ok, "detail": note}
    repro = find_reproducer()
    checks["reproducer_present"] = {
        "passed": repro is not None,
        "detail": str(repro) if repro else "no reproducer under /app/output/01-diagnose",
    }
    repro_out = ""
    repro_rc = None
    if repro is not None:
        repro_rc, repro_out = run(["bash", str(repro)], cwd=TESTBED, timeout=900)
    checks["reproducer_runs"] = {
        "passed": repro is not None and repro_rc is not None and bool(repro_out.strip()),
        "detail": f"rc={repro_rc}, {len(repro_out)} bytes output",
    }
    terms = ("v0.34", "v0.35", "kube-scheduler", "kubernetes/pkg/scheduler", "watchlist", "1.35")
    named = [t for t in terms if t.lower() in repro_out.lower()]
    demonstrates = repro is not None and repro_rc not in (None, 0) and len(named) >= 2
    checks["reproducer_demonstrates_gap"] = {
        "passed": demonstrates,
        "detail": f"rc={repro_rc}, terms={named}",
    }
    ok, note = stage_report_contract("01-diagnose")
    checks["diagnosis_report"] = {"passed": ok, "detail": note}
    ok, note = handoff_contract()
    checks["handoff"] = {"passed": ok, "detail": note}
    return checks


def graded_go_gates(stage: str, checks: dict[str, dict], *, build_key: str = "build_clean") -> None:
    ok, out = go_build(STAGE_BUILD[stage])
    checks[build_key] = {"passed": ok, "detail": "ok" if ok else out}
    stages = stages_upto(stage)
    corpus = hidden_corpus_size(stages)
    ok, out, raw, corpus_root = run_hidden_tests(stages, verbose=True, run_pattern=hidden_run_pattern(stages))
    try:
        if raw:
            _CTRF_GO_RUNS.append(raw)
        ran_ok, ran_note = graded_tests_all_ran(stages, raw)
        checks["hidden_tests_pass"] = {
            "passed": ok and ran_ok,
            "detail": f"{corpus} hidden files in isolated corpus; {ran_note}" + ("" if ok and ran_ok else f"\n{out}"),
        }
        vet_ok, vet_out = go_vet_production(stage)
    finally:
        cleanup_hidden_corpus(corpus_root)
    checks["vet_clean"] = {"passed": vet_ok, "detail": "ok" if vet_ok else vet_out}


def deps(stage: str) -> dict:
    checks: dict[str, dict] = {}
    graded_go_gates(stage, checks)
    ok, note = stage_report_contract(stage)
    checks["implementation_report"] = {"passed": ok, "detail": note}
    ok, note = handoff_contract()
    checks["handoff"] = {"passed": ok, "detail": note}
    return checks


def framework(stage: str) -> dict:
    checks: dict[str, dict] = {}
    graded_go_gates(stage, checks)
    ok, note = stage_report_contract(stage)
    checks["review_report"] = {"passed": ok, "detail": note}
    ok, note = handoff_contract()
    checks["handoff"] = {"passed": ok, "detail": note}
    return checks


def harden(stage: str) -> dict:
    checks: dict[str, dict] = {}
    graded_go_gates(stage, checks, build_key="full_build")
    stages = stages_upto(stage)
    ok, out, raw, corpus_root = run_hidden_tests(
        stages,
        timeout=3600,
        verbose=True,
        run_pattern="^TestVolumeBinding|^TestPassiveAssumeCache|^TestInstallerDockerfiles",
    )
    try:
        if raw:
            _CTRF_GO_RUNS.append(raw)
    finally:
        cleanup_hidden_corpus(corpus_root)
    checks["volumebinding_tests"] = {"passed": ok, "detail": "ok" if ok else out}
    ok_installer, installer_note = installer_images_use_go125()
    checks["installer_go125"] = {"passed": ok_installer, "detail": installer_note}
    ok_closure, closure_note = verify_implementation_closure_artifact()
    checks["implementation_closure"] = {"passed": ok_closure, "detail": closure_note}
    ok, note = stage_report_contract(stage)
    checks["final_report"] = {"passed": ok, "detail": note}
    data, _ = load_json(OUTPUT / "handoff.json")
    handoff_ok, handoff_note = handoff_contract()
    declared = isinstance(data, dict) and data.get("merge_ready") is True
    next_steps = data.get("next_steps") if isinstance(data, dict) else None
    task_complete = (
        isinstance(next_steps, list)
        and any("task complete" in str(item).lower() for item in next_steps)
    )
    merge_pass = handoff_ok and declared and task_complete
    if merge_pass:
        merge_detail = "ok"
    elif not handoff_ok:
        merge_detail = f"handoff invalid: {handoff_note}"
    elif not declared:
        merge_detail = f"handoff must declare merge_ready=true ({handoff_note})"
    else:
        merge_detail = 'handoff next_steps must include "Task complete."'
    checks["merge_ready"] = {
        "passed": merge_pass,
        "detail": merge_detail,
    }
    return checks


def _go_test_ctrf_entries(raw: str, suite: str) -> list[dict[str, object]]:
    entries: list[dict[str, object]] = []
    status_map = {"PASS": "passed", "FAIL": "failed", "SKIP": "skipped"}
    for match in re.finditer(r"^\s*--- (PASS|FAIL|SKIP): (Test[A-Za-z0-9_]+)", raw, re.MULTILINE):
        entries.append(
            {
                "name": match.group(2),
                "status": status_map[match.group(1)],
                "duration": 0,
                "suite": suite,
                "message": "",
            }
        )
    return entries


def write_ctrf(stage: str, checks: dict[str, dict], integrity_report: dict) -> None:
    now_ms = int(time.time() * 1000)
    start_ms = now_ms
    weights = WEIGHTS[stage]
    tests: list[dict[str, object]] = []
    for name in sorted(weights):
        check = checks.get(name, {})
        passed = bool(check.get("passed"))
        tests.append(
            {
                "name": name,
                "status": "passed" if passed else "failed",
                "duration": 0,
                "suite": f"{stage} :: check",
                "message": str(check.get("detail", ""))[:500],
            }
        )
    integrity_ok = bool(integrity_report.get("passed"))
    findings = integrity_report.get("findings") or []
    tests.append(
        {
            "name": "integrity",
            "status": "passed" if integrity_ok else "failed",
            "duration": 0,
            "suite": f"{stage} :: integrity",
            "message": "; ".join(str(item) for item in findings)[:500],
        }
    )
    for raw in _CTRF_GO_RUNS:
        tests.extend(_go_test_ctrf_entries(raw, f"{stage} :: hidden"))
    passed = sum(1 for entry in tests if entry["status"] == "passed")
    failed = sum(1 for entry in tests if entry["status"] == "failed")
    skipped = sum(1 for entry in tests if entry["status"] == "skipped")
    payload = {
        "results": {
            "tool": {"name": CTRF_TOOL_NAME},
            "summary": {
                "tests": len(tests),
                "passed": passed,
                "failed": failed,
                "pending": 0,
                "skipped": skipped,
                "other": 0,
                "start": start_ms,
                "stop": now_ms,
            },
            "tests": tests,
        }
    }
    atomic_write_text(RESULT_DIR / "ctrf.json", json.dumps(payload, indent=2, sort_keys=True) + "\n")


def write_reward(stage: str, checks: dict[str, dict], integrity_report: dict) -> float:
    weights = WEIGHTS[stage]
    integrity_ok = bool(integrity_report.get("passed"))
    d_num, d_den = deterministic_components(checks, weights, integrity_ok=integrity_ok)
    critical = CRITICAL_CHECKS[stage]
    required_pass = all(bool(checks.get(name, {}).get("passed")) for name in critical)
    binary = binary_outcome(required_checks_pass=required_pass, integrity_ok=integrity_ok)
    lam = parse_lambda(os.environ.get("NONDETERMINISTIC_LAMBDA", "0.0"))
    training = calculate_training_score(
        d_num=d_num, d_den=d_den, nondeterministic_lambda=lam, integrity_ok=integrity_ok, rewardkit_available=False
    )
    payload = {
        "reward": binary,
        "binary_reward": binary,
        "training_score": clamp01(training),
        "deterministic_score": round(clamp01(d_num / d_den) if d_den else 0.0, 6),
        "valid_trial": 1.0 if integrity_ok else 0.0,
        "stage_complete": 1.0 if not [n for n in weights if not checks.get(n, {}).get("passed")] and integrity_ok else 0.0,
    }
    non_critical = sorted(set(weights) - set(critical))
    every_weighted = all(bool(checks.get(name, {}).get("passed")) for name in weights)
    details = {
        "stage": stage,
        "checks": checks,
        "weights": weights,
        "critical_checks": critical,
        "non_critical_checks": non_critical,
        "critical_pass": required_pass,
        "every_weighted_check_passed": every_weighted,
        "binary_gated_on_critical_only": True,
        "integrity": integrity_report,
    }
    atomic_write_text(RESULT_DIR / "reward.json", json.dumps(payload, indent=2, sort_keys=True) + "\n")
    atomic_write_text(RESULT_DIR / "reward-details.json", json.dumps(details, indent=2, sort_keys=True) + "\n")
    atomic_write_text(RESULT_DIR / "reward.txt", f"{binary:.4f}\n")
    events = {
        "stage": stage,
        "binary_reward": binary,
        "integrity_ok": integrity_ok,
        "checks": {
            name: bool(check.get("passed"))
            for name, check in checks.items()
        },
        "critical_checks": critical,
    }
    atomic_write_text(RESULT_DIR / "reward-events.json", json.dumps(events, indent=2, sort_keys=True) + "\n")
    manifest = {
        "stage": stage,
        "binary_reward": binary,
        "training_score": payload["training_score"],
        "deterministic_score": payload["deterministic_score"],
        "valid_trial": payload["valid_trial"],
        "stage_complete": payload["stage_complete"],
        "critical_pass": required_pass,
        "integrity_ok": integrity_ok,
    }
    atomic_write_text(
        RESULT_DIR / "training_export_manifest.json",
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
    )
    return binary


def main() -> int:
    global _CTRF_GO_RUNS
    _CTRF_GO_RUNS = []
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", required=True)
    args = parser.parse_args()
    stage = resolve_stage(args.stage)
    if stage not in STAGES:
        print(f"unknown stage key: {args.stage}", file=sys.stderr)
        return 2
    shutil.rmtree(TESTBED / "verifierprobe", ignore_errors=True)
    integrity_ok, integrity_report = integrity(stage)
    if stage == "01-diagnose":
        checks = diagnose()
    elif stage == "02-k8s-deps-and-apis":
        checks = deps(stage)
    elif stage == "03-scheduler-framework":
        checks = framework(stage)
    else:
        checks = harden(stage)
    binary = write_reward(stage, checks, integrity_report)
    write_ctrf(stage, checks, integrity_report)
    print(f"stage={stage} integrity_ok={integrity_ok} binary_reward={binary}")
    for name in sorted(checks):
        state = "PASS" if checks[name].get("passed") else "FAIL"
        print(f"  [{state}] {name}: {str(checks[name].get('detail', ''))[:400]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
