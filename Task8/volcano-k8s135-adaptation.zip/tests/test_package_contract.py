from __future__ import annotations

import hashlib
import json
import re
import sys
import tomllib
from pathlib import Path

import pytest

PKG = Path(__file__).resolve().parents[1]
TESTS = PKG / "tests"
STEPS = PKG / "steps"
STAGES = [
    "01-diagnose",
    "02-k8s-deps-and-apis",
    "03-scheduler-framework",
    "04-volume-binding-harden",
]
DISPATCH = {
    "01-diagnose": "diagnose",
    "02-k8s-deps-and-apis": "deps",
    "03-scheduler-framework": "framework",
    "04-volume-binding-harden": "harden",
}
PATCH_STAGES = STAGES[1:]

sys.path.insert(0, str(TESTS))
import score_formula  # noqa: E402
import stage_check  # noqa: E402


def config() -> dict:
    return tomllib.loads((PKG / "task.toml").read_text(encoding="utf-8"))


def patch_files(stage: str) -> list[tuple[str, str]]:
    text = (STEPS / stage / "solution" / "golden.patch").read_text(encoding="utf-8", errors="replace")
    return re.findall(r"^diff --git a/(.+?) b/(.+?)$", text, re.MULTILINE)


def hidden_test_names(stage: str) -> list[str]:
    names: set[str] = set()
    for path in (TESTS / "hidden" / stage).rglob("*_test.go"):
        names.update(re.findall(r"^func (Test[A-Za-z0-9_]+)\(", path.read_text(encoding="utf-8"), re.M))
    names.discard("TestMain")
    return sorted(names)


def test_schema_version_and_strategy():
    cfg = config()
    assert cfg["schema_version"] == "1.3"
    assert cfg["multi_step_reward_strategy"] == "final"


def test_task_name_and_repo_metadata():
    cfg = config()
    assert cfg["task"]["name"] == "long-horizon/volcano-k8s135-adaptation"
    meta = cfg["metadata"]
    assert meta["repository"] == "volcano-sh/volcano"
    assert meta["base_commit"] == "7ea02f980af2e1bcfaabf9b107370c4775bd0dfa"
    assert meta["merge_commit"] == "83a654ff219f6c5c95a7e4db66c31e53fbc0fc26"
    assert meta["source_license"] == "Apache-2.0"
    assert "source_pull_request" not in meta


def test_step_names_match_directories():
    assert [step["name"] for step in config()["steps"]] == STAGES


def test_no_min_reward_anywhere():
    assert all("min_reward" not in step for step in config()["steps"])


def test_expert_time_estimate():
    assert config()["metadata"]["expert_time_estimate_hours"] == 32.0


def test_environment_judges_default_off():
    assert config()["environment"]["env"]["RUN_LLM_JUDGES"] == "0"


def test_environment_resources_and_network():
    env = config()["environment"]
    assert env["allow_internet"] is True
    assert env["cpus"] == 4
    assert env["memory_mb"] == 8192
    assert env["storage_mb"] == 10240


def test_verifier_env_block_present():
    cfg = config()
    env = cfg.get("verifier", {}).get("env", cfg.get("verifier.env", {}))
    for key in ("ANTHROPIC_API_KEY", "GEMINI_API_KEY", "NONDETERMINISTIC_LAMBDA"):
        assert key in env


def test_tags_field_present():
    assert "tags" in config()["metadata"]


def test_patches_disjoint_and_provenanced():
    seen: set[str] = set()
    for stage in PATCH_STAGES:
        patch = STEPS / stage / "solution" / "golden.patch"
        provenance = json.loads((patch.parent / "provenance.json").read_text(encoding="utf-8"))
        pairs = patch_files(stage)
        assert pairs and all(a == b for a, b in pairs)
        files = sorted(a for a, _ in pairs)
        assert files == sorted(provenance["files"])
        assert not seen.intersection(files)
        seen.update(files)
        digest = hashlib.sha256(patch.read_bytes()).hexdigest()
        assert digest == provenance["patch_sha256"]
        assert provenance["incremental"] is True
    assert len(seen) == 184
    assert not [p for p in seen if p.endswith("_test.go")]


def test_provenance_file_counts():
    counts = {
        "02-k8s-deps-and-apis": 146,
        "03-scheduler-framework": 33,
        "04-volume-binding-harden": 5,
    }
    for stage, want in counts.items():
        prov = json.loads((STEPS / stage / "solution" / "provenance.json").read_text(encoding="utf-8"))
        assert len(prov["files"]) == want


def test_hidden_corpus_counts():
    assert len(hidden_test_names("02-k8s-deps-and-apis")) == 4
    assert len(hidden_test_names("03-scheduler-framework")) == 5
    assert len(hidden_test_names("04-volume-binding-harden")) == 3


def test_requirement_map_present():
    payload = json.loads((TESTS / "contracts" / "requirement_map.json").read_text(encoding="utf-8"))
    assert len(payload["stages"]) == 4
    assert payload["promptToTestFairness"]
    dep = json.loads((TESTS / "contracts" / "stage_dependencies.json").read_text(encoding="utf-8"))
    rows = {row["stage"]: row for row in dep["stages"]}
    assert list(rows) == STAGES
    for stage in PATCH_STAGES:
        assert sorted(rows[stage]["newTestFunctions"]) == hidden_test_names(stage)
        assert rows[stage]["dispatchKey"] == DISPATCH[stage]


def test_artifact_schema_matches_stage_check():
    shipped = json.loads((TESTS / "contracts" / "artifacts.schema.json").read_text(encoding="utf-8"))
    assert shipped == stage_check.artifact_schema_document()


def test_go_vet_uses_production_files_only():
    text = (TESTS / "stage_check.py").read_text(encoding="utf-8")
    assert "range .GoFiles" in text
    assert '["vet", "-tests=false", *targets]' in text
    assert "go_vet_production" in text


def test_stage_vet_excludes_third_party_and_test_files():
    vet = stage_check.STAGE_VET
    assert "./third_party/" not in " ".join(vet["03-scheduler-framework"])
    assert "cmd/scheduler" not in " ".join(vet["04-volume-binding-harden"])


def test_stage_check_stage_aliases():
    assert stage_check.resolve_stage("diagnose") == STAGES[0]
    assert stage_check.resolve_stage("deps") == STAGES[1]
    assert stage_check.resolve_stage("framework") == STAGES[2]
    assert stage_check.resolve_stage("harden") == STAGES[3]


def test_stage_weights_sum_to_one():
    for stage in STAGES:
        assert abs(sum(stage_check.WEIGHTS[stage].values()) - 1.0) < 1e-9


def test_executable_weight_dominates_patch_stages():
    for stage in PATCH_STAGES:
        w = stage_check.WEIGHTS[stage]
        executable = (
            w.get("build_clean", 0.0)
            + w.get("full_build", 0.0)
            + w.get("hidden_tests_pass", 0.0)
            + w.get("vet_clean", 0.0)
            + w.get("volumebinding_tests", 0.0)
        )
        assert executable >= 0.5


def test_critical_checks_are_executable():
    assert "diagnosis_report" not in stage_check.CRITICAL_CHECKS["01-diagnose"]
    for stage in PATCH_STAGES:
        assert {"hidden_tests_pass", "vet_clean"}.issubset(set(stage_check.CRITICAL_CHECKS[stage]))


def test_step_wrappers_dispatch_correctly():
    for stage in STAGES:
        wrapper = (STEPS / stage / "tests" / "test.sh").read_text(encoding="utf-8")
        assert f"stage_test.sh {DISPATCH[stage]}" in wrapper


def test_every_step_has_instruction_and_solve():
    for stage in STAGES:
        assert (STEPS / stage / "instruction.md").is_file()
        assert (STEPS / stage / "solution" / "solve.sh").is_file()


def test_patch_stages_have_golden_and_provenance():
    for stage in PATCH_STAGES:
        assert (STEPS / stage / "solution" / "golden.patch").is_file()
        assert (STEPS / stage / "solution" / "provenance.json").is_file()


def test_diagnose_instruction_forbids_production_changes():
    text = (STEPS / "01-diagnose" / "instruction.md").read_text(encoding="utf-8").lower()
    assert "do not modify production" in text


def test_stage02_instruction_discloses_verifier_checks():
    text = (STEPS / "02-k8s-deps-and-apis" / "instruction.md").read_text(encoding="utf-8")
    assert "v0.35.0" in text
    assert "ToListWatcherWithWatchListSemantics" in text


def test_stage03_instruction_discloses_framework_migration():
    text = (STEPS / "03-scheduler-framework" / "instruction.md").read_text(encoding="utf-8")
    assert "k8s.io/kube-scheduler/framework" in text
    assert "EnableDeviceTaintRules" in text


def test_stage04_instruction_discloses_closure_and_installers():
    text = (STEPS / "04-volume-binding-harden" / "instruction.md").read_text(encoding="utf-8")
    assert "passiveAssumeCache" in text
    assert "implementation_closure_proof.json" in text
    assert "Task complete." in text
    assert "1.25" in text
    assert "verifier-corpus" in text
    assert "merge_reference_manifest.json" not in text
    assert "non-empty" in text.lower() or "non empty" in text.lower()
    assert "next_steps" in text


def test_oracle_solve_scripts_do_not_reference_tests():
    for stage in STAGES:
        assert "/tests/" not in (STEPS / stage / "solution" / "solve.sh").read_text(encoding="utf-8")


def test_dockerfile_pins_base_and_go_toolchain():
    body = (PKG / "environment" / "Dockerfile").read_text(encoding="utf-8")
    assert "ARG GO_VERSION=1.25.0" in body
    assert "2852af0cb20a13139b3448992e69b868e50ed0f8a1e5940ee1de9e19a123b613" in body
    assert "ARG BASE_COMMIT=7ea02f980af2e1bcfaabf9b107370c4775bd0dfa" in body
    assert "ARG BASE_TREE=44a30a25f7f456f198da074bae7c8cd156fccf7a" in body
    assert "rm -rf .git" in body
    assert "COPY merge_reference_manifest.json" not in body
    assert "COPY steps/" not in body


def test_author_merge_manifest_for_pack_gate_only():
    payload = json.loads((PKG / "environment" / "merge_reference_manifest.json").read_text(encoding="utf-8"))
    assert payload["file_count"] == 184
    assert len(payload["files"]) == 184
    body = (PKG / "environment" / "Dockerfile").read_text(encoding="utf-8")
    assert "/opt/merge_reference_manifest.json" not in body


def test_dockerfile_has_verifier_venv():
    body = (PKG / "environment" / "Dockerfile").read_text(encoding="utf-8")
    assert "/opt/verifier-venv" in body
    assert "pytest" in body


def test_fallback_reward_exists():
    assert (TESTS / "fallback_reward.py").is_file()


def test_stage_test_publishes_early_sentinel():
    wrapper = (TESTS / "stage_test.sh").read_text(encoding="utf-8")
    assert wrapper.index('> "$RESULT_DIR/reward.json"') < wrapper.index("stage_check.py")
    assert "volcano-k8s135-verifier" in wrapper


def test_judge_toml_files_parse():
    for dimension in ("process", "validity", "task_quality", "merge_readiness"):
        data = tomllib.loads((TESTS / dimension / "judge.toml").read_text(encoding="utf-8"))
        assert data["judge"]["prompt_template"] == "../judge_prompt.md"
        assert "gemini" in data["judge"]["judge"]


def test_merge_readiness_has_six_dimensions():
    merge = tomllib.loads((TESTS / "merge_readiness" / "judge.toml").read_text(encoding="utf-8"))
    required = {
        "repository_conventions",
        "focused_change",
        "maintainability",
        "architecture",
        "useful_tests",
        "no_patch_bloat",
    }
    assert required.issubset({c["name"] for c in merge["criterion"]})


def test_task_quality_weight_zero():
    quality = tomllib.loads((TESTS / "task_quality" / "judge.toml").read_text(encoding="utf-8"))
    assert quality["judge"]["weight"] == 0.0


def test_reward_json_core_keys():
    assert score_formula.REWARD_JSON_CORE_KEYS == {
        "binary_reward",
        "deterministic_score",
        "reward",
        "stage_complete",
        "training_score",
        "valid_trial",
    }


def test_readme_has_mermaid_and_validation():
    readme = (PKG / "README.md").read_text(encoding="utf-8")
    assert "mermaid" in readme
    assert "## Validation" in readme


def test_calibration_summary_placeholder():
    summary = json.loads((PKG / "calibration_summary.json").read_text(encoding="utf-8"))
    assert summary["status"] in {
        "oracle_passed",
        "pending_docker_validation",
        "pending_platform_revalidation",
        "docker_oracle_pass_pending_dataos",
    }
    assert summary["oracle"]["repeat_runs"] >= 2
    if summary["status"] == "oracle_passed":
        assert summary["oracle"]["results"]


def test_tools_layout_canonical():
    tools = sorted(p.name for p in (PKG / "tools").glob("*") if p.is_file())
    assert tools == ["run_inline_judged_terminus.sh"]


def test_no_cross_task_contamination():
    forbidden = ("gitea", "actionrunattempt", "sqlite_unlock_notify")
    for path in PKG.rglob("*"):
        if not path.is_file() or path.name in {"golden.patch", "test_package_contract.py"}:
            continue
        if path.suffix not in {".md", ".toml", ".py", ".sh", ".json"}:
            continue
        text = path.read_text(encoding="utf-8", errors="replace").lower()
        assert not [w for w in forbidden if w in text], path


def test_shell_scripts_lf_only():
    for script in PKG.rglob("*.sh"):
        data = script.read_bytes()
        assert b"\r\n" not in data, script
        # Pack gate normalizes to world-executable; shipped zip must not be mode 0600-only.
        assert script.stat().st_mode & 0o111, script


def test_hidden_stage02_checks_go_mod_and_watchlist():
    text = (
        TESTS / "hidden" / "02-k8s-deps-and-apis" / "verifierprobe" / "k8s135_deps_contract_test.go"
    ).read_text(encoding="utf-8")
    assert "TestGoModPinsK8sV035" in text
    assert "ToListWatcherWithWatchListSemantics" in text


def test_hidden_stage03_checks_framework_and_dra():
    dra = (
        TESTS / "hidden" / "03-scheduler-framework" / "verifierprobe" / "dra_contract_test.go"
    ).read_text(encoding="utf-8")
    pred = (
        TESTS / "hidden" / "03-scheduler-framework" / "verifierprobe" / "framework_contract_test.go"
    ).read_text(encoding="utf-8")
    assert "EnableDeviceTaintRules" in dra
    assert "k8s.io/kube-scheduler/framework" in pred


def test_hidden_corpus_does_not_mutate_testbed(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    testbed = tmp_path / "testbed"
    testbed.mkdir()
    (testbed / "go.mod").write_text("module example.com\n\ngo 1.25.0\n", encoding="utf-8")
    hidden = tmp_path / "hidden" / "02-k8s-deps-and-apis" / "verifierprobe"
    hidden.mkdir(parents=True)
    (hidden / "k8s135_deps_contract_test.go").write_text("package verifierprobe\n", encoding="utf-8")
    monkeypatch.setattr(stage_check, "TESTBED", testbed)
    monkeypatch.setattr(stage_check, "HIDDEN_ROOT", tmp_path / "hidden")
    monkeypatch.setattr(stage_check, "CORPUS_BASE", tmp_path / "corpus")
    root = stage_check.prepare_hidden_corpus(["02-k8s-deps-and-apis"])
    assert root.is_dir()
    assert not (testbed / "verifierprobe").exists()
    stage_check.cleanup_hidden_corpus(root)


def test_hidden_stage04_checks_passive_cache():
    text = (
        TESTS
        / "hidden"
        / "04-volume-binding-harden"
        / "verifierprobe"
        / "volumebinding_contract_test.go"
    ).read_text(encoding="utf-8")
    assert "passiveAssumeCache" in text
    assert "TestPassiveAssumeCacheWiringPresent" in text


def test_run_optional_judges_targets_final_stage():
    body = (TESTS / "run_optional_judges.sh").read_text(encoding="utf-8")
    assert "04-volume-binding-harden:1" in body
    assert "04-api-artifacts-and-harden" not in body
    assert "GEMINI_API_KEY" in body


def test_judge_prompt_mentions_volcano():
    text = (TESTS / "judge_prompt.md").read_text(encoding="utf-8").lower()
    assert "volcano" in text
    assert "5000" not in text


def test_stage_judge_inputs_default_family():
    assert "volcano-k8s135-adaptation-tier2" in (TESTS / "stage_judge_inputs.py").read_text(encoding="utf-8")
