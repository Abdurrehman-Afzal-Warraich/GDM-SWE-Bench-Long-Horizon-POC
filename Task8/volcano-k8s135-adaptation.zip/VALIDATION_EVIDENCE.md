# Validation evidence — volcano-k8s135-adaptation v7

Rework target: Hamid Raza R1/R2 (2026-08-07 / 2026-08-14) checklist failures on v6.

## Finding matrix (reviewer → v7 fix)

| Check / theme | v6 issue | v7 disposition |
|---|---|---|
| Headroom / attribution | Gemini S2 `valid_trial=0` + S4 merge-byte gate | **Fix**: remove 184-file SHA gate; integrity stays on executed commands; frontier re-run after Oracle |
| `merge_equivalence` / Oracle coupling | Byte-identical manifest rejects valid alternatives | **Fix**: `implementation_closure` (critical paths + agent proof JSON) |
| Hidden tests | Injected into `/testbed/verifierprobe` | **Fix**: isolated `/tmp/verifier-corpus` module, `TESTBED_DIR=/testbed` |
| Hidden test brittleness | AST shape matching on `passiveAssumeCache` | **Fix**: build + file/string wiring checks only |
| Integrity (R1) | Trajectory prose false positives | **Fix** (v6 partial): ATIF executed commands only; diagnose gap uses reproducer output only |
| Network policy | `allow_internet=true` + judges on | **Fix**: `RUN_LLM_JUDGES=0` default; policy text clarifies judges-only internet |
| Stage 04 grading gaps | Dockerfiles + merge proof not fairly graded | **Fix**: `installer_go125` + `implementation_closure` critical; handoff requires `Task complete.` |
| Expert time | 8h estimate vs 30h+ gate | **Fix**: 32h in `task.toml` |
| Calibration evidence | 1 Oracle, 1 noop, no near-miss | **Fix**: `calibration_summary.json` documents matrix; platform runs pending |
| CTRF / parse errors | Missing per-check CTRF on green runs | **Fix**: `write_ctrf()` in `stage_check.py` |
| Merge manifest in image | Agent-visible `/opt/merge_reference_manifest.json` | **Fix**: author-only file under `environment/` for pack gate; not COPY'd into image |

## Host-side gates (this rework)

```text
docker run ... /opt/verifier-venv/bin/python -m pytest -q tests/test_package_contract.py tests/test_reward_contract.py
→ 70 passed (2026-08-14, image volcano-k8s135-adaptation-v7:local)
```

Pack gate: `Task8/pack_volcano_v7.py` → `volcano-k8s135-adaptation-v7.zip`
sha256=`9111ba1cd885f5e5efe1165b4ab2814400a8d5d3812c9b81abb29f077b4b09ad`

## Docker Oracle replay (local Harbor image, 2026-08-14)

Script: `Task8/docker_oracle_verify_inner.sh` — cumulative state in one container,
`GOPROXY=off`, mounted `/tests` + oracle `solve.sh` + `/solution/golden.patch`.

| Stage | binary_reward | Notes |
|---|---|---|
| 01-diagnose | 1.0 | all checks pass |
| 02-k8s-deps-and-apis | 1.0 | build + hidden + vet (apis module) |
| 03-scheduler-framework | 1.0 | build + hidden + vet (production GoFiles) |
| 04-volume-binding-harden | 1.0 | build + hidden + closure + installers |

Repeated 3× with identical outcome (runs 2–3 after vet fix).

**Root cause of prior Oracle failures (eval 182374):** verifier `vet_clean` ran
`go vet ./pkg/scheduler/...` which analyzed upstream `_test.go` files (Go 1.25
ignores `-tests=false` for wildcard package patterns). Fixed with hybrid vet:
apis uses package-level `-tests=false`; scheduler stages vet `go list .GoFiles` per package.

**Secondary fix:** Dockerfile `environment/warm/` applies cumulative golden patches at
build time and runs `go mod download` + builds so offline `GOPROXY=off` runtime works.

## Docker no-op replay (2026-08-14)

Script: `Task8/docker_nop_verify_inner.sh` — pristine base, no patches.

| Stage | binary_reward | First failure |
|---|---|---|
| 01-diagnose | 0.0 | missing reproducer + diagnosis.json |
| 02-k8s-deps-and-apis | 0.0 | hidden_tests_pass (go.mod still v0.34) |
| 03-scheduler-framework | 0.0 | hidden_tests_pass (framework/DRA not migrated) |
| 04-volume-binding-harden | 0.0 | installer_go125 + implementation_closure |

## Platform matrix (required before resubmit)

| Run | Expected | Local Docker |
|---|---|---|
| Oracle ×2 | All stages `binary_reward=1.0` | **Pass ×3** |
| No-op | Stage 01 fails | **Pass** (all stages 0.0) |
| Near-miss: deps skip codegen | Stage 02 `hidden_tests_pass` fail | authored (not executed locally) |
| Near-miss: framework legacy import | Stage 03 build/hidden fail | authored |
| Near-miss: S4 installers without 1.25 | `installer_go125` fail | covered by no-op S4 |
| Frontier Gemini | Re-measure headroom (~5–20% target) | pending DataOS |

## Author merge-head proof (not graded at runtime)

Pack script verifies cumulative golden patches on base commit produce empty residual diff
against upstream merge commit for the 184 scoped production files, using
`environment/merge_reference_manifest.json` as author reference only.

## Dev Defense drafts (paste into tracker column M)

**Headroom / Gemini S2 invalid:** Prior frontier run executed `go get` (forbidden); engineering checks passed but `valid_trial=0`. v7 does not conflate that with task difficulty. Re-run frontier after v7 Oracle.

**Merge-byte coupling:** v6 Stage 4 required 184-file SHA-256 match to protected manifest, rejecting behaviorally correct alternatives. v7 replaces with `implementation_closure` (disclosed critical paths + agent proof JSON).

**Hidden test injection:** v6 copied probes into `/testbed`. v7 runs hidden corpus from `/tmp/verifier-corpus` without mutating agent workspace.

**Network / judges:** `RUN_LLM_JUDGES=0` by default; `allow_internet` documents optional judge egress only.
