/*
Copyright 2026 The Volcano Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package verifierprobe

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

func TestVolumeBindingPackageBuilds(t *testing.T) {
	root := testbedRoot(t)
	cmd := exec.Command("go", "build", "./pkg/scheduler/capabilities/volumebinding/...", "./cmd/scheduler/...")
	cmd.Dir = root
	cmd.Env = append(os.Environ(), "GOWORK=off", "CGO_ENABLED=0")
	out, err := cmd.CombinedOutput()
	if err != nil {
		t.Fatalf("volumebinding build: %v\n%s", err, out)
	}
}

func TestPassiveAssumeCacheWiringPresent(t *testing.T) {
	root := testbedRoot(t)
	rel := filepath.Join("pkg", "scheduler", "capabilities", "volumebinding")
	// Behavioral, implementation-neutral: the passiveAssumeCache feature may live in any
	// file under the volumebinding package (per the Stage 04 prompt). We assert the symbol
	// is present and wired, not that it lives in a specific filename.
	if !packageContains(t, root, rel, "passiveAssumeCache") {
		t.Fatal("volumebinding package must reference passiveAssumeCache")
	}
	if !packageContains(t, root, rel, "NewVolumeBinder") {
		t.Fatal("volumebinding package must wire NewVolumeBinder")
	}
}

func TestInstallerDockerfilesReferenceGo125(t *testing.T) {
	root := testbedRoot(t)
	for _, rel := range []string{
		"installer/dockerfile/agent-scheduler/Dockerfile",
		"installer/dockerfile/agent/Dockerfile",
		"installer/dockerfile/controller-manager/Dockerfile",
		"installer/dockerfile/scheduler/Dockerfile",
		"installer/dockerfile/webhook-manager/Dockerfile",
	} {
		data, err := os.ReadFile(filepath.Join(root, rel))
		if err != nil {
			t.Fatalf("read %s: %v", rel, err)
		}
		if !strings.Contains(string(data), "1.25") {
			t.Fatalf("%s must reference Go 1.25", rel)
		}
	}
}
