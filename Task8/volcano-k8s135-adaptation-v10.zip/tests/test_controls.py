"""Executed near-miss + valid-alternative control matrix.

These run as part of the standard host-side contract gate (``pytest tests/``) inside the
built image, so the controls are *executed*, not merely authored. They prove the verifier
discriminates: a structurally different but correct layout passes, while each near-miss
fails the specific gate it targets. The build/test-dependent near-misses (deps skip
codegen, framework legacy import) are additionally documented with runnable mutations in
``tests/controls/`` for the in-image runner; the checks below cover the reviewer's core
concern — implementation neutrality and gate discrimination — with no Go toolchain needed.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

import stage_check

BASE_COMMIT = "7ea02f980af2e1bcfaabf9b107370c4775bd0dfa"


def _valid_proof() -> dict:
    return {
        "base_commit": BASE_COMMIT,
        "feature_complete": True,
        "packages_touched": [
            "pkg/scheduler/capabilities/volumebinding",
            "installer/dockerfile",
        ],
        "verification_performed": ["go build ./...", "go test ./..."],
    }


def _make_oracle_like_testbed(root: Path, *, go125: bool = True) -> None:
    """Create a tree that satisfies every CRITICAL_IMPLEMENTATION_PATHS entry."""
    for rel in stage_check.CRITICAL_IMPLEMENTATION_PATHS:
        path = root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        if rel.endswith("Dockerfile"):
            path.write_text(
                "FROM golang:1.25 AS build\nRUN go build ./...\n" if go125
                else "FROM golang:1.24 AS build\nRUN go build ./...\n",
                encoding="utf-8",
            )
        elif rel.endswith("go.mod"):
            path.write_text("module x\n\ngo 1.25.0\n", encoding="utf-8")
        else:
            path.write_text("package volumebinding\n", encoding="utf-8")


def _write_proof(output: Path, proof: dict) -> None:
    stage_dir = output / "04-volume-binding-harden"
    stage_dir.mkdir(parents=True, exist_ok=True)
    (stage_dir / "implementation_closure_proof.json").write_text(
        json.dumps(proof) + "\n", encoding="utf-8"
    )


# --- Cluster A: filename decoupling is locked in -----------------------------------

def test_control_closure_is_filename_neutral_static() -> None:
    # The exact feature filename must NOT be a closure gate (Stage 04 permits any file).
    assert (
        "pkg/scheduler/capabilities/volumebinding/passive_assume_cache.go"
        not in stage_check.CRITICAL_IMPLEMENTATION_PATHS
    )


def test_control_valid_alternative_layout_passes_closure(tmp_path, monkeypatch) -> None:
    # VALID ALTERNATIVE: passiveAssumeCache implemented in a NON-standard filename.
    # Closure (module/installer paths + proof) must still pass — no source-shape coupling.
    testbed = tmp_path / "testbed"
    output = tmp_path / "output"
    _make_oracle_like_testbed(testbed)
    alt = testbed / "pkg/scheduler/capabilities/volumebinding/cache_alt.go"
    alt.write_text(
        "package volumebinding\n\nfunc newPassiveAssumeCache() {}\n// passiveAssumeCache\n",
        encoding="utf-8",
    )
    _write_proof(output, _valid_proof())
    monkeypatch.setattr(stage_check, "TESTBED", testbed)
    monkeypatch.setattr(stage_check, "OUTPUT", output)
    ok, note = stage_check.verify_implementation_closure_artifact()
    assert ok, note


# --- Near-misses: each fails the specific gate it targets ---------------------------

def test_control_nearmiss_missing_core_file_fails_closure(tmp_path, monkeypatch) -> None:
    testbed = tmp_path / "testbed"
    output = tmp_path / "output"
    _make_oracle_like_testbed(testbed)
    (testbed / "pkg/scheduler/capabilities/volumebinding/volume_binding.go").unlink()
    _write_proof(output, _valid_proof())
    monkeypatch.setattr(stage_check, "TESTBED", testbed)
    monkeypatch.setattr(stage_check, "OUTPUT", output)
    ok, note = stage_check.verify_implementation_closure_artifact()
    assert not ok
    assert "critical implementation paths missing" in note


def test_control_nearmiss_incomplete_proof_fails_closure(tmp_path, monkeypatch) -> None:
    testbed = tmp_path / "testbed"
    output = tmp_path / "output"
    _make_oracle_like_testbed(testbed)
    bad = _valid_proof()
    bad["feature_complete"] = False
    _write_proof(output, bad)
    monkeypatch.setattr(stage_check, "TESTBED", testbed)
    monkeypatch.setattr(stage_check, "OUTPUT", output)
    ok, note = stage_check.verify_implementation_closure_artifact()
    assert not ok
    assert "feature_complete" in note


def test_control_nearmiss_installer_without_go125_fails(tmp_path, monkeypatch) -> None:
    testbed = tmp_path / "testbed"
    _make_oracle_like_testbed(testbed, go125=True)
    monkeypatch.setattr(stage_check, "TESTBED", testbed)
    ok, _ = stage_check.installer_images_use_go125()
    assert ok  # baseline: all installers reference Go 1.25

    # NEAR-MISS: one installer reverts to Go 1.24 -> installer_go125 must fail.
    (testbed / "installer/dockerfile/scheduler/Dockerfile").write_text(
        "FROM golang:1.24 AS build\n", encoding="utf-8"
    )
    ok, note = stage_check.installer_images_use_go125()
    assert not ok
    assert "1.25" in note
