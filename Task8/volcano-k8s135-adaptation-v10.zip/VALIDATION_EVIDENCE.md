# Validation evidence — volcano-k8s135-adaptation v10

Rework target: Hamid Raza **R3 (2026-08-17)** checklist failures on v9 (which itself
addressed R1 2026-08-07 and R2 2026-08-14). This document records the v10 disposition
of every R3 finding cluster: **fixed in-package**, **defended (platform-provided)**, or
**pending re-run** on the sealed v10 artifact.

## R3 finding matrix (reviewer cluster → v10 disposition)

| Cluster | R3 finding | v10 disposition | Type |
|---|---|---|---|
| A. Stage 04 exact-filename gate | `implementation may live in any file` contradicted a hard requirement for `passive_assume_cache.go` (stage_check `CRITICAL_IMPLEMENTATION_PATHS`, hidden test, instruction). | **Fixed**: removed the filename from `CRITICAL_IMPLEMENTATION_PATHS`; hidden `TestPassiveAssumeCacheWiringPresent` now asserts only the `passiveAssumeCache`/`NewVolumeBinder` symbols via `packageContains` (any file); instruction + `requirement_map.json` reworded to behavioral closure. | Code fix |
| B. Stage 02 codegen vs integrity | Integrity forbids `go install`/`go get` but Stage 02 needs regenerated codegen with no disclosed generator. | **Fixed (two parts)**: (1) `k8s.io/code-generator v0.35.0` is pinned + warm-cached; Stage 02 discloses `go run k8s.io/code-generator/cmd/<gen>` and warns the repo's legacy scripts call the forbidden install/get. (2) **Integrity false-positive fixed** — a frontier run invalidated Stage 02 when the agent ran `grep "go install"` while investigating; the scanner now head-tokenizes each sub-command and ignores forbidden strings passed to read-only tools (grep/cat/echo/…). Redundant git blob pattern removed; regression tests added. | Code fix (rerun to confirm) |
| C. Network isolation | `allow_internet=true` + all evals `override_network_mode=public` contradicted the isolation claim. | **Fixed in package**: `allow_internet=false`; `network_policy` states agent has no egress and all work runs offline from the warm cache; judges need separate egress. Release runs must NOT override to public. | Config fix (rerun to confirm) |
| D. Version binding | Archive v9 while `task.toml`=v1, `calibration_summary`/`shipped_archive`=v7. | **Fixed**: all identifiers rebound to `v10`; `calibration_summary` marks evidence as pending v10 re-run rather than reusing v7 numbers. | Config fix |
| E. Missing v10 controls | Only 1 Oracle / 1 no-op / 1 Gemini; near-miss authored; no ×3 stability; no valid-alternative; no horizon ablation. | **Pending re-run** (user/Data-OS): matrix enumerated in `calibration_summary.json → revalidation_required`. | Rerun campaign |
| F. Required-but-non-gating reports | Stage 03 `review_response`/handoff required by prompt but non-critical (Gemini S3 `binary_reward=1`, `stage_complete=0`). | **Fixed**: prompts (02/03/04) now state report+handoff artifacts score into `training_score` only and do not gate promotion — matching `reward_formula`. Stage 04 keeps `implementation_closure_proof.json` as a required (critical) input. | Code fix |
| G. Trust boundary / sandbox | No non-root agent; grading on live `/testbed`; no process teardown; shared verifier identity. | **Partially in-package + defended** (see below). | Defend + platform |
| H. Supply chain / packaging | apt versions unpinned, RewardKit allowed to fail; `.sh`/`.py` shipped `0600`. | **Fixed**: executables normalized to `0755` at pack time (LF-normalized). apt/RewardKit hardening documented as residual (see below). | Packaging fix + defend |
| I. Thin late-stage fault/recovery | Stage 04 is mostly cumulative build/installer checks. | **Defended**: the intended terminal risk is cumulative correctness + Go 1.25 installer closure across the accumulated multi-stage change; no synthetic late fault is added rather than manufacture one. | Defend |

## Cluster G — trust-boundary disposition

The strict trust-model rows (freeze-and-hash the candidate before grading, terminate
agent processes before the verifier runs, run candidate under a non-root identity
separate from the trusted verifier/root) are **Harbor / Data-OS harness guarantees**,
not properties a single `task.toml`/Dockerfile can fully enforce:

- **Already fixed (v9):** hidden tests execute from an isolated `/tmp/verifier-corpus`
  module; the live `/testbed` tree is not mutated by grading.
- **Platform-provided (defend):** candidate freeze+hash, agent-process teardown, and
  verifier-as-trusted-identity are provided by the Harbor sandbox lifecycle. The package
  requests that the harness (a) run the agent step under a non-root identity and (b) run
  the verifier step as the trusted/root identity, with the candidate frozen between the
  two. Trusted tool checksums are already pinned at `/opt/verifier-binary-checksums.txt`
  (mode 444).
- **Residual to confirm on rebuild:** if the deployment does not run the agent non-root
  by default, provision a dedicated non-root agent uid in the environment and chown the
  agent-writable trees (`/testbed`, `/app/output`, `/logs`, `/workspace`, `/go`,
  `/gocache`) to it, leaving the verifier as root.

## Residuals (defended, low severity)

- **apt pinning:** base image is digest-pinned (`python:3.12-bookworm@sha256:...`) and
  the Go toolchain is SHA-256 pinned; apt top-up packages are best-effort and
  non-fatal. Full apt version pinning is deferred to avoid brittle build breakage on
  bookworm point releases; the digest-pinned base bounds the surface.
- **RewardKit install non-fatal:** judges default OFF and never change `binary_reward`,
  so a missing RewardKit cannot affect deterministic scoring.

## Prior v7 Docker evidence — SUPERSEDED, must be re-run on v10

The following was captured on the **v7** image and is **not** valid evidence for v10
(v10 changes grading and prompts). It is retained only to show the expected shape.

- v7 Oracle ×3 → all four stages `binary_reward=1.0` (image `volcano-k8s135-adaptation-v7:local`).
- v7 no-op → Stage 01 fails at reproducer; all stages `0.0`.
- v7 host-side `pytest tests/test_package_contract.py tests/test_reward_contract.py` → 70 passed.

**v10 requires:** rebuild the image, re-run host-side contract tests (note
`test_stage04_critical_checks_include_closure_gates` still holds — `implementation_closure`
remains critical; only the filename coupling was removed), then run the
`revalidation_required` matrix in `calibration_summary.json`.

## Author merge-head proof (not graded at runtime)

Cumulative golden patches on the base commit produce an empty residual diff against the
upstream merge commit for the scoped production files, using
`environment/merge_reference_manifest.json` as author reference only. v10 does not change
the golden patches, so this proof is unaffected.

## Dev Defense drafts (paste into tracker column M)

**A — Stage 04 filename coupling:** v10 removes the exact `passive_assume_cache.go` gate.
Closure is now behavioral (package builds; `passiveAssumeCache`/`NewVolumeBinder` symbols
present via `packageContains`, any file), matching the prompt's stated implementation
freedom. A differently-organized correct implementation now passes.

**B — Stage 02 codegen fairness:** the pinned `k8s.io/code-generator v0.35.0` is warmed
in the module cache; the honest offline path (`go run .../code-generator/cmd/...`) is now
disclosed and is not a forbidden command. `go install`/`go get` remain unnecessary.

**C — Network:** `allow_internet=false`; the agent runs offline. Optional judges (default
off) use a separate egress. Release runs must not override the agent to public network.

**F — Required deliverables:** report/handoff artifacts are explicitly non-decisive
(`training_score` only), consistent with `reward_formula`. Deterministic build/hidden/vet
gates decide official pass/fail; Stage 04 closure proof remains required.

**G — Trust model:** hidden tests run isolated from `/testbed`; freeze/hash, process
teardown, and non-root/verifier identity separation are harness-provided; the package
pins trusted tool checksums and requests the standard non-root-agent / trusted-verifier
split.

**E — Headroom:** the v9 Gemini run is excluded (S2 `valid_trial=0`, S4 filename-coupled).
v10 removes both defects; a fresh frontier ×3 under offline network is required before any
solve-rate/headroom is claimed.
