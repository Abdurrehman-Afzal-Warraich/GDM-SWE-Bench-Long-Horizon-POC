#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import random
import re
import shutil
import subprocess
import tempfile
import time
from pathlib import Path

from score_formula import (
    binary_outcome,
    calculate_training_score,
    deterministic_components,
    formula_text,
    parse_lambda,
)


TESTBED = Path(os.environ.get("TESTBED_DIR", "/testbed"))
RESULT = Path(os.environ.get("RESULT_DIR", "/logs/verifier"))
OUTPUT = Path(os.environ.get("OUTPUT_DIR", "/app/output"))
UNITTEST = TESTBED / "build/reldebug/test/unittest"

DIAGNOSE_WEIGHTS = {
    "executable_reproduction": 0.65,
    "base_behavior_observed": 0.25,
    "architecture_handoff": 0.05,
    "diagnosis_handoff": 0.05,
}

CORE_WEIGHTS = {
    "incremental_build": 0.15,
    "basic_indexed_remap": 0.25,
    "duplicate_key_remap": 0.20,
    "fallback_paths": 0.15,
    "generated_remap_variants": 0.20,
    "handoff_consumed": 0.025,
    "implementation_report": 0.025,
}

REVIEW_WEIGHTS = {
    "incremental_build": 0.10,
    "legacy_rebuild": 0.10,
    "legacy_geometry_fallback": 0.10,
    "checkpoint_persistence": 0.20,
    "concurrent_scan_checkpoint": 0.25,
    "core_regression": 0.15,
    "generated_concurrency_variants": 0.05,
    "review_response": 0.05,
}

HARDEN_WEIGHTS = {
    "incremental_build": 0.05,
    "partial_chunk_and_collision": 0.20,
    "multitask_persistence": 0.15,
    "multi_index_null_unique": 0.15,
    "persistence_regression": 0.05,
    "concurrency_regression": 0.05,
    "legacy_regression": 0.05,
    "visible_regression_suite": 0.10,
    "generated_final_variants": 0.10,
    "patch_hygiene": 0.05,
    "hardening_artifacts": 0.05,
}

CRITICAL_CHECKS = {
    "diagnose": frozenset(DIAGNOSE_WEIGHTS),
    "core": frozenset(
        {
            "incremental_build",
            "basic_indexed_remap",
            "duplicate_key_remap",
            "fallback_paths",
            "generated_remap_variants",
        }
    ),
    "review": frozenset(
        {
            "incremental_build",
            "legacy_rebuild",
            "legacy_geometry_fallback",
            "checkpoint_persistence",
            "concurrent_scan_checkpoint",
            "core_regression",
            "generated_concurrency_variants",
        }
    ),
    "harden": frozenset(
        name for name in HARDEN_WEIGHTS if name != "hardening_artifacts"
    ),
}

def run(
    command: list[str],
    timeout: int = 1800,
    cwd: Path = TESTBED,
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        cwd=cwd,
        text=True,
        capture_output=True,
        timeout=timeout,
    )


def record(
    checks: dict[str, dict[str, object]],
    name: str,
    completed: subprocess.CompletedProcess[str],
) -> None:
    checks[name] = {
        "passed": completed.returncode == 0,
        "detail": (completed.stderr + completed.stdout)[-12000:],
    }


def incremental_build() -> subprocess.CompletedProcess[str]:
    return run(
        [
            "cmake",
            "--build",
            "build/reldebug",
            "--target",
            "unittest",
            "-j",
            os.environ.get("CMAKE_BUILD_PARALLEL_LEVEL", "8"),
        ],
        timeout=5400,
    )


def require_discovered_test(
    completed: subprocess.CompletedProcess[str],
) -> subprocess.CompletedProcess[str]:
    output = completed.stderr + completed.stdout
    if not re.search(r"No test cases matched|No tests ran", output, re.I):
        return completed
    return subprocess.CompletedProcess(
        args=completed.args,
        returncode=2,
        stdout=completed.stdout,
        stderr=(
            completed.stderr
            + "\n[verifier] DuckDB did not discover the protected SQLLogicTest.\n"
        ),
    )


def run_sql_test(filename: str, timeout: int = 1800) -> subprocess.CompletedProcess[str]:
    source = Path("/tests") / filename
    relative_name = Path("test") / "long_horizon" / filename
    with tempfile.TemporaryDirectory(prefix="duckdb-lh-protected-") as directory:
        hidden_root = Path(directory)
        target = hidden_root / relative_name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        completed = run(
            [
                str(UNITTEST),
                "--run-id",
                "auto",
                "--test-dir",
                str(hidden_root),
                str(relative_name),
            ],
            timeout=timeout,
        )
        return require_discovered_test(completed)


def run_sql_tests(
    filenames: list[str],
    timeout: int = 1800,
) -> subprocess.CompletedProcess[str]:
    stdout: list[str] = []
    stderr: list[str] = []
    failed = False
    for filename in filenames:
        completed = run_sql_test(filename, timeout=timeout)
        stdout.append(f"===== {filename} =====\n{completed.stdout}")
        stderr.append(f"===== {filename} =====\n{completed.stderr}")
        failed = failed or completed.returncode != 0
    return subprocess.CompletedProcess(
        args=[str(UNITTEST), *filenames],
        returncode=1 if failed else 0,
        stdout="\n".join(stdout),
        stderr="\n".join(stderr),
    )


def run_sql_test_repeated(
    filename: str,
    repeats: int = 3,
    timeout: int = 1800,
) -> subprocess.CompletedProcess[str]:
    return run_sql_tests([filename] * repeats, timeout=timeout)


def run_generated_sql_tests(
    cases: list[tuple[str, str]],
    timeout: int = 1800,
) -> subprocess.CompletedProcess[str]:
    stdout: list[str] = []
    stderr: list[str] = []
    failed = False
    with tempfile.TemporaryDirectory(prefix="duckdb-lh-generated-") as directory:
        hidden_root = Path(directory)
        for filename, source in cases:
            relative_name = Path("test") / "long_horizon" / filename
            target = hidden_root / relative_name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(source, encoding="utf-8")
            completed = require_discovered_test(
                run(
                    [
                        str(UNITTEST),
                        "--run-id",
                        "auto",
                        "--test-dir",
                        str(hidden_root),
                        str(relative_name),
                    ],
                    timeout=timeout,
                )
            )
            stdout.append(f"===== {filename} =====\n{completed.stdout}")
            stderr.append(f"===== {filename} =====\n{completed.stderr}")
            failed = failed or completed.returncode != 0
    return subprocess.CompletedProcess(
        args=[str(UNITTEST), *(name for name, _ in cases)],
        returncode=1 if failed else 0,
        stdout="\n".join(stdout),
        stderr="\n".join(stderr),
    )


def generated_remap_cases(seed: int = 23653) -> list[tuple[str, str]]:
    rng = random.Random(seed)
    cases: list[tuple[str, str]] = []
    for index in range(3):
        deleted = rng.choice((512, 640, 768, 896))
        tail = rng.choice(tuple(value for value in (256, 384, 512) if value <= deleted))
        duplicate_key = rng.randrange(29, 97)
        first_duplicate = deleted + rng.randrange(7, 31)
        target_value = 2048 + tail // 2
        expected_target_rowid = target_value - deleted
        expected_count = 2048 - deleted + tail
        filename = f"generated_core_{seed}_{index}.test"
        cases.append(
            (
                filename,
                f"""# name: test/long_horizon/{filename}
# description: Seeded indexed-vacuum remap property.
# group: [long_horizon]

statement ok
ATTACH '{{TEST_DIR}}/{filename}.db' AS generated (STORAGE_VERSION 'latest', ROW_GROUP_SIZE 2048);

statement ok
SET max_vacuum_tasks = 99;

statement ok
CREATE TABLE generated.t(i INTEGER, g INTEGER);

statement ok
INSERT INTO generated.t
SELECT i, CASE WHEN i = {first_duplicate} THEN {duplicate_key} ELSE i + 100000 END
FROM range(2048) tbl(i);

statement ok
CHECKPOINT generated;

statement ok
INSERT INTO generated.t
SELECT i, CASE WHEN i = {target_value} THEN {duplicate_key} ELSE i + 100000 END
FROM range(2048, {2048 + tail}) tbl(i);

statement ok
CHECKPOINT generated;

statement ok
CREATE UNIQUE INDEX generated_i_idx ON generated.t(i);

statement ok
CREATE INDEX generated_g_idx ON generated.t(g);

statement ok
DELETE FROM generated.t WHERE i < {deleted};

statement ok
FORCE CHECKPOINT generated;

query III
SELECT min(rowid), max(rowid), count(*) FROM generated.t;
----
0\t{expected_count - 1}\t{expected_count}

query II
SELECT rowid, i FROM generated.t WHERE i = {target_value};
----
{expected_target_rowid}\t{target_value}

query II
SELECT rowid, i FROM generated.t WHERE g = {duplicate_key} ORDER BY i;
----
{first_duplicate - deleted}\t{first_duplicate}
{expected_target_rowid}\t{target_value}

query II
EXPLAIN ANALYZE SELECT rowid, i FROM generated.t WHERE i = {target_value};
----
analyzed_plan\t<REGEX>:.*Type: Index Scan.*
""",
            )
        )
    return cases


def generated_concurrency_cases(seed: int = 23654) -> list[tuple[str, str]]:
    rng = random.Random(seed)
    cases: list[tuple[str, str]] = []
    for index in range(2):
        deleted = rng.choice((512, 640, 768))
        tail = rng.choice((256, 384, 512))
        target_value = 2048 + tail // 2
        expected_target_rowid = target_value - deleted
        loop_count = rng.choice((5, 7, 9))
        filename = f"generated_concurrency_{seed}_{index}.test"
        cases.append(
            (
                filename,
                f"""# name: test/long_horizon/{filename}
# description: Seeded concurrent index-scan and checkpoint property.
# group: [long_horizon]

statement ok
ATTACH '{{TEST_DIR}}/{filename}.db' AS generated (STORAGE_VERSION 'latest', ROW_GROUP_SIZE 2048);

statement ok
SET max_vacuum_tasks = 99;

statement ok
CREATE TABLE generated.t AS SELECT i FROM range(2048) tbl(i);

statement ok
CHECKPOINT generated;

statement ok
INSERT INTO generated.t SELECT i FROM range(2048, {2048 + tail}) tbl(i);

statement ok
CHECKPOINT generated;

statement ok
CREATE UNIQUE INDEX generated_i_idx ON generated.t(i);

statement ok
DELETE FROM generated.t WHERE i < {deleted};

concurrentloop threadid 0 {loop_count}

query I
SELECT count(*) FROM generated.t WHERE i = {target_value};
----
1

statement ok
FORCE CHECKPOINT generated;

query I
SELECT count(*) FROM generated.t WHERE i = {target_value};
----
1

endloop

query II
SELECT rowid, i FROM generated.t WHERE i = {target_value};
----
{expected_target_rowid}\t{target_value}

query II
EXPLAIN ANALYZE SELECT rowid, i FROM generated.t WHERE i = {target_value};
----
analyzed_plan\t<REGEX>:.*Type: Index Scan.*
""",
            )
        )
    return cases


def reward_value_for_stage(
    stage: str,
    training_score: float,
    strict: bool,
    integrity_ok: bool,
    critical_pass: bool,
) -> float:
    del stage, training_score, critical_pass
    return binary_outcome(
        required_checks_pass=strict,
        integrity_ok=integrity_ok,
    )


def _meaningful(value: object) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, (list, dict, tuple, set)):
        return bool(value)
    return True


def json_alias_contract(
    path: Path,
    aliases: dict[str, tuple[str, ...]],
) -> tuple[bool, dict[str, object]]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            return False, {
                "failed_requirements": ["json_object"],
                "detail": "artifact must be a JSON object",
            }
        resolved = {
            canonical: next(
                (name for name in names if _meaningful(payload.get(name))),
                None,
            )
            for canonical, names in aliases.items()
        }
        missing = [name for name, actual in resolved.items() if actual is None]
        return not missing, {
            "accepted_keys": aliases,
            "resolved_keys": resolved,
            "failed_requirements": missing,
        }
    except Exception as exc:
        return False, {
            "failed_requirements": ["valid_json"],
            "detail": repr(exc),
        }


def diagnosis_handoff(path: Path) -> tuple[bool, dict[str, object]]:
    aliases = {
        "invariant": ("invariant", "safety_invariant"),
        "evidence": ("evidence", "executable_evidence"),
        "affected_boundaries": ("affected_boundaries",),
        "risks": ("risks",),
        "next_stage_checks": ("next_stage_checks", "concrete_checks"),
    }
    return json_alias_contract(path, aliases)


def architecture_handoff(path: Path) -> tuple[bool, dict[str, object]]:
    expected = {
        "latest_art_strategy": "REMAP",
        "indexless_strategy": "NO_INDEXES",
        "small_legacy_rebuild_strategy": "REBUILD",
        "unsupported_or_legacy_strategy": "KEEP_ROW_IDS",
        "buffers_old_and_new_rowids": True,
        "deletes_old_before_inserting_new": True,
        "index_scan_uses_shared_vacuum_lock": True,
    }
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        checks = {
            key: (
                payload.get(key).casefold() == value.casefold()
                if isinstance(value, str) and isinstance(payload.get(key), str)
                else payload.get(key) is value
            )
            for key, value in expected.items()
        }
        failed = [name for name, passed in checks.items() if not passed]
        return not failed, {
            "expected": expected,
            "actual": {key: payload.get(key) for key in expected},
            "failed_requirements": failed,
        }
    except Exception as exc:
        return False, {
            "failed_requirements": ["valid_typed_handoff"],
            "detail": repr(exc),
        }


def implementation_report(path: Path) -> tuple[bool, dict[str, object]]:
    return json_alias_contract(
        path,
        {
            "strategy_selection": ("strategy_selection", "strategy"),
            "remap_data": ("remap_data", "buffered_data"),
            "collision_handling": ("collision_handling", "collision_order"),
            "tests_run": ("tests_run", "verification"),
            "deferred_review_work": ("deferred_review_work", "remaining_work"),
        },
    )


def review_response(path: Path) -> tuple[bool, dict[str, object]]:
    return json_alias_contract(
        path,
        {
            "feedback": ("feedback",),
            "changes": ("changes", "changed_boundaries"),
            "verification": ("verification", "verification_commands"),
            "compatibility_risk": ("compatibility_risk", "remaining_risk"),
        },
    )


def changed_files() -> list[str]:
    tracked = run(["git", "diff", "--name-only"], timeout=60).stdout.splitlines()
    untracked = run(
        ["git", "ls-files", "--others", "--exclude-standard"],
        timeout=60,
    ).stdout.splitlines()
    return sorted(set(tracked + untracked))


def _uses_runtime_package_installation(command: str) -> bool:
    return bool(
        re.search(
            r"\b(?:apt|apt-get|apk|dnf|yum)\s+(?:update|install|add)\b"
            r"|\b(?:(?:python|python3)\s+-m\s+)?pip3?\s+install\b"
            r"|\b(?:npm|pnpm|yarn)\s+(?:update|install|add)\b"
            r"|\bcargo\s+install\b"
            r"|\bbrew\s+install\b",
            command,
            re.I,
        )
    )


def command_integrity_violations(commands: list[str]) -> list[dict[str, str]]:
    rules = {
        "network downloader": re.compile(r"(^|\s)(curl|wget)(\s|$)", re.I),
        "network client": re.compile(
            r"(^|\s)(?:aria2c|http|https|nc|ncat|scp|sftp|ssh)(\s|$)"
            r"|\bgh\s+(?:api|repo|pr|issue|search)\b",
            re.I,
        ),
        "author or verifier path": re.compile(
            r"(?<![A-Za-z0-9_.-])/(?:tests|solution)(?:/|\b)",
            re.I,
        ),
        "verifier temporary path": re.compile(
            r"(?<![A-Za-z0-9_.-])/tmp/duckdb-lh-(?:protected|generated)(?:[-/]\S*)?",
            re.I,
        ),
        "forbidden Git remote or hidden reference": re.compile(
            r"\bgit\s+(?:remote|reflog|fetch|pull|clone|ls-remote)\b",
            re.I,
        ),
    }
    violations: list[dict[str, str]] = []
    for command in commands:
        for name, pattern in rules.items():
            if pattern.search(command):
                violations.append({"rule": name, "command": command.strip()[:500]})
        if _uses_runtime_package_installation(command):
            violations.append(
                {
                    "rule": "runtime package installation",
                    "command": command.strip()[:500],
                }
            )
    return violations


def trusted_oracle() -> bool:
    return (
        Path("/logs/agent/oracle.txt").is_file()
        or os.environ.get("TRUSTED_ORACLE", "") == "1"
    )


def process_integrity() -> tuple[bool, dict[str, object]]:
    candidates = [
        Path(os.environ.get("TRAJECTORY_PATH", "")),
        Path("/logs/agent/trajectory.json"),
        Path("/logs/artifacts/trajectory.json"),
        Path("/logs/trajectory.json"),
        Path("/app/trajectory.json"),
    ]
    trajectory = next(
        (path for path in candidates if str(path) and path.is_file()),
        None,
    )
    if trajectory is None:
        if trusted_oracle():
            return True, {
                "trajectory": "not applicable for trusted Oracle",
                "commands_audited": 0,
                "violations": [],
                "oracle": True,
            }
        return False, {
            "trajectory": "not available",
            "commands_audited": 0,
            "violations": [{"rule": "missing agent trajectory"}],
            "oracle": False,
        }
    try:
        payload = json.loads(
            trajectory.read_text(encoding="utf-8", errors="replace")
        )
    except Exception as exc:
        return False, {"trajectory": str(trajectory), "error": repr(exc)}

    commands: list[str] = []
    for step in payload.get("steps", []):
        if not isinstance(step, dict) or step.get("source") != "agent":
            continue
        for call in step.get("tool_calls", []):
            if not isinstance(call, dict):
                continue
            arguments = call.get("arguments", {})
            if isinstance(arguments, dict):
                command = arguments.get("keystrokes") or arguments.get("command")
                if isinstance(command, str):
                    commands.append(command)

    violations = command_integrity_violations(commands)
    return not violations, {
        "trajectory": str(trajectory),
        "commands_audited": len(commands),
        "violations": violations,
    }


def integrity() -> tuple[bool, dict[str, object]]:
    changed = changed_files()
    config_path = TESTBED / ".git/config"
    config = config_path.read_text(encoding="utf-8", errors="replace")
    forbidden = [
        item
        for item in changed
        if item.startswith((".git/", "solution/", "tests/"))
    ]
    repository_ok = (
        not forbidden
        and '[remote "' not in config
        and not re.search(r"^\s*url\s*=", config, re.M)
        and not (TESTBED / "solution").exists()
        and not (TESTBED / "tests").exists()
    )
    process_ok, process_detail = process_integrity()
    return repository_ok and process_ok, {
        "changed_files": changed,
        "forbidden": forbidden,
        "repository_ok": repository_ok,
        "process_ok": process_ok,
        "process": process_detail,
    }


def moved_row_expectation(test_text: str) -> tuple[bool, dict[str, object]]:
    executable = "\n".join(
        line for line in test_text.splitlines() if not line.lstrip().startswith("#")
    )
    candidates: list[dict[str, object]] = []
    for block in re.split(r"(?im)^\s*query\s+\S+\s*$", executable)[1:]:
        if "----" not in block:
            continue
        query, expected = block.split("----", 1)
        if not re.search(r"\bSELECT\s+rowid\s*,", query, re.I):
            continue
        if not re.search(r"\bWHERE\b", query, re.I):
            continue
        expected_line = next(
            (line.strip() for line in expected.splitlines() if line.strip()),
            "",
        )
        values = re.findall(r"(?<![\w.])-?\d+(?![\w.])", expected_line)
        moved = len(values) >= 2 and values[0] != values[1]
        candidates.append(
            {
                "query": " ".join(query.split())[:500],
                "expected": expected_line[:500],
                "rowid_differs_from_stable_key": moved,
            }
        )
    passed = any(
        bool(item["rowid_differs_from_stable_key"]) for item in candidates
    )
    return passed, {
        "candidate_count": len(candidates),
        "candidates": candidates,
    }


def uses_latest_storage(test_text: str) -> bool:
    return bool(re.search(r"\bSTORAGE_VERSION\s+'latest'", test_text, re.I))


def diagnose(checks: dict[str, dict[str, object]]) -> dict[str, float]:
    script = OUTPUT / "01-diagnose/reproducer.sh"
    test_file = OUTPUT / "01-diagnose/test/long_horizon/reproducer.test"
    if script.is_file() and test_file.is_file() and os.access(script, os.X_OK):
        script_text = script.read_text(encoding="utf-8", errors="replace")
        test_text = test_file.read_text(encoding="utf-8", errors="replace")
        direct_result = require_discovered_test(
            run(
                [
                    str(UNITTEST),
                    "--run-id",
                    "auto",
                    "--test-dir",
                    str(OUTPUT / "01-diagnose"),
                    "test/long_horizon/reproducer.test",
                ],
                timeout=1200,
            )
        )
        result = run([str(script)], timeout=1200)
        log = OUTPUT / "01-diagnose/reproducer.log"
        log_text = (
            log.read_text(encoding="utf-8", errors="replace")
            if log.is_file()
            else ""
        )
        moved_row_ok, moved_row_detail = moved_row_expectation(test_text)
        direct_output = direct_result.stderr + direct_result.stdout
        real_mismatch = (
            direct_result.returncode != 0
            and bool(re.search(r"Wrong result in query|Mismatch on row", direct_output, re.I))
        )
        invalid_failure = bool(
            re.search(
                r"Parser Error|Binder Error|Catalog Error|Syntax Error|"
                r"IO Error|INTERNAL Error|No test cases matched|No tests ran",
                direct_output + log_text,
                re.I,
            )
        )
        requirements = {
            "runs_duckdb_unittest": (
                "build/reldebug/test/unittest" in script_text
            ),
            "runs_declared_test": "test/long_horizon/reproducer.test" in script_text,
            "captures_reproducer_log": "reproducer.log" in script_text,
            "uses_latest_storage": uses_latest_storage(test_text),
            "creates_index": bool(re.search(r"CREATE\s+(?:UNIQUE\s+)?INDEX", test_text, re.I)),
            "deletes_rows": bool(re.search(r"\bDELETE\s+FROM\b", test_text, re.I)),
            "forces_checkpoint": "FORCE CHECKPOINT" in test_text.upper(),
            "checks_physical_compaction": (
                moved_row_ok and real_mismatch and not invalid_failure
            ),
            "checks_moved_rowid": moved_row_ok,
            "declares_test_name": "# name: test/long_horizon/reproducer.test" in test_text,
        }
        failed = [name for name, passed in requirements.items() if not passed]
        marker = "expected-indexed-vacuum-remap-missing" in (
            result.stdout + result.stderr
        )
        checks["executable_reproduction"] = {
            "passed": (
                result.returncode == 0
                and marker
                and real_mismatch
                and not invalid_failure
                and not failed
            ),
            "detail": (
                result.stderr + result.stdout + direct_output + log_text
            )[-12000:],
            "requirements": requirements,
            "failed_requirements": failed,
            "moved_row_evidence": moved_row_detail,
            "invalid_failure_kind": invalid_failure,
            "direct_test_returncode": direct_result.returncode,
        }
    else:
        checks["executable_reproduction"] = {
            "passed": False,
            "detail": "missing executable reproducer.sh or test/long_horizon/reproducer.test",
        }

    record(
        checks,
        "base_behavior_observed",
        run_sql_test("base_indexed_vacuum_probe.test"),
    )
    architecture_ok, architecture_detail = architecture_handoff(
        OUTPUT / "handoff.json"
    )
    checks["architecture_handoff"] = {
        "passed": architecture_ok,
        "detail": architecture_detail,
    }
    handoff_ok, handoff_detail = diagnosis_handoff(OUTPUT / "handoff.json")
    checks["diagnosis_handoff"] = {
        "passed": handoff_ok,
        "detail": handoff_detail,
    }
    production_changes = [
        item
        for item in changed_files()
        if item.startswith(("src/", "test/", "tools/", "extension/"))
    ]
    if production_changes:
        checks["base_behavior_observed"]["passed"] = False
        checks["base_behavior_observed"]["detail"] = {
            "reason": "Stage 1 changed production or repository test files",
            "production_changes": production_changes,
        }
    return dict(DIAGNOSE_WEIGHTS)


def core(checks: dict[str, dict[str, object]]) -> dict[str, float]:
    record(checks, "incremental_build", incremental_build())
    record(
        checks,
        "basic_indexed_remap",
        run_sql_test("stage2_basic_remap.test"),
    )
    record(
        checks,
        "duplicate_key_remap",
        run_sql_test("stage2_duplicate_key_remap.test"),
    )
    record(
        checks,
        "fallback_paths",
        run_sql_test("stage2_fallback_paths.test"),
    )
    record(
        checks,
        "generated_remap_variants",
        run_generated_sql_tests(generated_remap_cases()),
    )
    handoff_ok, handoff_detail = diagnosis_handoff(OUTPUT / "handoff.json")
    checks["handoff_consumed"] = {
        "passed": handoff_ok,
        "detail": handoff_detail,
    }
    report_ok, report_detail = implementation_report(
        OUTPUT / "02-core/implementation.json"
    )
    checks["implementation_report"] = {
        "passed": report_ok,
        "detail": report_detail,
    }
    return dict(CORE_WEIGHTS)


def review(checks: dict[str, dict[str, object]]) -> dict[str, float]:
    record(checks, "incremental_build", incremental_build())
    record(
        checks,
        "legacy_rebuild",
        run_sql_test("stage3_legacy_rebuild.test", timeout=2400),
    )
    record(
        checks,
        "legacy_geometry_fallback",
        run_sql_test("stage3_legacy_geometry.test", timeout=2400),
    )
    record(
        checks,
        "checkpoint_persistence",
        run_sql_test("stage3_persistence.test"),
    )
    record(
        checks,
        "concurrent_scan_checkpoint",
        run_sql_test_repeated(
            "stage3_concurrent_scan_checkpoint.test",
            repeats=3,
            timeout=2400,
        ),
    )
    record(
        checks,
        "core_regression",
        run_sql_test("stage2_basic_remap.test"),
    )
    record(
        checks,
        "generated_concurrency_variants",
        run_generated_sql_tests(
            generated_concurrency_cases(),
            timeout=2400,
        ),
    )
    response_ok, response_detail = review_response(
        OUTPUT / "03-review/review_response.json"
    )
    checks["review_response"] = {
        "passed": response_ok,
        "detail": response_detail,
    }
    return dict(REVIEW_WEIGHTS)


def visible_regression_suite() -> tuple[bool, dict[str, object]]:
    files = [
        TESTBED / item
        for item in changed_files()
        if item.startswith("test/sql/storage/rowid_gaps/")
        and item.endswith(".test")
        and (TESTBED / item).is_file()
    ]
    coverage = {
        "at_least_four_executable_regressions": len(files) >= 4,
        "at_most_sixteen_tests": len(files) <= 16,
    }
    results: dict[str, dict[str, object]] = {}
    for path in files:
        relative = path.relative_to(TESTBED).as_posix()
        completed = require_discovered_test(
            run(
                visible_test_command(relative),
                timeout=1800,
            )
        )
        results[relative] = {
            "passed": completed.returncode == 0,
            "detail": (completed.stderr + completed.stdout)[-4000:],
        }
    failed_coverage = [name for name, passed in coverage.items() if not passed]
    failed_tests = [
        name for name, result in results.items() if not result["passed"]
    ]
    return not failed_coverage and not failed_tests, {
        "files": [str(path.relative_to(TESTBED)) for path in files],
        "coverage": coverage,
        "failed_requirements": failed_coverage,
        "failed_tests": failed_tests,
        "results": results,
    }


def visible_test_command(relative: str) -> list[str]:
    return [str(UNITTEST), "--run-id", "auto", relative]


def hardening_artifacts() -> tuple[bool, dict[str, object]]:
    contracts = {
        "fault_matrix.json": {
            "partial_chunk": ("partial_chunk",),
            "duplicate_keys": ("duplicate_keys",),
            "rowid_collision": ("rowid_collision",),
            "persistence": ("persistence",),
            "legacy_fallback": ("legacy_fallback",),
        },
        "concurrency.json": {
            "index_scan_lock": ("index_scan_lock",),
            "checkpoint_stress": ("checkpoint_stress",),
            "lock_order": ("lock_order",),
        },
        "final_report.json": {
            "invariant": ("invariant",),
            "changed_boundaries": ("changed_boundaries",),
            "verification": ("verification",),
            "remaining_risk": ("remaining_risk",),
        },
    }
    details: dict[str, object] = {}
    passed = True
    for filename, aliases in contracts.items():
        valid, detail = json_alias_contract(
            OUTPUT / f"04-hardening/{filename}",
            aliases,
        )
        details[filename] = detail
        passed = passed and valid

    rollback = OUTPUT / "04-hardening/rollback_check.sh"
    if rollback.is_file() and os.access(rollback, os.X_OK):
        text = rollback.read_text(encoding="utf-8", errors="replace")
        executable_lines = [
            line.strip()
            for line in text.splitlines()
            if line.strip()
            and not line.lstrip().startswith("#")
            and not line.startswith("#!")
        ]
        rollback_ok = bool(executable_lines)
        details["rollback_check.sh"] = {
            "passed": rollback_ok,
            "detail": {
                "executable": True,
                "non_comment_line_count": len(executable_lines),
                "note": (
                    "The verifier does not execute agent-authored scripts. "
                    "Build and patch checks run independently."
                ),
            },
        }
    else:
        rollback_ok = False
        details["rollback_check.sh"] = {
            "passed": False,
            "detail": "missing executable rollback_check.sh",
        }
    return passed and rollback_ok, details


def harden(checks: dict[str, dict[str, object]]) -> dict[str, float]:
    record(checks, "incremental_build", incremental_build())
    record(
        checks,
        "partial_chunk_and_collision",
        run_sql_test("stage4_partial_and_collision.test", timeout=2400),
    )
    record(
        checks,
        "multitask_persistence",
        run_sql_test("stage4_multitask_persistence.test", timeout=2400),
    )
    record(
        checks,
        "multi_index_null_unique",
        run_sql_test("stage4_multi_index_null_unique.test", timeout=2400),
    )
    record(
        checks,
        "persistence_regression",
        run_sql_test("stage3_persistence.test"),
    )
    record(
        checks,
        "concurrency_regression",
        run_sql_test_repeated(
            "stage3_concurrent_scan_checkpoint.test",
            repeats=3,
            timeout=2400,
        ),
    )
    record(
        checks,
        "legacy_regression",
        run_sql_tests(
            ["stage3_legacy_rebuild.test", "stage3_legacy_geometry.test"],
            timeout=2400,
        ),
    )
    visible_ok, visible_detail = visible_regression_suite()
    checks["visible_regression_suite"] = {
        "passed": visible_ok,
        "detail": visible_detail,
    }
    record(
        checks,
        "generated_final_variants",
        run_generated_sql_tests(
            [
                *generated_remap_cases(seed=23655),
                *generated_concurrency_cases(seed=23656),
            ],
            timeout=2400,
        ),
    )
    diff_check = run(["git", "diff", "--check"], timeout=120)
    changed = changed_files()
    generated = [
        item
        for item in changed
        if item.startswith(("build/", "duckdb_unittest_tempdir/"))
        or item.endswith((".o", ".a", ".so", ".dll", ".exe"))
    ]
    checks["patch_hygiene"] = {
        "passed": diff_check.returncode == 0 and not generated and len(changed) <= 80,
        "detail": {
            "git_diff_check": (diff_check.stderr + diff_check.stdout)[-4000:],
            "generated_files": generated,
            "changed_file_count": len(changed),
        },
    }
    artifacts_ok, artifacts_detail = hardening_artifacts()
    checks["hardening_artifacts"] = {
        "passed": artifacts_ok,
        "detail": artifacts_detail,
    }
    return dict(HARDEN_WEIGHTS)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--stage",
        required=True,
        choices=["diagnose", "core", "review", "harden"],
    )
    args = parser.parse_args()
    RESULT.mkdir(parents=True, exist_ok=True)
    checks: dict[str, dict[str, object]] = {}
    started = time.time()
    weights = {
        "diagnose": diagnose,
        "core": core,
        "review": review,
        "harden": harden,
    }[args.stage](checks)
    integrity_ok, integrity_detail = integrity()
    checks["integrity"] = {
        "passed": integrity_ok,
        "detail": integrity_detail,
    }

    d_num, d_den = deterministic_components(
        checks,
        weights,
        integrity_ok=integrity_ok,
    )
    configured_lambda = parse_lambda(
        os.environ.get("NONDETERMINISTIC_LAMBDA", "0.0")
    )
    training_score = calculate_training_score(
        d_num=d_num,
        d_den=d_den,
        nondeterministic_lambda=configured_lambda,
        integrity_ok=integrity_ok,
        rewardkit_available=False,
    )
    training_score = round(training_score, 6)
    critical_checks = CRITICAL_CHECKS[args.stage]
    required_checks_pass = all(
        bool(checks.get(name, {}).get("passed")) for name in weights
    )
    binary_reward = binary_outcome(
        required_checks_pass=required_checks_pass,
        integrity_ok=integrity_ok,
    )
    strict = binary_reward == 1.0
    critical_pass = (
        all(bool(checks.get(name, {}).get("passed")) for name in critical_checks)
        and integrity_ok
    )
    oracle = trusted_oracle()
    changed = integrity_detail["changed_files"]

    reward = {
        "reward": binary_reward,
        "binary_reward": binary_reward,
        "training_score": training_score,
        "valid_trial": 1.0 if integrity_ok else 0.0,
        "stage_complete": 1.0 if strict else 0.0,
        "critical_pass": 1.0 if critical_pass else 0.0,
        "promotion_ready": binary_reward,
    }
    if args.stage == "harden":
        reward.update(
            {
                "storage_correctness": 1.0
                if checks.get("partial_chunk_and_collision", {}).get("passed")
                else 0.0,
                "persistence": 1.0
                if checks.get("multitask_persistence", {}).get("passed")
                else 0.0,
                "concurrency": 1.0
                if checks.get("concurrency_regression", {}).get("passed")
                else 0.0,
                "regression_quality": 1.0
                if checks.get("visible_regression_suite", {}).get("passed")
                else 0.0,
            }
        )

    details = {
        "stage": args.stage,
        "duration_sec": round(time.time() - started, 3),
        "checks": checks,
        "weights": weights,
        "critical_checks": sorted(critical_checks),
        "critical_pass": critical_pass,
        "changed_files": changed,
        "scoring": {
            "D_num": round(d_num, 6),
            "D_den": round(d_den, 6),
            "N_num": 0.0,
            "N_den": 0.0,
            "lambda": configured_lambda,
            "effective_lambda": 0.0,
            "training_score": training_score,
            "calculation": (
                "integrity hard gate failed => training_score = 0.000000"
                if not integrity_ok
                else formula_text(
                    d_num=d_num,
                    d_den=d_den,
                    n_num=0.0,
                    n_den=0.0,
                    nondeterministic_lambda=configured_lambda,
                    result=training_score,
                )
            ),
            "integrity_passed": integrity_ok,
            "integrity_hard_gate": True,
            "oracle": oracle,
            "oracle_rewardkit_policy": (
                "N/A: trusted Oracle skips RewardKit"
                if oracle
                else "agent: RewardKit may update N_num/N_den"
            ),
            "rewardkit_available": False,
            "rewardkit_applied": False,
            "calculation_mode": (
                "integrity hard gate"
                if not integrity_ok
                else "deterministic-only fallback"
            ),
            "deterministic_weights": weights,
            "required_checks_passed": required_checks_pass,
        },
    }
    (RESULT / "reward.json").write_text(
        json.dumps(reward, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    (RESULT / "reward-details.json").write_text(
        json.dumps(details, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    (RESULT / "reward.txt").write_text(
        f"{reward['reward']:.4f}\n",
        encoding="utf-8",
    )
    events = [
        {
            "stage": args.stage,
            "check": name,
            "passed": bool(value.get("passed")),
            "weight": round(float(weights.get(name, 0.0)), 6),
            "deterministic": True,
            "critical": name in critical_checks,
        }
        for name, value in checks.items()
    ]
    (RESULT / "reward-events.json").write_text(
        json.dumps(events, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    (RESULT / "training_export_manifest.json").write_text(
        json.dumps(
            {
                "schema": "repo-engineering-training-v2",
                "task_family": "duckdb-index-vacuum-tier2",
                "stage": args.stage,
                "eligible_for_eval": integrity_ok,
                "eligible_for_training": False,
                "training_candidate": integrity_ok,
                "split_policy": (
                    "keep active evaluation instances out of training until "
                    "a protected repository/time/variant split decision"
                ),
                "artifacts": [
                    "patch.diff",
                    "changed_files.txt",
                    "reward-details.json",
                    "reward-events.json",
                    "test_output.log",
                    "agent_output",
                    "judge_inputs",
                ],
                "failure_labels": [
                    name
                    for name, value in checks.items()
                    if not value.get("passed")
                ],
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "stage": args.stage,
                "reward": reward,
                "failed_checks": {
                    name: value.get(
                        "failure_reasons",
                        value.get("detail", "failed"),
                    )
                    for name, value in checks.items()
                    if not value.get("passed")
                },
            },
            indent=2,
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
