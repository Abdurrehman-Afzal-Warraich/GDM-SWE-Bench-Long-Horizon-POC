"""Discoverable contract tests for the staged Harbor and RewardKit package."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tomllib

import pytest

import stage_check
from merge_rewardkit_scores import merge_scores
from score_formula import calculate_training_score, deterministic_components
from stage_judge_inputs import trajectory_activity
from stage_check import (
    CORE_WEIGHTS,
    CRITICAL_CHECKS,
    DIAGNOSE_WEIGHTS,
    HARDEN_WEIGHTS,
    REVIEW_WEIGHTS,
    architecture_handoff,
    command_integrity_violations,
    generated_concurrency_cases,
    generated_remap_cases,
    moved_row_expectation,
    require_discovered_test,
    reward_value_for_stage,
    run_generated_sql_tests,
    run_sql_test,
    uses_latest_storage,
    visible_test_command,
)


TESTS = Path(__file__).resolve().parent
TASK_ROOT = TESTS.parent


def test_task_declares_multistep_cpp_and_inline_anthropic_judges() -> None:
    config = tomllib.loads((TASK_ROOT / "task.toml").read_text(encoding="utf-8"))
    metadata = config["metadata"]
    environment = config["environment"]
    steps = config["steps"]

    assert config["multi_step_reward_strategy"] == "final"
    assert metadata["benchmark_type"] == "swe-bench"
    assert metadata["language"] == "cpp"
    assert metadata["base_commit"] == "3305afbcb08c39a056ad9c098754df57d07bcbe0"
    assert environment["allow_internet"] is True
    assert environment["env"]["RUN_LLM_JUDGES"] == "1"
    assert environment["env"]["JUDGE_MODEL"] == "anthropic/claude-sonnet-4-6"
    assert environment["env"]["CMAKE_BUILD_PARALLEL_LEVEL"] == "4"
    assert config["verifier"]["env"] == {
        "GEMINI_API_KEY": "${GEMINI_API_KEY:-}",
        "ANTHROPIC_API_KEY": "${ANTHROPIC_API_KEY:-}",
        "NONDETERMINISTIC_LAMBDA": "${NONDETERMINISTIC_LAMBDA:-0.0}",
    }
    assert metadata["judge_dimensions"] == [
        "process",
        "validity",
        "merge-readiness",
    ]
    assert [step["name"] for step in steps] == [
        "01-diagnose",
        "02-indexed-vacuum-core",
        "03-review-concurrency-compatibility",
        "04-adversarial-hardening",
    ]
    assert steps[0]["min_reward"] == pytest.approx(1.0)
    assert steps[1]["min_reward"] == pytest.approx(0.85)
    assert steps[2]["min_reward"] == pytest.approx(0.85)
    assert not (TASK_ROOT / "tests/Dockerfile").exists()


def test_stage_weights_are_normalized_and_functional_evidence_dominates() -> None:
    for weights in (
        DIAGNOSE_WEIGHTS,
        CORE_WEIGHTS,
        REVIEW_WEIGHTS,
        HARDEN_WEIGHTS,
    ):
        assert sum(weights.values()) == pytest.approx(1.0)

    assert DIAGNOSE_WEIGHTS["executable_reproduction"] == pytest.approx(0.65)
    assert (
        DIAGNOSE_WEIGHTS["architecture_handoff"]
        + DIAGNOSE_WEIGHTS["diagnosis_handoff"]
        == pytest.approx(0.10)
    )
    assert (
        CORE_WEIGHTS["basic_indexed_remap"]
        + CORE_WEIGHTS["duplicate_key_remap"]
        + CORE_WEIGHTS["fallback_paths"]
        == pytest.approx(0.60)
    )
    assert sum(
        weight
        for name, weight in CORE_WEIGHTS.items()
        if name not in {"handoff_consumed", "implementation_report"}
    ) == pytest.approx(0.95)
    assert sum(
        weight
        for name, weight in REVIEW_WEIGHTS.items()
        if name != "review_response"
    ) == pytest.approx(0.95)
    assert sum(
        weight
        for name, weight in HARDEN_WEIGHTS.items()
        if name != "hardening_artifacts"
    ) == pytest.approx(0.95)
    assert (
        HARDEN_WEIGHTS["partial_chunk_and_collision"]
        + HARDEN_WEIGHTS["multitask_persistence"]
        + HARDEN_WEIGHTS["multi_index_null_unique"]
        == pytest.approx(0.50)
    )
    assert CRITICAL_CHECKS["diagnose"] == frozenset(DIAGNOSE_WEIGHTS)
    assert CRITICAL_CHECKS["harden"] == frozenset(
        name for name in HARDEN_WEIGHTS if name != "hardening_artifacts"
    )
    assert "implementation_report" not in CRITICAL_CHECKS["core"]
    assert "review_response" not in CRITICAL_CHECKS["review"]


def test_every_stage_has_instruction_solution_and_test_entrypoint() -> None:
    for step in tomllib.loads(
        (TASK_ROOT / "task.toml").read_text(encoding="utf-8")
    )["steps"]:
        root = TASK_ROOT / "steps" / step["name"]
        assert (root / "instruction.md").is_file()
        assert (root / "solution/solve.sh").is_file()
        assert (root / "tests/test.sh").is_file()


def test_protected_sql_tests_cover_each_disclosed_behavior() -> None:
    expected = {
        "base_indexed_vacuum_probe.test",
        "stage2_basic_remap.test",
        "stage2_duplicate_key_remap.test",
        "stage2_fallback_paths.test",
        "stage3_persistence.test",
        "stage3_legacy_rebuild.test",
        "stage3_legacy_geometry.test",
        "stage3_concurrent_scan_checkpoint.test",
        "stage4_partial_and_collision.test",
        "stage4_multitask_persistence.test",
        "stage4_multi_index_null_unique.test",
    }
    assert expected <= {path.name for path in TESTS.glob("*.test")}
    aggregate = "\n".join(
        (TESTS / name).read_text(encoding="utf-8") for name in expected
    )
    for required in (
        "CREATE UNIQUE INDEX",
        "Type: Index Scan",
        "STORAGE_VERSION",
        "FORCE CHECKPOINT",
        "concurrentloop",
        "DETACH",
        "rowid",
    ):
        assert required in aggregate
    for name in expected:
        text = (TESTS / name).read_text(encoding="utf-8")
        assert f"# name: test/long_horizon/{name}" in text
        assert "# group: [long_horizon]" in text


@pytest.mark.parametrize("message", ["No tests ran", "No test cases matched 'x.test'"])
def test_zero_discovered_tests_are_deterministic_failures(message: str) -> None:
    completed = subprocess.CompletedProcess(
        args=["unittest"],
        returncode=0,
        stdout=message,
        stderr="",
    )
    guarded = require_discovered_test(completed)
    assert guarded.returncode != 0
    assert "did not discover" in guarded.stderr


def test_diagnosis_scores_observed_failure_not_optional_shell_style() -> None:
    scorer = (TESTS / "stage_check.py").read_text(encoding="utf-8")
    assert '"does_not_mask_failure"' not in scorer
    assert '"declares_test_group"' not in scorer
    assert '"pragma_storage_info" in test_text' not in scorer
    assert "moved_row_ok and real_mismatch and not invalid_failure" in scorer
    assert "invalid_failure_kind" in scorer
    assert "real_mismatch" in scorer


def test_moved_row_evidence_requires_an_executable_changed_rowid() -> None:
    valid = """query II
SELECT rowid, i FROM db.t WHERE i = 2048;
----
1024 2048
"""
    unchanged = """query II
SELECT rowid, i FROM db.t WHERE i = 2048;
----
2048 2048
"""
    comment_only = """# SELECT rowid, i FROM db.t WHERE i = 2048;
# ----
# 1024 2048
query I
SELECT i FROM db.t WHERE i = 2048;
----
2048
"""
    assert moved_row_expectation(valid)[0] is True
    assert moved_row_expectation(unchanged)[0] is False
    assert moved_row_expectation(comment_only)[0] is False


def test_latest_storage_check_is_case_and_whitespace_insensitive() -> None:
    assert uses_latest_storage("STORAGE_VERSION 'latest'")
    assert uses_latest_storage("storage_version   'LATEST'")
    assert not uses_latest_storage("STORAGE_VERSION 'v1.5.0'")


def test_visible_repo_tests_use_duckdb_relative_paths() -> None:
    command = visible_test_command(
        "test/sql/storage/rowid_gaps/example.test"
    )
    assert command[-1] == "test/sql/storage/rowid_gaps/example.test"
    assert "--test-dir" not in command
    assert command[1:3] == ["--run-id", "auto"]


def test_generated_variants_are_seeded_behavior_not_source_shape() -> None:
    core = generated_remap_cases()
    concurrent = generated_concurrency_cases()
    assert core == generated_remap_cases()
    assert concurrent == generated_concurrency_cases()
    assert core != generated_remap_cases(seed=999)
    assert concurrent != generated_concurrency_cases(seed=999)
    aggregate = "\n".join(source for _, source in [*core, *concurrent])
    for behavior in (
        "STORAGE_VERSION 'latest'",
        "CREATE UNIQUE INDEX",
        "FORCE CHECKPOINT",
        "rowid",
        "Type: Index Scan",
    ):
        assert behavior in aggregate
    assert "concurrentloop" in aggregate


def test_critical_verifier_does_not_require_golden_source_symbols() -> None:
    scorer = (TESTS / "stage_check.py").read_text(encoding="utf-8")
    for implementation_symbol in (
        "VacuumIndexRemapper",
        "GetVacuumIndexStrategy",
        "AllIndexesBoundOfType",
        "HasLegacyGeometryKeys",
        "SharedVacuumLock",
        "TableScanInitGlobal",
    ):
        assert implementation_symbol not in scorer


def test_reward_and_binary_reward_use_the_same_strict_outcome() -> None:
    assert reward_value_for_stage(
        "core",
        training_score=0.95,
        strict=False,
        integrity_ok=True,
        critical_pass=False,
    ) == pytest.approx(0.0)
    assert reward_value_for_stage(
        "review",
        training_score=0.90,
        strict=False,
        integrity_ok=True,
        critical_pass=True,
    ) == pytest.approx(0.0)
    assert reward_value_for_stage(
        "core",
        training_score=0.95,
        strict=True,
        integrity_ok=True,
        critical_pass=True,
    ) == pytest.approx(1.0)
    assert reward_value_for_stage(
        "core",
        training_score=1.0,
        strict=True,
        integrity_ok=False,
        critical_pass=True,
    ) == pytest.approx(0.0)


def test_verifier_does_not_execute_agent_authored_rollback_script() -> None:
    source = (TESTS / "stage_check.py").read_text(encoding="utf-8")
    assert "rollback_script_contract" not in source
    assert 'run([str(rollback)]' not in source
    assert '"git", "diff", "--check"' in source
    assert "incremental_build()" in source


def test_collision_fixture_is_not_the_public_pr_fixture() -> None:
    collision = (TESTS / "stage4_partial_and_collision.test").read_text(
        encoding="utf-8"
    )
    assert "FROM range(8192)" in collision
    assert "i % 5 <> 1" in collision
    assert "i IN (1, 8190)" in collision
    assert "FROM range(6144)" not in collision
    assert "i % 3 <> 2" not in collision


def test_golden_patches_are_scoped_and_not_truncated() -> None:
    expected = {
        "02-indexed-vacuum-core": (
            20_000,
            "src/storage/table/row_group_collection.cpp",
        ),
        "03-review-concurrency-compatibility": (
            2_000,
            "src/function/table/table_scan.cpp",
        ),
        "04-adversarial-hardening": (
            25_000,
            "test/sql/storage/rowid_gaps/",
        ),
    }
    for stage, (minimum_size, marker) in expected.items():
        patch = TASK_ROOT / "steps" / stage / "solution/golden.patch"
        text = patch.read_text(encoding="utf-8")
        assert patch.stat().st_size >= minimum_size
        assert marker in text
        assert text.endswith("\n")


def test_golden_patch_provenance_and_stage_boundaries() -> None:
    seen_paths: set[str] = set()
    for patch in sorted(TASK_ROOT.glob("steps/*/solution/golden.patch")):
        provenance = json.loads(
            patch.with_name("provenance.json").read_text(encoding="utf-8")
        )
        assert provenance["patch_sha256"] == hashlib.sha256(
            patch.read_bytes()
        ).hexdigest()
        touched = {
            line.split()[2][2:]
            for line in patch.read_text(encoding="utf-8").splitlines()
            if line.startswith("diff --git a/")
        }
        assert touched
        assert not (seen_paths & touched)
        seen_paths |= touched
    assert len(seen_paths) == 31


def test_stage_one_prompt_discloses_reproducer_and_typed_handoff() -> None:
    prompt = (
        TASK_ROOT / "steps/01-diagnose/instruction.md"
    ).read_text(encoding="utf-8")
    for text in (
        "build/reldebug/test/unittest",
        "reproducer.log",
        "wrapper must exit `0`",
        "SELECT rowid",
        "No particular\nstorage-metadata function or SQL spelling is required.",
        "latest_art_strategy",
        "buffers_old_and_new_rowids",
        "deletes_old_before_inserting_new",
        "index_scan_uses_shared_vacuum_lock",
    ):
        assert text in prompt


def test_stage_prompts_require_behavior_without_oracle_symbol_contracts() -> None:
    core = (
        TASK_ROOT / "steps/02-indexed-vacuum-core/instruction.md"
    ).read_text(encoding="utf-8")
    for behavior in (
        "duplicate-key",
        "old/new-row-ID collisions",
        "indexless and rebuild behavior",
        "not class,",
    ):
        assert behavior in core

    review = (
        TASK_ROOT
        / "steps/03-review-concurrency-compatibility/instruction.md"
    ).read_text(encoding="utf-8")
    for behavior in (
        "concurrent behavior",
        "persistence",
        "compatibility fallbacks",
        "does not require the Oracle patch's symbols",
    ):
        assert behavior in review


def test_architecture_handoff_uses_explicit_technical_fields(tmp_path: Path) -> None:
    path = tmp_path / "handoff.json"
    path.write_text(
        json.dumps(
            {
                "latest_art_strategy": "REMAP",
                "indexless_strategy": "NO_INDEXES",
                "small_legacy_rebuild_strategy": "REBUILD",
                "unsupported_or_legacy_strategy": "KEEP_ROW_IDS",
                "buffers_old_and_new_rowids": True,
                "deletes_old_before_inserting_new": True,
                "index_scan_uses_shared_vacuum_lock": True,
            }
        ),
        encoding="utf-8",
    )
    valid, detail = architecture_handoff(path)
    assert valid is True
    assert detail["failed_requirements"] == []

    payload = json.loads(path.read_text(encoding="utf-8"))
    payload["deletes_old_before_inserting_new"] = False
    path.write_text(json.dumps(payload), encoding="utf-8")
    invalid, invalid_detail = architecture_handoff(path)
    assert invalid is False
    assert "deletes_old_before_inserting_new" in invalid_detail["failed_requirements"]


def test_integrity_allows_local_work_but_blocks_leakage_and_network() -> None:
    assert command_integrity_violations(
        [
            "git log --oneline -n 5",
            "git show --stat HEAD",
            "build/reldebug/test/unittest test/sql/storage/example.test",
            "rg -n 'https://github.com' README.md",
        ]
    ) == []

    commands = (
        "cat /tests/stage_check.py",
        "cp /solution/golden.patch /tmp/fix",
        "git remote -v",
        "git reflog",
        "git fetch origin",
        "curl https://github.com/duckdb/duckdb/pull/23653.patch",
        "gh pr view 23653",
        "git ls-remote https://example.invalid/repo.git",
        "find /tmp/duckdb-lh-protected-abcd -type f",
        "cat /tmp/duckdb-lh-generated-1234/test/long_horizon/case.test",
        "cargo install helper",
        "apt-get install clang",
    )
    for command in commands:
        assert command_integrity_violations([command])


def test_protected_and_generated_test_directories_are_ephemeral(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    observed_roots: list[Path] = []

    def fake_copyfile(_source: Path, target: Path) -> None:
        target.write_text("# protected fixture\n", encoding="utf-8")

    def fake_run(
        command: list[str],
        timeout: int = 1800,
        cwd: Path = stage_check.TESTBED,
    ) -> subprocess.CompletedProcess[str]:
        del timeout, cwd
        root = Path(command[command.index("--test-dir") + 1])
        assert root.is_dir()
        assert any(root.rglob("*.test"))
        observed_roots.append(root)
        return subprocess.CompletedProcess(command, 0, "All tests passed\n", "")

    monkeypatch.setattr(stage_check.shutil, "copyfile", fake_copyfile)
    monkeypatch.setattr(stage_check, "run", fake_run)

    assert run_sql_test("protected.test").returncode == 0
    assert run_generated_sql_tests(
        [("generated.test", "# generated fixture\n")]
    ).returncode == 0
    assert len(observed_roots) == 2
    assert all(not root.exists() for root in observed_roots)


def test_judge_context_distinguishes_an_empty_agent_stage(tmp_path: Path) -> None:
    trajectory = tmp_path / "trajectory.json"
    trajectory.write_text(
        json.dumps(
            {
                "steps": [
                    {"source": "user", "message": "stage instruction"},
                ]
            }
        ),
        encoding="utf-8",
    )
    assert trajectory_activity(trajectory) == {
        "trajectory_available": True,
        "agent_steps": 0,
        "tool_calls": 0,
    }


def test_rewardkit_files_are_self_contained_and_use_declared_model() -> None:
    config = tomllib.loads((TASK_ROOT / "task.toml").read_text(encoding="utf-8"))
    model = config["metadata"]["judge_model"]
    for dimension in ("process", "validity", "task_quality", "merge_readiness"):
        judge = tomllib.loads(
            (TESTS / dimension / "judge.toml").read_text(encoding="utf-8")
        )
        assert judge["judge"]["judge"] == model
    packaged_text = "\n".join(
        path.read_text(encoding="utf-8", errors="replace")
        for path in TESTS.rglob("*")
        if path.is_file()
        and path.name != "test_reward_contract.py"
        and path.suffix in {".py", ".sh", ".toml", ".md"}
    )
    assert "from _common" not in packaged_text
    assert "import _common" not in packaged_text


def test_semantic_judges_cannot_change_deterministic_gates() -> None:
    stage_runner = (TESTS / "stage_test.sh").read_text(encoding="utf-8")
    judge_runner = (TESTS / "run_optional_judges.sh").read_text(
        encoding="utf-8"
    )
    merger = (TESTS / "merge_rewardkit_scores.py").read_text(encoding="utf-8")
    assert stage_runner.index("stage_check.py") < stage_runner.index(
        "run_optional_judges.sh"
    )
    assert 'run_optional_judges.sh "$RESULT_DIR" || true' in stage_runner
    assert '"binary_reward_affected": False' in judge_runner
    assert "dimensions=(process validity)" in judge_runner
    assert "dimensions+=(merge_readiness)" in judge_runner
    assert "task_quality" not in judge_runner
    assert "reward[\"reward\"] = binary" in merger
    assert "reward[\"binary_reward\"] = binary" in merger


def test_lambda_zero_uses_only_deterministic_score() -> None:
    assert calculate_training_score(
        d_num=0.7,
        d_den=1.0,
        n_num=1.0,
        n_den=1.0,
        nondeterministic_lambda=0.0,
    ) == pytest.approx(0.7)


def test_nonzero_lambda_uses_applicable_rewardkit_score() -> None:
    assert calculate_training_score(
        d_num=0.7,
        d_den=1.0,
        n_num=0.4,
        n_den=0.5,
        nondeterministic_lambda=0.5,
    ) == pytest.approx((0.7 + 0.5 * 0.4) / (1.0 + 0.5 * 0.5))


def test_integrity_failure_zeros_deterministic_and_training_scores() -> None:
    d_num, d_den = deterministic_components(
        {"functional": {"passed": True}},
        {"functional": 1.0},
        integrity_ok=False,
    )
    assert d_num == 0.0
    assert d_den == 1.0
    assert calculate_training_score(
        d_num=d_num,
        d_den=d_den,
        n_num=1.0,
        n_den=1.0,
        nondeterministic_lambda=1.0,
        integrity_ok=False,
    ) == 0.0


@pytest.mark.parametrize(
    ("d_num", "d_den", "n_num", "n_den", "weight"),
    [
        (0.0, 1.0, 0.0, 1.0, 0.0),
        (1.0, 1.0, 1.0, 1.0, 100.0),
        (5.0, 1.0, 5.0, 1.0, 1.0),
        (-5.0, 1.0, -5.0, 1.0, 1.0),
    ],
)
def test_training_score_is_always_bounded(
    d_num: float,
    d_den: float,
    n_num: float,
    n_den: float,
    weight: float,
) -> None:
    score = calculate_training_score(
        d_num=d_num,
        d_den=d_den,
        n_num=n_num,
        n_den=n_den,
        nondeterministic_lambda=weight,
    )
    assert 0.0 <= score <= 1.0


def test_oracle_skips_rewardkit_and_marks_it_not_applicable(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("TRUSTED_ORACLE", "1")
    assert stage_check.trusted_oracle() is True
    stage_runner = (TESTS / "stage_test.sh").read_text(encoding="utf-8")
    judge_runner = (TESTS / "run_optional_judges.sh").read_text(
        encoding="utf-8"
    )
    deterministic = (TESTS / "stage_check.py").read_text(encoding="utf-8")
    assert "trusted Oracle: RewardKit skipped" in stage_runner
    assert "non-deterministic reward is N/A" in stage_runner
    assert "trusted Oracle: RewardKit skipped" in judge_runner
    assert '"merge_ready_score"' not in deterministic
    assert '"merge_readiness_judge"' not in deterministic


def test_correct_oracle_writes_perfect_deterministic_reward(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    def passing_stage(
        checks: dict[str, dict[str, object]],
    ) -> dict[str, float]:
        checks["functional"] = {"passed": True, "detail": "passed"}
        return {"functional": 1.0}

    monkeypatch.setattr(stage_check, "RESULT", tmp_path)
    monkeypatch.setattr(stage_check, "diagnose", passing_stage)
    monkeypatch.setattr(
        stage_check,
        "CRITICAL_CHECKS",
        {**stage_check.CRITICAL_CHECKS, "diagnose": frozenset({"functional"})},
    )
    monkeypatch.setattr(
        stage_check,
        "integrity",
        lambda: (True, {"changed_files": [], "process": {"oracle": True}}),
    )
    monkeypatch.setattr(stage_check, "trusted_oracle", lambda: True)
    monkeypatch.setattr(sys, "argv", ["stage_check.py", "--stage", "diagnose"])

    assert stage_check.main() == 0
    reward = json.loads((tmp_path / "reward.json").read_text(encoding="utf-8"))
    details = json.loads(
        (tmp_path / "reward-details.json").read_text(encoding="utf-8")
    )
    assert reward["reward"] == reward["binary_reward"] == 1.0
    assert reward["training_score"] == 1.0
    assert "merge_ready_score" not in reward
    assert "merge_readiness_judge" not in reward
    assert details["scoring"]["D_num"] == 1.0
    assert details["scoring"]["D_den"] == 1.0
    assert details["scoring"]["N_num"] == 0.0
    assert details["scoring"]["N_den"] == 0.0
    assert details["scoring"]["oracle"] is True
    assert details["scoring"]["rewardkit_applied"] is False


def test_missing_agent_trajectory_is_not_compliant(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("TRUSTED_ORACLE", raising=False)
    monkeypatch.setattr(stage_check.Path, "is_file", lambda _self: False)
    passed, detail = stage_check.process_integrity()
    assert passed is False
    assert detail["violations"] == [{"rule": "missing agent trajectory"}]


def test_agent_rewardkit_formula_preserves_binary_reward(tmp_path: Path) -> None:
    (tmp_path / "reward.json").write_text(
        json.dumps(
            {
                "reward": 0.0,
                "binary_reward": 0.0,
                "training_score": 0.8,
                "valid_trial": 1.0,
            }
        ),
        encoding="utf-8",
    )
    (tmp_path / "reward-details.json").write_text(
        json.dumps(
            {
                "scoring": {
                    "D_num": 0.8,
                    "D_den": 1.0,
                    "integrity_passed": True,
                }
            }
        ),
        encoding="utf-8",
    )
    run = tmp_path / "judge_runs/repeat-1"
    run.mkdir(parents=True)
    (run / "reward.json").write_text(
        json.dumps({"process": 1.0, "validity": 0.5}),
        encoding="utf-8",
    )
    detail: dict[str, object] = {}
    for dimension, value in (("process", 1.0), ("validity", 0.5)):
        judge = tomllib.loads(
            (TESTS / dimension / "judge.toml").read_text(encoding="utf-8")
        )
        detail[dimension] = {
            "criteria": [
                {
                    "name": criterion["name"],
                    "value": value,
                    "weight": criterion["weight"],
                }
                for criterion in judge["criterion"]
            ]
        }
    (run / "reward-details.json").write_text(
        json.dumps(detail),
        encoding="utf-8",
    )

    summary = merge_scores(
        tmp_path,
        stage="core",
        selected_dimensions=("process", "validity"),
        judge_model="test-model",
        attempted_runs=1,
        successful_run_count=1,
        tests_dir=TESTS,
        nondeterministic_lambda=0.5,
    )
    reward = json.loads((tmp_path / "reward.json").read_text(encoding="utf-8"))
    scoring = json.loads(
        (tmp_path / "reward-details.json").read_text(encoding="utf-8")
    )["scoring"]
    assert reward["reward"] == reward["binary_reward"] == 0.0
    assert reward["training_score"] == pytest.approx(
        (0.8 + 0.5 * summary["N_num"])
        / (1.0 + 0.5 * summary["N_den"]),
        abs=1e-6,
    )
    assert scoring["D_num"] == pytest.approx(0.8)
    assert scoring["D_den"] == pytest.approx(1.0)
    assert scoring["N_num"] == pytest.approx(summary["N_num"])
    assert scoring["N_den"] == pytest.approx(summary["N_den"])
    assert scoring["lambda"] == pytest.approx(0.5)
