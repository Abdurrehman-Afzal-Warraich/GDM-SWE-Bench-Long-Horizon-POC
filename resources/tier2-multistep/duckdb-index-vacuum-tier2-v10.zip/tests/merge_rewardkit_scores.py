#!/usr/bin/env python3
"""Merge applicable RewardKit rubric scores into the continuous training score."""

from __future__ import annotations

import argparse
import json
import os
import tomllib
from pathlib import Path

from score_formula import calculate_training_score, formula_text, parse_lambda


AGENT_DIMENSIONS = ("process", "validity", "merge_readiness")


def load_json(path: Path) -> dict[str, object]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return payload if isinstance(payload, dict) else {}


def clamp(value: object) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return max(0.0, min(1.0, float(value)))


def rubric_definition(tests_dir: Path, dimension: str) -> tuple[float, dict[str, float]]:
    payload = tomllib.loads(
        (tests_dir / dimension / "judge.toml").read_text(encoding="utf-8")
    )
    dimension_weight = max(0.0, float(payload["judge"]["weight"]))
    criteria = {
        str(criterion["name"]): max(0.0, float(criterion["weight"]))
        for criterion in payload.get("criterion", [])
    }
    total = sum(criteria.values())
    if total:
        criteria = {
            name: dimension_weight * weight / total
            for name, weight in criteria.items()
        }
    return dimension_weight, criteria


def nondeterministic_components(
    runs_dir: Path,
    selected_dimensions: tuple[str, ...],
    tests_dir: Path,
) -> tuple[float, float, dict[str, object]]:
    selected = tuple(
        dimension
        for dimension in selected_dimensions
        if dimension in AGENT_DIMENSIONS
    )
    criterion_values: dict[tuple[str, str], list[float]] = {}
    dimension_values: dict[str, list[float]] = {
        dimension: [] for dimension in selected
    }
    successful_runs: list[str] = []

    for run in sorted(runs_dir.glob("repeat-*")):
        reward = load_json(run / "reward.json")
        if not reward:
            continue
        successful_runs.append(run.name)
        details = load_json(run / "reward-details.json")
        for dimension in selected:
            dimension_value = clamp(reward.get(dimension))
            if dimension_value is not None:
                dimension_values[dimension].append(dimension_value)
            dimension_detail = details.get(dimension, {})
            if not isinstance(dimension_detail, dict):
                continue
            criteria = dimension_detail.get("criteria", [])
            if not isinstance(criteria, list):
                continue
            for criterion in criteria:
                if not isinstance(criterion, dict):
                    continue
                name = criterion.get("name")
                raw = str(criterion.get("raw", "")).strip().casefold()
                if raw in {
                    "not_applicable",
                    "not applicable",
                    "n/a",
                    "na",
                }:
                    continue
                value = clamp(criterion.get("value"))
                if isinstance(name, str) and value is not None:
                    criterion_values.setdefault((dimension, name), []).append(value)

    n_num = 0.0
    n_den = 0.0
    rubric_rows: list[dict[str, object]] = []
    dimension_means: dict[str, float] = {}
    dimension_spreads: dict[str, float] = {}
    for dimension in selected:
        dimension_samples = dimension_values[dimension]
        if dimension_samples:
            dimension_means[dimension] = sum(dimension_samples) / len(
                dimension_samples
            )
            if len(dimension_samples) > 1:
                dimension_spreads[dimension] = max(
                    dimension_samples
                ) - min(dimension_samples)
        dimension_weight, criteria = rubric_definition(tests_dir, dimension)
        used_criteria = False
        for name, rubric_weight in criteria.items():
            criterion_samples = criterion_values.get((dimension, name), [])
            if not criterion_samples:
                continue
            value = sum(criterion_samples) / len(criterion_samples)
            n_num += value * rubric_weight
            n_den += rubric_weight
            used_criteria = True
            rubric_rows.append(
                {
                    "dimension": dimension,
                    "criterion": name,
                    "value": round(value, 6),
                    "weight": round(rubric_weight, 6),
                    "weighted_value": round(value * rubric_weight, 6),
                }
            )
        if not used_criteria and dimension_samples:
            value = sum(dimension_samples) / len(dimension_samples)
            n_num += value * dimension_weight
            n_den += dimension_weight
            rubric_rows.append(
                {
                    "dimension": dimension,
                    "criterion": "dimension_score_fallback",
                    "value": round(value, 6),
                    "weight": round(dimension_weight, 6),
                    "weighted_value": round(value * dimension_weight, 6),
                }
            )

    evidence = {
        "selected_dimensions": list(selected),
        "successful_runs": successful_runs,
        "dimension_means": {
            name: round(value, 6) for name, value in dimension_means.items()
        },
        "dimension_spreads": {
            name: round(value, 6) for name, value in dimension_spreads.items()
        },
        "rubrics": rubric_rows,
    }
    return n_num, n_den, evidence


def merge_scores(
    result_dir: Path,
    *,
    stage: str,
    selected_dimensions: tuple[str, ...],
    judge_model: str,
    attempted_runs: int,
    successful_run_count: int,
    tests_dir: Path,
    nondeterministic_lambda: object,
) -> dict[str, object]:
    reward_path = result_dir / "reward.json"
    details_path = result_dir / "reward-details.json"
    reward = load_json(reward_path)
    details = load_json(details_path)
    scoring = details.get("scoring", {})
    if not isinstance(scoring, dict):
        scoring = {}

    d_num = float(scoring.get("D_num", 0.0) or 0.0)
    d_den = float(scoring.get("D_den", 0.0) or 0.0)
    integrity_ok = bool(scoring.get("integrity_passed", False))
    n_num, n_den, evidence = nondeterministic_components(
        result_dir / "judge_runs",
        selected_dimensions,
        tests_dir,
    )
    weight = parse_lambda(nondeterministic_lambda)
    training_score = calculate_training_score(
        d_num=d_num,
        d_den=d_den,
        n_num=n_num,
        n_den=n_den,
        nondeterministic_lambda=weight,
        integrity_ok=integrity_ok,
        rewardkit_available=n_den > 0.0,
    )

    means = evidence["dimension_means"]
    spreads = evidence["dimension_spreads"]
    reward.update(
        {
            "training_score": round(training_score, 6),
            "judge_available": 1.0,
            "process_judge": float(means.get("process", 0.0)),
            "process_judge_applicable": (
                1.0 if "process" in selected_dimensions else 0.0
            ),
            "validity_review": float(means.get("validity", 0.0)),
            "validity_review_applicable": (
                1.0 if "validity" in selected_dimensions else 0.0
            ),
            "judge_disagreement": max(
                (float(value) for value in spreads.values()),
                default=0.0,
            ),
        }
    )
    if "merge_readiness" in selected_dimensions:
        reward["merge_readiness_judge"] = float(
            means.get("merge_readiness", 0.0)
        )
        reward["merge_readiness_judge_applicable"] = 1.0

    scoring.update(
        {
            "D_num": round(d_num, 6),
            "D_den": round(d_den, 6),
            "N_num": round(n_num, 6),
            "N_den": round(n_den, 6),
            "lambda": weight,
            "effective_lambda": weight if n_den > 0.0 else 0.0,
            "training_score": round(training_score, 6),
            "calculation": (
                formula_text(
                    d_num=d_num,
                    d_den=d_den,
                    n_num=n_num,
                    n_den=n_den,
                    nondeterministic_lambda=weight,
                    result=training_score,
                )
                if integrity_ok
                else "integrity hard gate failed => training_score = 0.000000"
            ),
            "integrity_hard_gate": True,
            "rewardkit_available": n_den > 0.0,
            "rewardkit_applied": (
                integrity_ok and n_den > 0.0 and weight > 0.0
            ),
            "calculation_mode": (
                "integrity hard gate"
                if not integrity_ok
                else (
                    "lambda formula"
                    if n_den > 0.0 and weight > 0.0
                    else "deterministic-only fallback"
                )
            ),
            "rewardkit_dimensions": list(selected_dimensions),
            "rewardkit_rubrics": evidence["rubrics"],
        }
    )
    details["scoring"] = scoring

    # These fields are deterministic truth and must remain identical and binary.
    binary = 1.0 if float(reward.get("binary_reward", 0.0) or 0.0) == 1.0 else 0.0
    reward["binary_reward"] = binary
    reward["reward"] = binary
    reward_path.write_text(
        json.dumps(reward, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    details_path.write_text(
        json.dumps(details, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    summary = {
        "available": True,
        "stage": stage,
        "judge_model": judge_model,
        "selected_dimensions": list(selected_dimensions),
        "attempted_runs": attempted_runs,
        "successful_run_count": successful_run_count,
        "successful_runs": evidence["successful_runs"],
        "dimension_means": means,
        "dimension_spreads": spreads,
        "D_num": round(d_num, 6),
        "D_den": round(d_den, 6),
        "N_num": round(n_num, 6),
        "N_den": round(n_den, 6),
        "lambda": weight,
        "training_score": round(training_score, 6),
        "binary_reward_affected": False,
    }
    for name in ("judge_summary.json", "judge_status.json"):
        (result_dir / name).write_text(
            json.dumps(summary, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
    manifest_path = result_dir / "training_export_manifest.json"
    manifest = load_json(manifest_path)
    manifest.update(
        {
            "judge_available": True,
            "judge_model": judge_model,
            "judge_selected_dimensions": list(selected_dimensions),
            "judge_dimension_means": means,
            "judge_artifacts": [
                "judge_summary.json",
                "judge_runs/",
                "judge_inputs/",
            ],
        }
    )
    manifest_path.write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return summary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("result_dir", type=Path)
    parser.add_argument("--stage", required=True)
    parser.add_argument("--dimensions", required=True)
    parser.add_argument("--judge-model", required=True)
    parser.add_argument("--attempted-runs", required=True, type=int)
    parser.add_argument("--successful-runs", required=True, type=int)
    args = parser.parse_args()
    selected = tuple(
        item for item in args.dimensions.split(",") if item in AGENT_DIMENSIONS
    )
    merge_scores(
        args.result_dir,
        stage=args.stage,
        selected_dimensions=selected,
        judge_model=args.judge_model,
        attempted_runs=args.attempted_runs,
        successful_run_count=args.successful_runs,
        tests_dir=Path(__file__).resolve().parent,
        nondeterministic_lambda=os.environ.get(
            "NONDETERMINISTIC_LAMBDA", "0.0"
        ),
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
