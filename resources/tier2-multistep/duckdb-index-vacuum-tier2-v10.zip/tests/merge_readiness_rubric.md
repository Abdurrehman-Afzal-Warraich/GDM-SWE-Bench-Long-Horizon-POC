# Merge-readiness rubric

Final review considers only a deterministic final pass.

- Storage/index correctness: every indexed row ID refers to the row in the
  row-group tree published with that index state.
- Compatibility: unsupported indexes, legacy storage, and legacy geometry
  preserve stable row IDs or use the configured rebuild path.
- Concurrency: index scans and checkpoint vacuum cannot observe a mixed
  ART/row-group generation; close-lock ordering does not require suppression.
- Engineering quality: vectorized buffering, index APIs, locking, comments,
  and SQLLogicTests follow DuckDB conventions.
- Scope and evidence: changes are justified and reports match executable logs.
