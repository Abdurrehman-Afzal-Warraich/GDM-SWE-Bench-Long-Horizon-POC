#!/usr/bin/env bash
set -uo pipefail

stage="${1:?stage name required}"
RESULT_DIR="${RESULT_DIR:-/logs/verifier}"
mkdir -p "$RESULT_DIR"

python3 /tests/stage_check.py --stage "$stage" > "$RESULT_DIR/test_output.log" 2>&1

if [ ! -f "$RESULT_DIR/reward.json" ]; then
  printf '%s\n' '{"reward":0.0,"binary_reward":0.0,"training_score":0.0,"valid_trial":0.0}' > "$RESULT_DIR/reward.json"
fi

git -C /testbed diff --binary > "$RESULT_DIR/patch.diff" 2>/dev/null || true
{
  git -C /testbed diff --name-only
  git -C /testbed ls-files --others --exclude-standard
} | sort -u > "$RESULT_DIR/changed_files.txt" 2>/dev/null || true
cp -a /app/output "$RESULT_DIR/agent_output" 2>/dev/null || true
if [ -f /logs/agent/oracle.txt ] || [ "${TRUSTED_ORACLE:-0}" = "1" ]; then
  python3 -S - "$RESULT_DIR/judge_status.json" "$stage" <<'PY'
import json, sys
from pathlib import Path
Path(sys.argv[1]).write_text(json.dumps({
    "available": False,
    "applicable": False,
    "stage": sys.argv[2],
    "reason": "trusted Oracle: RewardKit skipped; non-deterministic reward is N/A",
    "binary_reward_affected": False,
}, indent=2, sort_keys=True) + "\n", encoding="utf-8")
PY
else
  TASK_FAMILY="duckdb-index-vacuum-tier2" TASK_STAGE="$stage" \
    python3 /tests/stage_judge_inputs.py || true
  if [ "${RUN_LLM_JUDGES:-0}" = "1" ]; then
    TASK_STAGE="$stage" bash /tests/run_optional_judges.sh "$RESULT_DIR" || true
  fi
fi
exit 0
