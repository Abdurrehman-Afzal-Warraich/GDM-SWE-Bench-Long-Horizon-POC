#!/usr/bin/env bash
set -euo pipefail
cd /testbed

git apply --whitespace=nowarn /solution/golden.patch

mkdir -p /app/output/04-hardening
cat > /app/output/04-hardening/fault_matrix.json <<'JSON'
{
  "partial_chunk": "mixed shifted and unchanged rows retain correct row IDs",
  "duplicate_keys": "non-unique keys remap across task windows",
  "rowid_collision": "old entries are deleted before colliding new row IDs are inserted",
  "persistence": "remapped indexes remain correct after detach and reattach",
  "legacy_fallback": "legacy storage rebuilds when configured or preserves stable row IDs"
}
JSON

cat > /app/output/04-hardening/concurrency.json <<'JSON'
{
  "index_scan_lock": "shared vacuum lock protects the ART probe and matching row-group fetch",
  "checkpoint_stress": "concurrent index scans and forced checkpoints complete with correct results",
  "lock_order": "Close is called after close_lock leaves scope"
}
JSON

cat > /app/output/04-hardening/rollback_check.sh <<'SH'
#!/usr/bin/env bash
set -euo pipefail
cd /testbed
git diff --check
cmake --build build/reldebug --target unittest -j "${CMAKE_BUILD_PARALLEL_LEVEL:-8}"
SH
chmod +x /app/output/04-hardening/rollback_check.sh

cat > /app/output/04-hardening/final_report.json <<'JSON'
{
  "invariant": "Published ART row IDs and the row-group tree always describe the same physical rows",
  "changed_boundaries": ["vacuum strategy selection", "per-task remap buffering", "ART update order", "index scan locking", "legacy storage fallback", "attached database close locking"],
  "verification": ["protected adversarial SQLLogicTests", "incremental reldebug build", "visible rowid-gap regressions", "patch hygiene"],
  "remaining_risk": "New index types must opt into a future remap capability rather than being treated as ART-compatible"
}
JSON
