# Stage 4: adversarial hardening and merge readiness

Finish the repository-level change and add visible regression tests under
`test/sql/storage/rowid_gaps/`. Tests must cover at least four distinct cases,
including duplicate keys, old/new row-ID collision, a mixed shifted/unshifted
scan chunk, persistence after detach/reattach, multiple vacuum tasks, or legacy
fallback. Change no more than sixteen SQLLogicTest files in that directory;
every changed file is executed. Across the visible suite, include a unique
index, multiple indexes, a null-key case, a forced checkpoint, row-ID
assertions, an index-scan assertion, and persistence or legacy coverage.

Harden the implementation against:

- duplicate non-unique keys in different vacuum task windows;
- a new row ID colliding with an old row ID for the same key;
- chunks containing both shifted and unchanged rows;
- multiple ART indexes, null keys, and unique indexes;
- checkpoint persistence and reopen;
- concurrent index scans and forced checkpoints;
- legacy storage and legacy geometry fallbacks.

Create:

- `/app/output/04-hardening/fault_matrix.json` with `partial_chunk`,
  `duplicate_keys`, `rowid_collision`, `persistence`, and `legacy_fallback`;
- `/app/output/04-hardening/concurrency.json` with `index_scan_lock`,
  `checkpoint_stress`, and `lock_order`;
- `/app/output/04-hardening/rollback_check.sh`, executable, documenting a
  practical pre-merge rollback validation procedure;
- `/app/output/04-hardening/final_report.json` with `invariant`,
  `changed_boundaries`, `verification`, and `remaining_risk`.

Final success requires every deterministic behavior and integrity check. Judge
scores cannot rescue a deterministic failure.

Keep the complete patch to at most 80 changed files and do not add generated
build outputs. The verifier checks patch hygiene and compilation independently;
it does not execute the agent-authored rollback script.
