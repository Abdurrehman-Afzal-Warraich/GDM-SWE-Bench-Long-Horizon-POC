# Stage 1: diagnose indexed checkpoint vacuum

Do not change production source in this stage.

Inspect checkpoint vacuum, row-group merging, table indexes, storage-version
compatibility, index scans, and attached-database shutdown. The current
repository can compact an indexless table, but a normal ART index prevents the
default checkpoint vacuum from closing row-id gaps.

Create:

- `/app/output/01-diagnose/test/long_horizon/reproducer.test`: a SQLLogicTest that creates at
  least two persistent row groups under latest storage, creates an ART index,
  deletes enough rows that the groups could merge, forces a checkpoint, and
  expects physical compaction, demonstrated by a moved row found through an
  index scan.
  DuckDB discovers external SQLLogicTests only below a `test/` directory, so
  keep this exact path and declare
  `# name: test/long_horizon/reproducer.test`.
- `/app/output/01-diagnose/reproducer.sh`: an executable script that runs
  `build/reldebug/test/unittest --test-dir /app/output/01-diagnose` on
  `test/long_horizon/reproducer.test`, writes
  `/app/output/01-diagnose/reproducer.log`, fails if the target behavior already
  passes, and prints `expected-indexed-vacuum-remap-missing` only after a real
  result mismatch. Parser, binder, catalog, I/O, internal, and zero-test errors
  are not acceptable reproductions. After recognizing the expected result
  mismatch, the wrapper must exit `0`; every unexpected outcome must exit
  nonzero.
- `/app/output/handoff.json` with the general fields and typed decisions below.

```json
{
  "invariant": "what must remain true between row groups and index row IDs",
  "evidence": "what the executable reproducer proved",
  "affected_boundaries": ["checkpoint vacuum", "ART", "index scan"],
  "risks": ["legacy storage", "duplicate keys", "concurrency"],
  "next_stage_checks": ["specific executable checks"],
  "latest_art_strategy": "REMAP",
  "indexless_strategy": "NO_INDEXES",
  "small_legacy_rebuild_strategy": "REBUILD",
  "unsupported_or_legacy_strategy": "KEEP_ROW_IDS",
  "buffers_old_and_new_rowids": true,
  "deletes_old_before_inserting_new": true,
  "index_scan_uses_shared_vacuum_lock": true
}
```

The handoff is engineering state for later stages. Do not use the network,
repository remotes, hidden verifier files, or public patch history.

The SQLLogicTest must include a `SELECT rowid, <stable integer key>` lookup
through an indexed key. Choose the key so its value is its original row ID,
then assert a different expected row ID after compaction. This makes the
physical move executable evidence rather than a prose claim. No particular
storage-metadata function or SQL spelling is required.
