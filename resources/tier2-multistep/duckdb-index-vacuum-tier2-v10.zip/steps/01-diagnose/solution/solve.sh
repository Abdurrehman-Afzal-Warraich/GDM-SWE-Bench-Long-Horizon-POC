#!/usr/bin/env bash
set -euo pipefail

mkdir -p /app/output/01-diagnose

mkdir -p /app/output/01-diagnose/test/long_horizon
cat > /app/output/01-diagnose/test/long_horizon/reproducer.test <<'TEST'
# name: test/long_horizon/reproducer.test
# description: Reproduce missing indexed checkpoint-vacuum remapping.
# group: [long_horizon]

# The target behavior is absent at the base commit: a normal ART blocks the
# row-id-changing merge, so this test must fail before implementation.

statement ok
ATTACH '{TEST_DIR}/diagnose_indexed_vacuum.db' AS diag (STORAGE_VERSION 'latest', ROW_GROUP_SIZE 2048);

statement ok
SET max_vacuum_tasks = 99;

statement ok
CREATE TABLE diag.t(i INTEGER, g INTEGER);

statement ok
INSERT INTO diag.t SELECT i, i % 17 FROM range(2048) tbl(i);

statement ok
CHECKPOINT diag;

statement ok
INSERT INTO diag.t SELECT i, i % 17 FROM range(2048, 2560) tbl(i);

statement ok
CHECKPOINT diag;

statement ok
CREATE UNIQUE INDEX diag_i_idx ON diag.t(i);

statement ok
CREATE INDEX diag_g_idx ON diag.t(g);

statement ok
DELETE FROM diag.t WHERE i < 1024;

statement ok
FORCE CHECKPOINT diag;

query I
SELECT COUNT(DISTINCT row_group_id) FROM pragma_storage_info('diag.t');
----
1

query II
SELECT rowid, i FROM diag.t WHERE i = 2048;
----
1024	2048
TEST

cat > /app/output/01-diagnose/reproducer.sh <<'SH'
#!/usr/bin/env bash
set -euo pipefail
cd /testbed
log=/app/output/01-diagnose/reproducer.log
set +e
build/reldebug/test/unittest --run-id auto --test-dir /app/output/01-diagnose \
  test/long_horizon/reproducer.test >"$log" 2>&1
status=$?
set -e
if grep -Eqi 'No test cases matched|No tests ran' "$log"; then
  echo "DuckDB did not discover reproducer.test" >&2
  exit 2
fi
if [ "$status" -eq 0 ]; then
  echo "target indexed-vacuum behavior unexpectedly passed" >&2
  exit 1
fi
if grep -Eqi 'Parser Error|Binder Error|Catalog Error|Syntax Error|IO Error|INTERNAL Error' "$log"; then
  echo "SQLLogicTest failed before reaching the target result assertion" >&2
  exit 1
fi
if ! grep -Eqi 'failure|mismatch|wrong result|expected|errors' "$log"; then
  echo "SQLLogicTest failed without a recognizable assertion mismatch" >&2
  exit 1
fi
echo expected-indexed-vacuum-remap-missing
SH
chmod +x /app/output/01-diagnose/reproducer.sh
/app/output/01-diagnose/reproducer.sh

cat > /app/output/handoff.json <<'JSON'
{
  "invariant": "Every index row ID must refer to the row in the row-group tree published with that index state.",
  "evidence": "The executable target test fails because a normal ART prevents a row-id-changing default vacuum merge at the base commit.",
  "affected_boundaries": ["checkpoint vacuum", "row-group merge", "ART maintenance", "index scan", "storage compatibility"],
  "risks": ["legacy storage cannot persist row-ID gaps", "duplicate keys can collide during remap", "index scans can observe mismatched ART and row-group state"],
  "next_stage_checks": ["latest-storage ART remaps after compaction", "duplicate keys survive delete-before-insert", "legacy fallback preserves correct index results"],
  "latest_art_strategy": "REMAP",
  "indexless_strategy": "NO_INDEXES",
  "small_legacy_rebuild_strategy": "REBUILD",
  "unsupported_or_legacy_strategy": "KEEP_ROW_IDS",
  "buffers_old_and_new_rowids": true,
  "deletes_old_before_inserting_new": true,
  "index_scan_uses_shared_vacuum_lock": true
}
JSON
