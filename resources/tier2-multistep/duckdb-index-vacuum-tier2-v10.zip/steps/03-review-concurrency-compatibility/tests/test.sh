#!/usr/bin/env bash
set -euo pipefail
bash /tests/stage_test.sh review
