#!/usr/bin/env bash
set -euo pipefail
cd /testbed

git apply --whitespace=nowarn /solution/golden.patch

mkdir -p /app/output/03-review
cat > /app/output/03-review/review_response.json <<'JSON'
{
  "feedback": [
    "keep ART row IDs paired with the matching row-group tree during index scans",
    "preserve legacy storage and legacy geometry fallback behavior",
    "do not call AttachedDatabase::Close while close_lock is held"
  ],
  "changes": [
    "index scans bind indexes before taking a shared vacuum lock when indexed vacuum may move row IDs",
    "strategy selection rejects remapping for legacy geometry keys",
    "sole ownership is checked under close_lock and Close runs after the lock scope"
  ],
  "verification": [
    "incremental reldebug build: passed",
    "legacy fallback and persistence: delegated to protected verifier",
    "concurrent index scan and checkpoint stress: delegated to protected verifier"
  ],
  "compatibility_risk": "Future index implementations require an explicit remap capability before they may select REMAP"
}
JSON
