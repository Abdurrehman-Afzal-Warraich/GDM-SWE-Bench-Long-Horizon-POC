#!/usr/bin/env bash
set -euo pipefail
cd /testbed

git apply --whitespace=nowarn /solution/golden.patch

mkdir -p /app/output/02-core
cat > /app/output/02-core/implementation.json <<'JSON'
{
  "strategy_selection": "REMAP for latest compatible storage and supported bound ART indexes; REBUILD for the configured small-table legacy path; NO_INDEXES for indexless tables; otherwise KEEP_ROW_IDS",
  "remap_data": "Only indexed key columns plus old and new row IDs are buffered for shifted rows in each vacuum task",
  "collision_handling": "Old entries are deleted for an index before new row IDs are inserted with duplicate insertion mode",
  "tests_run": ["incremental reldebug build: passed", "basic indexed compaction: delegated to protected verifier", "duplicate non-unique key remap: delegated to protected verifier"],
  "deferred_review_work": ["shared vacuum lock around index scans", "attached-database close-lock scope", "concurrent checkpoint stress"]
}
JSON
