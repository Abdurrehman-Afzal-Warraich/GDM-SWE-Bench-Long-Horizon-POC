# Stage 2: implement indexed vacuum remapping

Use the persistent diagnosis and implement the sequential core behavior.

Introduce a clear `VacuumIndexStrategy` with these cases:

- `KEEP_ROW_IDS`: an index/storage combination cannot safely move row IDs.
- `NO_INDEXES`: no index maintenance is needed.
- `REBUILD`: the existing configured small-table rebuild path is selected.
- `REMAP`: latest compatible storage with supported bound ART indexes can
  incrementally update shifted row IDs.

Integrate this at the appropriate storage, index, and checkpoint boundaries in
the repository. The verifier checks the resulting behavior, not class,
function, or variable names, so an equivalent maintainable design is valid.

When a vacuum merge shifts rows, buffer only indexed key columns together with
their old and new row IDs. Apply each remap after the vacuum task. Remove stale
index entries before publishing replacement entries so duplicate-key leaves
and old/new-row-ID collisions remain valid. Do not rerun uniqueness validation
for rows that were already accepted. Keep indexless and rebuild behavior
working.

This stage is intentionally sequential. Broad concurrent index-scan locking and
attached-database lock-order feedback arrive in Stage 3.

Write `/app/output/02-core/implementation.json`:

```json
{
  "strategy_selection": "implemented strategy and fallback order",
  "remap_data": "what is buffered and why",
  "collision_handling": "delete-before-insert behavior",
  "tests_run": ["command: observed result"],
  "deferred_review_work": ["concurrency or compatibility work left for Stage 3"]
}
```

Do not use a compatibility shim that disables vacuum for all indexed tables.
Do not retrieve a public patch or alter verifier/reward files.

Compilation, basic remapping, duplicate-key remapping, indexless behavior,
configured rebuild behavior, and generated protected variants are critical
promotion checks. A documentation artifact cannot compensate for failure of
any of them.
