# Tier 2: DuckDB indexed-vacuum engineering task

## What this sample is

This is a four-stage, full-repository C++ task. Each stage gets a fresh agent
call, but the DuckDB worktree and explicit handoff files persist. The task asks
an agent to make checkpoint vacuum compact indexed tables without leaving ART
indexes pointing at stale row IDs.

It is based on [DuckDB PR #23653, "Default vacuuming in the presence of
indexes"](https://github.com/duckdb/duckdb/pull/23653), merged on July 23, 2026.
The source repository starts at the exact pre-change commit
`3305afbcb08c39a056ad9c098754df57d07bcbe0`.

The public change contained 37 commits, 31 files, 1,303 additions, and 135
deletions. It crossed checkpoint vacuum, row groups, ART indexes, storage
compatibility, index scans, attached-database locking, SQLLogicTests, and test
configuration. Review discussion included TSAN and lock-order concerns.

The solving agent is not shown the PR number, title, solution patches, or
upstream tests.

## Why it is genuinely long horizon

The change is not difficult merely because it is large. It requires one
invariant to survive several systems:

```text
ART row ID -> row in the row-group tree published with that ART state
```

Vacuum may move a row. Every supported index must then remove the old row ID
and install the new one. Unsupported or legacy cases must preserve row IDs or
use a safe rebuild path. At the same time, an index scan cannot observe the ART
from one generation and the row-group tree from another.

```mermaid
flowchart LR
    A["Stage 1: reproduce and diagnose"] -->|strict 1.00| B["Stage 2: sequential remap core"]
    B -->|required checks pass; binary reward 1| C["Stage 3: concurrency and compatibility review"]
    C -->|required checks pass; binary reward 1| D["Stage 4: adversarial hardening"]
    D --> E{"Every final deterministic check passes?"}
    E -- Yes --> F["Binary reward 1"]
    E -- No --> G["Binary reward 0 plus partial training vector"]
```

## Stage 1: diagnosis

The agent must not change production code. It creates an executable
SQLLogicTest that asks for the target indexed-vacuum behavior and proves that
the base commit does not have it.

| Deterministic check | Weight | What must pass |
|---|---:|---|
| `executable_reproduction` | 0.65 | A real DuckDB SQLLogicTest fails on the missing target behavior, includes an executable changed-row-ID expectation, and returns success only after recognizing the intended mismatch. |
| `base_behavior_observed` | 0.25 | A protected test proves the base keeps two row groups and the original indexed row ID. Production files remain unchanged. |
| `architecture_handoff` | 0.05 | Explicit strategy, buffering, collision-order, and lock decisions have the disclosed technical values. |
| `diagnosis_handoff` | 0.05 | Invariant, evidence, boundaries, risks, and next-stage checks are present. |

All four checks and integrity must pass. Stage 1 cannot advance on a prose-only
diagnosis.

## Stage 2: sequential remap core

The agent implements strategy selection and per-task index remapping. This
stage deliberately does not require concurrent index-scan locking yet.

| Deterministic check | Weight | What must pass |
|---|---:|---|
| `incremental_build` | 0.15 | DuckDB and its unit-test runner compile in the reldebug build. |
| `basic_indexed_remap` | 0.25 | Two row groups compact into one; the unique ART finds the moved row ID and the plan uses an index scan. |
| `duplicate_key_remap` | 0.20 | A non-unique key with shifted and unchanged rows remains correct after compaction. |
| `fallback_paths` | 0.15 | Indexless latest storage still compacts, and configured legacy index rebuild remains correct. |
| `generated_remap_variants` | 0.20 | Seeded, protected SQL cases vary deletion sizes, appended tails, duplicate keys, and lookup targets; row IDs, both indexes, compaction, and index scans must remain correct. |
| `handoff_consumed` | 0.025 | The persistent diagnosis remains valid. |
| `implementation_report` | 0.025 | The structured implementation report contains executable evidence and deferred review work. |

The stage reward is binary. Every required check and integrity must pass for
`reward = binary_reward = 1`; otherwise both are `0`. The verifier does not
require the golden patch's class, function, or variable names.

## Stage 3: concurrency and compatibility review

Fresh review feedback adds three requirements:

- keep ART row IDs paired with the matching row-group tree during index scans;
- preserve rebuild or stable-row-ID fallbacks for legacy storage and legacy
  geometry encoding;
- call `AttachedDatabase::Close` after `close_lock` leaves scope.

| Deterministic check | Weight | What must pass |
|---|---:|---|
| `incremental_build` | 0.10 | The reviewed source compiles. |
| `legacy_rebuild` | 0.10 | Configured legacy storage rebuilds its ART and finds the new row ID. |
| `legacy_geometry_fallback` | 0.10 | A legacy geometry ART keeps stable row IDs after storage upgrade. |
| `checkpoint_persistence` | 0.20 | Remapped row IDs and both indexes remain correct after detach and reattach. |
| `concurrent_scan_checkpoint` | 0.25 | Three isolated repetitions of concurrent index probes and forced checkpoints complete correctly. |
| `core_regression` | 0.15 | Stage 2 compaction still passes. |
| `generated_concurrency_variants` | 0.05 | Seeded concurrent index probes and forced checkpoints run with varied deletion sizes, tail sizes, targets, and loop counts, then verify remapped row IDs and index scans. |
| `review_response` | 0.05 | Feedback, changes, verification, and compatibility risk are recorded. |

Judge opinion cannot replace these checks. Every required check must pass for
the binary stage reward.

## Stage 4: adversarial hardening

The agent adds visible DuckDB regression tests and must pass new protected
variants that are not copied from the public PR.

| Deterministic check | Weight | What must pass |
|---|---:|---|
| `incremental_build` | 0.05 | Final C++ and test targets compile. |
| `partial_chunk_and_collision` | 0.20 | Mixed shifted/unchanged chunks and same-key old/new row-ID collisions are correct. |
| `multitask_persistence` | 0.15 | Duplicate keys remap in disjoint task windows and survive reopen. |
| `multi_index_null_unique` | 0.15 | Multiple indexes, null keys, and unique-key lookups remain correct after remapping. |
| `persistence_regression` | 0.05 | Stage 3 persistence remains correct. |
| `concurrency_regression` | 0.05 | Three more isolated concurrent index scan/checkpoint repetitions remain correct. |
| `legacy_regression` | 0.05 | Both configured legacy rebuild and legacy geometry fallback still pass. |
| `visible_regression_suite` | 0.10 | At least four and no more than sixteen changed rowid-gap tests exist, and every submitted test executes successfully. |
| `generated_final_variants` | 0.10 | Fresh seeded remap and concurrency variants recheck the final repository without depending on source names or golden-patch shape. |
| `patch_hygiene` | 0.05 | No whitespace errors, generated binaries, or excessive changed-file bloat. |
| `hardening_artifacts` | 0.05 | Fault, concurrency, rollback, and final-report evidence is complete. |

Final success requires every deterministic check plus integrity.

## Novel protected variants

The protected tests use different table sizes, deletion ranges, key values, and
row-ID expectations from the upstream PR:

- a 2,560-row basic compaction with two indexes;
- an unchanged and shifted row sharing one non-unique key;
- indexless compaction and configured legacy rebuild fallback;
- persistence after deleting 600 leading rows;
- a v1.4 geometry index reopened under latest storage;
- concurrent ART probes and forced checkpoints;
- a 2,148-row mixed partial chunk;
- an 8,192-row modulo-5 same-key collision case;
- a 16,384-row multi-task gap with duplicate keys.
- a 3,072-row three-index case with null and unique keys.

Public patch recall may help an agent understand the domain, but narrow fixture
matching cannot satisfy these variants.

## Deterministic and non-deterministic evaluation

Deterministic checks decide stage promotion and final binary success. They
compile source, execute SQLLogicTests, validate artifacts, and audit integrity.

RewardKit uses Anthropic Claude Sonnet 4.6 for separate reviews of:

- engineering process;
- trial validity and anti-cheating;
- final merge readiness.

Judges run twice when configured. Only agent process, validity/anti-cheating,
and final merge readiness are eligible for the continuous score. Author-side
task quality is excluded.

```text
D_num = sum(passed deterministic weight)
D_den = sum(deterministic weight)
training_score = (D_num + lambda * N_num) / (D_den + lambda * N_den)
```

`NONDETERMINISTIC_LAMBDA=0` gives the deterministic score only. If RewardKit is
unavailable, the deterministic score is also used. RewardKit never changes
`reward` or `binary_reward`, which remain identical and binary. Trusted Oracle
runs skip RewardKit; their non-deterministic reward and merge readiness are
`N/A`, and a correct Oracle has reward and training score `1`.

## Anti-contamination boundary

The Docker build downloads the exact base commit, archives its files into
`/testbed`, removes the original clone, and creates a new local Git repository
with one commit named `sanitized benchmark base`.

The verifier rejects:

- access to `/solution` or `/tests`;
- Git remotes, reflogs, fetch, pull, or clone;
- URLs, network downloaders, and runtime package installation;
- repository replacement, reward manipulation, or generated binaries.

Read-only `git log` and `git show` are allowed because the sanitized repository
contains only the benchmark base.

## Task package

```text
duckdb-index-vacuum-tier2/
|-- task.toml
|-- README.md
|-- environment/
|   `-- Dockerfile
|-- steps/
|   |-- 01-diagnose/
|   |-- 02-indexed-vacuum-core/
|   |-- 03-review-concurrency-compatibility/
|   `-- 04-adversarial-hardening/
|-- tests/
|   |-- stage_check.py
|   |-- stage_test.sh
|   |-- score_formula.py
|   |-- merge_rewardkit_scores.py
|   |-- *.test
|   |-- process/
|   |-- validity/
|   |-- task_quality/
|   `-- merge_readiness/
`-- tools/
    `-- run_inline_judged_terminus.sh
```

Author-only patches are split by stage and together cover all 31 upstream
changed files. They are not available to the solving agent.

## Run locally

Use Harbor 0.8 or newer. The first build is intentionally substantial because
it compiles DuckDB's reldebug `unittest` target, which also builds the touched
production dependencies used by every SQLLogicTest. Benchmark, TPC-H, TPC-DS, and
sanitizer targets are disabled to avoid unrelated build time and disk use.

```bash
harbor run \
  -p ./duckdb-index-vacuum-tier2 \
  -a nop \
  --jobs-dir /root/harbor-jobs \
  --job-name duckdb-index-vacuum-tier2-nop-v1

harbor run \
  -p ./duckdb-index-vacuum-tier2 \
  -a oracle \
  --jobs-dir /root/harbor-jobs \
  --job-name duckdb-index-vacuum-tier2-oracle-v1
```

For Terminus with a Gemini solving model and inline Anthropic judges:

```bash
export GEMINI_API_KEY='your-google-ai-studio-key'
export ANTHROPIC_API_KEY='your-anthropic-key'

bash ./duckdb-index-vacuum-tier2/tools/run_inline_judged_terminus.sh \
  duckdb-index-vacuum-tier2-terminus-v1
```

Results appear under:

```text
/root/harbor-jobs/<job-name>/
`-- duckdb-index-vacuum-tier2__<trial-id>/
    `-- steps/
        |-- 01-diagnose/
        |-- 02-indexed-vacuum-core/
        |-- 03-review-concurrency-compatibility/
        `-- 04-adversarial-hardening/
```

Each stage contains deterministic reward details, test output, patch and
changed-file evidence, agent artifacts, trajectory, and judge inputs/status.

## Source record

- [DuckDB repository](https://github.com/duckdb/duckdb)
- [Base pull request](https://github.com/duckdb/duckdb/pull/23653)
- Base commit: `3305afbcb08c39a056ad9c098754df57d07bcbe0`
- PR head: `fe22fc9f84bb1dde10e7dd105488ba9c30e627e6`
- Merge commit: `9fdc1696a610f0f76e4ad8c557514ccb6915ff2b`
- Merged: July 23, 2026
