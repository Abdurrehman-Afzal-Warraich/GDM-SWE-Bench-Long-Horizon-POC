#!/usr/bin/env bash
set -euo pipefail

die() {
  printf 'ERROR: %s\n' "$*" >&2
  exit 1
}

[ "$#" -eq 1 ] || die "usage: run_inline_judged_terminus.sh JOB_NAME"

JOB_NAME="$1"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TASK_PATH="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd)"
JOBS_DIR="${HARBOR_JOBS_DIR:-/root/harbor-jobs}"
AGENT_MODEL="${AGENT_MODEL:-gemini/gemini-3.6-flash}"
JUDGE_REPEATS="${JUDGE_REPEATS:-2}"
JUDGE_TIMEOUT_SEC="${JUDGE_TIMEOUT_SEC:-300}"

case "$AGENT_MODEL" in
  gemini/*)
    [ -n "${GEMINI_API_KEY:-}" ] || die "GEMINI_API_KEY is not exported for the solving model"
    ;;
esac
[ -n "${ANTHROPIC_API_KEY:-}" ] || die "ANTHROPIC_API_KEY is not exported for the semantic judge"
[ -f "$TASK_PATH/task.toml" ] || die "task not found: $TASK_PATH"
[ ! -e "$JOBS_DIR/$JOB_NAME" ] || die "job already exists; choose a fresh JOB_NAME"

if [ -n "${HARBOR_BIN:-}" ]; then
  [ -x "$HARBOR_BIN" ] || die "HARBOR_BIN is not executable: $HARBOR_BIN"
elif [ -x /root/.local/bin/harbor ]; then
  HARBOR_BIN=/root/.local/bin/harbor
else
  HARBOR_BIN="$(command -v harbor || true)"
  [ -n "$HARBOR_BIN" ] || die "harbor is not available"
fi
HARBOR_VERSION="$($HARBOR_BIN --version 2>/dev/null || true)"
HARBOR_MAJOR="${HARBOR_VERSION%%.*}"
HARBOR_REST="${HARBOR_VERSION#*.}"
HARBOR_MINOR="${HARBOR_REST%%.*}"
case "$HARBOR_MAJOR:$HARBOR_MINOR" in
  *[!0-9:]*|:|*:)
    die "could not parse Harbor version '${HARBOR_VERSION:-unknown}'"
    ;;
esac
if [ "$HARBOR_MAJOR" -eq 0 ] && [ "$HARBOR_MINOR" -lt 8 ]; then
  die "Harbor 0.8 or newer is required for staged tasks and verifier environment variables; found '$HARBOR_VERSION'"
fi

case "$JUDGE_REPEATS" in
  1|2|3) ;;
  *) die "JUDGE_REPEATS must be 1, 2, or 3" ;;
esac
case "$JUDGE_TIMEOUT_SEC" in
  ''|*[!0-9]*) die "JUDGE_TIMEOUT_SEC must be an integer" ;;
esac

# Avoid LiteLLM's os.getcwd() failure when WSL retains a stale mounted cwd.
cd /

exec "$HARBOR_BIN" run \
  -p "$TASK_PATH" \
  -a terminus-2 \
  -m "$AGENT_MODEL" \
  --jobs-dir "$JOBS_DIR" \
  --job-name "$JOB_NAME" \
  --yes \
  --ve RUN_LLM_JUDGES=1 \
  --ve "ANTHROPIC_API_KEY=${ANTHROPIC_API_KEY}" \
  --ve "JUDGE_REPEATS=${JUDGE_REPEATS}" \
  --ve "JUDGE_TIMEOUT_SEC=${JUDGE_TIMEOUT_SEC}"
