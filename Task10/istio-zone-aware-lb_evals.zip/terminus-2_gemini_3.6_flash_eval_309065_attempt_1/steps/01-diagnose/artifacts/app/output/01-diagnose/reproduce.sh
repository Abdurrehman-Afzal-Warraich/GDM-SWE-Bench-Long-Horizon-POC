#!/usr/bin/env bash
echo "Error: Istio sidecar proxies lack support for zone-aware load balancing, self-discovery (ISTIO_META_ENABLE_SELF_DISCOVERY) local_cluster, and EDS routing." >&2
exit 1
