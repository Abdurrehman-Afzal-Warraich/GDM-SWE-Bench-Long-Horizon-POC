#!/usr/bin/env bash
set -uo pipefail
cd /testbed

echo "== zone-aware load balancer symbols =="
if grep -q 'ZoneAwareLBSettings' pilot/pkg/networking/core/loadbalancer/loadbalancer.go 2>/dev/null; then
  echo "unexpected: ZoneAwareLBSettings already present"
else
  echo "GAP: zone-aware LB settings type missing from loadbalancer package"
fi
if grep -q 'ApplyZoneAwareLoadBalancer' pilot/pkg/networking/core/loadbalancer/loadbalancer.go 2>/dev/null; then
  echo "unexpected: ApplyZoneAwareLoadBalancer already present"
else
  echo "GAP: ApplyZoneAwareLoadBalancer helper missing"
fi

echo "== self discovery bootstrap wiring =="
if grep -q 'ISTIO_META_ENABLE_SELF_DISCOVERY' pilot/cmd/pilot-agent/options/options.go 2>/dev/null; then
  echo "unexpected: ISTIO_META_ENABLE_SELF_DISCOVERY already registered"
else
  echo "GAP: self discovery metadata constant not registered in pilot-agent options"
fi
if grep -q 'enable_self_discovery' tools/packaging/common/envoy_bootstrap.json 2>/dev/null; then
  echo "unexpected: enable_self_discovery already in bootstrap template"
else
  echo "GAP: envoy bootstrap lacks self-discovery local_cluster gate"
fi

echo "== EDS local_cluster routing =="
if grep -q 'SelfDiscoveryCluster' pilot/pkg/xds/eds.go 2>/dev/null; then
  echo "unexpected: SelfDiscoveryCluster already handled in EDS"
else
  echo "GAP: EDS generator does not route local_cluster for zone-aware spillover"
fi
if grep -q 'local_cluster' pilot/pkg/xds/eds.go 2>/dev/null && grep -q 'ZoneAware' pilot/pkg/xds/endpoints/endpoint_builder.go 2>/dev/null; then
  echo "unexpected: zone-aware endpoint builder hooks already present"
else
  echo "GAP: endpoint discovery (EDS) lacks zone-aware local_cluster endpoint filtering"
fi

echo "== validation =="
if grep -q 'ValidateZoneAwareLbSetting' pkg/config/validation/agent/validation.go 2>/dev/null; then
  echo "unexpected: ValidateZoneAwareLbSetting already present"
else
  echo "GAP: ValidateZoneAwareLbSetting missing from agent validation"
fi

exit 1
