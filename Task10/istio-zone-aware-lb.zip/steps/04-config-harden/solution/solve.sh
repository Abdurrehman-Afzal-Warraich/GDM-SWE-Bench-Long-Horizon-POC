#!/usr/bin/env bash
# Oracle, stage 04 — validation hardening and cumulative closure.
set -euo pipefail

OUT=/app/output
STAGE=04-config-harden
STAGE_OUT="$OUT/$STAGE"
mkdir -p "$STAGE_OUT"
cd /testbed

git apply --whitespace=nowarn /solution/golden.patch
git add -A
git -c user.email=a@b.c -c user.name=oracle commit -q -m 'stage04: config harden and closure'

echo "== build =="
go build ./pilot/pkg/xds/... ./pilot/pkg/networking/core/loadbalancer/... ./pkg/config/validation/...

python3 - <<'PY'
import json
from pathlib import Path

stage_out = Path("/app/output/04-config-harden")
out = Path("/app/output")

(stage_out / "final_report.json").write_text(json.dumps({
    "feature_summary": (
        "Istio sidecar proxies support zone-aware load balancing via zoneAwareLbSetting "
        "with ISTIO_META_ENABLE_SELF_DISCOVERY injecting the self-discovery local_cluster."
    ),
    "validation_scope": (
        "ValidateZoneAwareLbSetting rejects topology labels in failover_priority and "
        "requires outlier detection; DestinationRule enforces mutual exclusion between "
        "localityLbSetting and zoneAwareLbSetting; proxy_dependencies honors EnableSelfDiscovery."
    ),
    "verification_performed": [
        "go build ./pilot/pkg/xds/...",
        "go build ./pilot/pkg/networking/core/loadbalancer/...",
        "go build ./pkg/config/validation/...",
        "cumulative hidden verifier probes",
        "implementation closure proof",
    ],
    "residual_risks": [
        "Ambient mode remains unsupported; integration tests under tests/integration/pilot are out of graded scope.",
    ],
    "packages_touched": [
        "pilot/pkg/xds",
        "pilot/pkg/networking/core/loadbalancer",
        "pkg/config/validation",
        "releasenotes/notes",
    ],
}, indent=2) + "\n", encoding="utf-8")

(stage_out / "implementation_closure_proof.json").write_text(json.dumps({
    "base_commit": "d17a4626923d3cb48ae7dafd2ef579ae1da8c5d8",
    "feature_complete": True,
    "packages_touched": [
        "pilot/pkg/networking/core/loadbalancer",
        "pilot/pkg/xds",
        "pkg/bootstrap",
        "pkg/config/validation",
        "pilot/pkg/model",
    ],
    "verification_performed": [
        "go build ./pilot/pkg/xds/...",
        "go build ./pilot/pkg/networking/core/loadbalancer/...",
        "go build ./pkg/config/validation/...",
        "hidden verifier probes",
    ],
}, indent=2) + "\n", encoding="utf-8")

(out / "handoff.json").write_text(json.dumps({
    "stage": "04-config-harden",
    "summary": "Zone-aware load balancing complete with validation, release note, and behavioral closure.",
    "next_steps": ["Task complete."],
    "merge_ready": True,
}, indent=2) + "\n", encoding="utf-8")
PY

echo "stage 04 complete"
