# Config harden and closure

Harden mesh/DestinationRule validation and incremental-push dependencies for **zone-aware load balancing** in `/testbed`. Sidecar mode only — **ambient is out of scope**.

Implement (at minimum):

- `ValidateZoneAwareLbSetting` in `/testbed/pkg/config/validation/agent/validation.go` (reject topology labels in `failover_priority`; require outlier detection for failover)
- Wire validation into `/testbed/pkg/config/validation/validation.go` (mutual exclusion: only one of `localityLbSetting` and `zoneAwareLbSetting`)
- Honor `EnableSelfDiscovery` local-service pushes in `/testbed/pilot/pkg/xds/proxy_dependencies.go`
- Add `/testbed/releasenotes/notes/zone-aware-load-balancing.yaml` documenting `zoneAwareLbSetting` and `ISTIO_META_ENABLE_SELF_DISCOVERY`

Commit your changes in `/testbed`.

Write:

- `/app/output/04-config-harden/final_report.json` — JSON object with required keys:
  - `feature_summary` (non-empty string)
  - `validation_scope` (non-empty string)
  - `verification_performed` (array, ≥1 string)
  - `residual_risks` (array, ≥1 string)
  - `packages_touched` (array, ≥1 string)
- `/app/output/04-config-harden/implementation_closure_proof.json` — JSON object with required keys:
  - `base_commit` = `d17a4626923d3cb48ae7dafd2ef579ae1da8c5d8`
  - `feature_complete` = `true`
  - `packages_touched` (array, ≥2 strings)
  - `verification_performed` (array, ≥1 string)
- `/app/output/handoff.json` — must include `merge_ready: true` and `next_steps` containing `"Task complete."`

**Verifier:** runs cumulative `go build` on `./pilot/pkg/xds/...`, `./pilot/pkg/networking/core/loadbalancer/...`, `./pkg/config/validation/...`, and `./verifierprobe/...`; runs `go vet -tests=false` on `./pilot/pkg/networking/core/loadbalancer/...`, `./pkg/config/validation`, and `./pilot/pkg/xds/...`; runs hidden probes (compile + vet + disclosed wiring checks) for `ValidateZoneAwareLbSetting`, proxy dependency filtering, and the release note; checks critical paths under `/testbed`. `release_note_present` and `implementation_closure_proof.json` are weighted but **non-critical** (binary pass does not require them). Critical symbols: `ValidateZoneAwareLbSetting`, `ZoneAwareLBSettings`, `ApplyZoneAwareLoadBalancer`, `SelfDiscoveryCluster`, `ISTIO_META_ENABLE_SELF_DISCOVERY`.
