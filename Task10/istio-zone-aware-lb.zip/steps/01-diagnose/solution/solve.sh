#!/usr/bin/env bash
# Oracle, stage 01 — diagnosis only (no production edits).
set -euo pipefail

OUT=/app/output
STAGE=01-diagnose
STAGE_OUT="$OUT/$STAGE"
mkdir -p "$STAGE_OUT"
cd /testbed

cat > "$STAGE_OUT/reproduce.sh" <<'REPRO'
#!/usr/bin/env bash
set -uo pipefail
cd /testbed

echo "== zone-aware load balancer symbols =="
if grep -q 'ZoneAwareLBSettings' pilot/pkg/networking/core/loadbalancer/loadbalancer.go 2>/dev/null; then
  echo "unexpected: ZoneAwareLBSettings already present"
else
  echo "GAP: zone-aware LB settings type missing from loadbalancer package"
fi
if grep -q 'ApplyZoneAwareLoadBalancer' pilot/pkg/networking/core/loadbalancer/loadbalancer.go 2>/dev/null; then
  echo "unexpected: ApplyZoneAwareLoadBalancer already present"
else
  echo "GAP: ApplyZoneAwareLoadBalancer helper missing"
fi

echo "== self discovery bootstrap wiring =="
if grep -q 'ISTIO_META_ENABLE_SELF_DISCOVERY' pilot/cmd/pilot-agent/options/options.go 2>/dev/null; then
  echo "unexpected: ISTIO_META_ENABLE_SELF_DISCOVERY already registered"
else
  echo "GAP: self discovery metadata constant not registered in pilot-agent options"
fi
if grep -q 'enable_self_discovery' tools/packaging/common/envoy_bootstrap.json 2>/dev/null; then
  echo "unexpected: enable_self_discovery already in bootstrap template"
else
  echo "GAP: envoy bootstrap lacks self-discovery local_cluster gate"
fi

echo "== EDS local_cluster routing =="
if grep -q 'SelfDiscoveryCluster' pilot/pkg/xds/eds.go 2>/dev/null; then
  echo "unexpected: SelfDiscoveryCluster already handled in EDS"
else
  echo "GAP: EDS generator does not route local_cluster for zone-aware spillover"
fi
if grep -q 'local_cluster' pilot/pkg/xds/eds.go 2>/dev/null && grep -q 'ZoneAware' pilot/pkg/xds/endpoints/endpoint_builder.go 2>/dev/null; then
  echo "unexpected: zone-aware endpoint builder hooks already present"
else
  echo "GAP: endpoint discovery (EDS) lacks zone-aware local_cluster endpoint filtering"
fi

echo "== validation =="
if grep -q 'ValidateZoneAwareLbSetting' pkg/config/validation/agent/validation.go 2>/dev/null; then
  echo "unexpected: ValidateZoneAwareLbSetting already present"
else
  echo "GAP: ValidateZoneAwareLbSetting missing from agent validation"
fi

exit 1
REPRO
chmod +x "$STAGE_OUT/reproduce.sh"
bash "$STAGE_OUT/reproduce.sh" >/tmp/repro.out 2>&1 || true

python3 - <<'PY'
import json
from pathlib import Path

out = Path("/app/output")
stage_out = out / "01-diagnose"
(stage_out / "diagnosis.json").write_text(json.dumps({
    "missing_capabilities": [
        "ISTIO_META_ENABLE_SELF_DISCOVERY bootstrap metadata and local_cluster template gate",
        "Proxy LocalService tracking for self-discovery incremental pushes",
        "ZoneAwareLBSettings and ApplyZoneAwareLoadBalancer in pilot loadbalancer",
        "EDS SelfDiscoveryCluster generation and zone-aware endpoint filtering",
        "ValidateZoneAwareLbSetting for mesh and DestinationRule policies",
    ],
    "affected_packages": [
        "pilot/cmd/pilot-agent/options",
        "pkg/bootstrap",
        "pkg/model",
        "pilot/pkg/model",
        "pilot/pkg/networking/core/loadbalancer",
        "pilot/pkg/xds",
        "pilot/pkg/xds/endpoints",
        "pkg/config/validation",
    ],
    "reproducer": "/app/output/01-diagnose/reproduce.sh",
    "root_cause": (
        "The base commit lacks self-discovery bootstrap wiring, zone-aware LB settings, "
        "EDS local_cluster routing, and validation for zoneAwareLbSetting — sidecars cannot "
        "enable Envoy zone-aware load balancing with automatic same-zone preference."
    ),
}, indent=2) + "\n", encoding="utf-8")

(out / "handoff.json").write_text(json.dumps({
    "stage": "01-diagnose",
    "summary": (
        "Base lacks ISTIO_META_ENABLE_SELF_DISCOVERY bootstrap wiring, ZoneAwareLBSettings, "
        "SelfDiscoveryCluster EDS handling, and ValidateZoneAwareLbSetting."
    ),
    "next_steps": [
        "Add self-discovery metadata, bootstrap template gate, and LocalService proxy context.",
        "Implement ZoneAwareLBSettings, ApplyZoneAwareLoadBalancer, and EDS local_cluster routing.",
        "Harden validation, proxy push dependencies, and release note; prove implementation closure.",
    ],
}, indent=2) + "\n", encoding="utf-8")
PY

echo "stage 01 complete"
