# Diagnose

At `/testbed`, determine why Istio sidecar proxies cannot use **zone-aware load balancing** with a self-discovery **local_cluster** and matching **EDS** routing. **Do not modify** `/testbed` (test files under `/testbed` are allowed).

**Scope:** sidecar mode only — **ambient is out of scope**.

The base commit lacks symbols the feature needs, including `ISTIO_META_ENABLE_SELF_DISCOVERY`, `ZoneAwareLBSettings`, `ApplyZoneAwareLoadBalancer`, `SelfDiscoveryCluster`, and `ValidateZoneAwareLbSetting`. Inspect at least:

- `/testbed/pilot/pkg/networking/core/loadbalancer/loadbalancer.go`
- `/testbed/pilot/pkg/xds/eds.go` and `/testbed/pilot/pkg/xds/endpoints/endpoint_builder.go`
- `/testbed/pkg/bootstrap/config.go` and `/testbed/tools/packaging/common/envoy_bootstrap.json`
- `/testbed/pkg/config/validation/agent/validation.go`

Write:

- `/app/output/01-diagnose/reproduce.sh` — executable; must **exit non-zero**; stdout/stderr must mention **zone aware** (or `zone-aware` / `zoneAware`), **self discovery** (or `self-discovery` / `ISTIO_META_ENABLE_SELF_DISCOVERY`), and **EDS** (or `endpoint discovery`)
- `/app/output/01-diagnose/diagnosis.json` — JSON object with required keys:
  - `missing_capabilities` (array, ≥1 string)
  - `affected_packages` (array, ≥1 string)
  - `reproducer` (non-empty string, path to the reproducer script)
  - `root_cause` (non-empty string)
- `/app/output/handoff.json` — JSON object with required keys:
  - `stage` (non-empty string)
  - `summary` (non-empty string)
  - `next_steps` (array, ≥1 string)

**Verifier:** confirms the base still lacks zone-aware/self-discovery/EDS wiring (`base_gap_observed`), runs your reproducer, validates artifact JSON schemas (extra keys allowed), and checks handoff shape. No `go build` on `/testbed` in this stage.
