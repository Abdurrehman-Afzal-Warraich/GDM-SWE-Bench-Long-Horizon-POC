#!/usr/bin/env bash
# Oracle, stage 02 — self-discovery bootstrap wiring.
set -euo pipefail

OUT=/app/output
STAGE=02-self-discovery-bootstrap
STAGE_OUT="$OUT/$STAGE"
mkdir -p "$STAGE_OUT"
cd /testbed

git apply --whitespace=nowarn /solution/golden.patch
git add -A
git -c user.email=a@b.c -c user.name=oracle commit -q -m 'stage02: self-discovery bootstrap'

echo "== build =="
go build ./pilot/cmd/pilot-agent/options/... ./pkg/bootstrap/... ./pkg/model/...
echo "== vet =="
go vet -tests=false ./pilot/cmd/pilot-agent/options/... ./pkg/bootstrap/... ./pkg/model/...

python3 - <<'PY'
import json
import subprocess
from pathlib import Path

changed = subprocess.check_output(
    ["git", "show", "--pretty=format:", "--name-only", "HEAD"], text=True
).splitlines()
packages = sorted({str(Path(p).parent) for p in changed if p.strip()})
stage_out = Path("/app/output/02-self-discovery-bootstrap")
out = Path("/app/output")

(stage_out / "bootstrap.json").write_text(json.dumps({
    "self_discovery_metadata": (
        "Registered ISTIO_META_ENABLE_SELF_DISCOVERY in pilot-agent options and "
        "NodeMetadata.EnableSelfDiscovery for proxy bootstrap."
    ),
    "bootstrap_template": (
        "pkg/bootstrap/config.go wires Metadata.EnableSelfDiscovery into template params; "
        "tools/packaging/common/envoy_bootstrap.json gates local_cluster on enable_self_discovery."
    ),
    "proxy_context": (
        "pilot/pkg/model/context.go tracks LocalServiceInfo/LocalService/PrevLocalService "
        "in SetServiceTargets for incremental self-discovery pushes."
    ),
    "packages_touched": packages[:20],
}, indent=2) + "\n", encoding="utf-8")

(out / "handoff.json").write_text(json.dumps({
    "stage": "02-self-discovery-bootstrap",
    "summary": (
        f"Self-discovery bootstrap landed across {len(changed)} files; "
        "ISTIO_META_ENABLE_SELF_DISCOVERY and local_cluster template gate compile."
    ),
    "next_steps": [
        "Implement ZoneAwareLBSettings, ApplyZoneAwareLoadBalancer, and EDS local_cluster routing.",
        "Add ValidateZoneAwareLbSetting, proxy dependency filtering, and release note.",
    ],
}, indent=2) + "\n", encoding="utf-8")
PY

echo "stage 02 complete"
