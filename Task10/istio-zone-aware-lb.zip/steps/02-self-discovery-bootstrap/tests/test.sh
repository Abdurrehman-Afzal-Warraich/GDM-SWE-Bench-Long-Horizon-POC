#!/usr/bin/env bash
exec bash /tests/stage_test.sh bootstrap
