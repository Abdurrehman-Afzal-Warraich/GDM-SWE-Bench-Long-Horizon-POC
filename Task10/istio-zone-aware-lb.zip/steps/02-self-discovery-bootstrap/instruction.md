# Self-discovery bootstrap

Wire **self-discovery** for sidecar proxies in `/testbed` so pilot-agent can inject a `local_cluster` static cluster when `ISTIO_META_ENABLE_SELF_DISCOVERY=true`. **Ambient is out of scope.**

Implement (at minimum):

- Register `ISTIO_META_ENABLE_SELF_DISCOVERY` / `EnableSelfDiscovery` in `/testbed/pilot/cmd/pilot-agent/options/options.go` using `env.Register("ISTIO_META_ENABLE_SELF_DISCOVERY", ...)` and document the zone-aware routing purpose in nearby comments or help text
- Expose `EnableSelfDiscovery` on proxy metadata (`/testbed/pkg/model/proxy.go`) and document `ISTIO_META_ENABLE_SELF_DISCOVERY` as the source
- Thread `EnableSelfDiscovery` through `/testbed/pkg/bootstrap/config.go` and define the bootstrap template key `enable_self_discovery` in `/testbed/pkg/bootstrap/option/instances.go`
- Gate `local_cluster` in `/testbed/tools/packaging/common/envoy_bootstrap.json` with `{{ if .enable_self_discovery }}` and, when enabled, configure:
  - a `local_cluster` static cluster
  - `cluster_manager.local_cluster_name`
  - `zone_aware_lb_config` including `min_cluster_size`
- Track `LocalServiceInfo` / `LocalService` / `PrevLocalService` in `/testbed/pilot/pkg/model/context.go` inside `SetServiceTargets`, populating `node.LocalService = LocalServiceInfo{...}` from the first service target

Commit your changes in `/testbed`.

Write:

- `/app/output/02-self-discovery-bootstrap/bootstrap.json` — JSON object with required keys:
  - `self_discovery_metadata` (non-empty string)
  - `bootstrap_template` (non-empty string)
  - `proxy_context` (non-empty string)
  - `packages_touched` (array, ≥1 string)
- `/app/output/handoff.json` — updated for this stage (`stage`, `summary`, `next_steps`)

**Verifier:** runs `go build` on `./pilot/cmd/pilot-agent/options/...`, `./pkg/bootstrap/...`, `./pkg/model/...`, and `./verifierprobe/...`; runs `go vet -tests=false` on those same packages; injects **hidden behavioral probes** (compile + vet + disclosed wiring checks) for the symbols and template keys above. Critical symbols include `ISTIO_META_ENABLE_SELF_DISCOVERY`, `EnableSelfDiscovery`, `enable_self_discovery`, `local_cluster`, `zone_aware_lb_config`, `min_cluster_size`, and `LocalServiceInfo`.
