# EDS and zone-aware load balancer

Build on the stage-02 self-discovery wiring. Implement **zone-aware load balancing** and **EDS local_cluster** generation for sidecar proxies in `/testbed`. **Ambient is out of scope.**

Implement (at minimum):

- `ZoneAwareLBSettings`, `GetEffectiveLbSetting`, and `ApplyZoneAwareLoadBalancer` in `/testbed/pilot/pkg/networking/core/loadbalancer/loadbalancer.go`
- Resolve effective LB settings in `/testbed/pilot/pkg/networking/core/cluster_traffic_policy.go`
- `SelfDiscoveryCluster` constant and EDS handling for `local_cluster` in `/testbed/pilot/pkg/xds/eds.go` and `/testbed/pilot/pkg/networking/util/util.go`
- Self-discovery endpoint filtering and zone-aware load assignment in `/testbed/pilot/pkg/xds/endpoints/endpoint_builder.go`

Commit your changes in `/testbed`.

Write:

- `/app/output/03-eds-loadbalancer/eds_report.json` — JSON object with required keys:
  - `lb_settings_interface` (non-empty string)
  - `eds_local_cluster` (non-empty string)
  - `traffic_policy` (non-empty string)
  - `packages_touched` (array, ≥1 string)
  - `verification_performed` (array, ≥1 string)
- `/app/output/handoff.json` — updated for this stage

**Verifier:** runs `go build` on `./pilot/pkg/networking/core/loadbalancer/...`, `./pilot/pkg/networking/core/...`, `./pilot/pkg/xds/...`, and `./verifierprobe/...`; runs `go vet -tests=false` on `./pilot/pkg/networking/core` and `./pilot/pkg/networking/core/loadbalancer/...`; injects **hidden behavioral probes** (compile + vet + disclosed wiring checks) for `ZoneAwareLBSettings`, `ApplyZoneAwareLoadBalancer`, `SelfDiscoveryCluster`, and EDS endpoint-builder hooks. Prior-stage self-discovery symbols must remain present.
