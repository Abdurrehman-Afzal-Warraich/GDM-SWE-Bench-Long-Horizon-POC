#!/usr/bin/env bash
# Oracle, stage 03 — EDS local_cluster and zone-aware load balancer.
set -euo pipefail

OUT=/app/output
STAGE=03-eds-loadbalancer
STAGE_OUT="$OUT/$STAGE"
mkdir -p "$STAGE_OUT"
cd /testbed

git apply --whitespace=nowarn /solution/golden.patch
git add -A
git -c user.email=a@b.c -c user.name=oracle commit -q -m 'stage03: eds and zone-aware loadbalancer'

echo "== build =="
go build ./pilot/pkg/networking/core ./pilot/pkg/networking/core/loadbalancer/... ./pilot/pkg/xds/...

python3 - <<'PY'
import json
import subprocess
from pathlib import Path

changed = subprocess.check_output(
    ["git", "show", "--pretty=format:", "--name-only", "HEAD"], text=True
).splitlines()
packages = sorted({str(Path(p).parent) for p in changed if p.strip()})
stage_out = Path("/app/output/03-eds-loadbalancer")
out = Path("/app/output")

(stage_out / "eds_report.json").write_text(json.dumps({
    "lb_settings_interface": (
        "ZoneAwareLBSettings implements LBSettings with ApplyToCluster and "
        "ApplyToLoadAssignment; GetEffectiveLbSetting resolves mesh/DR precedence."
    ),
    "eds_local_cluster": (
        "SelfDiscoveryCluster routes EDS for local_cluster; endpoint_builder filters "
        "endpoints to the local workload and applies zone-aware load assignment."
    ),
    "traffic_policy": (
        "cluster_traffic_policy.go passes enableSelfDiscovery into applyLoadBalancer "
        "and delegates to GetEffectiveLbSetting/ApplyZoneAwareLoadBalancer."
    ),
    "packages_touched": packages[:20],
    "verification_performed": [
        "go build ./pilot/pkg/networking/core/loadbalancer/...",
        "go build ./pilot/pkg/networking/core/...",
        "go build ./pilot/pkg/xds/...",
    ],
}, indent=2) + "\n", encoding="utf-8")

(out / "handoff.json").write_text(json.dumps({
    "stage": "03-eds-loadbalancer",
    "summary": (
        "Zone-aware LB settings and EDS local_cluster generation compile; "
        "ApplyZoneAwareLoadBalancer and SelfDiscoveryCluster wired."
    ),
    "next_steps": [
        "Add ValidateZoneAwareLbSetting, proxy dependency pushes, and release note.",
        "Run cumulative verification and implementation closure proof.",
    ],
}, indent=2) + "\n", encoding="utf-8")
PY

echo "stage 03 complete"
