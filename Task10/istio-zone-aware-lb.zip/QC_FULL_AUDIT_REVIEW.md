# QC Full Audit — Task10 `istio-zone-aware-lb`

**Package:** `Task10/istio-zone-aware-lb/`  
**Upstream:** [istio/istio#60765](https://github.com/istio/istio/pull/60765)  
**Calibration:** `v2-istio-zone-aware-lb`  
**Audit date:** 2026-08-21  
**Auditor basis:** `Generic-QC-Rubric.xlsx` / `LH-Task-Review.xlsx` / `LH-Eval.xlsx` (via `docs/QC_CHECKLISTS_REFERENCE.md`), team-lead critical checklist, package source, `VALIDATION_EVIDENCE.md`, `calibration_summary.json`, local Harbor jobs under `Task10/harbor-jobs/`.  
**Eval bundle:** `Task10/istio-zone-aware-lb_evals.zip` was referenced but **not present on disk** in this workspace; platform eval IDs **eval_181197** (Oracle), **eval_182277** (no-op), **eval_182278** (Gemini 3.6 Flash) are cited from author evidence.

---

## Executive summary

| Area | Disposition |
|------|-------------|
| Verifier / reward architecture (critical-only binary, details split) | **Strong — mostly PASS** |
| Behavioral instructions | **PASS with WATCH** (S02 hidden substring detail) |
| Prompt ↔ verifier alignment | **PARTIAL — FIX** (undisclosed hidden assertions) |
| Test coverage (100% + edge/negative) | **PARTIAL — FIX/WATCH** (symbol-heavy; limited negative runtime) |
| Anticheat | **PARTIAL — WATCH** (no ctime anchor; checksum-only toolchain) |
| Reward / RewardKit / OpenAPI model | **FAIL** (Gemini not gpt-5.6-terra; judge TOML cross-contamination) |
| Grading integrity | **FAIL/WATCH** (`valid_trial` in `reward.json`; CTRF envelope; broken calibration JSON) |
| Harness / packaging | **PARTIAL** (pack gate 45/45; judge bleed; `calibration_summary.json` invalid) |
| Network policy | **FAIL** (`allow_internet = true`; no per-step network blocks) |
| Separate verifier environment | **WATCH — refuttal required** (same-container Harbor pattern) |
| README hygiene | **PASS** (no eval numbers in README) |
| Expert time | **PASS** (36h) |
| Agent failure validity (Gemini eval_182278) | **PASS** (legitimate S02 hidden wiring miss) |
| Rework completed? | **NO — in progress** (v2 local green; platform refresh + fixes below pending) |

**Recommendation:** Do **not** mark rework complete or re-upload until **P0 blockers** below are fixed and Oracle ×2 is recorded on the repacked archive.

---

## P0 blockers (fix before upload)

| # | Finding | Evidence | Required fix |
|---|---------|----------|--------------|
| 1 | **Judge TOML describes Cilium Gateway API**, not Istio zone-aware LB | `tests/process/judge.toml` (`gateway_api_reasoning`, TCPRoute/Helm); `tests/merge_readiness/judge.toml` (Cilium operator); `tests/task_quality/judge.toml` (`Cilium Gateway API L4`) | Rewrite all four `judge.toml` criterion text for Istio pilot/xDS/EDS scope |
| 2 | **Qualitative judge model is Gemini**, not team-required **OpenAPI gpt-5.6-terra** | All `judge.toml`: `judge = "gemini/gemini-3.5-flash"`; `task.toml` `judge_model` | Switch judge provider/model to OpenAI **gpt-5.6-terra** per current team directive; verify RewardKit discovery |
| 3 | **`allow_internet = true`** in `task.toml` | `[environment] allow_internet = true` | Set `allow_internet = false`; add **per-step** agent network-off settings per Harbor schema; keep judge network isolated to verifier-only path if platform supports it |
| 4 | **`valid_trial` published in `reward.json`** | `tests/score_formula.py` `REWARD_JSON_CORE_KEYS`; `stage_check.write_reward()`; `stage_test.sh` fallbacks | Move `valid_trial` to `reward-details.json` only (Task7/DataOS averaging lesson); slim core keys to 4–5 scores |
| 5 | **`calibration_summary.json` is invalid JSON** | Lines 74–77: stray strings outside object | Repair JSON structure |

---

## P1 should-fix

| # | Finding | Fix |
|---|---------|-----|
| 6 | S02 hidden tests assert **undisclosed** literals (`zone_aware_lb_config`, `min_cluster_size`, `local_cluster_name`, exact `env.Register("ISTIO_META_ENABLE_SELF_DISCOVERY"`, doc strings containing `zone-aware`, exact `node.LocalService = LocalServiceInfo{`) | Disclose in `steps/02-self-discovery-bootstrap/instruction.md` **or** relax probes to match disclosed contract |
| 7 | Platform **Oracle ×1 only** (eval_181197); checklist expects ×2+ | Re-run Oracle twice on repacked zip; update evidence |
| 8 | **Frontier calibration incomplete** (1× Gemini 0% full solve) | Run 2–3 more Gemini trials on v2+ archive for 5–20% headroom band |
| 9 | **CTRF missing full envelope** (`reportFormat`, `specVersion`) | Add CTRF v0 fields if DataOS parser requires them (Gitea v7 lesson) |
| 10 | **No ctime/container-start anti-cheat** | Add optional `ctime_anchor_enforced` like Gitea v6+ or document defense if checksum-only deemed sufficient |

---

## Team-lead critical checklist

| Critical item | Verdict | Detail |
|---------------|---------|--------|
| Instructions behavioral, no verifier gap | **WATCH/FIX** | Stages 01/03/04 well disclosed; **S02 gap** on bootstrap JSON template literals and exact registration patterns (see hidden `self_discovery_contract_test.go`) |
| Test coverage 100% + edge/negative | **PARTIAL** | 20 cumulative hidden tests + near-miss self-tests; **no** live EDS/LB runtime; mostly compile/vet/symbol probes; upstream integration test explicitly out of scope |
| Anticheat incorporated | **WATCH** | Trajectory network/git leak scan, ephemeral hidden injection, GOPROXY off, toolchain checksum manifest — **no** ctime anchor; root `go` swap + manifest rewrite not fully defeated |
| Reward formula (deterministic + RewardKit) | **PASS architecture / FAIL config** | Lambda=0 default; judges cannot rescue binary; **wrong judge model**; contaminated judge criteria |
| Prompt–verifier misalignment | **FIX** | See P1 #6 |
| Grading integrity | **FAIL/WATCH** | `valid_trial` in averaged `reward.json`; CTRF envelope; invalid calibration file |
| Harness & packaging | **WATCH** | 45/45 pack pytest; merge-head proof; **judge cross-task bleed** |
| README without eval evidence | **PASS** | README is operator doc only; evidence in `VALIDATION_EVIDENCE.md` |
| OpenAPI gpt-5.6-terra for RewardKit | **FAIL** | Uses Gemini 3.5 Flash |
| No verifier–oracle coupling | **WATCH** | Hidden tests align to golden symbols (`test_oracle_hidden_alignment.py`); behavioral-core scope stated; some probes are golden-shape specific |
| `allow_internet` must not be true | **FAIL** | Currently true with prose justification only |
| Separate verifier environment | **WATCH (refuttal)** | Standard Harbor: agent step then `exec bash /tests/stage_test.sh` in **same** container. Reference `aetherius-pg-pool-hermetic-contracts-v2` not vendored here. **In-progress task:** document why same-container + protected `/tests` mount is used, or migrate to hermetic split if platform requires |
| Expert time ≥ 24h | **PASS** | 36.0h in `task.toml` |
| Agent failure reason valid | **PASS** | eval_182278: S01 pass, S02 fail `hidden_tests_pass` 3/6 wiring probes with `build_clean`/`vet_clean` pass — genuine partial implementation, not grader bug |

---

## Tab 1 — Generic QC Rubric (100 checks)

Legend: **P** pass · **F** fail · **W** watch/partial · **N/A** not applicable · **D** defend with evidence

### FS — File structure (4)

| ID | Sev | Disposition | Notes |
|----|-----|-------------|-------|
| FS-01 | P0 | **P** | Full tree: task.toml, 4 steps, tests/, environment/, tools/, contracts, hidden/, evidence doc |
| FS-02 | P0 | **P** | Agent: instruction + /testbed; verifier: /tests; oracle: steps/*/solution; author: merge manifest, VALIDATION_EVIDENCE |
| FS-03 | P0 | **P** | Harbor 1.3 multi-step layout; no root solution/ |
| FS-04 | P2 | **P** | VALIDATION_EVIDENCE labeled author-side |

### PQ — Prompt quality (7)

| ID | Sev | Disposition | Notes |
|----|-----|-------------|-------|
| PQ-01 | P0 | **P** | Zone-aware LB sidecar feature objective clear |
| PQ-02 | P1 | **P** | Paths, artifacts, build targets disclosed per stage |
| PQ-03 | P1 | **P** | Critical vs non-critical stated stage 04 |
| PQ-04 | P0 | **P** | Offline Go build feasible; deps at image build |
| PQ-05 | P1 | **W** | Istio compile weight heavy but disclosed |
| PQ-06 | P0 | **W** | S02 hidden exceptions not fully stated |
| PQ-07 | P0 | **W** | Hidden substring literals not all in prompt |

### PV — Prompt–verifier alignment (7)

| ID | Sev | Disposition | Notes |
|----|-----|-------------|-------|
| PV-01 | P0 | **F** | S02 hidden probes exceed disclosed contract |
| PV-02 | P0 | **W** | Verifier blocks list checks; hidden detail gap remains |
| PV-03 | P1 | **P** | Patch capture rules in stage_test.sh |
| PV-04 | P1 | **P** | go build/vet/reproducer channels match |
| PV-05 | P1 | **P** | Non-critical reports separated |
| PV-06 | P0 | **F** | judge.toml conflicts with Istio task identity |
| PV-07 | P0 | **W** | Most gates disclosed; S02 template literals missing |

### VC — Verifier correctness (9)

| ID | Sev | Disposition | Notes |
|----|-----|-------------|-------|
| VC-01 | P0 | **P** | Oracle path green locally + eval_181197 |
| VC-02 | P0 | **P** | Scores from grader observations |
| VC-03 | P1 | **P** | Fallback reward on crash |
| VC-04 | P1 | **P** | Deterministic grader; lambda=0 default |
| VC-05 | P1 | **P** | Hidden tests ephemeral inject/restore |
| VC-06 | P2 | **P** | CTRF fallback on crash |
| VC-07 | P0 | **W** | Oracle ×1 platform only; need ×2 |
| VC-08 | P0 | **P** | No-op all zeros eval_182277 + local |
| VC-09 | P1 | **P** | stage_test always exit 0 with explicit zeros |

### TC — Test coverage (12)

| ID | Sev | Disposition | Notes |
|----|-----|-------------|-------|
| TC-01 | P1 | **W** | Happy path via build+hidden pass |
| TC-02 | P1 | **W** | Edge via symbol probes; not runtime mesh |
| TC-03 | P1 | **W** | Near-miss self-tests; limited invalid-path variety |
| TC-04 | P2 | **P** | Checks map to subsystems |
| TC-05 | P1 | **W** | Behavioral-core narrows upstream; alt impl partial |
| TC-06 | P1 | **W** | Integration test excluded (documented) |
| TC-07 | P1 | **W** | Exact string patterns in hidden tests |
| TC-08 | P0 | **W** | Compile/vet state verified; not post-push xDS |
| TC-09 | P1 | **P** | Artifact JSON schemas with extra keys allowed |
| TC-10 | P1 | **N/A** | Agent tests not graded |
| TC-11 | P1 | **P** | Weights sum 1.0; no duplicate inflation |
| TC-12 | P0 | **W** | Contract-based not reference-quirk based, but symbol-heavy |

### AF — Agent fairness (6)

| ID | Sev | Disposition | Notes |
|----|-----|-------------|-------|
| AF-01 | P0 | **W** | S02 undisclosed literals risk unfair fail |
| AF-02 | P1 | **P** | Behavioral-core scope explicit |
| AF-03 | P1 | **P** | Not byte-identical to full PR |
| AF-04 | P1 | **P** | Timeouts generous per stage |
| AF-05 | P0 | **P** | Gemini fail reviewed — agent miss |
| AF-06 | P0 | **P** | Documented build/vet paths match grader |

### RS — Reward integrity (9)

| ID | Sev | Disposition | Notes |
|----|-----|-------------|-------|
| RS-01 | P0 | **W** | Formula correct; `valid_trial` pollutes vector |
| RS-02 | P1 | **P** | Core vs judged keys separated in code intent |
| RS-03 | P2 | **W** | `valid_trial`/`stage_complete` still in reward.json |
| RS-04 | P1 | **F** | RewardKit configured but wrong model + bad criteria |
| RS-05 | P1 | **W** | Judges off by default — end-to-end judge path untested on platform |
| RS-06 | P1 | **P** | binary vs training documented |
| RS-08 | P0 | **W** | valid_trial can skew DataOS mean |
| RS-09 | P0 | **P** | Task defects tracked separately in this audit |

### ER — Environment (8)

| ID | Sev | Disposition | Notes |
|----|-----|-------------|-------|
| ER-01 | P1 | **P** | Go 1.26, commit+tree pinned |
| ER-02 | P2 | **P** | Dockerfile pattern acceptable for Go stream |
| ER-03 | P1 | **P** | CGO off; standard users |
| ER-04 | P1 | **P** | Agent GOPROXY off at grade time |
| ER-05 | P1 | **P** | Build retries in Dockerfile |
| ER-06 | P0 | **P** | No keys in image |
| ER-07 | P0 | **F** | allow_internet=true conflicts with team rule |
| ER-08 | P1 | **P** | Stage 01 allows test files explicitly |

### VE — Validation evidence (7)

| ID | Sev | Disposition | Notes |
|----|-----|-------------|-------|
| VE-01 | P1 | **W** | Oracle/no-op yes; near-miss self-test only; Oracle ×1 platform |
| VE-02 | P0 | **W** | v2 rework partially documented; calibration JSON broken |
| VE-03 | P1 | **W** | Gemini 3.6 used; not gpt-5.6-terra |
| VE-04 | P0 | **W** | eval_182278 reviewed; zip not on disk for re-audit |
| VE-05 | P0 | **P** | No invalid low scores booked as difficulty |
| VE-06 | P2 | **P** | VALIDATION_EVIDENCE + pack script |
| VE-07 | P0 | **W** | Headroom band not established (1/3 frontier runs) |

### AD — Adversarial (8)

| ID | Sev | Disposition | Notes |
|----|-----|-------------|-------|
| AD-01 | P0 | **P** | /tests not agent-readable by policy |
| AD-02 | P0 | **W** | Checksum manifest skippable if absent; no ctime |
| AD-03 | P1 | **P** | No bundled golden in agent tree |
| AD-04 | P2 | **P** | Threat model proportionate |
| AD-05 | P3 | **N/A** | Optional |
| AD-06 | P0 | **P** | Hidden variants in protected tree |
| AD-07 | P0 | **P** | reward.json written by verifier only |
| AD-08 | P0 | **P** | Trajectory audited |

### AT — Authenticity (5)

| ID | Sev | Disposition | Notes |
|----|-----|-------------|-------|
| AT-01 | P1 | **P** | Real Istio networking engineering |
| AT-02 | P2 | **P** | No synthetic boilerplate in prompts |
| AT-03 | P2 | **P** | Calibration in evidence doc not README |
| AT-04 | P2 | **P** | README + contracts navigable |
| AT-05 | P1 | **P** | Multi-subsystem stages |

### DM — Documentation (6)

| ID | Sev | Disposition | Notes |
|----|-----|-------------|-------|
| DM-01 | P1 | **P** | `long-horizon/istio-zone-aware-lb` |
| DM-02 | P1 | **W** | v2 rework; calibration file broken |
| DM-03 | P2 | **P** | Weights in code; README stage table |
| DM-04 | P1 | **P** | Pack script referenced |
| DM-05 | P1 | **W** | Judge TOML contamination breaks release hygiene |
| DM-06 | P1 | **P** | requirement_map generated alignment tests |

### RK — RewardKit (10)

| ID | Sev | Disposition | Notes |
|----|-----|-------------|-------|
| RK-01 | P1 | **P** | Judges optional for process/validity/merge-readiness |
| RK-02 | P0 | **P** | Judges cannot rescue binary (lambda=0; merge not wired to binary) |
| RK-03 | P1 | **F** | Criteria text wrong task |
| RK-04 | P0 | **W** | judge_inputs bounded; end-to-end not proven with terra |
| RK-05 | P1 | **P** | judge_prompt.md Istio-specific |
| RK-06 | P0 | **P** | Trajectory untrusted |
| RK-07 | P0 | **W** | RUN_LLM_JUDGES=0 — failure path untested live |
| RK-08 | P1 | **N/A** | Judges not run on platform |
| RK-09 | P0 | **F** | No proof OpenAPI gpt-5.6-terra judge run |
| RK-10 | P1 | **F** | Cilium criteria not attainable/fair for Istio |

**Generic QC tally (approx.):** Pass 62 · Watch 28 · Fail 10 · N/A 2  
**Hard-gate fails:** PV-01, PV-06, PV-07, ER-07, RS-04, RK-03, RK-09, RK-10 (+ RS-08/VC-07 borderline)

---

## Tab 2 — LH Task Review (pre-run)

| Row theme | Criticality | Disposition | Notes |
|-----------|-------------|-------------|-------|
| Real expert work | Critical | **P** | Istio pilot/xDS/EDS multi-file feature |
| Credible difficulty/headroom | High | **W** | 36h; 1 Gemini run 0% — resample needed |
| Contamination controlled | Critical | **P** | Sanitized git; no remotes |
| Source eligible (Go, Apache, recency) | Critical | **P** | PR #60765 merged 2026-07-17 |
| Causal stage dependency | Critical | **P** | 4 stages cumulative |
| Multiple valid impl paths | High | **W** | Behavioral-core; some symbol probes narrow |
| Objective clear | Critical | **P** | |
| Stage count meaningful | High | **P** | 4 stages |
| Every stage adds signal | Critical | **P** | |
| Instructions fair | Critical | **W** | S02 gap |
| State/handoffs | Critical | **P** | handoff.json + typed artifacts |
| Executable outcomes | Critical | **P** | |
| Stage-appropriate prompts | High | **P** | |
| Typed bounded handoffs | High | **P** | artifacts.schema.json |
| Intent reconstruction fair | Critical | **W** | Hidden template literals |
| Final stage closure | Critical | **P** | Stage 04 cumulative hidden + validation |
| task.toml complete | Critical | **F/W** | allow_internet; judge model |
| Repo pinned resettable | Critical | **P** | commit+tree |
| Time/resource limits | High | **P** | |
| Protected boundary | Critical | **P** | /tests mount |
| Sanitized solving repo | Critical | **P** | single synthetic commit |
| Network controlled | Critical | **F** | allow_internet true |
| Integrity checks | High | **W** | no ctime anchor |
| Step folders match config | Critical | **P** | |
| Verifier tooling separated | High | **W** | same container |
| Author artifacts protected | High | **P** | |
| README matches reality | Critical | **P** | |
| Harbor/RewardKit discovery | Critical | **F/W** | wrong judge model/criteria |
| Oracle solves legitimately | Critical | **P** | |
| Oracle/no-op repeatable | Critical | **W** | Oracle ×1 platform |
| Golden provenance | High | **P** | provenance.json + merge manifest |
| Near-misses fail | High | **W** | self-tested; not platform |
| Executable behavior tests | Critical | **P** | build/vet/hidden |
| Normal/edge/invalid cases | High | **W** | symbol-heavy |
| Integration/regressions | Critical | **W** | no cluster integration |
| Major requirements checked | Critical | **W** | narrowed scope |
| Cheating rejected | Critical | **P** | hidden variants |
| No vacuous go test | Critical | **P** | contract test guards |
| Hidden variants independent | High | **P** | verifierprobe not from upstream PR tests |
| Variants deterministic | High | **P** | |
| Performance thresholds fair | High | **N/A** | |
| Agent scripts not trusted | High | **P** | |
| Tests stable | Critical | **P** | |
| Deterministic gates control pass | Critical | **P** | |
| Standard judge prompt | High | **W** | prompt OK; TOML wrong |
| Weights meaningful | High | **P** | |
| LLM judge limited scope | High | **P** | when enabled |
| Critical non-compensable | Critical | **P** | S04 prose non-critical |
| Score fields bounded | Critical | **W** | valid_trial in reward.json |
| Integrity zeros success | Critical | **P** | |
| Judge inputs bounded | High | **P** | |
| Judge applicability | High | **P** | Oracle skips judges |
| Judge failures non-fatal | High | **P** | |
| Repeated judge merge | High | **N/A** | judges off |
| Lambda/oracle fields | Critical | **W** | valid_trial placement |

---

## Tab 3 — LH-Eval (post-run)

Based on eval_181197, eval_182277, eval_182278 + local Harbor v2.

| Row theme | Criticality | Disposition | Notes |
|-----------|-------------|-------------|-------|
| Intended task/models | Critical | **W** | Gemini frontier OK; judge model directive unmet |
| Environment usable | Critical | **P** | Oracle/no-op/Gemini completed |
| All verifiers/judges ran | Critical | **W** | LLM judges not run (RUN_LLM_JUDGES=0) |
| Evidence package complete | High | **W** | eval zip missing locally |
| Real long-horizon work | High | **P** | Gemini multi-stage attempt |
| Stage work before promotion | Critical | **P** | all stages executed |
| Persistent state/handoffs | High | **P** | |
| Agent responded to evidence | High | **W** | Gemini stuck S02 |
| Final closure reran contract | Critical | **P** | Oracle S04 cumulative |
| Failures functional/reproducible | Critical | **P** | Gemini S02 hidden_tests_pass |
| Checks only stated requirements | Critical | **W** | S02 hidden vs prompt |
| Partial credit proportional | High | **P** | training_score 0.48 Gemini |
| Result fields match outcome | Critical | **W** | valid_trial in reward.json |
| Judge applicability | High | **P** | skipped Oracle |
| Judge fair evidence | High | **N/A** | |
| Judge non-gating | High | **P** | |
| Rule out unstated requirement | Critical | **W** | S02 substring literals |
| Rule out infra/flakiness | Critical | **P** | |
| Rule out grader false negative | Critical | **P** | Gemini fail explained |
| Failure classification | Critical | **P** | Agent — partial S02 |
| Avoid hard-coding | Critical | **P** | Gemini built partial wiring |
| Avoid answer sources | Critical | **P** | |
| Trajectory credible | High | **P** | engineering iteration |
| Oracle deterministic no judge rescue | Critical | **P** | |
| Oracle patch stage boundaries | Critical | **P** | incremental golden patches |
| Final verdict evidence-based | Critical | **W** | pending v2 platform rerun |
| Next action clear | High | **P** | this audit |
| Useful headroom | High | **W** | 0/1 full solve — resample |

---

## Prompt ↔ verifier gap detail (Stage 02)

**Disclosed in instruction:** `ISTIO_META_ENABLE_SELF_DISCOVERY`, `EnableSelfDiscovery`, `local_cluster` gating, `LocalServiceInfo` / `SetServiceTargets`, build/vet packages.

**Graded in hidden tests but NOT fully disclosed:**

| Hidden assertion | File |
|------------------|------|
| `enable_self_discovery` template key in `pkg/bootstrap/option/instances.go` | `TestBootstrapTemplateReferencesSelfDiscovery` |
| `zone_aware_lb_config`, `min_cluster_size`, `local_cluster_name` in envoy bootstrap JSON | `TestEnvoyBootstrapJsonHasDisableZoneAwareParam` |
| Exact `env.Register("ISTIO_META_ENABLE_SELF_DISCOVERY"` | `TestPilotAgentOptionsWireMetadata` |
| Comment/doc must mention `zone-aware` | `TestPilotAgentOptionsWireMetadata` |
| Exact `node.LocalService = LocalServiceInfo{` assignment shape | `TestProxyContextEnableSelfDiscoveryField` |

These drove **eval_182278** failures (`TestProxyContextEnableSelfDiscoveryField`, `TestEnvoyBootstrapJsonHasDisableZoneAwareParam`, `TestPilotAgentOptionsWireMetadata`).

---

## Agent failure analysis (eval_182278)

| Stage | binary_reward | Decisive gate | Classification |
|-------|---------------|---------------|----------------|
| 01-diagnose | 1.0 | — | Pass |
| 02-self-discovery-bootstrap | 0.0 | hidden_tests_pass (3/6) | **Valid agent failure** — partial bootstrap wiring |
| 03-eds-loadbalancer | 0.0 | blocked | Not reached meaningfully |
| 04-config-harden | 0.0 | blocked | Not reached meaningfully |

`valid_trial=1.0` on a failed trial is **misleading** for platform averaging — fix per Task7 pattern.

---

## Separate verifier environment — refuttal (in-progress task)

**Current design:** Harbor multi-step standard — each step runs agent, then `steps/*/tests/test.sh` → `exec bash /tests/stage_test.sh`, grading `/testbed` in the **same** container with `/tests` mounted read-only at verifier time.

**Why not hermetic split yet:**
- Matches approved Tier-2 samples (duckdb, cilium reference) and existing Task8–10 Harbor layout
- Protected `/tests` + ephemeral hidden injection + integrity trajectory scan provide practical isolation
- Separate VM/step verifier (aetherius pattern) adds platform integration work not yet wired in this repo

**If lead requires hermetic split:** migrate to post-agent snapshot + isolated verifier job before claiming rework complete.

---

## Required rework checklist (single pass)

- [ ] Fix all four `judge.toml` files (Istio criteria + **gpt-5.6-terra**)
- [ ] Set `allow_internet = false` + per-step agent network-off
- [ ] Move `valid_trial` (and consider `stage_complete`) out of `reward.json`
- [ ] Fix `calibration_summary.json` JSON
- [ ] Align S02 instruction with hidden tests OR relax hidden tests
- [ ] Add CTRF `reportFormat` / `specVersion` if required by DataOS
- [ ] Optional: ctime anti-cheat anchor
- [ ] Repack; 45/45+ pytest; Oracle ×2 + Gemini ×2–3 on DataOS
- [ ] Update `VALIDATION_EVIDENCE.md` with new sha256 and eval IDs

---

## Rework completed confirmation

**This task is NOT marked rework complete.** v2 local Oracle/no-op are green; platform Oracle ×2, judge model migration, network policy, prompt alignment, and packaging hygiene fixes remain open.

---

*End of audit — reviewer pickup file for Task10 istio-zone-aware-lb.*
