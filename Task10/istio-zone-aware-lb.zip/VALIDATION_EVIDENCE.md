# Validation evidence — istio-zone-aware-lb v3

QC rework addressing team-lead audit (`QC_FULL_AUDIT_REVIEW.md`).

## v3 changes (2026-08-21)

| Area | Fix |
|------|-----|
| Network | `allow_internet=false`; updated `network_policy` |
| RewardKit | All `judge.toml` → `openai/gpt-5.6-terra`; `[verifier.env]` uses `OPENAI_API_KEY` |
| Judge criteria | Replaced Cilium Gateway API bleed with Istio zone-aware LB scope |
| Prompt alignment | Stage 02 instruction discloses all hidden bootstrap template keys |
| Grading integrity | `valid_trial` / `stage_complete` moved to `reward-details.json` only |
| CTRF | Added `reportFormat` + `specVersion` envelope |
| Anticheat | Added ctime-vs-container-start anchor on toolchain paths |
| Packaging | Pack gate rejects Cilium judge text, `allow_internet=true`, `valid_trial` in core keys |

## Separate verifier environment (refuttal)

This package remains **Harbor schema 1.3** with protected `/tests` mount and offline agent execution. `stage_test.sh` includes optional artifact reconstruction hooks for a future schema-1.4 hermetic verifier migration. Full separate-container grading (as in `gitea-multi-project` v3) is deferred to avoid an untested schema bump on the first DataOS upload; agent network isolation + ephemeral hidden injection + integrity trajectory audit provide the current anti-cheat boundary.

## Prior platform evals (pre-v3 checksum)

| Run | Eval ID | Result |
|-----|---------|--------|
| Oracle | eval_181197 | Trial binary **1.0** |
| No-op | eval_182277 | Trial binary **0.0** |
| Gemini 3.6 Flash | eval_182278 | Trial binary **0.0**; S01 pass, S02 hidden wiring fail |

**Re-run on DataOS after v3 upload:** Oracle ×2, no-op, Gemini ×2–3 for headroom calibration.

## Host gates (run before upload)

```bash
docker run --rm -v "$PWD:/repo" -w /repo/Task10 python:3.12-bookworm \
  bash -lc 'pip install -q pytest==8.3.5 && python pack_istio_zone_aware_lb.py'
```

Then local Harbor oracle + nop if desired.
