// SPDX-License-Identifier: Apache-2.0
// Hidden verifier probes for stage 04-config-harden.

package verifierprobe

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestValidateZoneAwareLbSettingSymbol(t *testing.T) {
	root := testbedRoot(t)
	agentValidation := readTestbedFile(t, root, "pkg/config/validation/agent/validation.go")
	if !strings.Contains(agentValidation, "func ValidateZoneAwareLbSetting(") {
		t.Fatal("agent validation must implement ValidateZoneAwareLbSetting")
	}
	if !strings.Contains(agentValidation, "ZoneAwareLoadBalancerSetting") {
		t.Fatal("ValidateZoneAwareLbSetting must validate ZoneAwareLoadBalancerSetting")
	}
	if !strings.Contains(agentValidation, "LabelTopologyRegion") {
		t.Fatal("zone-aware validation must reject topology labels in failover_priority")
	}
	topValidation := readTestbedFile(t, root, "pkg/config/validation/validation.go")
	if !strings.Contains(topValidation, "ValidateZoneAwareLbSetting") {
		t.Fatal("DestinationRule validation must call ValidateZoneAwareLbSetting")
	}
	if !strings.Contains(topValidation, "only one of localityLbSetting and zoneAwareLbSetting can be set") {
		t.Fatal("validation must enforce mutual exclusion between locality and zone-aware LB settings")
	}
}

func TestProxyDependenciesServiceTargetPush(t *testing.T) {
	root := testbedRoot(t)
	deps := readTestbedFile(t, root, "pilot/pkg/xds/proxy_dependencies.go")
	if !strings.Contains(deps, "EnableSelfDiscovery") {
		t.Fatal("proxy dependency filter must honor EnableSelfDiscovery")
	}
	for _, symbol := range []string{"PrevLocalService", "LocalService", "kind.ServiceEntry", "kind.Endpoints"} {
		if !strings.Contains(deps, symbol) {
			t.Fatalf("proxy dependency filter must track %s for local service pushes", symbol)
		}
	}
	meshValidation := readTestbedFile(t, root, "pkg/config/validation/agent/validation.go")
	if !strings.Contains(meshValidation, "ValidateZoneAwareLbSetting(mesh.ZoneAwareLbSetting") {
		t.Fatal("mesh config validation must validate mesh-wide ZoneAwareLbSetting")
	}
}

func TestReleaseNotePresent(t *testing.T) {
	root := testbedRoot(t)
	path := filepath.Join(root, "releasenotes/notes/zone-aware-load-balancing.yaml")
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("read release note: %v", err)
	}
	text := string(data)
	if !strings.Contains(text, "zoneAwareLbSetting") && !strings.Contains(text, "zone-aware") {
		t.Fatal("release note must document zoneAwareLbSetting / zone-aware load balancing")
	}
	if !strings.Contains(text, "ISTIO_META_ENABLE_SELF_DISCOVERY") {
		t.Fatal("release note must document ISTIO_META_ENABLE_SELF_DISCOVERY requirement")
	}
}

func TestValidationPackagesBuild(t *testing.T) {
	root := testbedRoot(t)
	out, err := runGo(
		t,
		root,
		"build",
		"./pkg/config/validation/...",
		"./pilot/pkg/xds/...",
		"./pilot/pkg/networking/core/loadbalancer/...",
		"./verifierprobe/...",
	)
	if err != nil {
		t.Fatalf("validation packages build failed: %v\n%s", err, out)
	}
}

func TestValidationProductionVetClean(t *testing.T) {
	root := testbedRoot(t)
	// Must match stage_check.STAGE_VET for 04-config-harden (instruction-disclosed targets).
	out, err := runGo(
		t,
		root,
		"vet",
		"-tests=false",
		"./pilot/pkg/networking/core/loadbalancer/...",
		"./pkg/config/validation",
	)
	if err != nil {
		t.Fatalf("validation production vet failed: %v\n%s", err, out)
	}
}

func TestCriticalPathsPresent(t *testing.T) {
	root := testbedRoot(t)
	critical := []string{
		"pilot/pkg/networking/core/loadbalancer/loadbalancer.go",
		"pilot/pkg/xds/eds.go",
		"pilot/pkg/xds/endpoints/endpoint_builder.go",
		"pkg/bootstrap/config.go",
		"tools/packaging/common/envoy_bootstrap.json",
		"pkg/config/validation/agent/validation.go",
	}
	for _, rel := range critical {
		path := filepath.Join(root, rel)
		if _, err := os.Stat(path); err != nil {
			t.Fatalf("missing critical implementation path %s: %v", rel, err)
		}
	}
	lb := readTestbedFile(t, root, "pilot/pkg/networking/core/loadbalancer/loadbalancer.go")
	for _, symbol := range []string{"ZoneAwareLBSettings", "ApplyZoneAwareLoadBalancer", "GetEffectiveLbSetting"} {
		if !strings.Contains(lb, symbol) {
			t.Fatalf("loadbalancer.go missing symbol %s", symbol)
		}
	}
	bootstrap := readTestbedFile(t, root, "pkg/bootstrap/config.go")
	if !strings.Contains(bootstrap, "ISTIO_META_ENABLE_SELF_DISCOVERY") && !strings.Contains(bootstrap, "EnableSelfDiscovery") {
		t.Fatal("bootstrap config must wire self-discovery metadata")
	}
	out, err := runGo(
		t,
		root,
		"build",
		"./pilot/pkg/networking/core/loadbalancer/...",
		"./pilot/pkg/xds/...",
		"./pkg/config/validation/...",
		"./pkg/bootstrap/...",
	)
	if err != nil {
		t.Fatalf("critical paths failed to compile together: %v\n%s", err, out)
	}
}
