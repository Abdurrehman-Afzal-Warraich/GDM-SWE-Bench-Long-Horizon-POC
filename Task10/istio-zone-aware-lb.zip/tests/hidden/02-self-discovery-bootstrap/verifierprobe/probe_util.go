// SPDX-License-Identifier: Apache-2.0
// Shared helpers for hidden verifier probes.

package verifierprobe

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

func testbedRoot(t *testing.T) string {
	t.Helper()
	if root := os.Getenv("TESTBED_DIR"); root != "" {
		return root
	}
	wd, _ := os.Getwd()
	dir := wd
	for {
		if _, err := os.Stat(filepath.Join(dir, "go.mod")); err == nil {
			return dir
		}
		parent := filepath.Dir(dir)
		if parent == dir {
			t.Fatal("could not locate testbed root")
		}
		dir = parent
	}
}

func runGo(t *testing.T, root string, args ...string) (string, error) {
	t.Helper()
	cmd := exec.Command("go", args...)
	cmd.Dir = root
	cmd.Env = append(os.Environ(), "GOWORK=off", "CGO_ENABLED=0", "GOPROXY=off")
	out, err := cmd.CombinedOutput()
	return string(out), err
}

func dirHasGoWith(t *testing.T, root, rel, needle string) bool {
	t.Helper()
	dir := filepath.Join(root, rel)
	entries, err := os.ReadDir(dir)
	if err != nil {
		return false
	}
	for _, entry := range entries {
		if entry.IsDir() || !strings.HasSuffix(entry.Name(), ".go") || strings.HasSuffix(entry.Name(), "_test.go") {
			continue
		}
		data, err := os.ReadFile(filepath.Join(dir, entry.Name()))
		if err != nil {
			continue
		}
		if strings.Contains(string(data), needle) {
			return true
		}
	}
	return false
}

func readTestbedFile(t *testing.T, root, rel string) string {
	t.Helper()
	data, err := os.ReadFile(filepath.Join(root, rel))
	if err != nil {
		t.Fatalf("read %s: %v", rel, err)
	}
	return string(data)
}
