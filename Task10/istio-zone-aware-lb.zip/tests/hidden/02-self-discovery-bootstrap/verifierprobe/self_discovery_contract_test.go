// SPDX-License-Identifier: Apache-2.0
// Hidden verifier probes for stage 02-self-discovery-bootstrap.

package verifierprobe

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestSelfDiscoveryMetadataConstant(t *testing.T) {
	root := testbedRoot(t)
	options := readTestbedFile(t, root, "pilot/cmd/pilot-agent/options/options.go")
	if !strings.Contains(options, "ISTIO_META_ENABLE_SELF_DISCOVERY") {
		t.Fatal("pilot-agent options must register ISTIO_META_ENABLE_SELF_DISCOVERY")
	}
	if !strings.Contains(options, "EnableSelfDiscovery") {
		t.Fatal("pilot-agent options must declare EnableSelfDiscovery env var")
	}
	proxyMeta := readTestbedFile(t, root, "pkg/model/proxy.go")
	if !strings.Contains(proxyMeta, "EnableSelfDiscovery") {
		t.Fatal("NodeMetadata must expose EnableSelfDiscovery")
	}
}

func TestBootstrapTemplateReferencesSelfDiscovery(t *testing.T) {
	root := testbedRoot(t)
	config := readTestbedFile(t, root, "pkg/bootstrap/config.go")
	if !strings.Contains(config, "EnableSelfDiscovery") || !strings.Contains(config, "option.EnableSelfDiscovery") {
		t.Fatal("bootstrap config must wire Metadata.EnableSelfDiscovery into template params")
	}
	instances := readTestbedFile(t, root, "pkg/bootstrap/option/instances.go")
	if !strings.Contains(instances, "enable_self_discovery") {
		t.Fatal("bootstrap option package must define enable_self_discovery template key")
	}
	template := readTestbedFile(t, root, "tools/packaging/common/envoy_bootstrap.json")
	if !strings.Contains(template, ".enable_self_discovery") {
		t.Fatal("envoy bootstrap template must gate self-discovery clusters on enable_self_discovery")
	}
	if !strings.Contains(template, "local_cluster") {
		t.Fatal("envoy bootstrap template must define local_cluster for self-discovery")
	}
}

func TestProxyContextEnableSelfDiscoveryField(t *testing.T) {
	root := testbedRoot(t)
	contextGo := readTestbedFile(t, root, "pilot/pkg/model/context.go")
	for _, symbol := range []string{"LocalServiceInfo", "LocalService", "PrevLocalService", "SetServiceTargets"} {
		if !strings.Contains(contextGo, symbol) {
			t.Fatalf("proxy context must define %s for self-discovery local_cluster support", symbol)
		}
	}
	if !strings.Contains(contextGo, "node.LocalService = LocalServiceInfo{") {
		t.Fatal("SetServiceTargets must populate LocalService from the first service target")
	}
}

func TestBootstrapPackagesBuild(t *testing.T) {
	root := testbedRoot(t)
	out, err := runGo(
		t,
		root,
		"build",
		"./pilot/cmd/pilot-agent/options/...",
		"./pkg/bootstrap/...",
		"./pkg/model/...",
		"./verifierprobe/...",
	)
	if err != nil {
		t.Fatalf("bootstrap packages build failed: %v\n%s", err, out)
	}
}

func TestBootstrapProductionVetClean(t *testing.T) {
	root := testbedRoot(t)
	out, err := runGo(
		t,
		root,
		"vet",
		"-tests=false",
		"./pilot/cmd/pilot-agent/options/...",
		"./pkg/bootstrap/...",
		"./pkg/model/...",
	)
	if err != nil {
		t.Fatalf("bootstrap production vet failed: %v\n%s", err, out)
	}
}

func TestEnvoyBootstrapJsonHasDisableZoneAwareParam(t *testing.T) {
	root := testbedRoot(t)
	template := readTestbedFile(t, root, "tools/packaging/common/envoy_bootstrap.json")
	// Self-discovery is optional; zone-aware LB wiring must only appear when enabled.
	if !strings.Contains(template, "{{ if .enable_self_discovery }}") {
		t.Fatal("envoy bootstrap must conditionally inject zone-aware local_cluster on enable_self_discovery")
	}
	if !strings.Contains(template, "zone_aware_lb_config") {
		t.Fatal("envoy bootstrap local_cluster must configure zone_aware_lb_config")
	}
	if !strings.Contains(template, "local_cluster_name") {
		t.Fatal("envoy bootstrap cluster_manager must set local_cluster_name when self-discovery is enabled")
	}
	if !strings.Contains(template, "min_cluster_size") {
		t.Fatal("zone_aware_lb_config must set min_cluster_size for local_cluster")
	}
}

func TestPilotAgentOptionsWireMetadata(t *testing.T) {
	root := testbedRoot(t)
	options := readTestbedFile(t, root, "pilot/cmd/pilot-agent/options/options.go")
	if !strings.Contains(options, `env.Register("ISTIO_META_ENABLE_SELF_DISCOVERY"`) {
		t.Fatal("pilot-agent must register ISTIO_META_ENABLE_SELF_DISCOVERY for proxyMetadata propagation")
	}
	if !strings.Contains(options, "zone-aware") && !strings.Contains(options, "zone aware") {
		t.Fatal("pilot-agent EnableSelfDiscovery registration must document zone-aware routing purpose")
	}
	proxyMeta := readTestbedFile(t, root, "pkg/model/proxy.go")
	if !strings.Contains(proxyMeta, "ISTIO_META_ENABLE_SELF_DISCOVERY") {
		t.Fatal("NodeMetadata EnableSelfDiscovery must document ISTIO_META_ENABLE_SELF_DISCOVERY source")
	}
	if _, err := os.Stat(filepath.Join(root, "pilot/cmd/pilot-agent/options/options.go")); err != nil {
		t.Fatalf("pilot-agent options path missing: %v", err)
	}
}
