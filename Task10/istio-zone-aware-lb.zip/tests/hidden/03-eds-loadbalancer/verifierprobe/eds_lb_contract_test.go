// SPDX-License-Identifier: Apache-2.0
// Hidden verifier probes for stage 03-eds-loadbalancer.

package verifierprobe

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestLoadBalancerZoneAwareTypesPresent(t *testing.T) {
	root := testbedRoot(t)
	lb := readTestbedFile(t, root, "pilot/pkg/networking/core/loadbalancer/loadbalancer.go")
	for _, symbol := range []string{"LBSettings", "LocalityLBSettings", "ZoneAwareLBSettings", "IsZoneAware"} {
		if !strings.Contains(lb, symbol) {
			t.Fatalf("loadbalancer package must define %s for zone-aware routing", symbol)
		}
	}
	if !strings.Contains(lb, "ApplyToCluster") || !strings.Contains(lb, "ApplyToLoadAssignment") {
		t.Fatal("LBSettings interface must expose ApplyToCluster and ApplyToLoadAssignment")
	}
}

func TestApplyZoneAwareLoadBalancerSymbol(t *testing.T) {
	root := testbedRoot(t)
	lb := readTestbedFile(t, root, "pilot/pkg/networking/core/loadbalancer/loadbalancer.go")
	if !strings.Contains(lb, "func ApplyZoneAwareLoadBalancer(") {
		t.Fatal("loadbalancer package must implement ApplyZoneAwareLoadBalancer")
	}
	if !strings.Contains(lb, "applyZoneAwareRegionalFailover") {
		t.Fatal("zone-aware load balancing must bucket endpoints by region for failover")
	}
	trafficPolicy := readTestbedFile(t, root, "pilot/pkg/networking/core/cluster_traffic_policy.go")
	if !strings.Contains(trafficPolicy, "GetEffectiveLbSetting") {
		t.Fatal("cluster traffic policy must resolve effective LB settings via GetEffectiveLbSetting")
	}
}

func TestEdsLocalClusterSymbol(t *testing.T) {
	root := testbedRoot(t)
	utilGo := readTestbedFile(t, root, "pilot/pkg/networking/util/util.go")
	if !strings.Contains(utilGo, "SelfDiscoveryCluster") || !strings.Contains(utilGo, "local_cluster") {
		t.Fatal("networking util must define SelfDiscoveryCluster constant")
	}
	eds := readTestbedFile(t, root, "pilot/pkg/xds/eds.go")
	for _, symbol := range []string{"parseClusterName", "affectedService", "SelfDiscoveryCluster"} {
		if !strings.Contains(eds, symbol) {
			t.Fatalf("EDS generator must implement %s for local_cluster routing", symbol)
		}
	}
	endpointBuilder := readTestbedFile(t, root, "pilot/pkg/xds/endpoints/endpoint_builder.go")
	if !strings.Contains(endpointBuilder, "buildLocalityLbEndpoints") &&
		!strings.Contains(endpointBuilder, "createClusterLoadAssignment") {
		t.Fatal("endpoint builder must build locality endpoints for the self-discovery cluster")
	}
}

func TestEndpointBuilderSelfDiscoveryHook(t *testing.T) {
	root := testbedRoot(t)
	endpointBuilder := readTestbedFile(t, root, "pilot/pkg/xds/endpoints/endpoint_builder.go")
	if !strings.Contains(endpointBuilder, "isSelfDiscoveryCluster") {
		t.Fatal("EndpointBuilder must track isSelfDiscoveryCluster")
	}
	if !strings.Contains(endpointBuilder, "GetEffectiveLbSetting") {
		t.Fatal("EndpointBuilder must resolve zone-aware settings via GetEffectiveLbSetting")
	}
	if !strings.Contains(endpointBuilder, "filterIstioEndpoint") || !strings.Contains(endpointBuilder, "WorkloadName") {
		t.Fatal("self-discovery endpoint filtering must restrict endpoints to the local workload")
	}
	if !strings.Contains(endpointBuilder, "ApplyToLoadAssignment") {
		t.Fatal("EndpointBuilder must apply resolved LB settings to cluster load assignments")
	}
}

func TestGetEffectiveLbSettingSymbol(t *testing.T) {
	root := testbedRoot(t)
	lb := readTestbedFile(t, root, "pilot/pkg/networking/core/loadbalancer/loadbalancer.go")
	if !strings.Contains(lb, "func GetEffectiveLbSetting(") {
		t.Fatal("loadbalancer package must implement GetEffectiveLbSetting")
	}
	if !strings.Contains(lb, "ZoneAwareLbSetting") || !strings.Contains(lb, "LocalityLbSetting") {
		t.Fatal("GetEffectiveLbSetting must reconcile mesh and DR locality/zone-aware settings")
	}
	trafficPolicy := readTestbedFile(t, root, "pilot/pkg/networking/core/cluster_traffic_policy.go")
	if !strings.Contains(trafficPolicy, "enableSelfDiscovery") {
		t.Fatal("cluster builder must pass enableSelfDiscovery into applyLoadBalancer")
	}
}

func TestEdsPackagesBuild(t *testing.T) {
	root := testbedRoot(t)
	out, err := runGo(
		t,
		root,
		"build",
		"./pilot/pkg/networking/core/loadbalancer/...",
		"./pilot/pkg/networking/core/...",
		"./pilot/pkg/xds/...",
		"./verifierprobe/...",
	)
	if err != nil {
		t.Fatalf("EDS/loadbalancer packages build failed: %v\n%s", err, out)
	}
	if _, err := os.Stat(filepath.Join(root, "pilot/pkg/xds/endpoints/endpoint_builder.go")); err != nil {
		t.Fatalf("endpoint builder source missing: %v", err)
	}
}

func TestEdsProductionVetClean(t *testing.T) {
	root := testbedRoot(t)
	// Must match stage_check.STAGE_VET for 03-eds-loadbalancer (instruction-disclosed targets).
	out, err := runGo(
		t,
		root,
		"vet",
		"-tests=false",
		"./pilot/pkg/networking/core",
		"./pilot/pkg/networking/core/loadbalancer/...",
	)
	if err != nil {
		t.Fatalf("EDS production vet failed: %v\n%s", err, out)
	}
}
