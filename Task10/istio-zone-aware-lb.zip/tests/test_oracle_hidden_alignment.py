"""Hidden probe strings must appear in cumulative golden patches."""
from __future__ import annotations

import re
from pathlib import Path

PKG = Path(__file__).resolve().parents[1]
STEPS = PKG / "steps"

PROBES = [
    ("02-self-discovery-bootstrap", "ISTIO_META_ENABLE_SELF_DISCOVERY"),
    ("02-self-discovery-bootstrap", "enable_self_discovery"),
    ("03-eds-loadbalancer", "ZoneAwareLBSettings"),
    ("03-eds-loadbalancer", "ApplyZoneAwareLoadBalancer"),
    ("03-eds-loadbalancer", "SelfDiscoveryCluster"),
    ("04-config-harden", "ValidateZoneAwareLbSetting"),
]


def cumulative_patch_text() -> str:
    chunks: list[str] = []
    for stage in ("02-self-discovery-bootstrap", "03-eds-loadbalancer", "04-config-harden"):
        chunks.append((STEPS / stage / "solution" / "golden.patch").read_text(encoding="utf-8", errors="replace"))
    return "\n".join(chunks)


def test_probe_symbols_in_golden_patches() -> None:
    blob = cumulative_patch_text()
    for stage, needle in PROBES:
        assert needle in blob, f"{needle} missing from golden patches (stage {stage})"


ALLOWED_TEST_PATCHES = {
    "pilot/pkg/networking/core/loadbalancer/loadbalancer_test.go",
    "pilot/pkg/networking/core/cluster_traffic_policy_test.go",
    "pilot/pkg/networking/core/cluster_test.go",
}


def test_no_unexpected_test_files_in_production_patches() -> None:
    for stage in ("02-self-discovery-bootstrap", "03-eds-loadbalancer", "04-config-harden"):
        text = (STEPS / stage / "solution" / "golden.patch").read_text(encoding="utf-8")
        files = re.findall(r"^diff --git a/(.+?) b/", text, re.MULTILINE)
        test_files = {f for f in files if f.endswith("_test.go")}
        assert test_files <= ALLOWED_TEST_PATCHES, (stage, test_files - ALLOWED_TEST_PATCHES)
