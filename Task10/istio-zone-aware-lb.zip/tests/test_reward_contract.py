"""Verifier self-validation for reward weights, critical gates, and handoff contract."""
from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

import stage_check
from score_formula import REWARD_JSON_CORE_KEYS, reward_json_shape_ok
from stage_check import CRITICAL_CHECKS, HANDOFF_FIELDS, WEIGHTS, json_contract, write_reward


@pytest.mark.parametrize("stage", list(WEIGHTS))
def test_weights_sum_to_one(stage: str) -> None:
    total = sum(WEIGHTS[stage].values())
    assert abs(total - 1.0) < 1e-6, f"{stage} weights sum to {total}"


@pytest.mark.parametrize("stage", list(CRITICAL_CHECKS))
def test_critical_checks_are_weighted(stage: str) -> None:
    for name in CRITICAL_CHECKS[stage]:
        assert name in WEIGHTS[stage], f"{name} missing from {stage} weights"


@pytest.mark.parametrize("stage", [s for s in WEIGHTS if s != "01-diagnose"])
def test_executable_checks_dominate(stage: str) -> None:
    executable = 0.0
    for name, weight in WEIGHTS[stage].items():
        if name in {"build_clean", "full_build", "hidden_tests_pass", "vet_clean"}:
            executable += weight
    assert executable >= 0.50, f"{stage} executable weight {executable} < 0.50"


def test_reward_json_shape() -> None:
    assert reward_json_shape_ok(REWARD_JSON_CORE_KEYS)


def test_stage04_closure_gates_are_non_critical() -> None:
    critical = set(stage_check.CRITICAL_CHECKS["04-config-harden"])
    assert "release_note_present" not in critical
    assert "implementation_closure" not in critical
    weights = stage_check.WEIGHTS["04-config-harden"]
    assert weights["release_note_present"] > 0.0
    assert weights["implementation_closure"] > 0.0


def test_zero_test_guard_rejects_empty_pattern_match(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_go_cmd(args: list[str], timeout: int) -> tuple[int, str]:
        return 0, "testing: warning: no tests to run\n"

    monkeypatch.setattr(stage_check, "go_cmd", fake_go_cmd)
    ok, note, _ = stage_check.go_test(["./verifierprobe/..."], run_pattern="^TestDoesNotExist$")
    assert not ok
    assert "zero tests" in note.lower()


def test_write_reward_payload() -> None:
    stage = "04-config-harden"
    checks = {name: {"passed": True, "detail": "ok"} for name in WEIGHTS[stage]}
    integrity = {"passed": True, "findings": [], "notes": [], "detail": "clean"}
    with tempfile.TemporaryDirectory() as tmp:
        result_dir = Path(tmp)
        old = stage_check.RESULT_DIR
        stage_check.RESULT_DIR = result_dir
        try:
            binary = write_reward(stage, checks, integrity)
            payload = json.loads((result_dir / "reward.json").read_text(encoding="utf-8"))
            details = json.loads((result_dir / "reward-details.json").read_text(encoding="utf-8"))
        finally:
            stage_check.RESULT_DIR = old
    assert binary == 1.0
    assert payload["binary_reward"] == 1.0
    assert set(payload.keys()) == set(REWARD_JSON_CORE_KEYS)
    assert "valid_trial" not in payload
    assert details["valid_trial"] == 1.0


def test_handoff_contract_requires_nonempty_next_steps(tmp_path: Path) -> None:
    handoff = tmp_path / "handoff.json"
    handoff.write_text(
        json.dumps({"stage": "04-config-harden", "summary": "done", "next_steps": []}) + "\n",
        encoding="utf-8",
    )
    ok, note = json_contract(handoff, dict(HANDOFF_FIELDS))
    assert not ok
    assert "next_steps" in note
