from __future__ import annotations

import hashlib
import json
import re
import sys
import tomllib
from pathlib import Path

PKG = Path(__file__).resolve().parents[1]
TESTS = PKG / "tests"
STEPS = PKG / "steps"
STAGES = [
    "01-diagnose",
    "02-self-discovery-bootstrap",
    "03-eds-loadbalancer",
    "04-config-harden",
]
DISPATCH = {
    "diagnose": "01-diagnose",
    "bootstrap": "02-self-discovery-bootstrap",
    "eds": "03-eds-loadbalancer",
    "harden": "04-config-harden",
}
PATCH_COUNTS = {
    "02-self-discovery-bootstrap": 33,
    "03-eds-loadbalancer": 9,
    "04-config-harden": 4,
}
ALLOWED_TEST_PATCHES = {
    "pilot/pkg/networking/core/loadbalancer/loadbalancer_test.go",
    "pilot/pkg/networking/core/cluster_traffic_policy_test.go",
    "pilot/pkg/networking/core/cluster_test.go",
}
HIDDEN_COUNTS = {
    "02-self-discovery-bootstrap": 7,
    "03-eds-loadbalancer": 7,
    "04-config-harden": 6,
}
ORACLE_REFERENCE_FILE_COUNT = 46

sys.path.insert(0, str(TESTS))
import stage_check  # noqa: E402


def config() -> dict:
    return tomllib.loads((PKG / "task.toml").read_text(encoding="utf-8"))


def patch_files(stage: str) -> list[tuple[str, str]]:
    text = (STEPS / stage / "solution" / "golden.patch").read_text(encoding="utf-8", errors="replace")
    return re.findall(r"^diff --git a/(.+?) b/(.+?)$", text, re.MULTILINE)


def hidden_test_names(stage: str) -> list[str]:
    names: set[str] = set()
    for path in (TESTS / "hidden" / stage).rglob("*_test.go"):
        names.update(re.findall(r"^func (Test[A-Za-z0-9_]+)\(", path.read_text(encoding="utf-8"), re.M))
    names.discard("TestMain")
    return sorted(names)


def test_schema_version_and_strategy() -> None:
    cfg = config()
    assert cfg["schema_version"] == "1.3"
    assert cfg["multi_step_reward_strategy"] == "final"


def test_task_name_and_repo_metadata() -> None:
    cfg = config()
    assert cfg["task"]["name"] == "long-horizon/istio-zone-aware-lb"
    meta = cfg["metadata"]
    assert meta["repository"] == "istio/istio"
    assert meta["base_commit"] == "d17a4626923d3cb48ae7dafd2ef579ae1da8c5d8"
    assert meta["merge_commit"] == "cb9728f907e7dd5d1fb7f625c96464e989857aee"


def test_step_names_match_directories() -> None:
    assert [step["name"] for step in config()["steps"]] == STAGES


def test_verifier_env_block_present() -> None:
    cfg = config()
    env = cfg.get("verifier", {}).get("env", {})
    assert "OPENAI_API_KEY" in env
    assert "NONDETERMINISTIC_LAMBDA" in env
    assert cfg["environment"]["allow_internet"] is False
    assert cfg["metadata"]["judge_model"] == "openai/gpt-5.6-terra"


def test_judge_toml_uses_openai_and_istio_scope() -> None:
    for dimension in ("process", "validity", "merge_readiness", "task_quality"):
        payload = tomllib.loads((TESTS / dimension / "judge.toml").read_text(encoding="utf-8"))
        assert payload["judge"]["judge"] == "openai/gpt-5.6-terra"
        blob = (TESTS / dimension / "judge.toml").read_text(encoding="utf-8").lower()
        assert "cilium" not in blob
        assert "tcproute" not in blob


def test_patches_disjoint_and_provenanced() -> None:
    seen: set[str] = set()
    for stage in STAGES[1:]:
        patch = STEPS / stage / "solution" / "golden.patch"
        provenance = json.loads((patch.parent / "provenance.json").read_text(encoding="utf-8"))
        pairs = patch_files(stage)
        assert pairs and all(a == b for a, b in pairs)
        files = sorted(a for a, _ in pairs)
        assert files == sorted(provenance["files"])
        assert not seen.intersection(files)
        seen.update(files)
        digest = hashlib.sha256(patch.read_bytes()).hexdigest()
        assert digest == provenance["patch_sha256"]
        assert provenance["incremental"] is True
    assert len(seen) == ORACLE_REFERENCE_FILE_COUNT
    test_files = [p for p in seen if p.endswith("_test.go")]
    assert set(test_files) == ALLOWED_TEST_PATCHES


def test_provenance_file_counts() -> None:
    for stage, want in PATCH_COUNTS.items():
        prov = json.loads((STEPS / stage / "solution" / "provenance.json").read_text(encoding="utf-8"))
        assert len(prov["files"]) == want


def test_hidden_corpus_counts() -> None:
    for stage, want in HIDDEN_COUNTS.items():
        assert len(hidden_test_names(stage)) == want


def test_requirement_map_present() -> None:
    payload = json.loads((TESTS / "contracts" / "requirement_map.json").read_text(encoding="utf-8"))
    assert payload["task"] == "long-horizon/istio-zone-aware-lb"
    dep = json.loads((TESTS / "contracts" / "stage_dependencies.json").read_text(encoding="utf-8"))
    rows = {row["stage"]: row for row in dep["stages"]}
    for stage in STAGES[1:]:
        assert sorted(rows[stage]["newTestFunctions"]) == hidden_test_names(stage)
        assert rows[stage]["dispatchKey"] == {v: k for k, v in DISPATCH.items()}[stage]


def test_stage_check_dispatch_keys() -> None:
    assert stage_check.STAGE_KEYS == DISPATCH


def test_dockerfile_base_asserts() -> None:
    dockerfile = (PKG / "environment" / "Dockerfile").read_text(encoding="utf-8")
    assert "d17a4626923d3cb48ae7dafd2ef579ae1da8c5d8" in dockerfile
    assert "3262cc71dcf6f0935dc79b51593879797e63a96f" in dockerfile
    assert "merge_reference_manifest.json" not in dockerfile


def test_merge_reference_manifest_present() -> None:
    manifest = PKG / "environment" / "merge_reference_manifest.json"
    assert manifest.is_file()
    payload = json.loads(manifest.read_text(encoding="utf-8"))
    assert payload["file_count"] == ORACLE_REFERENCE_FILE_COUNT
