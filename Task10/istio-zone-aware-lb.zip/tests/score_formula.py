#!/usr/bin/env python3
"""Shared deterministic/RewardKit scoring primitives.

Task-agnostic. The trial reward is a strict deterministic binary; the
continuous training_score blends deterministic evidence (D) with optional,
never-authoritative RewardKit signals (N) under a configurable lambda.
"""

from __future__ import annotations

import math
from collections.abc import Mapping


# Harbor loads reward.json wholesale into the trial reward vector, so every
# published key is treated as a score. valid_trial and stage_complete are
# metadata and belong in reward-details.json only.
REWARD_JSON_CORE_KEYS = frozenset(
    {
        "reward",
        "binary_reward",
        "training_score",
        "deterministic_score",
    }
)

REWARD_JSON_JUDGED_KEYS = frozenset({"non_deterministic_score"})

REWARD_JSON_KEYS = REWARD_JSON_CORE_KEYS | REWARD_JSON_JUDGED_KEYS


def reward_json_shape_ok(keys: object) -> bool:
    """True when a reward.json key set is the core set, optionally plus judge keys."""
    try:
        present = frozenset(keys)  # type: ignore[arg-type]
    except TypeError:
        return False
    return present >= REWARD_JSON_CORE_KEYS and present <= REWARD_JSON_KEYS


def clamp01(value: float) -> float:
    if not math.isfinite(value):
        return 0.0
    return max(0.0, min(1.0, float(value)))


def parse_lambda(value: object) -> float:
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return 0.0
    if not math.isfinite(parsed) or parsed < 0.0:
        return 0.0
    return min(parsed, 1.0)


def deterministic_components(
    checks: Mapping[str, Mapping[str, object]],
    weights: Mapping[str, float],
    *,
    integrity_ok: bool,
) -> tuple[float, float]:
    denominator = sum(max(0.0, float(weight)) for weight in weights.values())
    if not integrity_ok:
        return 0.0, denominator
    numerator = sum(
        max(0.0, float(weight))
        for name, weight in weights.items()
        if bool(checks.get(name, {}).get("passed"))
    )
    return numerator, denominator


def binary_outcome(*, required_checks_pass: bool, integrity_ok: bool) -> float:
    return 1.0 if required_checks_pass and integrity_ok else 0.0


def calculate_training_score(
    *,
    d_num: float,
    d_den: float,
    n_num: float = 0.0,
    n_den: float = 0.0,
    nondeterministic_lambda: float = 0.0,
    integrity_ok: bool = True,
    rewardkit_available: bool = True,
) -> float:
    if not integrity_ok:
        return 0.0
    d_num = max(0.0, float(d_num))
    d_den = max(0.0, float(d_den))
    n_num = max(0.0, float(n_num))
    n_den = max(0.0, float(n_den))
    weight = parse_lambda(nondeterministic_lambda)
    if not rewardkit_available or weight == 0.0 or n_den == 0.0:
        return clamp01(d_num / d_den) if d_den else 0.0
    denominator = d_den + weight * n_den
    if denominator == 0.0:
        return 0.0
    return clamp01((d_num + weight * n_num) / denominator)


def formula_text(
    *,
    d_num: float,
    d_den: float,
    n_num: float,
    n_den: float,
    nondeterministic_lambda: float,
    result: float,
) -> str:
    return (
        f"({d_num:.6f} + {nondeterministic_lambda:.6f} * {n_num:.6f}) / "
        f"({d_den:.6f} + {nondeterministic_lambda:.6f} * {n_den:.6f}) "
        f"= {result:.6f}"
    )
