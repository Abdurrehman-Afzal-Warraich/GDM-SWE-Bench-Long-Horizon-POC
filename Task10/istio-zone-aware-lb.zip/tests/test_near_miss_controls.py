"""Near-miss and negative-control self-tests for critical gate wiring."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

import stage_check
from stage_check import CRITICAL_CHECKS, WEIGHTS, write_ctrf, write_reward
from score_formula import binary_outcome


@pytest.mark.parametrize("stage", list(CRITICAL_CHECKS))
def test_each_critical_check_is_weighted(stage: str) -> None:
    for name in CRITICAL_CHECKS[stage]:
        assert name in WEIGHTS[stage]
        assert WEIGHTS[stage][name] > 0.0


@pytest.mark.parametrize(
    ("stage", "failed_check"),
    [
        ("01-diagnose", "reproducer_present"),
        ("02-self-discovery-bootstrap", "hidden_tests_pass"),
        ("03-eds-loadbalancer", "build_clean"),
        ("04-config-harden", "full_build"),
    ],
)
def test_critical_failure_zeros_binary(stage: str, failed_check: str, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    result_dir = tmp_path / "verifier" / stage
    result_dir.mkdir(parents=True)
    monkeypatch.setattr(stage_check, "RESULT_DIR", result_dir)
    checks = {name: {"passed": True, "detail": "ok"} for name in WEIGHTS[stage]}
    checks[failed_check] = {"passed": False, "detail": "seeded near-miss"}
    integrity = {"passed": True, "findings": []}
    required = all(bool(checks.get(name, {}).get("passed")) for name in CRITICAL_CHECKS[stage])
    binary = binary_outcome(required_checks_pass=required, integrity_ok=True)
    assert binary == 0.0
    reward_binary = write_reward(stage, checks, integrity)
    assert reward_binary == 0.0


def test_integrity_failure_zeros_binary(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    stage = "02-self-discovery-bootstrap"
    result_dir = tmp_path / "verifier" / stage
    result_dir.mkdir(parents=True)
    monkeypatch.setattr(stage_check, "RESULT_DIR", result_dir)
    checks = {name: {"passed": True, "detail": "ok"} for name in WEIGHTS[stage]}
    integrity = {"passed": False, "findings": ["seeded integrity fail"]}
    assert write_reward(stage, checks, integrity) == 0.0


def test_write_ctrf_marks_failed_check(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    stage = "01-diagnose"
    result_dir = tmp_path / "verifier"
    result_dir.mkdir()
    monkeypatch.setattr(stage_check, "RESULT_DIR", result_dir)
    checks = {name: {"passed": True, "detail": "ok"} for name in WEIGHTS[stage]}
    checks["reproducer_present"] = {"passed": False, "detail": "missing reproducer"}
    integrity = {"passed": True, "findings": []}
    write_ctrf(stage, checks, integrity)
    payload = json.loads((result_dir / "ctrf.json").read_text(encoding="utf-8"))
    assert payload["results"]["tool"]["name"] == stage_check.CTRF_TOOL_NAME
    assert payload["results"]["summary"]["failed"] >= 1
    names = {entry["name"] for entry in payload["results"]["tests"]}
    assert "reproducer_present" in names
    assert "integrity" in names


def test_write_ctrf_green_stage_has_no_failed_entries(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    stage = "02-self-discovery-bootstrap"
    result_dir = tmp_path / "verifier"
    result_dir.mkdir()
    monkeypatch.setattr(stage_check, "RESULT_DIR", result_dir)
    monkeypatch.setattr(stage_check, "_CTRF_GO_RUNS", ["--- PASS: TestBootstrapPackagesBuild (0.01s)\n"])
    checks = {name: {"passed": True, "detail": "ok"} for name in WEIGHTS[stage]}
    integrity = {"passed": True, "findings": []}
    write_ctrf(stage, checks, integrity)
    payload = json.loads((result_dir / "ctrf.json").read_text(encoding="utf-8"))
    assert payload["results"]["summary"]["failed"] == 0
    assert payload["results"]["summary"]["passed"] == payload["results"]["summary"]["tests"]
