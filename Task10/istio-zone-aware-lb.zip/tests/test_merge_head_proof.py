"""Author-side merge-head proof: incremental golden patches cover the full upstream diff."""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

PKG = Path(__file__).resolve().parents[1]
STEPS = PKG / "steps"
ENV = PKG / "environment"

STAGES = [
    "02-self-discovery-bootstrap",
    "03-eds-loadbalancer",
    "04-config-harden",
]
MERGE_COMMIT = "cb9728f907e7dd5d1fb7f625c96464e989857aee"
BASE_COMMIT = "d17a4626923d3cb48ae7dafd2ef579ae1da8c5d8"
ORACLE_REFERENCE_FILE_COUNT = 46


def patch_files(path: Path) -> list[str]:
    text = path.read_text(encoding="utf-8", errors="replace")
    pairs = re.findall(r"^diff --git a/(.+?) b/(.+?)$", text, re.MULTILINE)
    assert pairs and all(a == b for a, b in pairs), f"rename drift in {path.name}"
    return sorted(a for a, _ in pairs)


def provenance_union() -> set[str]:
    files: set[str] = set()
    for stage in STAGES:
        prov = json.loads((STEPS / stage / "solution" / "provenance.json").read_text(encoding="utf-8"))
        files.update(prov["files"])
    return files


def test_provenance_union_file_count() -> None:
    files = provenance_union()
    assert len(files) == ORACLE_REFERENCE_FILE_COUNT


def test_incremental_patches_match_provenance() -> None:
    for stage in STAGES:
        prov = json.loads((STEPS / stage / "solution" / "provenance.json").read_text(encoding="utf-8"))
        patch = patch_files(STEPS / stage / "solution" / "golden.patch")
        assert patch == sorted(prov["files"]), stage


def test_incremental_union_matches_provenance_and_full_patch() -> None:
    cumulative: set[str] = set()
    for stage in STAGES:
        cumulative.update(patch_files(STEPS / stage / "solution" / "golden.patch"))
    scoped = provenance_union()
    assert cumulative == scoped
    full = set(patch_files(STEPS / "04-config-harden" / "solution" / "golden_full.patch"))
    assert scoped <= full, sorted(full - scoped)[:8]
    extra = full - scoped
    assert extra, "golden_full.patch should include upstream test-only files beyond agent scope"
    assert all(
        path.endswith("_test.go") or path.startswith("tests/integration/")
        for path in extra
    ), sorted(extra)


def test_merge_reference_manifest_matches_provenance() -> None:
    manifest_path = ENV / "merge_reference_manifest.json"
    assert manifest_path.is_file(), "author-only merge manifest required for QC proof"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    files = provenance_union()
    assert manifest["base_commit"] == BASE_COMMIT
    assert manifest["merge_commit"] == MERGE_COMMIT
    assert manifest["file_count"] == ORACLE_REFERENCE_FILE_COUNT
    assert set(manifest["files"]) == files
    full_patch = STEPS / "04-config-harden" / "solution" / "golden_full.patch"
    digest = hashlib.sha256(full_patch.read_bytes()).hexdigest()
    assert manifest["golden_full_patch_sha256"] == digest


def test_dockerfile_does_not_ship_merge_manifest() -> None:
    docker = (ENV / "Dockerfile").read_text(encoding="utf-8")
    assert "merge_reference_manifest.json" not in docker
    assert "/opt/merge_reference_manifest.json" not in docker
