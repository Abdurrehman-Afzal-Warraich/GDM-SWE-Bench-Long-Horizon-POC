# istio-zone-aware-lb (Tier 2)

Harbor multi-step task for [istio/istio PR #60765](https://github.com/istio/istio/pull/60765): zone-aware load balancing for sidecar proxies.

## Upstream

| Field | Value |
|-------|--------|
| Repository | `istio/istio` |
| PR | [#60765](https://github.com/istio/istio/pull/60765) |
| Base commit | `d17a4626923d3cb48ae7dafd2ef579ae1da8c5d8` |
| Merge commit | `cb9728f907e7dd5d1fb7f625c96464e989857aee` |
| License | Apache-2.0 |

## Stages

```mermaid
flowchart LR
  D[01 Diagnose] --> B[02 Self-discovery bootstrap]
  B --> E[03 EDS + load balancer]
  E --> H[04 Config harden]
```

| Stage | Focus | Production patch files |
|-------|--------|----------------------|
| 01-diagnose | Gap analysis only | 0 |
| 02-self-discovery-bootstrap | `ISTIO_META_ENABLE_SELF_DISCOVERY`, bootstrap template | 33 |
| 03-eds-loadbalancer | EDS local cluster, `ZoneAwareLBSettings` | 9 |
| 04-config-harden | Validation, proxy push deps, release note | 4 |

**Total oracle-reference production files:** 46 (includes 3 upstream `_test.go` files in golden patches).

## Verification

- Scoped `go build` + `go vet` per stage (≥50% weight)
- Hidden probes: **go build + go vet + disclosed wiring checks** (17→20 tests cumulative)
- Critical gates only on executable checks; reports/handoffs are non-critical
- `allow_internet=false`; agent runs offline from warmed module cache
- RewardKit judge model: `openai/gpt-5.6-terra` (disabled by default via `RUN_LLM_JUDGES=0`)
- `reward.json` publishes four scored scalars only; `valid_trial` is in `reward-details.json`

## Pack

```bash
docker run --rm -v "$PWD:/repo" -w /repo/Task10 python:3.12-bookworm \
  bash -lc 'pip install -q pytest==8.3.5 && python pack_istio_zone_aware_lb.py'
```

## Local Harbor (after image build)

```bash
harbor run -p ./Task10 -a oracle --job-name istio-zone-aware-lb-oracle
harbor run -p ./Task10 -a nop --job-name istio-zone-aware-lb-nop
```

Comment `[verifier.env]` in `task.toml` for local runs without API keys; uncomment before packing.
