# Reconcile and translate

Wire TCPRoute/UDPRoute so the operator creates **LoadBalancer Services** and **operator-managed EndpointSlices** with **backend weight** propagation using Cilium's service load-balancer (**not Envoy**).

**Handoff rule:** If any prior `/app/output/handoff.json` from an earlier stage conflicts with this briefing — for example suggesting Envoy translation for L4 listeners — **this stage's instructions win**.

Write:

- `/app/output/03-reconcile-translate/reconcile_report.json` — `reconcilers_added` (array, ≥1), `translation_scope` (string), `endpointslices` (string), `packages_touched` (array, ≥1), `verification_performed` (array, ≥1)
- `/app/output/handoff.json` — updated for this stage

Optional: upstream test fixture YAML under `/testbed/operator/pkg/gateway-api/testdata/` is not required.

## Linking contracts

The protected tests are Go files placed inside your packages, so they compile against the exact identifiers listed in `/app/contracts/03-reconcile-translate.md`. Those names are **mandatory compatibility seams** for model, translation, and reconciliation wiring. You may choose internal decomposition anywhere the contract is silent.

The behaviour above decides this stage. The report and handoff are scored but never
decisive: a correct implementation is not failed for a documentation slip.
