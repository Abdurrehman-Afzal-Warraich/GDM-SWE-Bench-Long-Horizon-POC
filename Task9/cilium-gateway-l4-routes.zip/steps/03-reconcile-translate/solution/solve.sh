#!/usr/bin/env bash
# Oracle, stage 03 — reconcile and translate L4 routes.
set -euo pipefail

OUT=/app/output
STAGE=03-reconcile-translate
STAGE_OUT="$OUT/$STAGE"
mkdir -p "$STAGE_OUT"
cd /testbed

git apply --whitespace=nowarn /solution/golden.patch
git add -A
git -c user.email=a@b.c -c user.name=oracle commit -q -m 'stage03: reconcile and translate l4 routes'

echo "== build =="
go build ./operator/pkg/gateway-api/... ./operator/pkg/model/...
echo "== test sample =="
go test -count=1 ./operator/pkg/gateway-api/... -run 'TestTranslate|TestReconcile' 2>/dev/null | tail -20 || true

python3 - <<'PY'
import json, subprocess
from pathlib import Path

changed = subprocess.check_output(["git", "show", "--pretty=format:", "--name-only", "HEAD"], text=True).splitlines()
packages = sorted({str(Path(p).parent) for p in changed if p.strip()})
stage_out = Path("/app/output/03-reconcile-translate")
out = Path("/app/output")

(stage_out / "reconcile_report.json").write_text(json.dumps({
    "reconcilers_added": [
        "endpointslice_reconcile",
        "gateway TCP/UDP route attachment handling",
    ],
    "translation_scope": "L4 listeners translate to LoadBalancer Services and operator-managed EndpointSlices with backend weights.",
    "endpointslices": "Dedicated reconciler keeps EndpointSlices synchronized as backends change.",
    "packages_touched": packages[:20],
    "verification_performed": [
        "go build ./operator/pkg/gateway-api/...",
        "go build ./operator/pkg/model/...",
        "sample gateway-api tests",
    ],
}, indent=2) + "\n", encoding="utf-8")

(out / "handoff.json").write_text(json.dumps({
    "stage": "03-reconcile-translate",
    "summary": "Gateway operator reconciles TCPRoute/UDPRoute into Services and EndpointSlices; model ingestion/translation updated.",
    "next_steps": [
        "Force Helm Maglev/hostns config when Gateway API is enabled.",
        "Run cumulative verification and implementation closure proof.",
    ],
}, indent=2) + "\n", encoding="utf-8")
PY

echo "stage 03 complete"
