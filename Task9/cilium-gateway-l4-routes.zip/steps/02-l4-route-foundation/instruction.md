# L4 foundation

Implement TCPRoute/UDPRoute foundation in `/testbed`: operator helpers, indexers, routechecks, and operator RBAC for `tcproutes`/`udproutes`.

**Handoff rule:** If any prior `/app/output/handoff.json` from an earlier stage conflicts with this briefing, **this stage's instructions win**.

Write:

- `/app/output/02-l4-route-foundation/foundation.json` — `rbac_scope` (string), `helper_packages` (array, ≥1), `indexer_coverage` (string), `routecheck_scope` (string)
- `/app/output/handoff.json` — updated for this stage

## Routecheck behaviour the verifier grades

Your routecheck layer must reject invalid Gateway parent references and incompatible listener ports, and must report the supported protocol set for each route kind (TCP for TCPRoute, UDP for UDPRoute). The protected tests exercise `TCPRouteInput` / `UDPRouteInput` together with the shared gateway validation helpers.

## Linking contracts

The protected tests are Go files placed inside your packages, so they compile against the exact identifiers listed in `/app/contracts/02-l4-route-foundation.md`. Those names are **mandatory compatibility seams**. You may choose file layout, helper decomposition, and internal structure anywhere the contract is silent.

The behaviour above decides this stage. The report and handoff are scored but never
decisive: a correct implementation is not failed for a documentation slip.
