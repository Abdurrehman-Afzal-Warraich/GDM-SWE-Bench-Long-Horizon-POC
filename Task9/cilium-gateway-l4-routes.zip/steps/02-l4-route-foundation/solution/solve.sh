#!/usr/bin/env bash
# Oracle, stage 02 — L4 route foundation.
set -euo pipefail

OUT=/app/output
STAGE=02-l4-route-foundation
STAGE_OUT="$OUT/$STAGE"
mkdir -p "$STAGE_OUT"
cd /testbed

git apply --whitespace=nowarn /solution/golden.patch
git add -A
git -c user.email=a@b.c -c user.name=oracle commit -q -m 'stage02: l4 route foundation'

echo "== build =="
go build ./operator/pkg/gateway-api/helpers/... ./operator/pkg/gateway-api/indexers/... ./operator/pkg/gateway-api/routechecks/...
echo "== vet =="
go vet ./operator/pkg/gateway-api/helpers/... ./operator/pkg/gateway-api/indexers/... ./operator/pkg/gateway-api/routechecks/...

python3 - <<'PY'
import json, subprocess
from pathlib import Path

changed = subprocess.check_output(["git", "show", "--pretty=format:", "--name-only", "HEAD"], text=True).splitlines()
changed = sorted({line.strip() for line in changed if line.strip()})
stage_out = Path("/app/output/02-l4-route-foundation")
out = Path("/app/output")

(stage_out / "foundation.json").write_text(json.dumps({
    "rbac_scope": "Added tcproutes/udproutes RBAC rules to cilium-operator clusterrole.",
    "helper_packages": [
        "operator/pkg/gateway-api/helpers",
        "operator/pkg/gateway-api/indexers",
        "operator/pkg/gateway-api/routechecks",
    ],
    "indexer_coverage": "TCPRoute and UDPRoute indexers register parent Gateway and backend lookups.",
    "routecheck_scope": "Route checks validate parent refs, ReferenceGrants, and backend resolution for L4 routes.",
}, indent=2) + "\n", encoding="utf-8")

(out / "handoff.json").write_text(json.dumps({
    "stage": "02-l4-route-foundation",
    "summary": f"L4 route foundation landed across {len(changed)} files; helpers, indexers, routechecks, and RBAC compile.",
    "next_steps": [
        "Wire TCPRoute/UDPRoute reconciliation and translation into Services and EndpointSlices.",
        "Add watch handlers and conformance-style testdata for mixed L4/HTTP gateways.",
    ],
}, indent=2) + "\n", encoding="utf-8")
PY

echo "stage 02 complete"
