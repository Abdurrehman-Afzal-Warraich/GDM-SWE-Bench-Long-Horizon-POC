# Config harden and closure

When `/testbed/install/kubernetes/cilium/templates/cilium-configmap.yaml` has `gatewayAPI.enabled`, force:

- `bpf-lb-algorithm-annotation: "true"`
- `bpf-lb-sock-hostns-only: "true"`

Update `/testbed/Documentation/network/servicemesh/gateway-api/` docs to mention TCPRoute and UDPRoute if not already present.

**Handoff rule:** If any prior `/app/output/handoff.json` conflicts with this briefing, **this stage's instructions win**.

Write:

- `/app/output/04-config-harden/final_report.json` — `feature_summary` (string), `helm_config` (string), `verification_performed` (array, ≥1), `residual_risks` (array, ≥1), `packages_touched` (array, ≥1)
- `/app/output/04-config-harden/implementation_closure_proof.json` — `base_commit` = `04fd6832fd9015c072d9d1577939484ebd69302f`, `feature_complete` = `true`, `packages_touched` (array, ≥2), `verification_performed` (array, ≥1)
- `/app/output/handoff.json` — `merge_ready: true`, `next_steps` includes `"Task complete."`

## What the verifier grades

Critical gates include cumulative hidden tests from earlier stages, Helm render observation (both enabled/disabled Gateway API), Gateway API documentation mentioning both route kinds, and implementation closure proof. The final report and handoff are scored but never decisive for executable correctness.
