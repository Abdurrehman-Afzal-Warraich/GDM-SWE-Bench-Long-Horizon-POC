#!/usr/bin/env bash
# Oracle, stage 04 — config hardening and cumulative closure.
set -euo pipefail

OUT=/app/output
STAGE=04-config-harden
STAGE_OUT="$OUT/$STAGE"
mkdir -p "$STAGE_OUT"
cd /testbed

git apply --whitespace=nowarn /solution/golden.patch
git add -A
git -c user.email=a@b.c -c user.name=oracle commit -q -m 'stage04: config harden and closure'

echo "== build =="
go build ./operator/pkg/gateway-api/... ./operator/pkg/model/...

python3 - <<'PY'
import json
from pathlib import Path

stage_out = Path("/app/output/04-config-harden")
out = Path("/app/output")

(stage_out / "final_report.json").write_text(json.dumps({
    "feature_summary": "Cilium Gateway API operator supports TCPRoute and UDPRoute via Cilium-native LB without Envoy.",
    "helm_config": "Helm configmap forces bpf-lb-algorithm-annotation and bpf-lb-sock-hostns-only when gatewayAPI.enabled.",
    "verification_performed": [
        "go build ./operator/pkg/gateway-api/...",
        "go build ./operator/pkg/model/...",
        "cumulative hidden verifier probes",
        "implementation closure proof",
    ],
    "residual_risks": [
        "Downstream cilium/proxy conformance may need separate UDPRoute CRD install updates.",
    ],
    "packages_touched": [
        "operator/pkg/gateway-api",
        "operator/pkg/model",
        "install/kubernetes/cilium/templates",
    ],
}, indent=2) + "\n", encoding="utf-8")

(stage_out / "implementation_closure_proof.json").write_text(json.dumps({
    "base_commit": "04fd6832fd9015c072d9d1577939484ebd69302f",
    "feature_complete": True,
    "packages_touched": [
        "operator/pkg/gateway-api",
        "operator/pkg/model",
        "install/kubernetes/cilium/templates",
    ],
    "verification_performed": [
        "go build ./operator/pkg/gateway-api/...",
        "go build ./operator/pkg/model/...",
        "hidden verifier probes",
    ],
}, indent=2) + "\n", encoding="utf-8")

(out / "handoff.json").write_text(json.dumps({
    "stage": "04-config-harden",
    "summary": "Cumulative L4 Gateway API support complete with behavioral closure.",
    "next_steps": ["Task complete."],
    "merge_ready": True,
}, indent=2) + "\n", encoding="utf-8")
PY

echo "stage 04 complete"
