#!/usr/bin/env bash
# Oracle, stage 01 — diagnosis only (no production edits).
set -euo pipefail

OUT=/app/output
STAGE=01-diagnose
STAGE_OUT="$OUT/$STAGE"
mkdir -p "$STAGE_OUT"
cd /testbed

cat > "$STAGE_OUT/reproduce.sh" <<'REPRO'
#!/usr/bin/env bash
set -uo pipefail
cd /testbed
echo "== TCPRoute/UDPRoute helper packages =="
if [ -f operator/pkg/gateway-api/helpers/tcproute.go ]; then
  echo "unexpected: tcproute helper already present"
else
  echo "GAP: operator/pkg/gateway-api/helpers/tcproute.go missing"
fi
if [ -f operator/pkg/gateway-api/helpers/udproute.go ]; then
  echo "unexpected: udproute helper already present"
else
  echo "GAP: operator/pkg/gateway-api/helpers/udproute.go missing"
fi
echo "== endpointslice reconciler =="
if [ -f operator/pkg/gateway-api/endpointslice_reconcile.go ]; then
  echo "unexpected: endpointslice reconciler already present"
else
  echo "GAP: dedicated EndpointSlice reconciliation for L4 routes absent"
fi
echo "== operator RBAC for L4 routes =="
if grep -q tcproutes install/kubernetes/cilium/templates/cilium-operator/clusterrole.yaml 2>/dev/null; then
  echo "unexpected: tcproutes RBAC already present"
else
  echo "GAP: clusterrole lacks tcproutes/udproutes permissions"
fi
exit 1
REPRO
chmod +x "$STAGE_OUT/reproduce.sh"
bash "$STAGE_OUT/reproduce.sh" >/tmp/repro.out 2>&1 || true

python3 - <<'PY'
import json
from pathlib import Path

out = Path("/app/output")
stage_out = out / "01-diagnose"
(stage_out / "diagnosis.json").write_text(json.dumps({
    "missing_capabilities": [
        "TCPRoute reconciliation in the Gateway API operator",
        "UDPRoute reconciliation in the Gateway API operator",
        "Operator-managed EndpointSlices for L4 backend weights",
        "RBAC and route checks for tcproutes/udproutes resources",
    ],
    "affected_packages": [
        "operator/pkg/gateway-api",
        "operator/pkg/model/ingestion",
        "operator/pkg/model/translation/gateway-api",
        "install/kubernetes/cilium/templates/cilium-operator",
    ],
    "reproducer": "/app/output/01-diagnose/reproduce.sh",
    "root_cause": (
        "The Gateway API operator reconciles HTTP/Gamma routes but does not yet "
        "translate TCPRoute and UDPRoute attachments into Cilium-native LoadBalancer "
        "Services and EndpointSlices for Maglev load-balancing."
    ),
}, indent=2) + "\n", encoding="utf-8")

(out / "handoff.json").write_text(json.dumps({
    "stage": "01-diagnose",
    "summary": (
        "Base lacks TCPRoute/UDPRoute helpers, L4 route checks, EndpointSlice "
        "reconciliation, and operator RBAC for tcproutes/udproutes."
    ),
    "next_steps": [
        "Add RBAC, helpers, indexers, and routechecks for TCPRoute/UDPRoute.",
        "Implement gateway reconciliation, translation, and EndpointSlice sync.",
        "Harden Helm config for Maglev backend weights when Gateway API is enabled.",
    ],
}, indent=2) + "\n", encoding="utf-8")
PY

echo "stage 01 complete"
