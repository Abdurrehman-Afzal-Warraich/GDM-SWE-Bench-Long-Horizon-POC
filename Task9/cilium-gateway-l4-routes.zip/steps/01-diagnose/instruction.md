# Diagnose

At `/testbed`, determine why Cilium's Gateway API operator lacks **TCPRoute** and **UDPRoute** support. **Do not modify** `/testbed`.

Write:

- `/app/output/01-diagnose/reproduce.sh` — must exit non-zero and its output must include **tcproute**, **udproute**, and **gateway-api** or **endpointslices**
- `/app/output/01-diagnose/diagnosis.json` — `missing_capabilities` (array, ≥1), `affected_packages` (array, ≥1), `reproducer` (string), `root_cause` (string)
- `/app/output/handoff.json` — `stage` (string), `summary` (string), `next_steps` (array, ≥1)

The reproducer, `diagnosis.json` and `handoff.json` decide this stage: a missing or
malformed one fails it. They are this stage's product.
