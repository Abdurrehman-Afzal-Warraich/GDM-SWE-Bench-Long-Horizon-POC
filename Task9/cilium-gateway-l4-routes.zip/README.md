# cilium-gateway-l4-routes

Tier 2 multi-step Harbor task: add **TCPRoute** and **UDPRoute** support to the Cilium Gateway API operator (cilium/cilium).

## Source change

| Field | Value |
|---|---|
| Repository | cilium/cilium (Apache-2.0) |
| Base commit | `04fd6832fd9015c072d9d1577939484ebd69302f` |
| Merge commit | `cd9a3ce2d9cd1c8004e18587ec5fbc77f43c5c61` |
| Scoped oracle reference | 71 production paths in golden patches |
| Merged | 2026-06-10 |

## Stages

```mermaid
flowchart LR
  S1[01-diagnose] --> S2[02-l4-route-foundation]
  S2 --> S3[03-reconcile-translate]
  S3 --> S4[04-config-harden]
```

1. **Diagnose** — identify missing L4 route reconciliation (no production edits)
2. **Foundation** — RBAC, helpers, indexers, routechecks
3. **Reconcile/translate** — Services, EndpointSlices, gateway/model translation
4. **Config harden** — Helm Maglev options + behavioral implementation closure

## Linking contracts

Graded hidden tests compile against identifiers published at `/app/contracts/<stage>.md` (read-only, image-built). See `tests/contracts/` for the requirement map and artifact schemas.

## Package layout

- `task.toml` — Harbor schema 1.3, `allow_internet = false` on environment and every step
- `environment/Dockerfile` — sanitized testbed, verifier venv, linking contracts
- `steps/<stage>/instruction.md` — agent briefing per stage
- `tests/stage_check.py` — deterministic grader (build/vet/hidden corpus)
- `tests/hidden/` — withheld upstream behavioral probes (injected only in verifier sandbox at grade time)

## Local development

```bash
python3 -m pytest -q tests/test_reward_contract.py tests/test_package_contract.py
docker build -t lh-cilium-l4:v3 environment/
bash tools/docker_verify.sh
```

Oracle `solve.sh` scripts apply cumulative `golden.patch` per stage and run real `go build` / `go vet` — not decrypt-only patch replay.
