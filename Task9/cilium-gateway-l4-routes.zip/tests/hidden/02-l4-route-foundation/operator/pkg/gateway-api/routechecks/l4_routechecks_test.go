// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

package routechecks

import (
	"context"
	"log/slog"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/utils/ptr"
	"sigs.k8s.io/controller-runtime/pkg/client/fake"
	gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"
	gatewayv1alpha2 "sigs.k8s.io/gateway-api/apis/v1alpha2"
)

func TestTCPRouteInputValidProtocols(t *testing.T) {
	input := &TCPRouteInput{
		TCPRoute: &gatewayv1alpha2.TCPRoute{
			ObjectMeta: metav1.ObjectMeta{Name: "tcp", Namespace: "default"},
		},
	}
	assert.Equal(t, []gatewayv1.ProtocolType{gatewayv1.TCPProtocolType}, input.GetValidProtocols())
}

func TestUDPRouteInputValidProtocols(t *testing.T) {
	input := &UDPRouteInput{
		UDPRoute: &gatewayv1alpha2.UDPRoute{
			ObjectMeta: metav1.ObjectMeta{Name: "udp", Namespace: "default"},
		},
	}
	assert.Equal(t, []gatewayv1.ProtocolType{gatewayv1.UDPProtocolType}, input.GetValidProtocols())
}

func TestCheckGatewayRouteKindAllowed_rejectsWrongKind(t *testing.T) {
	scheme := runtime.NewScheme()
	require.NoError(t, gatewayv1.Install(scheme))
	require.NoError(t, gatewayv1alpha2.Install(scheme))

	route := &gatewayv1alpha2.TCPRoute{
		ObjectMeta: metav1.ObjectMeta{Name: "r", Namespace: "ns"},
		Spec: gatewayv1alpha2.TCPRouteSpec{
			CommonRouteSpec: gatewayv1.CommonRouteSpec{
				ParentRefs: []gatewayv1.ParentReference{{
					Name:  "parent",
					Kind:  ptr.To(gatewayv1.Kind("Service")),
					Group: ptr.To(gatewayv1.Group("core")),
				}},
			},
		},
	}
	cl := fake.NewClientBuilder().WithScheme(scheme).WithObjects(route).Build()
	input := &TCPRouteInput{
		Ctx:      context.Background(),
		Client:   cl,
		Logger:   slog.Default(),
		TCPRoute: route,
	}
	parent := route.Spec.ParentRefs[0]
	CheckGatewayRouteKindAllowed(input, parent)
	require.NotEmpty(t, route.Status.Parents)
	cond := route.Status.Parents[0].Conditions[0]
	assert.Equal(t, string(gatewayv1.RouteConditionAccepted), cond.Type)
	assert.Equal(t, metav1.ConditionFalse, cond.Status)
}

func TestCheckGatewayRouteKindAllowed_missingGateway(t *testing.T) {
	scheme := runtime.NewScheme()
	require.NoError(t, gatewayv1.Install(scheme))
	require.NoError(t, gatewayv1alpha2.Install(scheme))

	route := &gatewayv1alpha2.TCPRoute{
		ObjectMeta: metav1.ObjectMeta{Name: "r", Namespace: "ns"},
		Spec: gatewayv1alpha2.TCPRouteSpec{
			CommonRouteSpec: gatewayv1.CommonRouteSpec{
				ParentRefs: []gatewayv1.ParentReference{{
					Name: "missing-gw",
				}},
			},
		},
	}
	cl := fake.NewClientBuilder().WithScheme(scheme).WithObjects(route).Build()
	input := &TCPRouteInput{
		Ctx:      context.Background(),
		Client:   cl,
		Logger:   slog.Default(),
		TCPRoute: route,
	}
	CheckGatewayRouteKindAllowed(input, route.Spec.ParentRefs[0])
	require.NotEmpty(t, route.Status.Parents)
	assert.Equal(t, metav1.ConditionFalse, route.Status.Parents[0].Conditions[0].Status)
}

func TestCheckGatewayMatchingPorts_rejectsWrongPort(t *testing.T) {
	scheme := runtime.NewScheme()
	require.NoError(t, gatewayv1.Install(scheme))
	require.NoError(t, gatewayv1alpha2.Install(scheme))

	gw := &gatewayv1.Gateway{
		ObjectMeta: metav1.ObjectMeta{Name: "gw", Namespace: "ns"},
		Spec: gatewayv1.GatewaySpec{
			GatewayClassName: "cilium",
			Listeners: []gatewayv1.Listener{{
				Name:     "tcp",
				Protocol: gatewayv1.TCPProtocolType,
				Port:     8080,
			}},
		},
	}
	route := &gatewayv1alpha2.TCPRoute{
		ObjectMeta: metav1.ObjectMeta{Name: "r", Namespace: "ns"},
		Spec: gatewayv1alpha2.TCPRouteSpec{
			CommonRouteSpec: gatewayv1.CommonRouteSpec{
				ParentRefs: []gatewayv1.ParentReference{{
					Name: "gw",
					Port: ptr.To(gatewayv1.PortNumber(9090)),
				}},
			},
		},
	}
	cl := fake.NewClientBuilder().WithScheme(scheme).WithObjects(gw, route).Build()
	input := &TCPRouteInput{
		Ctx:      context.Background(),
		Client:   cl,
		Logger:   slog.Default(),
		TCPRoute: route,
	}
	parent := route.Spec.ParentRefs[0]
	CheckGatewayMatchingPorts(input, parent)
	require.NotEmpty(t, route.Status.Parents)
	cond := route.Status.Parents[0].Conditions[0]
	assert.Equal(t, string(gatewayv1.RouteConditionAccepted), cond.Type)
	assert.Equal(t, metav1.ConditionFalse, cond.Status)
	assert.Equal(t, string(gatewayv1.RouteReasonNoMatchingParent), cond.Reason)
}
