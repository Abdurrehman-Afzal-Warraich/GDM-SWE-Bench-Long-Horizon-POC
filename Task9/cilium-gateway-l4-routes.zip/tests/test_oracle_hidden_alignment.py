"""Ensure hidden verifier probes match oracle golden patches before upload."""
from __future__ import annotations

import re
from pathlib import Path

PKG = Path(__file__).resolve().parents[1]
STEPS = PKG / "steps"
HIDDEN = PKG / "tests" / "hidden"
PATCH_STAGES = [
    "02-l4-route-foundation",
    "03-reconcile-translate",
    "04-config-harden",
]

PATH_RE = re.compile(r'"(operator/[^"]+|install/[^"]+|Documentation/[^"]+)"')
CONTAINS_RE = re.compile(r'strings\.Contains\(text,\s*(?:"([^"]+)"|`([^`]+)`)')


def cumulative_patch_text() -> str:
    parts: list[str] = []
    for stage in PATCH_STAGES:
        parts.append((STEPS / stage / "solution" / "golden.patch").read_text(encoding="utf-8", errors="replace"))
    return "\n".join(parts)


def patch_file_paths() -> set[str]:
    paths: set[str] = set()
    for line in cumulative_patch_text().splitlines():
        if line.startswith("diff --git a/"):
            match = re.match(r"diff --git a/(.+?) b/", line)
            if match:
                paths.add(match.group(1))
    return paths


def hidden_probe_sources() -> list[Path]:
    return sorted(HIDDEN.rglob("*_test.go"))


def referenced_file_paths(source: str) -> set[str]:
    refs: set[str] = set()
    for raw in PATH_RE.findall(source):
        if raw.endswith("/"):
            continue
        if "/" in raw and "." not in Path(raw).name:
            # directory probe (e.g. routechecks/) — validated by build, not patch header
            continue
        refs.add(raw)
    return refs


def test_hidden_probe_file_paths_are_in_golden_patches():
    patch_paths = patch_file_paths()
    missing: list[str] = []
    for src in hidden_probe_sources():
        refs = referenced_file_paths(src.read_text(encoding="utf-8"))
        for rel in sorted(refs):
            if rel not in patch_paths:
                missing.append(f"{src.name}: {rel}")
    assert not missing, "hidden probe file paths missing from golden.patch headers:\n" + "\n".join(missing)


def test_hidden_probe_needles_are_in_cumulative_golden_patch():
    patch_text = cumulative_patch_text()
    missing: list[str] = []
    for src in hidden_probe_sources():
        text = src.read_text(encoding="utf-8")
        refs = referenced_file_paths(text)
        needles = [a or b for a, b in CONTAINS_RE.findall(text)]
        for needle in needles:
            if needle in patch_text:
                continue
            missing.append(f"{src.name}: needle {needle!r} (files={sorted(refs)})")
    assert not missing, "hidden probe strings absent from cumulative golden patches:\n" + "\n".join(missing)
