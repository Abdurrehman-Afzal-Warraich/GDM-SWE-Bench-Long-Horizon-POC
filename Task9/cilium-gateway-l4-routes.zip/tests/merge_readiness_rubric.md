# Merge-readiness rubric — Cilium Gateway API L4 routes

The executable verdict is already final. A terminal reviewer evaluates the six
standard dimensions declared in `merge_readiness/judge.toml`: repository
conventions, focused change, maintainability, architecture, useful tests and no
patch bloat.
