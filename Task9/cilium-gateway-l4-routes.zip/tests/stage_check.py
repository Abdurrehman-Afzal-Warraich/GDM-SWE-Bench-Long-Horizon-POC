#!/usr/bin/env python3
"""Deterministic stage grader for long-horizon/cilium-gateway-l4-routes."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from score_formula import (  # noqa: E402
    binary_outcome,
    calculate_training_score,
    clamp01,
    deterministic_components,
    parse_lambda,
)

TESTBED = Path(os.environ.get("TESTBED_DIR", "/testbed"))
OUTPUT = Path(os.environ.get("AGENT_OUTPUT_DIR", "/app/output"))
AGENT_LOGS = Path(os.environ.get("AGENT_LOGS_DIR", "/logs/agent"))
HIDDEN_ROOT = Path(os.environ.get("HIDDEN_TESTS_DIR", "/tests/hidden"))
GRADE_SANDBOX_ROOT = Path(os.environ.get("GRADE_SANDBOX_ROOT", "/opt/verifier-grade"))
RESULT_DIR = Path(os.environ.get("RESULT_DIR", "/logs/verifier"))
CTRF_TOOL_NAME = "cilium-gateway-l4-routes-verifier"
_CTRF_GO_RUNS: list[str] = []

STAGES = [
    "01-diagnose",
    "02-l4-route-foundation",
    "03-reconcile-translate",
    "04-config-harden",
]

STAGE_KEYS = {
    "diagnose": "01-diagnose",
    "foundation": "02-l4-route-foundation",
    "reconcile": "03-reconcile-translate",
    "harden": "04-config-harden",
}

GATEWAY_PACKAGES = [
    "./operator/pkg/gateway-api/...",
    "./operator/pkg/model/...",
    # The withheld corpus includes operator/pkg/ingress/ingress_reconcile_test.go: the change
    # shares the ingress translation path, and upstream guards it against regression there.
    "./operator/pkg/ingress/...",
]

# The graded corpus is the upstream test suite the PR shipped, injected at its real
# repository paths, so the packages under test are the real ones rather than a probe package.
STAGE_PKGS = {
    "02-l4-route-foundation": [
        "./operator/pkg/gateway-api/helpers/...",
        "./operator/pkg/gateway-api/indexers/...",
        "./operator/pkg/gateway-api/routechecks/...",
    ],
    "03-reconcile-translate": list(GATEWAY_PACKAGES),
    "04-config-harden": list(GATEWAY_PACKAGES),
}

STAGE_BUILD = {
    "02-l4-route-foundation": [
        "./operator/pkg/gateway-api/helpers/...",
        "./operator/pkg/gateway-api/indexers/...",
        "./operator/pkg/gateway-api/routechecks/...",
    ],
    "03-reconcile-translate": GATEWAY_PACKAGES,
    "04-config-harden": GATEWAY_PACKAGES,
}

DIAGNOSE_WEIGHTS = {
    "base_gap_observed": 0.25,
    "reproducer_present": 0.05,
    "reproducer_runs": 0.20,
    "reproducer_demonstrates_gap": 0.25,
    "diagnosis_report": 0.20,
    "handoff": 0.05,
}

DEPS_WEIGHTS = {
    "build_clean": 0.20,
    "hidden_tests_pass": 0.45,
    "vet_clean": 0.12,
    # Required by the stage-2 briefing and previously ungraded: an agent could skip the
    # operator ClusterRole entirely and still pass.
    "rbac_l4_routes": 0.13,
    "implementation_report": 0.07,
    "handoff": 0.03,
}

FRAMEWORK_WEIGHTS = {
    "build_clean": 0.20,
    "hidden_tests_pass": 0.50,
    "vet_clean": 0.15,
    "review_report": 0.10,
    "handoff": 0.05,
}

HARDEN_WEIGHTS = {
    "full_build": 0.15,
    "hidden_tests_pass": 0.48,
    "vet_clean": 0.10,
    "helm_l4_config": 0.10,
    # Required by the stage-4 briefing and previously ungraded.
    "docs_l4_routes": 0.07,
    "implementation_closure": 0.07,
    "final_report": 0.02,
    "merge_ready": 0.01,
}

WEIGHTS = {
    "01-diagnose": DIAGNOSE_WEIGHTS,
    "02-l4-route-foundation": DEPS_WEIGHTS,
    "03-reconcile-translate": FRAMEWORK_WEIGHTS,
    "04-config-harden": HARDEN_WEIGHTS,
}

# Every artifact a briefing lists under "Write:" now gates the stage. Previously the
# reports and the handoff were scored but non-critical, so a stage could be a binary
# success while the deliverables its own prompt demanded were absent -- a requirement
# stated to the agent and never enforced. The rule is now symmetric: if the prompt asks
# for it, it decides the stage; nothing is asked for that does not.
CRITICAL_CHECKS = {
    "01-diagnose": [
        "base_gap_observed",
        "reproducer_present",
        "reproducer_runs",
        "reproducer_demonstrates_gap",
        "diagnosis_report",
        "handoff",
    ],
    "02-l4-route-foundation": [
        "build_clean", "hidden_tests_pass", "vet_clean", "rbac_l4_routes",
    ],
    "03-reconcile-translate": ["build_clean", "hidden_tests_pass", "vet_clean"],
    "04-config-harden": [
        "full_build",
        "hidden_tests_pass",
        "vet_clean",
        "helm_l4_config",
        "implementation_closure",
        "docs_l4_routes",
    ],
}

# Only a genuine attempt to read the protected trees or the upstream answer counts.
# `git remote -v` is a read-only diagnostic and is NOT listed: an earlier revision
# invalidated trials for running it, which is exactly the "harmless command voids the
# run" defect. Adding or repointing a remote still counts.
LEAK_PATTERNS = [
    r"\b(?:cat|less|more|head|tail)\b[^|;&\n]*\s/(?:tests|solution)\b",
    r"\b(?:cp|rsync|install)\b[^|;&\n]*\s/(?:tests|solution)\b",
    r"\bgit\s+(?:fetch|clone|pull|ls-remote)\b",
    r"\bgit\s+remote\s+(?:add|set-url)\b",
    r"\bpulls?/5000\b",
]

# A command position: start of text, or after a separator that begins a new command.
# Without this anchor a tool name matched anywhere inside a heredoc body or a quoted
# payload -- which is how a written-out `cat` heredoc was read as the `ncat` tool.
_CMD_POS = r"(?:^|[\n;&|`]|\|\||&&|\$\()\s*(?:sudo\s+)?(?:env\s+\S+=\S+\s+)*"

# A network tool invoked at a command position, with an argument that is a URL or a
# host. Go import paths (k8s.io/...) are domain-shaped, so the anchor is what keeps
# them from matching: they are never the command being run.
NONLOCAL_EGRESS = re.compile(
    _CMD_POS
    + r"(?:curl|wget|nc|ncat|telnet|ssh|scp|sftp)\s+"
    + r"(?![^\n]*(?:127\.0\.0\.1|localhost|::1|0\.0\.0\.0))"
    + r"[^\n]*?(?:https?://|\b[a-z0-9-]+\.[a-z]{2,}\b)",
    re.IGNORECASE,
)

FORBIDDEN_COMMANDS = re.compile(
    _CMD_POS
    + r"(?:curl|wget|pip3?\s+install|go\s+(?:install|get)|apt(?:-get)?\s+install)\b"
    + r"|\bgit\s+(?:clone|fetch|pull|ls-remote)\b"
    + r"|\bgit\s+remote\s+(?:add|set-url)\b",
    re.IGNORECASE,
)

# Real network API usage only. The previous pattern matched the bare word "requests",
# so writing `handler.EnqueueRequestsFromMapFunc` through python voided the trial.
PYTHON_NETWORK = re.compile(
    r"\bpython3?\b[^\n]*?(?:"
    r"import\s+(?:requests|urllib|httpx|aiohttp)\b"
    r"|from\s+urllib\b"
    r"|requests\.(?:get|post|put|patch|delete|head|request|Session)\s*\("
    r"|urllib\.request\b"
    r"|http\.client\.[A-Za-z]"
    r"|httpx\.(?:get|post|Client|AsyncClient)\s*\("
    r"|aiohttp\.[A-Za-z]"
    r"|socket\.socket\s*\("
    r"|socket\.create_connection\s*\("
    r")",
    re.IGNORECASE,
)

INTEGRITY_RULE_NOTES = {
    "reference-solution leakage": "reading /tests or /solution, or fetching the upstream "
        "change, would hand the agent the answer",
    "forbidden command": "installs or repository fetches would change the pinned "
        "toolchain or bring in the upstream implementation",
    "forbidden python network use": "a language runtime can open a socket that command "
        "scanning would otherwise miss; matches real network APIs only, never the word "
        "'requests' appearing inside source the agent is writing",
    "non-local egress attempt": "a network client invoked at a command position with a "
        "remote target; heredoc bodies and file payloads are not commands",
}

_ESCAPES = ((r"\\n", "\n"), (r"\\r", "\r"), (r"\\t", "\t"))


def command_surface(line: str) -> str:
    """The text to scan for a recorded command.

    Trajectories store commands JSON-escaped, so a newline arrives as the two
    characters backslash-n. Left alone, "...\\ncat << EOF" contains the literal
    substring "ncat" and matched the ncat tool. Decode the escapes first so a line
    break is a line break, and the anchors above can do their job.
    """
    text = line
    for src, dst in _ESCAPES:
        text = re.sub(src, dst, text)
    return text


ORACLE_REFERENCE_FILE_COUNT = 71
# Capabilities that must exist somewhere in the given package, identified by a symbol the
# contract already discloses rather than by filename. The previous version required exact
# paths: a real solver implemented the reconciler in endpointslice_reconciler.go and was
# failed for not calling it endpointslice_reconcile.go, which grades internal layout.
# Files whose path IS the contract (Helm templates the chart loads by name) stay exact.
CRITICAL_IMPLEMENTATION_CAPABILITIES = (
    ("operator/pkg/gateway-api/helpers", "TCPRoute helper", "TCPRoute"),
    ("operator/pkg/gateway-api/helpers", "UDPRoute helper", "UDPRoute"),
    ("operator/pkg/gateway-api", "EndpointSlice reconciler", "endpointSliceReconciler"),
    ("operator/pkg/model/translation/gateway-api", "L4 EndpointSlice translation",
     "desiredL4EndpointSlices"),
)
CRITICAL_IMPLEMENTATION_PATHS = (
    # Helm resolves these by path, so the path is the requirement, not a layout choice.
    "install/kubernetes/cilium/templates/cilium-operator/clusterrole.yaml",
    "install/kubernetes/cilium/templates/cilium-configmap.yaml",
)

HANDOFF_FIELDS = {"stage": str, "summary": str, "next_steps": list}
MAX_ARTIFACT_BYTES = 256 * 1024

ARTIFACT_SCHEMAS: dict[str, dict[str, object]] = {
    "01-diagnose": {
        "file": "diagnosis.json",
        "fields": {
            "missing_capabilities": list,
            "affected_packages": list,
            "reproducer": str,
            "root_cause": str,
        },
    },
    "02-l4-route-foundation": {
        "file": "foundation.json",
        "fields": {
            "rbac_scope": str,
            "helper_packages": list,
            "indexer_coverage": str,
            "routecheck_scope": str,
        },
    },
    "03-reconcile-translate": {
        "file": "reconcile_report.json",
        "fields": {
            "reconcilers_added": list,
            "translation_scope": str,
            "endpointslices": str,
            "packages_touched": list,
            "verification_performed": list,
        },
    },
    "04-config-harden": {
        "file": "final_report.json",
        "fields": {
            "feature_summary": str,
            "helm_config": str,
            "verification_performed": list,
            "residual_risks": list,
            "packages_touched": list,
        },
    },
}

TRUSTED_DIRS = [
    "/opt/verifier-venv/bin",
    "/usr/local/go/bin",
    "/usr/local/sbin",
    "/usr/local/bin",
    "/usr/sbin",
    "/usr/bin",
    "/sbin",
    "/bin",
]


def artifact_schema_document() -> dict:
    type_names = {str: "string", list: "array", dict: "object", bool: "boolean"}

    def properties(fields: dict) -> dict:
        out = {}
        for key, want in fields.items():
            entry: dict[str, object] = {"type": type_names[want]}
            if want is str:
                entry["minLength"] = 1
            elif want is list:
                entry["minItems"] = 1
            out[key] = entry
        return out

    stages = {}
    for stage, spec in ARTIFACT_SCHEMAS.items():
        fields = spec["fields"]
        stages[stage] = {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "title": f"{stage} :: /app/output/{stage}/{spec['file']}",
            "type": "object",
            "additionalProperties": True,
            "required": sorted(fields),
            "properties": properties(fields),
        }
    return {
        "maxBytes": MAX_ARTIFACT_BYTES,
        "handoff": {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "title": "/app/output/handoff.json",
            "type": "object",
            "additionalProperties": True,
            "required": sorted(HANDOFF_FIELDS),
            "properties": properties(HANDOFF_FIELDS),
        },
        "stageReports": stages,
    }


def resolve_stage(name: str) -> str:
    return STAGE_KEYS.get(name, name)


def in_container() -> bool:
    return Path("/testbed").is_dir() and Path("/opt/verifier-venv").is_dir()


def container_start_epoch() -> float | None:
    try:
        stat_fields = Path("/proc/1/stat").read_text(encoding="utf-8").split()
        starttime = int(stat_fields[21])
        uptime = float(Path("/proc/uptime").read_text(encoding="utf-8").split()[0])
        clock_ticks = os.sysconf("SC_CLK_TCK")
        return time.time() - uptime + (starttime / clock_ticks)
    except (OSError, ValueError, IndexError):
        return None


def verify_ctime_anchor(paths: list[str], slack_sec: float = 5.0) -> tuple[bool, dict]:
    """Detect userspace replacement of trusted toolchain binaries after container start."""
    if not in_container():
        return True, {"skipped": "ctime anchor enforced only in container runs"}
    start = container_start_epoch()
    if start is None:
        return True, {"skipped": "container start anchor unavailable"}
    violations: list[str] = []
    checked: dict[str, str] = {}
    for rel in paths:
        path = Path(rel)
        if not path.is_file():
            continue
        ctime = path.stat().st_ctime
        checked[str(path)] = "ok"
        if ctime > start + slack_sec:
            violations.append(f"{path} ctime {ctime:.0f} after container start {start:.0f}")
            checked[str(path)] = "post-start"
    return not violations, {
        "container_start_epoch": start,
        "checked": checked,
        "violations": violations,
        "slack_sec": slack_sec,
    }


def trusted_path() -> str:
    dirs = list(TRUSTED_DIRS)
    extra = os.environ.get("VERIFIER_EXTRA_PATH", "")
    if extra and not in_container():
        dirs = [d for d in extra.split(":") if d] + dirs
    return ":".join(dirs)


def hardened_env() -> dict[str, str]:
    env = {
        "PATH": trusted_path(),
        "HOME": os.environ.get("HOME", "/root"),
        "LANG": "C.UTF-8",
        "GOWORK": "off",
        "GOTOOLCHAIN": "local",
        "GOFLAGS": "",
        "GOPROXY": "off",
        "CGO_ENABLED": "0",
    }
    if in_container():
        env.update({"GOPATH": "/go", "GOMODCACHE": "/go/pkg/mod", "GOCACHE": "/gocache", "TESTBED_DIR": str(TESTBED)})
    else:
        for key in ("GOPATH", "GOMODCACHE", "GOCACHE"):
            if os.environ.get(key):
                env[key] = os.environ[key]
    return env


def run(cmd: list[str], *, cwd: Path = TESTBED, timeout: int = 900) -> tuple[int, str]:
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(cwd),
            env=hardened_env(),
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return 124, f"TIMEOUT: {' '.join(cmd)}"
    except (OSError, ValueError) as exc:
        return 127, f"EXEC FAILED: {exc}"
    return proc.returncode, (proc.stdout or "") + (proc.stderr or "")


def tail(text: str, limit: int = 3000) -> str:
    return text if len(text) <= limit else text[-limit:]


def atomic_write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    temporary.write_text(content, encoding="utf-8")
    os.replace(temporary, path)


def stages_upto(stage: str) -> list[str]:
    idx = STAGES.index(stage)
    return [s for s in STAGES[1 : idx + 1]]


def _injection_manifest(stage: str) -> Path:
    return VERIFIER_STATE / f"injected-{stage.replace('/', '_')}.json"


def purge_leaked_injections() -> list[str]:
    """Delete protected files a previous grading run may have left in the candidate tree.

    Hidden tests are injected into /testbed and restored in a finally block, but a crash,
    OOM or timeout between injection and restore would leave protected material sitting
    in the tree for the agent's next stage to read. The injected paths are therefore
    recorded in verifier-owned state BEFORE the copy happens, and every stage starts by
    clearing anything a previous run failed to remove.
    """
    removed: list[str] = []
    if not VERIFIER_STATE.is_dir():
        return removed
    for manifest in sorted(VERIFIER_STATE.glob("injected-*.json")):
        try:
            entries = json.loads(manifest.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            entries = []
        for item in entries:
            path = Path(item)
            try:
                if path.is_file():
                    path.unlink()
                    removed.append(str(path))
            except OSError:
                continue
        try:
            manifest.unlink()
        except OSError:
            pass
    return removed


def candidate_freeze() -> dict:
    """Identify exactly what is being graded, before any protected file is injected.

    Grading happened against a live, mutable tree with no record of its state, so a
    result could not be tied to a specific candidate. This records the committed tree id
    plus a digest over any uncommitted working-tree content, which is what a re-grade
    has to reproduce to be comparable.
    """
    rc, tree = run(["git", "-C", str(TESTBED), "rev-parse", "HEAD^{tree}"], timeout=120)
    rc2, dirty = run(["git", "-C", str(TESTBED), "status", "--porcelain"], timeout=180)
    dirty_lines = [ln for ln in (dirty or "").splitlines() if ln.strip()]
    digest = hashlib.sha256()
    for line in sorted(dirty_lines):
        digest.update(line.encode("utf-8", "replace"))
        rel = line[3:].strip().strip('"')
        candidate = TESTBED / rel
        try:
            if candidate.is_file():
                digest.update(candidate.read_bytes())
        except OSError:
            continue
    return {
        "tree": (tree or "").strip() if rc == 0 else "unavailable",
        "uncommittedFiles": len(dirty_lines),
        "uncommittedDigest": digest.hexdigest(),
        "note": "recorded before any protected file was injected",
    }


def inject_hidden(
    stages: list[str],
    backups: dict[str, bytes | None] | None = None,
    *,
    target_root: Path = TESTBED,
) -> dict[str, bytes | None]:
    backups = {} if backups is None else backups
    for st in stages:
        root = HIDDEN_ROOT / st
        if not root.is_dir():
            continue
        sources: list[Path] = []
        probe_dir = root / "verifierprobe"
        if probe_dir.is_dir():
            sources.extend(sorted(probe_dir.glob("*.go")))
        else:
            # The upstream suite is golden-file driven, so its testdata fixtures travel with
            # it: without them the tests fail on a missing file rather than on behaviour.
            sources.extend(sorted(root.rglob("*_test.go")))
            sources.extend(
                p for p in sorted(root.rglob("*"))
                if p.is_file() and "testdata" in p.relative_to(root).parts
            )
        # Record where protected material is ABOUT to land, in verifier-owned state and
        # before the first copy. Paths are under the grade sandbox, never the persistent
        # candidate tree the agent continues to edit between stages.
        planned = [str(target_root / src.relative_to(root)) for src in sources]
        newly_created = [q for q in planned if not Path(q).is_file()]
        try:
            VERIFIER_STATE.mkdir(parents=True, exist_ok=True)
            _injection_manifest(st).write_text(json.dumps(newly_created), encoding="utf-8")
        except OSError:
            pass
        for src in sources:
            rel = src.relative_to(root)
            dst = target_root / rel
            if str(dst) not in backups:
                backups[str(dst)] = dst.read_bytes() if dst.is_file() else None
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(src, dst)
    return backups


def restore_hidden(backups: dict[str, bytes | None]) -> None:
    # Restoration succeeded, so the crash-recovery manifests are no longer needed.
    try:
        for manifest in VERIFIER_STATE.glob("injected-*.json"):
            manifest.unlink()
    except OSError:
        pass
    for path_str, original in backups.items():
        path = Path(path_str)
        try:
            if original is None:
                path.unlink(missing_ok=True)
            else:
                path.write_bytes(original)
        except OSError:
            pass


def materialize_grade_sandbox() -> Path:
    """Copy the candidate tree into a verifier-owned sandbox for hidden grading.

    Authoritative hidden tests never mutate the persistent /testbed workspace the agent
    carries between stages. The sandbox is root-owned and discarded after grading.
    """
    import tempfile

    GRADE_SANDBOX_ROOT.mkdir(parents=True, exist_ok=True)
    label = f"grade-{os.getpid()}-{int(time.time())}"
    sandbox = GRADE_SANDBOX_ROOT / label
    sandbox.mkdir(parents=True, exist_ok=True)
    if in_container():
        rc, out = run(["cp", "-al", f"{TESTBED}/.", str(sandbox)], cwd=Path("/"), timeout=900)
        if rc != 0:
            rc, out = run(["cp", "-a", f"{TESTBED}/.", str(sandbox)], cwd=Path("/"), timeout=1800)
            if rc != 0:
                raise RuntimeError(f"grade sandbox copy failed: {out}")
    else:
        for entry in TESTBED.iterdir():
            dest = sandbox / entry.name
            if entry.is_dir():
                shutil.copytree(entry, dest, symlinks=True, dirs_exist_ok=True)
            else:
                shutil.copy2(entry, dest)
    try:
        os.chmod(sandbox, 0o700)
    except OSError:
        pass
    return sandbox


def teardown_grade_sandbox(sandbox: Path) -> None:
    shutil.rmtree(sandbox, ignore_errors=True)


def hidden_corpus_size(stages: list[str]) -> int:
    return sum(
        len(list((HIDDEN_ROOT / st).rglob("*_test.go")))
        for st in stages
        if (HIDDEN_ROOT / st).is_dir()
    )


def summarize_go(out: str, limit: int = 2500) -> str:
    kept = [
        line
        for line in (out or "").splitlines()
        if line.startswith(("--- FAIL", "FAIL", "ok  ", "panic:", "# "))
        or "undefined:" in line
        or "Error:" in line
    ]
    return tail("\n".join(kept) if kept else (out or ""), limit)


def go_cmd(args: list[str], timeout: int, *, cwd: Path = TESTBED) -> tuple[int, str]:
    return run(["go", *args], timeout=timeout, cwd=cwd)


def go_build(pkgs: list[str], timeout: int = 1500) -> tuple[bool, str]:
    rc, out = go_cmd(["build", *pkgs], timeout)
    return rc == 0, summarize_go(out)


def go_vet_production(stage: str, timeout: int = 1200) -> tuple[bool, str]:
    # Previously every stage except 02 vetted ./verifierprobe/..., so a check named
    # "vet_production" never actually vetted production code. Vet the stage's own tree.
    targets = STAGE_BUILD[stage]
    rc, out = go_cmd(["vet", "-tests=false", *targets], timeout)
    return rc == 0, summarize_go(out, 2000)


STAGE_TEST = {
    "02-l4-route-foundation": [
        "./operator/pkg/gateway-api/helpers/...",
        "./operator/pkg/gateway-api/indexers/...",
        "./operator/pkg/gateway-api/routechecks/...",
    ],
    "03-reconcile-translate": list(GATEWAY_PACKAGES),
    "04-config-harden": list(GATEWAY_PACKAGES),
}


def go_test(
    pkgs: list[str],
    timeout: int = 2400,
    verbose: bool = False,
    run_pattern: str | None = None,
    *,
    cwd: Path = TESTBED,
) -> tuple[bool, str, str]:
    args = ["test", "-count=1", "-p=2"]
    if run_pattern:
        args.extend(["-run", run_pattern])
    if verbose:
        args.append("-v")
    args.extend(pkgs)
    rc, out = go_cmd(args, timeout, cwd=cwd)
    raw = out or ""
    # A per-package "no tests to run" warning is EXPECTED here and must not fail the stage.
    # The graded corpus is the upstream suite injected at its real repository paths, so it is
    # spread over many packages; every package that holds none of the graded functions reports
    # that warning. (It could not happen when the corpus was a single probe package.) The
    # condition actually worth catching is the pattern matching nothing ANYWHERE, which is what
    # the check below detects -- and graded_tests_all_ran() separately confirms that every
    # expected function ran.
    if run_pattern and rc == 0 and not re.search(r"^\s*--- PASS:", raw, re.MULTILINE):
        return False, "the required hidden run pattern matched no tests in any package", raw
    return rc == 0, summarize_go(raw, 4000), raw


def hidden_run_pattern(stages: list[str]) -> str | None:
    expected = expected_graded_tests(stages)
    if not expected:
        return None
    return "^(" + "|".join(sorted(expected)) + ")$"


def expected_graded_tests(stages: list[str]) -> set[str]:
    names: set[str] = set()
    for st in stages:
        root = HIDDEN_ROOT / st
        if not root.is_dir():
            continue
        for src in sorted(root.rglob("*_test.go")):
            try:
                text = src.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            names.update(re.findall(r"^func (Test[A-Za-z0-9_]*)\s*\(", text, re.MULTILINE))
    names.discard("TestMain")
    return names


def graded_tests_all_ran(stages: list[str], out: str) -> tuple[bool, str]:
    expected = expected_graded_tests(stages)
    if not expected:
        return True, "no graded test functions expected"
    passed = set(re.findall(r"^\s*--- PASS: (Test[A-Za-z0-9_]+)", out, re.MULTILINE))
    missing = sorted(expected - passed)
    if not missing:
        return True, f"all {len(expected)} graded test functions ran and passed"
    return False, f"{len(missing)} of {len(expected)} graded test functions did not pass: {missing[:8]}"


def load_json(path: Path) -> tuple[dict | None, str]:
    if not path.is_file():
        return None, f"missing {path}"
    if path.stat().st_size > MAX_ARTIFACT_BYTES:
        return None, f"{path} exceeds {MAX_ARTIFACT_BYTES} bytes"
    try:
        data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except (json.JSONDecodeError, OSError) as exc:
        return None, f"unparseable {path}: {exc}"
    if not isinstance(data, dict):
        return None, f"{path} is not a JSON object"
    return data, "ok"


def json_contract(path: Path, required: dict[str, type | tuple[type, ...]]) -> tuple[bool, str]:
    data, note = load_json(path)
    if data is None:
        return False, note
    problems = []
    for key, want in required.items():
        if key not in data:
            problems.append(f"missing key '{key}'")
            continue
        value = data[key]
        if not isinstance(value, want):
            problems.append(f"'{key}' has wrong type {type(value).__name__}")
        elif isinstance(value, str) and not value.strip():
            problems.append(f"'{key}' is empty")
        elif isinstance(value, list) and not value:
            problems.append(f"'{key}' is an empty list")
    return (not problems), ("; ".join(problems) if problems else "ok")


def stage_report_contract(stage: str) -> tuple[bool, str]:
    spec = ARTIFACT_SCHEMAS[stage]
    return json_contract(OUTPUT / stage / str(spec["file"]), dict(spec["fields"]))


VERIFIER_STATE = Path(os.environ.get("VERIFIER_STATE_DIR", "/opt/verifier-state"))


def _handoff_digest() -> str | None:
    path = OUTPUT / "handoff.json"
    if not path.is_file():
        return None
    return hashlib.sha256(path.read_bytes()).hexdigest()


def handoff_lineage(stage: str) -> tuple[bool, str]:
    """Bind this stage's handoff to the exact handoff the previous stage was graded on.

    The handoff is agent-authored and lives in /app/output, which the agent may rewrite
    at any time, so schema validation alone proves nothing about continuity: a stage
    could present a handoff unrelated to the one its predecessor actually produced.
    The digest of each ACCEPTED handoff is therefore recorded in verifier-owned state
    that the agent cannot write, and the next stage is checked against it.

    Recording is verifier-side on purpose: requiring the agent to carry a digest would
    make an unstated bookkeeping field decide the stage.
    """
    index = STAGES.index(stage) if stage in STAGES else 0
    current = _handoff_digest()
    try:
        VERIFIER_STATE.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        return True, f"lineage not recorded ({exc}); not held against the submission"

    if index == 0:
        if current:
            (VERIFIER_STATE / "handoff-00.sha256").write_text(current, encoding="utf-8")
        return True, "first stage: lineage root recorded"

    prior_path = VERIFIER_STATE / f"handoff-{index - 1:02d}.sha256"
    if not prior_path.is_file():
        # No predecessor was ever recorded (single-stage rerun, or the earlier stage was
        # never graded here). Absence of verifier state is not agent misconduct.
        if current:
            (VERIFIER_STATE / f"handoff-{index:02d}.sha256").write_text(current, encoding="utf-8")
        return True, "no recorded predecessor; lineage started at this stage"

    prior = prior_path.read_text(encoding="utf-8").strip()
    if current is None:
        return False, "handoff.json is absent, so it cannot continue the previous stage"
    if current == prior:
        return False, (
            "handoff.json is byte-identical to the one accepted at the previous stage; "
            "each stage must hand forward its own state"
        )
    (VERIFIER_STATE / f"handoff-{index:02d}.sha256").write_text(current, encoding="utf-8")
    return True, f"handoff continues the accepted predecessor {prior[:12]}"


def handoff_contract() -> tuple[bool, str]:
    return json_contract(OUTPUT / "handoff.json", HANDOFF_FIELDS)


def read_trajectory() -> str:
    chunks: list[str] = []
    for base in (AGENT_LOGS, OUTPUT):
        if not base.is_dir():
            continue
        for path in sorted(base.rglob("*")):
            if path.is_file() and path.stat().st_size <= 8 << 20:
                try:
                    chunks.append(path.read_text(encoding="utf-8", errors="replace"))
                except OSError:
                    continue
    return "\n".join(chunks)


def strip_shell_comments(line: str) -> str:
    if line.lstrip().startswith("#"):
        return ""
    if "#" not in line:
        return line
    out: list[str] = []
    quote: str | None = None
    for ch in line:
        if quote:
            out.append(ch)
            if ch == quote:
                quote = None
            continue
        if ch in {"'", '"'}:
            quote = ch
            out.append(ch)
            continue
        if ch == "#":
            break
        out.append(ch)
    return "".join(out)


def trajectory_command_lines(text: str) -> list[str]:
    lines: list[str] = []
    for raw in text.splitlines():
        cleaned = strip_shell_comments(raw).strip()
        if cleaned:
            lines.append(cleaned)
    return lines


def split_keystrokes_blob(keystrokes: str) -> list[str]:
    lines: list[str] = []
    for raw in keystrokes.splitlines():
        cleaned = strip_shell_comments(raw).strip()
        if cleaned:
            lines.append(cleaned)
    return lines


def keystrokes_from_command_objects(commands: object) -> list[str]:
    if not isinstance(commands, list):
        return []
    lines: list[str] = []
    for cmd in commands:
        if not isinstance(cmd, dict):
            continue
        keystrokes = cmd.get("keystrokes")
        if isinstance(keystrokes, str) and keystrokes.strip():
            lines.extend(split_keystrokes_blob(keystrokes))
    return lines


def keystrokes_from_atif_step(step: dict) -> list[str]:
    lines: list[str] = []
    for tool_call in step.get("tool_calls") or []:
        if not isinstance(tool_call, dict):
            continue
        arguments = tool_call.get("arguments")
        if not isinstance(arguments, dict):
            continue
        keystrokes = arguments.get("keystrokes")
        if isinstance(keystrokes, str) and keystrokes.strip():
            lines.extend(split_keystrokes_blob(keystrokes))

    message = step.get("message")
    if isinstance(message, dict):
        lines.extend(keystrokes_from_command_objects(message.get("commands")))
    elif isinstance(message, str):
        stripped = message.strip()
        if stripped.startswith("{"):
            try:
                payload = json.loads(stripped)
            except json.JSONDecodeError:
                payload = None
            if isinstance(payload, dict) and payload.get("commands"):
                lines.extend(keystrokes_from_command_objects(payload.get("commands")))
    return lines


def extract_atif_command_lines(payload: dict) -> list[str]:
    steps = payload.get("steps")
    if not isinstance(steps, list):
        return []
    lines: list[str] = []
    for step in steps:
        if not isinstance(step, dict):
            continue
        if step.get("source") == "user":
            continue
        lines.extend(keystrokes_from_atif_step(step))
    return lines


def try_parse_atif_command_lines(path: Path, text: str) -> list[str] | None:
    if path.name != "trajectory.json" and '"steps"' not in text[:8192]:
        return None
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        return None
    if not isinstance(payload, dict) or not isinstance(payload.get("steps"), list):
        return None
    return extract_atif_command_lines(payload)


def should_scan_plain_command_file(path: Path) -> bool:
    if path.suffix in {".sh", ".bash"}:
        return True
    if path.name in {"oracle.txt", "reproduce.sh", "reproducer.sh", "repro.sh", "commands.log", "terminal.log"}:
        return True
    if path.suffix in {".log", ".txt"} and "agent" in path.parts:
        return True
    return False


def collect_executed_command_lines() -> list[str]:
    lines: list[str] = []
    for base in (AGENT_LOGS, OUTPUT):
        if not base.is_dir():
            continue
        for path in sorted(base.rglob("*")):
            if not path.is_file() or path.stat().st_size > 8 << 20:
                continue
            try:
                text = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            atif_lines = try_parse_atif_command_lines(path, text)
            if atif_lines is not None:
                lines.extend(atif_lines)
                continue
            if should_scan_plain_command_file(path):
                lines.extend(trajectory_command_lines(text))
    return lines


def verify_binary_integrity() -> tuple[bool, dict]:
    manifest = Path("/opt/verifier-binary-checksums.txt")
    if not manifest.is_file():
        return True, {"skipped": "checksum manifest absent in local/dev runs"}
    errors: list[str] = []
    verified: dict[str, str] = {}
    for line in manifest.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split(None, 1)
        if len(parts) != 2:
            continue
        expected, binary = parts
        rc, out = run(["sha256sum", binary], timeout=30)
        if rc != 0:
            errors.append(f"cannot hash {binary}")
            continue
        actual = out.split()[0] if out.split() else ""
        if actual != expected:
            errors.append(f"{binary} modified")
        verified[binary] = "ok" if actual == expected else "tampered"
    return not errors, {"verified": verified, "errors": errors}


def integrity(stage: str) -> tuple[bool, dict]:
    findings: list[str] = []
    # Structured, so an invalidated trial can be root-caused from the eval bundle
    # instead of guessed at. An earlier revision recorded 120 characters and no rule
    # id, and two voided stages could not be explained by the reviewer at all.
    evidence: list[dict] = []

    def record(rule: str, matched: str, command: str) -> None:
        findings.append(f"{rule}: {matched[:120]}")
        evidence.append({
            "rule": rule,
            "matched": matched[:400],
            "command": command[:2000],
            "why": INTEGRITY_RULE_NOTES.get(rule, ""),
        })

    executed_lines = [command_surface(line) for line in collect_executed_command_lines()]
    executed_blob = "\n".join(executed_lines)
    for pattern in LEAK_PATTERNS:
        match = re.search(pattern, executed_blob, re.IGNORECASE)
        if match:
            record("reference-solution leakage", match.group(0), match.group(0))
    for line in executed_lines:
        match = FORBIDDEN_COMMANDS.search(line)
        if match:
            record("forbidden command", match.group(0), line)
            break
        match = PYTHON_NETWORK.search(line)
        if match:
            record("forbidden python network use", match.group(0), line)
            break
        match = NONLOCAL_EGRESS.search(line)
        if match:
            record("non-local egress attempt", match.group(0), line)
            break
    rc, out = run(["git", "-C", str(TESTBED), "remote", "-v"], timeout=120)
    if rc == 0 and out.strip():
        findings.append(f"git remote present: {out.strip()[:120]}")
    binary_ok, binary_ev = verify_binary_integrity()
    if not binary_ok:
        findings.append("toolchain binary integrity failed")
    ctime_ok, ctime_ev = verify_ctime_anchor(
        [
            "/usr/local/go/bin/go",
            "/usr/bin/go",
            "/opt/verifier-binary-checksums.txt",
            "/bin/bash",
            "/usr/bin/bash",
        ]
    )
    if not ctime_ok:
        findings.append(
            "toolchain ctime anchor failed: "
            + "; ".join(ctime_ev.get("violations", [])[:2])
        )
    ok = not findings
    return ok, {
        "passed": ok,
        "findings": findings,
        # Each finding with its rule id, the exact text that matched, the full command
        # it came from and why the rule exists. valid_trial=0 must always be explainable
        # from the retained bundle alone.
        "evidence": evidence,
        "binary_integrity": binary_ev,
        "ctime_anchor": ctime_ev,
        "notes": [],
        "detail": "clean" if ok else "; ".join(findings[:5]),
    }


def _helm_render(enabled: bool, timeout: int = 240) -> tuple[bool, str]:
    """Render the shipped chart with Gateway API on or off. Returns (ok, rendered-or-error)."""
    chart = TESTBED / "install/kubernetes/cilium"
    if not chart.is_dir():
        return False, "install/kubernetes/cilium chart directory missing"
    argv = [
        "helm", "template", "cilium", str(chart),
        "--namespace", "kube-system",
        "--set", f"gatewayAPI.enabled={'true' if enabled else 'false'}",
        "--show-only", "templates/cilium-configmap.yaml",
    ]
    rc, out = run(argv, cwd=TESTBED, timeout=timeout)
    if rc != 0:
        return False, tail(out, 2000)
    return True, out or ""


def _rendered_setting(rendered: str, key: str) -> str | None:
    """The value the rendered ConfigMap gives `key`, or None when it is absent."""
    match = re.search(rf"^\s*{re.escape(key)}:\s*\"?([^\"\n]*)\"?\s*$", rendered, re.MULTILINE)
    return match.group(1).strip() if match else None


def helm_l4_config_for_weights() -> tuple[bool, str]:
    """Observe the CONDITION, not the template text.

    The contract is that enabling Gateway API forces the two L4 load-balancing options on.
    A conditional can only be observed by rendering both ways: reading the template as a
    string cannot distinguish "forced when enabled" from "always set" or "mentioned in a
    comment", which is why the previous token scan passed implementations that did neither.
    """
    keys = ("bpf-lb-algorithm-annotation", "bpf-lb-sock-hostns-only")

    ok_on, on = _helm_render(True)
    if not ok_on:
        return False, f"helm template with gatewayAPI.enabled=true failed: {on}"
    ok_off, off = _helm_render(False)
    if not ok_off:
        return False, f"helm template with gatewayAPI.enabled=false failed: {off}"

    for key in keys:
        value = _rendered_setting(on, key)
        if value is None:
            return False, f"with Gateway API enabled the rendered ConfigMap omits {key}"
        if value.lower() != "true":
            return False, f"with Gateway API enabled {key} renders as {value!r}, expected \"true\""

    # The forcing must be conditional. If disabling Gateway API leaves both options forced on
    # regardless, the chart is not honouring the condition -- it is hardcoding.
    still_forced = [
        key for key in keys
        if (_rendered_setting(off, key) or "").lower() == "true"
    ]
    if len(still_forced) == len(keys):
        return False, (
            "both L4 options render as \"true\" even with gatewayAPI.enabled=false, so they are "
            f"hardcoded rather than conditionally forced ({still_forced})"
        )
    return True, (
        "chart rendered twice: Gateway API on forces "
        f"{', '.join(keys)} to \"true\"; off does not force them"
    )


def verify_implementation_closure_artifact() -> tuple[bool, str]:
    proof_path = OUTPUT / "04-config-harden" / "implementation_closure_proof.json"
    data, note = load_json(proof_path)
    if data is None:
        return False, note
    for field in ("base_commit", "feature_complete", "packages_touched", "verification_performed"):
        if field not in data:
            return False, f"proof missing required field '{field}'"
    if str(data.get("base_commit")) != "04fd6832fd9015c072d9d1577939484ebd69302f":
        return False, "proof base_commit does not match task base"
    if data.get("feature_complete") is not True:
        return False, "proof feature_complete must be true"
    packages = data.get("packages_touched")
    verification = data.get("verification_performed")
    if not isinstance(packages, list) or len(packages) < 2:
        return False, "proof packages_touched must be an array with at least 2 entries"
    if not isinstance(verification, list) or len(verification) < 1:
        return False, "proof verification_performed must be a non-empty array"
    missing_paths: list[str] = []
    for rel in CRITICAL_IMPLEMENTATION_PATHS:
        if not (TESTBED / rel).is_file():
            missing_paths.append(rel)
    missing_caps: list[str] = []
    for pkg_rel, label, symbol in CRITICAL_IMPLEMENTATION_CAPABILITIES:
        pkg_dir = TESTBED / pkg_rel
        found = False
        if pkg_dir.is_dir():
            for src in pkg_dir.rglob("*.go"):
                if src.name.endswith("_test.go"):
                    continue
                try:
                    if symbol in src.read_text(encoding="utf-8", errors="replace"):
                        found = True
                        break
                except OSError:
                    continue
        if not found:
            missing_caps.append(f"{label} (no {symbol} in {pkg_rel})")
    if missing_paths or missing_caps:
        return False, (
            "closure incomplete: "
            + "; ".join(missing_caps + [f"missing file {m}" for m in missing_paths])
        )
    return True, (
        f"behavioral closure: {len(CRITICAL_IMPLEMENTATION_CAPABILITIES)} capabilities "
        f"present (any filename); {len(packages)} packages reported"
    )


def base_gap_observed() -> tuple[bool, str]:
    observed: list[str] = []
    problems: list[str] = []
    try:
        if (TESTBED / "operator/pkg/gateway-api/helpers/tcproute.go").is_file():
            problems.append("TCPRoute helper already present")
        else:
            observed.append("tcproute_helper")
        if (TESTBED / "operator/pkg/gateway-api/helpers/udproute.go").is_file():
            problems.append("UDPRoute helper already present")
        else:
            observed.append("udproute_helper")
        if (TESTBED / "operator/pkg/gateway-api/endpointslice_reconcile.go").is_file():
            problems.append("endpointslice reconciler already present")
        else:
            observed.append("endpointslice_reconcile")
        rbac = TESTBED / "install/kubernetes/cilium/templates/cilium-operator/clusterrole.yaml"
        if rbac.is_file() and "tcproutes" in rbac.read_text(encoding="utf-8", errors="replace"):
            problems.append("TCPRoute RBAC already present")
        else:
            observed.append("tcproute_rbac")
    except OSError as exc:
        problems.append(f"probe failed: {exc}")
    if problems:
        return False, "; ".join(problems)
    if len(observed) < 3:
        return False, f"insufficient gaps observed: {observed}"
    return True, f"base still lacks L4 Gateway API route support: {observed}"


def find_reproducer() -> Path | None:
    root = OUTPUT / "01-diagnose"
    if not root.is_dir():
        return None
    for name in ("reproduce.sh", "reproducer.sh", "repro.sh"):
        candidate = root / name
        if candidate.is_file():
            return candidate
    for candidate in sorted(root.rglob("*")):
        if candidate.is_file() and candidate.suffix in {".sh", ".bash"}:
            return candidate
    return None


def diagnose() -> dict:
    checks: dict[str, dict] = {}
    ok, note = base_gap_observed()
    checks["base_gap_observed"] = {"passed": ok, "detail": note}
    repro = find_reproducer()
    checks["reproducer_present"] = {
        "passed": repro is not None,
        "detail": str(repro) if repro else "no reproducer under /app/output/01-diagnose",
    }
    repro_out = ""
    repro_rc = None
    if repro is not None:
        repro_rc, repro_out = run(["bash", str(repro)], cwd=TESTBED, timeout=900)
    checks["reproducer_runs"] = {
        "passed": repro is not None and repro_rc is not None and bool(repro_out.strip()),
        "detail": f"rc={repro_rc}, {len(repro_out)} bytes output",
    }
    blob = (repro_out + "\n" + read_trajectory()).lower()
    has_tcp = "tcproute" in blob
    has_udp = "udproute" in blob
    has_context = ("gateway-api" in blob) or ("endpointslices" in blob)
    demonstrates = (
        repro is not None
        and repro_rc not in (None, 0)
        and has_tcp
        and has_udp
        and has_context
    )
    checks["reproducer_demonstrates_gap"] = {
        "passed": demonstrates,
        "detail": f"rc={repro_rc}, tcproute={has_tcp}, udproute={has_udp}, context={has_context}",
    }
    ok, note = stage_report_contract("01-diagnose")
    checks["diagnosis_report"] = {"passed": ok, "detail": note}
    ok, note = handoff_contract()
    lineage_ok, lineage_note = handoff_lineage("01-diagnose")
    checks["handoff"] = {
        "passed": ok and lineage_ok,
        "detail": note if ok else note,
        "lineage": lineage_note,
    }
    return checks


def graded_go_gates(stage: str, checks: dict[str, dict], *, build_key: str = "build_clean") -> None:
    ok, out = go_build(STAGE_BUILD[stage])
    checks[build_key] = {"passed": ok, "detail": "ok" if ok else out}
    stages = stages_upto(stage)
    corpus = hidden_corpus_size(stages)
    sandbox = materialize_grade_sandbox()
    backups: dict[str, bytes | None] = {}
    try:
        inject_hidden(stages, backups, target_root=sandbox)
        ok, out, raw = go_test(
            STAGE_TEST[stage],
            verbose=True,
            run_pattern=hidden_run_pattern(stages),
            cwd=sandbox,
        )
        if raw:
            _CTRF_GO_RUNS.append(raw)
        ran_ok, ran_note = graded_tests_all_ran(stages, raw)
        checks["hidden_tests_pass"] = {
            "passed": ok and ran_ok,
            "detail": (
                f"{corpus} hidden files; grade_root={sandbox}; {ran_note}"
                + ("" if ok and ran_ok else f"\n{out}")
            ),
        }
        vet_ok, vet_out = go_vet_production(stage)
    finally:
        restore_hidden(backups)
        teardown_grade_sandbox(sandbox)
    checks["vet_clean"] = {"passed": vet_ok, "detail": "ok" if vet_ok else vet_out}


OPERATOR_CLUSTERROLE = "install/kubernetes/cilium/templates/cilium-operator/clusterrole.yaml"
L4_DOC_DIR = "Documentation/network/servicemesh/gateway-api"


def rbac_grants_l4_routes() -> tuple[bool, str]:
    """Stage 2 requires operator RBAC for tcproutes/udproutes; grade it directly.

    The briefing states this as required work, but nothing verified it: an agent could
    skip the ClusterRole entirely and still pass the stage, and at runtime the operator
    would be unable to watch the routes it is supposed to reconcile. The status
    subresources matter as much as the resources -- route status is how a Gateway
    reports acceptance -- so both are required.
    """
    path = TESTBED / OPERATOR_CLUSTERROLE
    if not path.is_file():
        return False, f"{OPERATOR_CLUSTERROLE} is missing"
    text = path.read_text(encoding="utf-8", errors="replace")
    required = ("tcproutes", "udproutes", "tcproutes/status", "udproutes/status")
    missing = [name for name in required if name not in text]
    if missing:
        return False, (
            "operator ClusterRole does not grant " + ", ".join(missing)
            + "; the operator cannot watch or report status on the L4 routes it reconciles"
        )
    # The grants have to be usable: a resource list is meaningless without verbs.
    verbs_ok = any(v in text for v in ("list", "watch"))
    if not verbs_ok:
        return False, "L4 route resources are listed but no list/watch verb is granted"
    return True, "operator ClusterRole grants tcproutes/udproutes and their status subresources"


def docs_mention_l4_routes() -> tuple[bool, str]:
    """Stage 4 requires the Gateway API docs to cover TCPRoute/UDPRoute.

    The briefing asks for it and the final verifier could pass without it, which is a
    requirement stated to the agent and never checked. This grades the outcome -- the
    shipped documentation mentions the two kinds -- not any particular wording.
    """
    root = TESTBED / L4_DOC_DIR
    if not root.is_dir():
        return False, f"{L4_DOC_DIR} is missing"
    hits = {"TCPRoute": [], "UDPRoute": []}
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in {".rst", ".md"}:
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        for kind in hits:
            if kind in text:
                hits[kind].append(path.name)
    missing = [kind for kind, files in hits.items() if not files]
    if missing:
        return False, (
            f"{L4_DOC_DIR} does not mention " + ", ".join(missing)
            + "; stage 4 requires the Gateway API documentation to cover both route kinds"
        )
    return True, (
        "gateway-api docs mention TCPRoute (" + ", ".join(sorted(set(hits["TCPRoute"]))[:3])
        + ") and UDPRoute (" + ", ".join(sorted(set(hits["UDPRoute"]))[:3]) + ")"
    )


def deps(stage: str) -> dict:
    checks: dict[str, dict] = {}
    graded_go_gates(stage, checks)
    ok, note = rbac_grants_l4_routes()
    checks["rbac_l4_routes"] = {"passed": ok, "detail": note}
    ok, note = stage_report_contract(stage)
    checks["implementation_report"] = {"passed": ok, "detail": note}
    ok, note = handoff_contract()
    lineage_ok, lineage_note = handoff_lineage(stage)
    checks["handoff"] = {
        "passed": ok and lineage_ok,
        "detail": note if ok else note,
        "lineage": lineage_note,
    }
    return checks


def framework(stage: str) -> dict:
    checks: dict[str, dict] = {}
    graded_go_gates(stage, checks)
    ok, note = stage_report_contract(stage)
    checks["review_report"] = {"passed": ok, "detail": note}
    ok, note = handoff_contract()
    lineage_ok, lineage_note = handoff_lineage(stage)
    checks["handoff"] = {
        "passed": ok and lineage_ok,
        "detail": note if ok else note,
        "lineage": lineage_note,
    }
    return checks


def harden(stage: str) -> dict:
    checks: dict[str, dict] = {}
    graded_go_gates(stage, checks, build_key="full_build")
    ok_installer, installer_note = helm_l4_config_for_weights()
    checks["helm_l4_config"] = {"passed": ok_installer, "detail": installer_note}
    ok_closure, closure_note = verify_implementation_closure_artifact()
    checks["implementation_closure"] = {"passed": ok_closure, "detail": closure_note}
    ok_docs, docs_note = docs_mention_l4_routes()
    checks["docs_l4_routes"] = {"passed": ok_docs, "detail": docs_note}
    ok, note = stage_report_contract(stage)
    checks["final_report"] = {"passed": ok, "detail": note}
    data, _ = load_json(OUTPUT / "handoff.json")
    handoff_ok, handoff_note = handoff_contract()
    lineage_ok, lineage_note = handoff_lineage(stage)
    handoff_ok = handoff_ok and lineage_ok
    declared = isinstance(data, dict) and data.get("merge_ready") is True
    next_steps = data.get("next_steps") if isinstance(data, dict) else None
    task_complete = (
        isinstance(next_steps, list)
        and any("task complete" in str(item).lower() for item in next_steps)
    )
    merge_pass = handoff_ok and declared and task_complete
    if merge_pass:
        merge_detail = "ok"
    elif not handoff_ok:
        merge_detail = f"handoff invalid: {handoff_note}"
    elif not declared:
        merge_detail = f"handoff must declare merge_ready=true ({handoff_note})"
    else:
        merge_detail = 'handoff next_steps must include "Task complete."'
    checks["merge_ready"] = {
        "passed": merge_pass,
        "detail": merge_detail,
    }
    return checks


def _go_test_ctrf_entries(raw: str, suite: str) -> list[dict[str, object]]:
    entries: list[dict[str, object]] = []
    status_map = {"PASS": "passed", "FAIL": "failed", "SKIP": "skipped"}
    for match in re.finditer(r"^\s*--- (PASS|FAIL|SKIP): (Test[A-Za-z0-9_]+)", raw, re.MULTILINE):
        entries.append(
            {
                "name": match.group(2),
                "status": status_map[match.group(1)],
                "duration": 0,
                "suite": suite,
                "message": "",
            }
        )
    return entries


def write_ctrf(stage: str, checks: dict[str, dict], integrity_report: dict) -> None:
    """Publish CTRF entries for Harbor/DataOS test-result parsing."""
    now_ms = int(time.time() * 1000)
    start_ms = now_ms
    weights = WEIGHTS[stage]
    tests: list[dict[str, object]] = []
    for name in sorted(weights):
        check = checks.get(name, {})
        passed = bool(check.get("passed"))
        tests.append(
            {
                "name": name,
                "status": "passed" if passed else "failed",
                "duration": 0,
                "suite": f"{stage} :: check",
                "message": str(check.get("detail", ""))[:500],
            }
        )
    integrity_ok = bool(integrity_report.get("passed"))
    findings = integrity_report.get("findings") or []
    tests.append(
        {
            "name": "integrity",
            "status": "passed" if integrity_ok else "failed",
            "duration": 0,
            "suite": f"{stage} :: integrity",
            "message": "; ".join(str(item) for item in findings)[:500],
        }
    )
    for raw in _CTRF_GO_RUNS:
        tests.extend(_go_test_ctrf_entries(raw, f"{stage} :: hidden"))
    passed = sum(1 for entry in tests if entry["status"] == "passed")
    failed = sum(1 for entry in tests if entry["status"] == "failed")
    skipped = sum(1 for entry in tests if entry["status"] == "skipped")
    payload = {
        "reportFormat": "CTRF",
        "specVersion": "0.0.0",
        "results": {
            "tool": {"name": CTRF_TOOL_NAME},
            "summary": {
                "tests": len(tests),
                "passed": passed,
                "failed": failed,
                "pending": 0,
                "skipped": skipped,
                "other": 0,
                "start": start_ms,
                "stop": now_ms,
            },
            "tests": tests,
        },
    }
    atomic_write_text(RESULT_DIR / "ctrf.json", json.dumps(payload, indent=2, sort_keys=True) + "\n")


def write_reward(stage: str, checks: dict[str, dict], integrity_report: dict) -> float:
    weights = WEIGHTS[stage]
    integrity_ok = bool(integrity_report.get("passed"))
    d_num, d_den = deterministic_components(checks, weights, integrity_ok=integrity_ok)
    critical = CRITICAL_CHECKS[stage]
    required_pass = all(bool(checks.get(name, {}).get("passed")) for name in critical)
    binary = binary_outcome(required_checks_pass=required_pass, integrity_ok=integrity_ok)
    lam = parse_lambda(os.environ.get("NONDETERMINISTIC_LAMBDA", "0.0"))
    training = calculate_training_score(
        d_num=d_num, d_den=d_den, nondeterministic_lambda=lam, integrity_ok=integrity_ok, rewardkit_available=False
    )
    payload = {
        "reward": binary,
        "binary_reward": binary,
        "training_score": clamp01(training),
        "deterministic_score": round(clamp01(d_num / d_den) if d_den else 0.0, 6),
    }
    valid_trial = 1.0 if integrity_ok else 0.0
    stage_complete = (
        1.0
        if not [n for n in weights if not checks.get(n, {}).get("passed")] and integrity_ok
        else 0.0
    )
    details = {
        "stage": stage,
        "checks": checks,
        "weights": weights,
        "critical_checks": critical,
        "integrity": integrity_report,
        "valid_trial": valid_trial,
        "stage_complete": stage_complete,
        "every_weighted_check_passed": stage_complete == 1.0,
        "critical_pass": required_pass,
    }
    atomic_write_text(RESULT_DIR / "reward.json", json.dumps(payload, indent=2, sort_keys=True) + "\n")
    atomic_write_text(RESULT_DIR / "reward-details.json", json.dumps(details, indent=2, sort_keys=True) + "\n")
    atomic_write_text(RESULT_DIR / "reward.txt", f"{binary:.4f}\n")
    events = {
        "stage": stage,
        "binary_reward": binary,
        "integrity_ok": integrity_ok,
        "checks": {
            name: bool(check.get("passed"))
            for name, check in checks.items()
            if name in weights
        },
        "critical_checks": critical,
    }
    atomic_write_text(RESULT_DIR / "reward-events.json", json.dumps(events, indent=2, sort_keys=True) + "\n")
    manifest = {
        "stage": stage,
        "binary_reward": binary,
        "training_score": payload["training_score"],
        "deterministic_score": payload["deterministic_score"],
        "valid_trial": valid_trial,
        "stage_complete": stage_complete,
        "critical_pass": required_pass,
        "integrity_ok": integrity_ok,
    }
    atomic_write_text(
        RESULT_DIR / "training_export_manifest.json",
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
    )
    return binary


def main() -> int:
    global _CTRF_GO_RUNS
    _CTRF_GO_RUNS = []
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", required=True)
    args = parser.parse_args()
    stage = resolve_stage(args.stage)
    if stage not in STAGES:
        print(f"unknown stage key: {args.stage}", file=sys.stderr)
        return 2
    shutil.rmtree(TESTBED / "verifierprobe", ignore_errors=True)
    # Before anything else: clear protected files a crashed earlier run may have left in
    # the candidate tree, and record exactly what is about to be graded.
    leaked = purge_leaked_injections()
    frozen = candidate_freeze()
    if leaked:
        frozen["purgedLeakedInjections"] = leaked
    integrity_ok, integrity_report = integrity(stage)
    # Travels with the integrity report, so every stage result says which candidate was
    # graded and whether anything had to be purged before grading.
    integrity_report["candidate"] = frozen
    if stage == "01-diagnose":
        checks = diagnose()
    elif stage == "02-l4-route-foundation":
        checks = deps(stage)
    elif stage == "03-reconcile-translate":
        checks = framework(stage)
    else:
        checks = harden(stage)
    binary = write_reward(stage, checks, integrity_report)
    write_ctrf(stage, checks, integrity_report)
    print(f"stage={stage} integrity_ok={integrity_ok} binary_reward={binary}")
    for name in sorted(checks):
        state = "PASS" if checks[name].get("passed") else "FAIL"
        print(f"  [{state}] {name}: {str(checks[name].get('detail', ''))[:400]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
