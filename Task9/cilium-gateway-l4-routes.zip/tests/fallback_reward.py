#!/usr/bin/env python3
"""Guarantee reward.json exists even if stage_check.py crashes."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

RESULT_DIR = Path(os.environ.get("RESULT_DIR", "/logs/verifier"))
CORE = {
    "reward": 0.0,
    "binary_reward": 0.0,
    "training_score": 0.0,
    "deterministic_score": 0.0,
}


def main() -> int:
    RESULT_DIR.mkdir(parents=True, exist_ok=True)
    reward = RESULT_DIR / "reward.json"
    if not reward.is_file() or reward.stat().st_size == 0:
        reward.write_text(json.dumps(CORE, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    txt = RESULT_DIR / "reward.txt"
    if not txt.is_file() or txt.stat().st_size == 0:
        txt.write_text("0.0000\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    sys.exit(main())
