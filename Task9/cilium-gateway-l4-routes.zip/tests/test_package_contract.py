from __future__ import annotations

import hashlib
import json
import re
import sys
import tomllib
from pathlib import Path

PKG = Path(__file__).resolve().parents[1]
TESTS = PKG / "tests"
STEPS = PKG / "steps"
STAGES = [
    "01-diagnose",
    "02-l4-route-foundation",
    "03-reconcile-translate",
    "04-config-harden",
]
DISPATCH = {
    "01-diagnose": "diagnose",
    "02-l4-route-foundation": "foundation",
    "03-reconcile-translate": "reconcile",
    "04-config-harden": "harden",
}
PATCH_STAGES = STAGES[1:]
PATCH_COUNTS = {
    "02-l4-route-foundation": 16,
    "03-reconcile-translate": 52,
    "04-config-harden": 3,
}
HIDDEN_COUNTS = {
    "02-l4-route-foundation": 12,
    "03-reconcile-translate": 44,
    "04-config-harden": 0,
}
ORACLE_REFERENCE_FILE_COUNT = 71

sys.path.insert(0, str(TESTS))
import score_formula  # noqa: E402
import stage_check  # noqa: E402


def config() -> dict:
    return tomllib.loads((PKG / "task.toml").read_text(encoding="utf-8"))


def patch_files(stage: str) -> list[tuple[str, str]]:
    text = (STEPS / stage / "solution" / "golden.patch").read_text(encoding="utf-8", errors="replace")
    return re.findall(r"^diff --git a/(.+?) b/(.+?)$", text, re.MULTILINE)


def hidden_test_names(stage: str) -> list[str]:
    names: set[str] = set()
    for path in (TESTS / "hidden" / stage).rglob("*_test.go"):
        names.update(re.findall(r"^func (Test[A-Za-z0-9_]+)\(", path.read_text(encoding="utf-8"), re.M))
    names.discard("TestMain")
    return sorted(names)


def test_schema_version_and_strategy():
    cfg = config()
    assert cfg["schema_version"] == "1.3"
    assert cfg["multi_step_reward_strategy"] == "final"


def test_task_name_and_repo_metadata():
    cfg = config()
    assert cfg["task"]["name"] == "long-horizon/cilium-gateway-l4-routes"
    meta = cfg["metadata"]
    assert meta["repository"] == "cilium/cilium"
    assert meta["base_commit"] == "04fd6832fd9015c072d9d1577939484ebd69302f"
    assert meta["merge_commit"] == "cd9a3ce2d9cd1c8004e18587ec5fbc77f43c5c61"
    assert meta["source_license"] == "Apache-2.0"
    assert meta["expert_time_estimate_hours"] >= 24.0
    assert "source_pull_request" not in meta
    env = cfg["environment"]
    assert env.get("allow_internet") is False
    for step in cfg["steps"]:
        assert step.get("environment", {}).get("allow_internet") is False, step["name"]


def test_step_names_match_directories():
    assert [step["name"] for step in config()["steps"]] == STAGES


def test_no_min_reward_anywhere():
    assert all("min_reward" not in step for step in config()["steps"])


def test_expert_time_estimate():
    assert config()["metadata"]["expert_time_estimate_hours"] == 36.0


def test_environment_resources_and_network():
    env = config()["environment"]
    # The agent runs without egress. base_commit is disclosed and the source pull request is
    # public, so an agent with network access could fetch the reference implementation and the
    # withheld test suite outright. Isolation is enforced here rather than asserted in prose.
    assert env["allow_internet"] is False
    assert env["cpus"] == 8
    assert env["memory_mb"] == 16384
    assert env["storage_mb"] == 20480


def test_verifier_env_block_present():
    cfg = config()
    env = cfg.get("verifier", {}).get("env", cfg.get("verifier.env", {}))
    for key in ("OPENAI_API_KEY", "NONDETERMINISTIC_LAMBDA"):
        assert key in env


def test_tags_field_present():
    assert "tags" in config()["metadata"]


def test_patches_disjoint_and_provenanced():
    seen: set[str] = set()
    for stage in PATCH_STAGES:
        patch = STEPS / stage / "solution" / "golden.patch"
        provenance = json.loads((patch.parent / "provenance.json").read_text(encoding="utf-8"))
        pairs = patch_files(stage)
        assert pairs and all(a == b for a, b in pairs)
        files = sorted(a for a, _ in pairs)
        assert files == sorted(provenance["files"])
        assert not seen.intersection(files)
        seen.update(files)
        digest = hashlib.sha256(patch.read_bytes()).hexdigest()
        assert digest == provenance["patch_sha256"]
        assert provenance["incremental"] is True
    assert len(seen) == ORACLE_REFERENCE_FILE_COUNT
    assert not [p for p in seen if p.endswith("_test.go")]
    assert ".github/renovate.json5" not in seen


def test_provenance_file_counts():
    for stage, want in PATCH_COUNTS.items():
        prov = json.loads((STEPS / stage / "solution" / "provenance.json").read_text(encoding="utf-8"))
        assert len(prov["files"]) == want


def test_hidden_corpus_counts():
    for stage, want in HIDDEN_COUNTS.items():
        assert len(hidden_test_names(stage)) == want


def test_requirement_map_present():
    payload = json.loads((TESTS / "contracts" / "requirement_map.json").read_text(encoding="utf-8"))
    assert len(payload["stages"]) == 4
    assert payload["promptToTestFairness"]
    dep = json.loads((TESTS / "contracts" / "stage_dependencies.json").read_text(encoding="utf-8"))
    rows = {row["stage"]: row for row in dep["stages"]}
    assert list(rows) == STAGES
    for stage in PATCH_STAGES:
        assert sorted(rows[stage]["newTestFunctions"]) == hidden_test_names(stage)
        assert rows[stage]["dispatchKey"] == DISPATCH[stage]


def test_artifact_schema_matches_stage_check():
    shipped = json.loads((TESTS / "contracts" / "artifacts.schema.json").read_text(encoding="utf-8"))
    assert shipped == stage_check.artifact_schema_document()


def test_stage_check_stage_aliases():
    assert stage_check.resolve_stage("diagnose") == STAGES[0]
    assert stage_check.resolve_stage("foundation") == STAGES[1]
    assert stage_check.resolve_stage("reconcile") == STAGES[2]
    assert stage_check.resolve_stage("harden") == STAGES[3]


def test_stage_weights_sum_to_one():
    for stage in STAGES:
        assert abs(sum(stage_check.WEIGHTS[stage].values()) - 1.0) < 1e-9


def test_executable_weight_dominates_patch_stages():
    for stage in PATCH_STAGES:
        w = stage_check.WEIGHTS[stage]
        executable = (
            w.get("build_clean", 0.0)
            + w.get("full_build", 0.0)
            + w.get("hidden_tests_pass", 0.0)
            + w.get("vet_clean", 0.0)
            + w.get("helm_l4_config", 0.0)
            + w.get("implementation_closure", 0.0)
        )
        assert executable >= 0.5


def test_critical_checks_match_what_the_prompts_say_decides():
    """Every prompt-required artifact either gates its stage or is declared non-decisive.

    The defect was the mismatch, not the choice: prompts listed reports under "Write:"
    while none of them could block a binary success. Stage 01's product IS the
    diagnosis, so its report and handoff gate. Stages 02-04 produce working code, so
    their reports stay scored-but-not-decisive -- and now say so.
    """
    assert {"diagnosis_report", "handoff"}.issubset(
        set(stage_check.CRITICAL_CHECKS["01-diagnose"])
    ), "stage 01's own deliverable must gate it"
    s1 = (STEPS / "01-diagnose" / "instruction.md").read_text(encoding="utf-8")
    assert "decide this stage" in s1
    for stage in PATCH_STAGES:
        for prose in ("implementation_report", "review_report", "final_report"):
            assert prose not in stage_check.CRITICAL_CHECKS[stage], (
                f"{prose} must not zero a correct implementation"
            )
        text = (STEPS / stage / "instruction.md").read_text(encoding="utf-8")
        assert "never" in text and "decisive" in text, (
            f"{stage} must state that its report is not decisive"
        )
    for stage in PATCH_STAGES:
        assert {"hidden_tests_pass", "vet_clean"}.issubset(set(stage_check.CRITICAL_CHECKS[stage]))


def test_step_wrappers_dispatch_correctly():
    for stage in STAGES:
        wrapper = (STEPS / stage / "tests" / "test.sh").read_text(encoding="utf-8")
        assert f"stage_test.sh {DISPATCH[stage]}" in wrapper


def test_every_step_has_instruction_and_solve():
    for stage in STAGES:
        assert (STEPS / stage / "instruction.md").is_file()
        assert (STEPS / stage / "solution" / "solve.sh").is_file()


def test_patch_stages_have_golden_and_provenance():
    for stage in PATCH_STAGES:
        assert (STEPS / stage / "solution" / "golden.patch").is_file()
        assert (STEPS / stage / "solution" / "provenance.json").is_file()


def test_diagnose_instruction_forbids_production_changes():
    text = (STEPS / "01-diagnose" / "instruction.md").read_text(encoding="utf-8").lower()
    assert "do not modify" in text


def test_instructions_are_outcome_focused():
    for stage in STAGES:
        text = (STEPS / stage / "instruction.md").read_text(encoding="utf-8").lower()
        assert "verifierprobe" not in text
        assert "go build" not in text
        assert "go vet" not in text


def test_stage03_instruction_discloses_reconcile_scope():
    text = (STEPS / "03-reconcile-translate" / "instruction.md").read_text(encoding="utf-8")
    assert "EndpointSlice" in text
    assert "LoadBalancer" in text


def test_stage04_instruction_discloses_closure_proof():
    text = (STEPS / "04-config-harden" / "instruction.md").read_text(encoding="utf-8")
    assert "04fd6832fd9015c072d9d1577939484ebd69302f" in text
    assert "implementation_closure_proof.json" in text
    assert "feature_complete" in text
    assert 'bpf-lb-sock-hostns-only: "true"' in text
    assert "TCPRoute" in text and "UDPRoute" in text


def test_reproducer_gate_requires_all_terms():
    source = (TESTS / "stage_check.py").read_text(encoding="utf-8")
    assert "has_tcp" in source and "has_udp" in source and "has_context" in source
    assert "tcproute" in source and "udproute" in source


def test_oracle_solve_scripts_do_not_reference_tests():
    for stage in STAGES:
        assert "/tests/" not in (STEPS / stage / "solution" / "solve.sh").read_text(encoding="utf-8")


def test_dockerfile_pins_base_and_go_toolchain():
    body = (PKG / "environment" / "Dockerfile").read_text(encoding="utf-8")
    assert "ARG GO_VERSION=1.26.0" in body
    assert "aac1b08a0fb0c4e0a7c1555beb7b59180b05dfc5a3d62e40e9de90cd42f88235" in body
    assert "ARG BASE_COMMIT=04fd6832fd9015c072d9d1577939484ebd69302f" in body
    assert "ARG BASE_TREE=b9cbf398d4ff4b760f36186c032c97fa2d4ef562" in body
    assert "rm -rf .git" in body
    assert "merge_reference_manifest.json" not in body
    assert "COPY steps/" not in body


def test_no_merge_manifest_in_agent_image():
    assert not (PKG / "environment" / "merge_reference_manifest.json").is_file()


def test_dockerfile_has_verifier_venv():
    body = (PKG / "environment" / "Dockerfile").read_text(encoding="utf-8")
    assert "/opt/verifier-venv" in body
    assert "pytest" in body


def test_fallback_reward_exists():
    assert (TESTS / "fallback_reward.py").is_file()


def test_stage_test_publishes_early_sentinel():
    wrapper = (TESTS / "stage_test.sh").read_text(encoding="utf-8")
    assert wrapper.index('> "$RESULT_DIR/reward.json"') < wrapper.index("stage_check.py")
    assert "cilium-gateway-l4-routes-verifier" in wrapper


def test_judge_toml_files_parse():
    for dimension in ("process", "validity", "task_quality", "merge_readiness"):
        data = tomllib.loads((TESTS / dimension / "judge.toml").read_text(encoding="utf-8"))
        assert data["judge"]["prompt_template"] == "../judge_prompt.md"
        assert "openai/gpt-5.6-terra" in data["judge"]["judge"]


def test_merge_readiness_has_six_dimensions():
    merge = tomllib.loads((TESTS / "merge_readiness" / "judge.toml").read_text(encoding="utf-8"))
    required = {
        "repository_conventions",
        "focused_change",
        "maintainability",
        "architecture",
        "useful_tests",
        "no_patch_bloat",
    }
    assert required.issubset({c["name"] for c in merge["criterion"]})


def test_task_quality_weight_zero():
    quality = tomllib.loads((TESTS / "task_quality" / "judge.toml").read_text(encoding="utf-8"))
    assert quality["judge"]["weight"] == 0.0


def test_reward_json_core_keys():
    assert score_formula.REWARD_JSON_CORE_KEYS == {
        "binary_reward",
        "deterministic_score",
        "reward",
        "training_score",
    }


def test_readme_has_mermaid_and_no_calibration_evidence():
    readme = (PKG / "README.md").read_text(encoding="utf-8")
    assert "mermaid" in readme
    for forbidden in ("oracle_passed", "eval_", "headroom", "QC status", "near_miss"):
        assert forbidden.lower() not in readme.lower(), f"README must not contain evaluation evidence: {forbidden}"


def test_calibration_summary_placeholder():
    summary = json.loads((PKG / "calibration_summary.json").read_text(encoding="utf-8"))
    # REVALIDATION_REQUIRED is a legitimate state: it says the recorded runs predate the
    # current graded corpus and must not be read as evidence for the packaged revision.
    # Claiming "oracle_passed" for a revision those runs never exercised would be worse.
    assert summary["status"] in {"oracle_passed", "pending_docker_validation", "REVALIDATION_REQUIRED"}
    if summary["status"] == "REVALIDATION_REQUIRED":
        assert summary.get("supersededBecause"), "a superseded calibration must say why"
        assert summary.get("requiredBeforeRelease"), "and what must be re-run"
    assert summary["task"] == "long-horizon/cilium-gateway-l4-routes"
    assert summary["noop"]["stage01_binary_reward"] == 0.0
    assert summary["oracle"]["results"]["04-config-harden"] == 1.0
    near_miss = summary.get("near_miss_controls") or []
    assert len(near_miss) >= 3


def test_tools_layout_canonical():
    tools = sorted(p.name for p in (PKG / "tools").glob("*") if p.is_file())
    # run_dead_code_control.sh is a release control, not runtime tooling: it plants the marker
    # strings the previous corpus grepped for as DEAD CODE and asserts the stage now scores 0.0.
    # It is the evidence that the corpus grades behaviour rather than source text.
    assert tools == ["docker_verify.sh", "run_dead_code_control.sh", "run_inline_judged_terminus.sh"]


def test_no_cross_task_contamination():
    forbidden = ("volcano-sh", "volcano-k8s135", "passiveAssumeCache", "83a654ff")
    for path in PKG.rglob("*"):
        if not path.is_file() or path.name in {"golden.patch", "test_package_contract.py"}:
            continue
        if path.suffix not in {".md", ".toml", ".py", ".sh", ".json"}:
            continue
        if ".build" in path.parts or "__pycache__" in path.parts:
            continue
        text = path.read_text(encoding="utf-8", errors="replace").lower()
        assert not [w for w in forbidden if w.lower() in text], path


def test_shell_scripts_lf_only():
    for script in PKG.rglob("*.sh"):
        if ".build" in script.parts:
            continue
        assert b"\r\n" not in script.read_bytes(), script






def test_stage04_closure_covers_the_same_ground_by_capability():
    """Four of the six exact paths became capability checks; two remain paths.

    The four Go files were graded by filename, which failed a solver that chose
    endpointslice_reconciler.go over endpointslice_reconcile.go. They are now matched by
    a disclosed symbol anywhere in the package. The two Helm templates stay exact
    because the chart resolves them by path -- there the path IS the requirement.
    """
    assert len(stage_check.CRITICAL_IMPLEMENTATION_CAPABILITIES) == 4
    assert len(stage_check.CRITICAL_IMPLEMENTATION_PATHS) == 2


def test_run_optional_judges_targets_final_stage():
    body = (TESTS / "run_optional_judges.sh").read_text(encoding="utf-8")
    assert "04-config-harden:1" in body
    assert "OPENAI_API_KEY" in body
    assert "openai/gpt-5.6-terra" in body


def test_judge_prompt_mentions_cilium():
    text = (TESTS / "judge_prompt.md").read_text(encoding="utf-8").lower()
    assert "cilium" in text
    assert "46184" not in text


def test_stage_judge_inputs_default_family():
    assert "cilium-gateway-l4-routes-tier2" in (TESTS / "stage_judge_inputs.py").read_text(encoding="utf-8")


def _corpus_text(stage: str) -> str:
    root = TESTS / "hidden" / stage
    return "\n".join(
        p.read_text(encoding="utf-8", errors="replace") for p in sorted(root.rglob("*_test.go"))
    )


def test_hidden_stage02_exercises_l4_foundation():
    """Stage 02 grades the withheld upstream tests for the helper and indexer packages."""
    files = sorted(
        p.relative_to(TESTS / "hidden" / "02-l4-route-foundation").as_posix()
        for p in (TESTS / "hidden" / "02-l4-route-foundation").rglob("*_test.go")
    )
    assert files, "stage 02 must ship a corpus"
    # Injected at real repository paths, so they compile against the agent's own packages.
    assert all(f.startswith("operator/pkg/gateway-api/") for f in files), files
    got = set(hidden_test_names("02-l4-route-foundation"))
    for want in ("TestHasTCPRouteSupport", "TestHasUDPRouteSupport",
                 "TestIndexTCPRouteByGateway", "TestIndexUDPRouteByGateway",
                 "TestTCPRouteInputValidProtocols", "TestUDPRouteInputValidProtocols",
                 "TestCheckGatewayRouteKindAllowed_rejectsWrongKind",
                 "TestCheckGatewayMatchingPorts_rejectsWrongPort"):
        assert want in got, f"{want} missing from stage 02 corpus"


def test_hidden_stage03_exercises_reconcile_and_translation():
    """Stage 03 grades real reconciliation and translation, not source tokens."""
    got = set(hidden_test_names("03-reconcile-translate"))
    # Behavioural entry points only. Test_matchServicePort, Test_matchEndpointSlicePort,
    # Test_portProtocol, Test_normalizedWeight and Test_buildEndpointSlice_familySuffix
    # were removed: they were unit tests of UNEXPORTED helpers, so they graded a
    # particular internal decomposition rather than user-visible behaviour. What they
    # covered -- port matching, protocol mapping, weight normalisation, per-family slice
    # construction -- is still exercised through reconciliation and translation below.
    for want in ("Test_endpointSliceReconciler_Reconcile",
                 "Test_desiredL4EndpointSlices_dualStack",
                 "Test_desiredL4EndpointSlices_weightAnnotation"):
        assert want in got, f"{want} missing from stage 03 corpus"
    for gone in ("Test_matchServicePort", "Test_portProtocol", "Test_normalizedWeight"):
        assert gone not in got, f"{gone} grades an internal helper and must stay removed"
    # The behaviour QC found untested previously: weights, EndpointSlices and Envoy cleanup.
    text = _corpus_text("03-reconcile-translate")
    assert "EndpointSlice" in text
    assert "Weight" in text


def test_hidden_corpus_lives_in_packages_the_stage_owns():
    """A corpus file must land in a package its own stage's golden patch actually changes."""
    for stage in ("02-l4-route-foundation", "03-reconcile-translate"):
        patch = (STEPS / stage / "solution" / "golden.patch").read_text(encoding="utf-8", errors="replace")
        touched_dirs = {
            path.rsplit("/", 1)[0]
            for path in re.findall(r"^diff --git a/(\S+) b/", patch, re.MULTILINE)
        }
        for src in (TESTS / "hidden" / stage).rglob("*_test.go"):
            rel = src.relative_to(TESTS / "hidden" / stage).as_posix()
            d = rel.rsplit("/", 1)[0]
            assert d in touched_dirs, f"{stage}: {rel} sits in {d}, which that stage never changes"


def test_hidden_corpus_is_behavioural_not_source_scanning():
    """Guard against the defect this corpus replaced.

    The previous corpus read implementation files and asserted `strings.Contains` on internal
    identifiers, so dead code satisfied it and a differently-named correct implementation
    failed it. Graded tests must exercise the code, not read it.
    """
    for stage in ("02-l4-route-foundation", "03-reconcile-translate"):
        for src in (TESTS / "hidden" / stage).rglob("*_test.go"):
            text = src.read_text(encoding="utf-8", errors="replace")
            # Reading a golden-file FIXTURE is normal table-driven testing. What must not
            # happen is reading the implementation's own source and asserting on its text,
            # which is what the corpus this replaced did.
            for line in text.splitlines():
                if "os.ReadFile" not in line and "os.Open" not in line:
                    continue
                assert "testdata" in line or "file" in line, (
                    f"{src.name}: reads a file that is not a testdata fixture: {line.strip()}"
                )
            assert ".go\"" not in text or "testdata" in text, (
                f"{src.name} appears to read Go source files"
            )
            assert "strings.Contains(text," not in text, (
                f"{src.name} asserts on source text instead of behaviour"
            )


def test_stage04_reruns_cumulative_corpus_and_renders_helm():
    """Stage 04 ships no corpus of its own; it re-runs 02-03 and renders the chart."""
    own = list((TESTS / "hidden" / "04-config-harden").rglob("*_test.go")) if (TESTS / "hidden" / "04-config-harden").is_dir() else []
    assert not own, "stage 04 is cumulative; it should not add its own corpus files"
    check = (TESTS / "stage_check.py").read_text(encoding="utf-8")
    assert "def _helm_render(" in check, "stage 04 must render the chart"
    assert "--show-only" in check and "gatewayAPI.enabled=" in check
    # Rendered twice, so the CONDITION is observable rather than the template text.
    assert check.count("_helm_render(") >= 3


def test_corpus_linking_identifiers_are_disclosed():
    """Every corpus-bound name the agent cannot derive must be published.

    The graded corpus is the upstream test suite, so it compiles against upstream's own
    identifiers. If one of those is absent from the base tree AND undisclosed, an agent that
    implements the behaviour correctly under different names cannot compile the tests at all --
    the whole corpus fails at once and the loss looks like an agent failure when it is a task
    defect. A data-os run died exactly this way on `undefined: L4Listener`.
    """
    snapshot = json.loads(
        (TESTS / "contracts" / "corpus_future_only.json").read_text(encoding="utf-8")
    )
    rmap = json.loads((TESTS / "contracts" / "requirement_map.json").read_text(encoding="utf-8"))
    published = rmap.get("linkingContracts", {}).get("byStage", {})
    dockerfile = (PKG / "environment" / "Dockerfile").read_text(encoding="utf-8")

    for stage, needed in snapshot["byStage"].items():
        if not needed:
            continue
        disclosed = set(published.get(stage, []))
        missing = sorted(set(needed) - disclosed)
        assert not missing, (
            f"{stage}: the corpus binds {missing}, which are absent from the base tree and are "
            f"not published in /app/contracts/{stage}.md"
        )
        # The contract must actually be written by the image, not merely recorded in JSON.
        assert f"/app/contracts/{stage}.md" in dockerfile, (
            f"{stage}: requirement_map lists a contract the image never writes"
        )
        for name in needed:
            assert name in dockerfile, (
                f"{stage}: {name} is recorded as disclosed but does not appear in the "
                f"contract the image writes"
            )


def test_stage_briefs_point_at_their_contract():
    """A published contract is useless if the brief never tells the agent it exists."""
    snapshot = json.loads(
        (TESTS / "contracts" / "corpus_future_only.json").read_text(encoding="utf-8")
    )
    for stage, needed in snapshot["byStage"].items():
        if not needed:
            continue
        brief = (STEPS / stage / "instruction.md").read_text(encoding="utf-8")
        assert f"/app/contracts/{stage}.md" in brief, (
            f"{stage}: brief does not point the agent at its linking contract"
        )


def test_integrity_does_not_void_ordinary_agent_work():
    """valid_trial=0 must mean misconduct, never routine editing.

    Two real stages were voided and neither touched the network:
      * a heredoc was recorded with escaped newlines, so "...\ncat << EOF" contained
        the literal substring "ncat" and matched the ncat network tool;
      * a python one-liner wrote Go source containing EnqueueRequestsFromMapFunc and
        matched the bare word "requests".
    These are the exact shapes from that run.
    """
    benign = [
        # heredoc, as recorded (escaped newlines) -- the "ncat" trap
        'cat << \'GEOF\' > "$TMPFILE"\npackage main\nimport (\n\t"k8s.io/apimachinery/pkg/runtime/schema"\n)',
        # python writing controller code -- the "requests" trap
        'python3 -c \'c = open(path).read(); c = c.replace("a", "handler.EnqueueRequestsFromMapFunc")\'',
        # python writing a file at all
        'python3 -c "with open(\'/app/output/01-diagnose/reproduce.sh\', \'w\') as f: f.write(\'#!/usr/bin/env bash\')"',
        "git remote -v",                      # read-only diagnostic
        "go build ./operator/pkg/gateway-api/...",
        "grep -rn 'resources.requests.cpu' install/kubernetes/",
    ]
    for cmd in benign:
        line = stage_check.command_surface(cmd)
        for name, rx in (
            ("NONLOCAL_EGRESS", stage_check.NONLOCAL_EGRESS),
            ("PYTHON_NETWORK", stage_check.PYTHON_NETWORK),
            ("FORBIDDEN_COMMANDS", stage_check.FORBIDDEN_COMMANDS),
        ):
            m = rx.search(line)
            assert not m, f"{name} voids benign work: {m.group(0)!r} in {cmd[:70]!r}"

    must_catch = [
        ("curl https://api.github.com/repos/cilium/cilium/pulls/5000", stage_check.NONLOCAL_EGRESS),
        ("wget http://example.com/patch.diff", stage_check.NONLOCAL_EGRESS),
        ("python3 -c 'import requests; requests.get(\"http://x.io\")'", stage_check.PYTHON_NETWORK),
        ("python3 -c 'import socket; socket.socket()'", stage_check.PYTHON_NETWORK),
        ("git clone https://github.com/cilium/cilium", stage_check.FORBIDDEN_COMMANDS),
        ("git remote add up https://github.com/cilium/cilium", stage_check.FORBIDDEN_COMMANDS),
        ("pip install requests", stage_check.FORBIDDEN_COMMANDS),
    ]
    for cmd, rx in must_catch:
        assert rx.search(stage_check.command_surface(cmd)), f"no longer caught: {cmd!r}"


def test_integrity_findings_are_root_causable():
    """An invalidated trial must be explainable from the retained bundle.

    The reviewer could not determine why two stages were voided: the finding held 120
    characters and no rule id. Every rule now carries a note, and findings record the
    rule, the matched text and the full command.
    """
    assert set(stage_check.INTEGRITY_RULE_NOTES) == {
        "reference-solution leakage",
        "forbidden command",
        "forbidden python network use",
        "non-local egress attempt",
    }
    for rule, note in stage_check.INTEGRITY_RULE_NOTES.items():
        assert len(note) > 40, f"{rule} needs a reviewer-facing explanation"
    src = (TESTS / "stage_check.py").read_text(encoding="utf-8")
    assert '"evidence": evidence' in src, "integrity payload must publish structured evidence"


def test_golden_patches_are_lf_only():
    """A CRLF byte in a patch makes `git apply` fail and takes the whole stage with it.

    Editing a patch with a text-mode writer on Windows silently rewrote every line
    ending; the oracle then scored 0.0 on that stage because solve.sh runs under
    `set -e` and exits the moment the patch is rejected. Patches are binary artifacts.
    """
    for stage in PATCH_STAGES:
        patch = STEPS / stage / "solution" / "golden.patch"
        data = patch.read_bytes()
        assert b"\r\n" not in data, f"{stage}/golden.patch contains CRLF; git apply will reject it"
    for script in sorted(PKG.rglob("*.sh")):
        assert b"\r\n" not in script.read_bytes(), f"{script.name} contains CRLF"


def test_protected_material_cannot_survive_a_crashed_grading_run():
    """Injected tests are recorded before the copy into a verifier-owned sandbox.

    Hidden tests never land in the persistent candidate tree. A crash during grading
    may leave files under /opt/verifier-grade, which the agent cannot read; manifests
    record sandbox paths for cleanup.
    """
    src = (TESTS / "stage_check.py").read_text(encoding="utf-8")
    assert "def purge_leaked_injections" in src
    assert "def materialize_grade_sandbox" in src
    assert "target_root=sandbox" in src
    assert "def candidate_freeze" in src
    # the manifest must be written before any copyfile in inject_hidden
    body = src[src.index("def inject_hidden"):src.index("def restore_hidden")]
    assert body.index("_injection_manifest") < body.index("shutil.copyfile"), (
        "the injection manifest must be recorded BEFORE protected files are copied"
    )
    # and the purge must run before the stage functions dispatch
    main_body = src[src.index("purge_leaked_injections()"):]
    assert main_body.index("purge_leaked_injections()") < main_body.index("checks = diagnose()")
    # verifier-owned, not agent-writable
    dockerfile = (PKG / "environment" / "Dockerfile").read_text(encoding="utf-8")
    assert "/opt/verifier-state" in dockerfile and "chmod 0700 /opt/verifier-state" in dockerfile
    assert "/opt/verifier-grade" in dockerfile
    assert "chmod 0700 /opt/verifier-state /opt/verifier-grade" in dockerfile


def test_every_graded_result_identifies_the_candidate():
    """A result must say what it graded, or a re-grade cannot be compared to it."""
    src = (TESTS / "stage_check.py").read_text(encoding="utf-8")
    assert 'integrity_report["candidate"] = frozen' in src
    for field in ("tree", "uncommittedFiles", "uncommittedDigest"):
        assert field in src, f"candidate freeze must record {field}"


def test_dockerfile_has_no_user_instruction():
    """Harbor rejects a USER instruction; the agent identity belongs in task.toml.

    The package was refused at upload with:
      environment/Dockerfile must not contain a USER instruction;
      set [agent].user in task.toml instead
    """
    text = (PKG / "environment" / "Dockerfile").read_text(encoding="utf-8")
    offenders = [ln for ln in text.splitlines() if ln.strip().startswith("USER ")]
    assert not offenders, f"Dockerfile must not contain USER: {offenders}"
    cfg = tomllib.loads((PKG / "task.toml").read_text(encoding="utf-8"))
    assert cfg.get("agent", {}).get("user") == "agent", (
        "the unprivileged account must be declared as [agent].user in task.toml"
    )
    # the account still has to exist in the image for that declaration to resolve
    assert "useradd" in text and "agent" in text


def _corpus_all_text() -> str:
    return "\n".join(p.read_text(encoding="utf-8", errors="replace")
                     for p in (TESTS / "hidden").rglob("*.go"))


def test_every_new_identifier_the_corpus_binds_is_disclosed():
    """The protected tests compile inside the agent's packages.

    A name they use that no contract states is not a hidden nicety: it is a compile
    error the solver cannot predict, and it fails the whole package at once. A real run
    lost stages 03 and 04 to `undefined: L4ProtocolTCP`, which was introduced by the
    golden patch, referenced four times by the corpus, and disclosed nowhere.
    """
    exclusions = json.loads(
        (TESTS / "contracts" / "disclosure_exclusions.json").read_text(encoding="utf-8")
    )
    known = set(exclusions["preexistingAtBase"]) | set(exclusions["goLanguageOrImportNoise"])
    dockerfile = (PKG / "environment" / "Dockerfile").read_text(encoding="utf-8")

    def contract_for(stage: str) -> str:
        """Only the block handed to the agent AT THAT STAGE counts as disclosure.

        A symbol documented in a later stage's contract is invisible to the agent that
        has to implement it. That mistake was made once with TCPRouteListKind, and a
        whole-Dockerfile comparison did not catch it.
        """
        m = re.search(
            rf"cat > /app/contracts/{re.escape(stage)}\.md <<'(\w+)'\n(.*?)\n\1\n",
            dockerfile, re.S)
        return m.group(2) if m else ""

    added: set[str] = set()
    for stage in PATCH_STAGES:
        patch = STEPS / stage / "solution" / "golden.patch"
        if not patch.is_file():
            continue
        for line in patch.read_text(encoding="utf-8", errors="replace").splitlines():
            if not line.startswith("+") or line.startswith("+++"):
                continue
            body = line[1:]
            added |= set(re.findall(
                r"^(?:func|type|var|const)\s+\(?[^)]*\)?\s*([A-Za-z_]\w+)", body))
            added |= set(re.findall(r"^\s*([A-Z]\w+)\s+[A-Za-z_]\w*\s*=", body))

    undisclosed: list[str] = []
    for stage in PATCH_STAGES:
        root = TESTS / "hidden" / stage
        if not root.is_dir():
            continue
        stage_corpus = "\n".join(
            f.read_text(encoding="utf-8", errors="replace") for f in root.rglob("*.go")
        )
        stage_contract = contract_for(stage)
        for name in sorted(added):
            if name in known:
                continue
            if not re.search(rf"\b{re.escape(name)}\b", stage_corpus):
                continue
            if not re.search(rf"\b{re.escape(name)}\b", stage_contract):
                undisclosed.append(f"{stage}: {name}")
    assert not undisclosed, (
        "graded tests bind identifiers no contract discloses: " + ", ".join(undisclosed)
    )


def test_closure_grades_capability_not_filename():
    """Requiring an exact filename grades internal layout, not behaviour.

    A real solver implemented the reconciler in endpointslice_reconciler.go and failed
    because the check demanded endpointslice_reconcile.go.
    """
    assert stage_check.CRITICAL_IMPLEMENTATION_CAPABILITIES
    for path in stage_check.CRITICAL_IMPLEMENTATION_PATHS:
        assert path.startswith("install/kubernetes/"), (
            f"{path} is graded by exact path but is not a Helm-resolved file"
        )
