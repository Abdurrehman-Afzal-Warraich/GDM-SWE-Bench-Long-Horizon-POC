#!/usr/bin/env bash
# Build the task image and run Oracle grading for all four stages inside Docker.
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
IMAGE="${IMAGE:-lh-cilium-l4:v3}"
STAGES=(
  "01-diagnose"
  "02-l4-route-foundation"
  "03-reconcile-translate"
  "04-config-harden"
)
DISPATCH=(
  "diagnose"
  "foundation"
  "reconcile"
  "harden"
)

echo "== docker build =="
docker build -t "$IMAGE" "$ROOT/environment"

echo "== oracle verify =="
for i in "${!STAGES[@]}"; do
  stage="${STAGES[$i]}"
  key="${DISPATCH[$i]}"
  echo "--- $stage ---"
  docker run --rm \
    -v "$ROOT/tests:/tests:ro" \
    -v "$ROOT/steps:/task-steps:ro" \
    "$IMAGE" \
    bash -lc "
      set -euo pipefail
      export TRUSTED_ORACLE=1
      mkdir -p /app/output /logs/verifier /logs/agent
      bash /task-steps/${stage}/solution/solve.sh
      bash /tests/stage_test.sh ${key}
      python3 - <<'PY'
import json
from pathlib import Path
p = Path('/logs/verifier/reward.json')
d = json.loads(p.read_text())
br = float(d.get('binary_reward', 0))
assert br == 1.0, d
print('binary_reward=', br)
PY
    "
done

echo "ALL STAGES PASSED"
