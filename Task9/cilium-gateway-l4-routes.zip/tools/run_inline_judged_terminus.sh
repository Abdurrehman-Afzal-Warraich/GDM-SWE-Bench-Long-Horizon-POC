#!/usr/bin/env bash
# Optional wrapper for judged Terminus runs (Harbor 0.8+).
set -euo pipefail
JOB="${1:?job name required}"
harbor run -p "$(dirname "$0")/.." -a terminus --job-name "$JOB"
bash "$(dirname "$0")/../tests/run_optional_judges.sh" "/logs/verifier"
