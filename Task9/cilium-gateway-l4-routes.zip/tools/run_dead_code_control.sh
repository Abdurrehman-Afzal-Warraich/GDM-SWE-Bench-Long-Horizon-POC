#!/usr/bin/env bash
# The control that proves the corpus rework did what QC asked.
#
# The previous graded corpus asserted `strings.Contains` on implementation markers, so an
# implementation that merely MENTIONED `normalizedWeight`, `desiredL4EndpointSlices`,
# `resolveBackendEndpoints`, `patchFrontend` or the comment `No Envoy config is needed` passed
# the gate without doing any of the work. QC called this out under anti_cheat_robustness and
# outcome_verified.
#
# This control takes the PRISTINE base tree, adds a file containing every one of those markers
# as dead code and nothing else, and grades stage 03.
#
#   Against the old corpus this scored a pass.
#   Against the withheld upstream suite it must score 0.0, because nothing reconciles,
#   translates or synchronises anything.
#
# A pass here is a regression, not a success.
set -euo pipefail
export MSYS_NO_PATHCONV=1

TASK_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
IMAGE="${IMAGE:-lh-cilium-l4:rework}"
STAGE="${STAGE:-03-reconcile-translate}"
C=lh-deadcode

cleanup() { docker rm -f "$C" >/dev/null 2>&1 || true; }
trap cleanup EXIT

docker rm -f "$C" >/dev/null 2>&1 || true
docker run -d --name "$C" \
  -v "$TASK_ROOT/tests:/tests:ro" \
  -v "$TASK_ROOT/steps:/steps:ro" \
  "$IMAGE" sleep infinity >/dev/null
docker exec "$C" bash -lc 'mkdir -p /app/output /logs/verifier /logs/agent /solution'

echo "==> planting the markers as dead code on the pristine base tree"
docker exec "$C" bash -lc 'cat > /testbed/operator/pkg/model/translation/gateway-api/l4_markers.go <<'"'"'EOF'"'"'
// SPDX-License-Identifier: Apache-2.0

package gatewayapi

// Every string the previous corpus grepped for, and nothing that does any work.
// No Envoy config is needed

var normalizedWeight int32

func desiredL4EndpointSlices() any { return nil }

func resolveBackendEndpoints() any { return nil }

func patchFrontend() any { return nil }

func ensureOwnedEnvoyConfigDeleted() {}
EOF
echo planted'

echo "==> grading ${STAGE} on that tree"
docker exec "$C" bash -lc "RESULT_DIR=/logs/verifier bash /tests/stage_test.sh ${STAGE} >/dev/null 2>&1 || true"
REWARD="$(docker exec "$C" bash -lc 'python3 -c "import json;print(json.load(open(\"/logs/verifier/reward.json\")).get(\"binary_reward\"))"' 2>/dev/null || echo ERR)"

echo
echo "dead-code near-miss binary_reward = ${REWARD}"
if [ "$REWARD" = "0.0" ]; then
  echo "PASS: the markers alone no longer satisfy the gate."
else
  echo "REGRESSION: markers alone scored ${REWARD}; the corpus is still source-scanning."
  exit 1
fi
