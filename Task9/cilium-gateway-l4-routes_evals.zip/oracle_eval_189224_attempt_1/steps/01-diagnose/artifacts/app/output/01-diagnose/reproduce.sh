#!/usr/bin/env bash
set -uo pipefail
cd /testbed
echo "== TCPRoute/UDPRoute helper packages =="
if [ -f operator/pkg/gateway-api/helpers/tcproute.go ]; then
  echo "unexpected: tcproute helper already present"
else
  echo "GAP: operator/pkg/gateway-api/helpers/tcproute.go missing"
fi
if [ -f operator/pkg/gateway-api/helpers/udproute.go ]; then
  echo "unexpected: udproute helper already present"
else
  echo "GAP: operator/pkg/gateway-api/helpers/udproute.go missing"
fi
echo "== endpointslice reconciler =="
if [ -f operator/pkg/gateway-api/endpointslice_reconcile.go ]; then
  echo "unexpected: endpointslice reconciler already present"
else
  echo "GAP: dedicated EndpointSlice reconciliation for L4 routes absent"
fi
echo "== operator RBAC for L4 routes =="
if grep -q tcproutes install/kubernetes/cilium/templates/cilium-operator/clusterrole.yaml 2>/dev/null; then
  echo "unexpected: tcproutes RBAC already present"
else
  echo "GAP: clusterrole lacks tcproutes/udproutes permissions"
fi
exit 1
