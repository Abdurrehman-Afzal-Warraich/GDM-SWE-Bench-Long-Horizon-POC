// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

package gateway_api

import (
"context"
"log/slog"

discoveryv1 "k8s.io/api/discovery/v1"
k8serrors "k8s.io/apimachinery/pkg/api/errors"
ctrl "sigs.k8s.io/controller-runtime"
"sigs.k8s.io/controller-runtime/pkg/client"

controllerruntime "github.com/cilium/cilium/operator/pkg/controller-runtime"
"github.com/cilium/cilium/pkg/logging/logfields"
)

type endpointSliceReconciler struct {
client.Client
logger *slog.Logger
}

func newEndpointSliceReconciler(mgr ctrl.Manager, logger *slog.Logger) *endpointSliceReconciler {
return &endpointSliceReconciler{
Client: mgr.GetClient(),
logger: logger,
}
}

func (r *endpointSliceReconciler) Reconcile(ctx context.Context, req ctrl.Request) (ctrl.Result, error) {
scopedLog := r.logger.With(logfields.Resource, req.NamespacedName)
scopedLog.DebugContext(ctx, "Reconciling EndpointSlice")

epSlice := &discoveryv1.EndpointSlice{}
if err := r.Get(ctx, req.NamespacedName, epSlice); err != nil {
if k8serrors.IsNotFound(err) {
return controllerruntime.Success()
}
return controllerruntime.Fail(err)
}

if epSlice.Labels == nil || epSlice.Labels[EndpointSliceManagedByLabel] != EndpointSliceManagedByValue {
return controllerruntime.Success()
}

return controllerruntime.Success()
}

func (r *endpointSliceReconciler) SetupWithManager(mgr ctrl.Manager) error {
return ctrl.NewControllerManagedBy(mgr).
For(&discoveryv1.EndpointSlice{}).
Complete(r)
}
