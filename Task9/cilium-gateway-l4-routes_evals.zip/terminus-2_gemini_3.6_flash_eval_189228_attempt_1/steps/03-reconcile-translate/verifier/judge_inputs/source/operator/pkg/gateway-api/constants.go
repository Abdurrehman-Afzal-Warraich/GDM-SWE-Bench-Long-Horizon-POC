// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

package gateway_api

const (
BackendPortAnnotation          = "service.cilium.io/backend-port"
BackendServiceAnnotation       = "service.cilium.io/backend-service"
EndpointSliceManagedByLabel    = "endpointslice.kubernetes.io/managed-by"
EndpointSliceManagedByValue    = "cilium-gateway-api-controller"
EndpointSliceServiceNameLabel = "kubernetes.io/service-name"
EndpointSliceWeightAnnotation  = "service.cilium.io/weight"
lbAlgorithmAnnotation          = "service.cilium.io/lb-algorithm"
lbAlgorithmMaglev              = "maglev"
)
