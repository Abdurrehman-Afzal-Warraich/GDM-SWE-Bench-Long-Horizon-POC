// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

package gateway_api

import (
"testing"
"github.com/stretchr/testify/assert"
"github.com/cilium/cilium/operator/pkg/model"
)

func TestContract03TranslationIdentifiers(t *testing.T) {
assert.Equal(t, "service.cilium.io/backend-port", BackendPortAnnotation)
assert.Equal(t, "service.cilium.io/backend-service", BackendServiceAnnotation)
assert.Equal(t, "endpointslice.kubernetes.io/managed-by", EndpointSliceManagedByLabel)
assert.Equal(t, "cilium-gateway-api-controller", EndpointSliceManagedByValue)
assert.Equal(t, "kubernetes.io/service-name", EndpointSliceServiceNameLabel)
assert.Equal(t, "service.cilium.io/weight", EndpointSliceWeightAnnotation)
assert.Equal(t, "service.cilium.io/lb-algorithm", lbAlgorithmAnnotation)
assert.Equal(t, "maglev", lbAlgorithmMaglev)

owner := &model.FullyQualifiedResource{Name: "gw", Namespace: "default", Kind: "Gateway"}
dummyEP := desiredL7DummyEndpointSlice(owner, nil, nil)
assert.NotNil(t, dummyEP)

l4Listener := &model.L4Listener{Name: "l4", Protocol: model.L4ProtocolTCP, Port: 80}
l4EPs := desiredL4EndpointSlices(owner, l4Listener, nil, nil)
assert.NotEmpty(t, l4EPs)
}
