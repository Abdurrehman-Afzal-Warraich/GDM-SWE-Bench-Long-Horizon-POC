// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

package model

import (
"testing"
"github.com/stretchr/testify/assert"
)

func TestContract03ModelIdentifiers(t *testing.T) {
assert.Equal(t, "TCP", L4ProtocolTCP)
assert.Equal(t, "UDP", L4ProtocolUDP)

route := L4Route{Name: "test-route"}
listener := L4Listener{
Name:      "test-listener",
Protocol:  L4ProtocolTCP,
Port:      8080,
TCPRoutes: []L4Route{route},
UDPRoutes: []L4Route{route},
}

m := &Model{L4: []L4Listener{listener}}
listeners := m.GetListeners()
assert.Len(t, listeners, 1)
assert.Equal(t, uint32(8080), listeners[0].GetPort())
}
