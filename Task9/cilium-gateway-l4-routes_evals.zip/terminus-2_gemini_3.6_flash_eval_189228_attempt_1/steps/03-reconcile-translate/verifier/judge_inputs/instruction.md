# Reconcile and translate

Wire TCPRoute/UDPRoute so the operator creates **LoadBalancer Services** and **operator-managed EndpointSlices** with **backend weight** propagation using Cilium's service load-balancer (**not Envoy**).

Write:

- `/app/output/03-reconcile-translate/reconcile_report.json` — `reconcilers_added` (array, ≥1), `translation_scope` (string), `endpointslices` (string), `packages_touched` (array, ≥1), `verification_performed` (array, ≥1)
- `/app/output/handoff.json` — updated for this stage

Optional: upstream test fixture YAML under `/testbed/operator/pkg/gateway-api/testdata/` is not required.

The protected tests are Go files placed inside your packages, so they compile against the exact identifiers listed in `/app/contracts/03-reconcile-translate.md`. Match those names; everything else is your design choice.

The behaviour above decides this stage. The report and handoff are scored but never
decisive: a correct implementation is not failed for a documentation slip.
