#!/usr/bin/env bash
set -e

echo "Checking Gateway API TCPRoute and UDPRoute support in Cilium operator..."

TESTBED_DIR="/testbed"

MISSING_SUPPORT=0

if ! grep -q "TCPRoute" "$TESTBED_DIR/operator/pkg/gateway-api/helpers/schemes.go" 2>/dev/null; then
    echo "[-] gateway-api: tcproute is missing from RequiredGVKs/AllOptionalKinds"
    MISSING_SUPPORT=1
fi

if ! grep -q "UDPRoute" "$TESTBED_DIR/operator/pkg/gateway-api/helpers/schemes.go" 2>/dev/null; then
    echo "[-] gateway-api: udproute is missing from RequiredGVKs/AllOptionalKinds"
    MISSING_SUPPORT=1
fi

if ! grep -q "TCPRoute" "$TESTBED_DIR/operator/pkg/gateway-api/gateway.go" 2>/dev/null; then
    echo "[-] gateway-api: tcproute watches and indexers missing in gateway reconciler"
    MISSING_SUPPORT=1
fi

if [ $MISSING_SUPPORT -ne 0 ]; then
    echo "FAILURE: Cilium gateway-api operator lacks tcproute and udproute support (endpointslices translation and route controllers missing)."
    exit 1
else
    echo "SUCCESS: tcproute and udproute supported in gateway-api."
    exit 0
fi
