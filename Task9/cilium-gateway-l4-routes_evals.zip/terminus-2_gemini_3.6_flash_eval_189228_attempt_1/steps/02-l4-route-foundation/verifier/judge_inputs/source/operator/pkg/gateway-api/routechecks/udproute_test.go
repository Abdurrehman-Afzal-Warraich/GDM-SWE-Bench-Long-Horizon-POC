// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

package routechecks

import (
"context"
"testing"

"github.com/stretchr/testify/assert"
metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"
gatewayv1alpha2 "sigs.k8s.io/gateway-api/apis/v1alpha2"
)

func TestUDPRouteInput(t *testing.T) {
route := &gatewayv1alpha2.UDPRoute{
ObjectMeta: metav1.ObjectMeta{
Name:      "udp-route",
Namespace: "default",
},
}
input := &UDPRouteInput{
Ctx:      context.Background(),
UDPRoute: route,
}

assert.Equal(t, "default", input.GetNamespace())
assert.Equal(t, gatewayv1alpha2.SchemeGroupVersion.WithKind("UDPRoute"), input.GetGVK())
assert.Equal(t, []gatewayv1.ProtocolType{gatewayv1.UDPProtocolType}, input.GetValidProtocols())
}
