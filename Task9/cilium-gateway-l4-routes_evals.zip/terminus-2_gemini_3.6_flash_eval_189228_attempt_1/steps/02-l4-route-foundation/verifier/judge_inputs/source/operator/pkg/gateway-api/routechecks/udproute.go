// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

package routechecks

import (
"context"
"fmt"
"log/slog"
"reflect"
"time"

corev1 "k8s.io/api/core/v1"
k8serrors "k8s.io/apimachinery/pkg/api/errors"
metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
"k8s.io/apimachinery/pkg/runtime/schema"
"sigs.k8s.io/controller-runtime/pkg/client"
gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"
gatewayv1alpha2 "sigs.k8s.io/gateway-api/apis/v1alpha2"

"github.com/cilium/cilium/operator/pkg/gateway-api/helpers"
)

// UDPRouteInput is used to implement the Input interface for UDPRoute
type UDPRouteInput struct {
Ctx            context.Context
Logger         *slog.Logger
Client         client.Client
Grants         *gatewayv1.ReferenceGrantList
UDPRoute       *gatewayv1alpha2.UDPRoute
ControllerName string

gateways map[gatewayv1.ParentReference]*gatewayv1.Gateway
}

func (u *UDPRouteInput) SetParentCondition(ref gatewayv1.ParentReference, condition metav1.Condition) {
condition.LastTransitionTime = metav1.NewTime(time.Now())
condition.ObservedGeneration = u.UDPRoute.GetGeneration()

u.mergeStatusConditions(ref, []metav1.Condition{
condition,
})
}

func (u *UDPRouteInput) SetAllParentCondition(condition metav1.Condition) {
condition.LastTransitionTime = metav1.NewTime(time.Now())
condition.ObservedGeneration = u.UDPRoute.GetGeneration()

for _, parent := range u.UDPRoute.Spec.ParentRefs {
u.mergeStatusConditions(parent, []metav1.Condition{
condition,
})
}
}

func (u *UDPRouteInput) GetRules() []GenericRule {
var rules []GenericRule
for _, rule := range u.UDPRoute.Spec.Rules {
rules = append(rules, &UDPRouteRule{Rule: rule})
}
return rules
}

type UDPRouteRule struct {
Rule gatewayv1alpha2.UDPRouteRule
}

func (r *UDPRouteRule) GetBackendRefs() []gatewayv1.BackendRef {
var backends []gatewayv1.BackendRef
for _, backend := range r.Rule.BackendRefs {
backends = append(backends, gatewayv1.BackendRef(backend))
}
return backends
}

func (u *UDPRouteInput) GetGVK() schema.GroupVersionKind {
return gatewayv1alpha2.SchemeGroupVersion.WithKind("UDPRoute")
}

func (u *UDPRouteInput) GetNamespace() string {
return u.UDPRoute.Namespace
}

func (u *UDPRouteInput) GetHostnames() []gatewayv1.Hostname {
return nil
}

func (u *UDPRouteInput) GetGrants() []gatewayv1.ReferenceGrant {
if u.Grants == nil {
return nil
}
return u.Grants.Items
}

func (u *UDPRouteInput) GetContext() context.Context {
return u.Ctx
}

func (u *UDPRouteInput) GetClient() client.Client {
return u.Client
}

func (u *UDPRouteInput) GetControllerName() string {
return u.ControllerName
}

func (u *UDPRouteInput) GetGateway(parent gatewayv1.ParentReference) (*gatewayv1.Gateway, error) {
if u.gateways == nil {
u.gateways = make(map[gatewayv1.ParentReference]*gatewayv1.Gateway)
}

if gw, exists := u.gateways[parent]; exists {
return gw, nil
}

ns := helpers.NamespaceDerefOr(parent.Namespace, u.GetNamespace())
gw := &gatewayv1.Gateway{}

if err := u.Client.Get(u.Ctx, client.ObjectKey{Namespace: ns, Name: string(parent.Name)}, gw); err != nil {
if !k8serrors.IsNotFound(err) {
return nil, fmt.Errorf("error while getting gateway: %w", err)
}
return nil, fmt.Errorf("gateway %q does not exist: %w", parent.Name, err)
}

u.gateways[parent] = gw
return gw, nil
}

func (u *UDPRouteInput) GetParentGammaService(parent gatewayv1.ParentReference) (*corev1.Service, error) {
return nil, fmt.Errorf("GAMMA support is not implemented in this reconciler")
}

func (u *UDPRouteInput) Log() *slog.Logger {
return u.Logger
}

func (u *UDPRouteInput) GetValidProtocols() []gatewayv1.ProtocolType {
return []gatewayv1.ProtocolType{gatewayv1.UDPProtocolType}
}

func (u *UDPRouteInput) mergeStatusConditions(ref gatewayv1.ParentReference, updates []metav1.Condition) {
for idx, parent := range u.UDPRoute.Status.Parents {
if reflect.DeepEqual(parent.ParentRef, ref) {
for _, update := range updates {
u.UDPRoute.Status.Parents[idx].Conditions = helpers.MergeConditions(parent.Conditions, update)
}
return
}
}
parentStatus := gatewayv1.RouteParentStatus{
ParentRef:      ref,
ControllerName: gatewayv1.GatewayController(u.ControllerName),
}
for _, update := range updates {
parentStatus.Conditions = helpers.MergeConditions(parentStatus.Conditions, update)
}
u.UDPRoute.Status.Parents = append(u.UDPRoute.Status.Parents, parentStatus)
}
