# L4 foundation

Implement TCPRoute/UDPRoute foundation in `/testbed`: operator helpers, indexers, routechecks, and operator RBAC for `tcproutes`/`udproutes`.

Write:

- `/app/output/02-l4-route-foundation/foundation.json` — `rbac_scope` (string), `helper_packages` (array, ≥1), `indexer_coverage` (string), `routecheck_scope` (string)
- `/app/output/handoff.json` — updated for this stage

The protected tests are Go files placed inside your packages, so they compile against the exact identifiers listed in `/app/contracts/02-l4-route-foundation.md`. Match those names; everything else is your design choice.

The behaviour above decides this stage. The report and handoff are scored but never
decisive: a correct implementation is not failed for a documentation slip.
