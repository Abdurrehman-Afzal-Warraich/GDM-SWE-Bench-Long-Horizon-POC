# Config harden and closure

When `/testbed/install/kubernetes/cilium/templates/cilium-configmap.yaml` has `gatewayAPI.enabled`, force:

- `bpf-lb-algorithm-annotation: "true"`
- `bpf-lb-sock-hostns-only: "true"`

Update `/testbed/Documentation/network/servicemesh/gateway-api/` docs to mention TCPRoute and UDPRoute if not already present.

Write:

- `/app/output/04-config-harden/final_report.json` — `feature_summary` (string), `helm_config` (string), `verification_performed` (array, ≥1), `residual_risks` (array, ≥1), `packages_touched` (array, ≥1)
- `/app/output/04-config-harden/implementation_closure_proof.json` — `base_commit` = `04fd6832fd9015c072d9d1577939484ebd69302f`, `feature_complete` = `true`, `packages_touched` (array, ≥2), `verification_performed` (array, ≥1)
- `/app/output/handoff.json` — `merge_ready: true`, `next_steps` includes `"Task complete."`

The behaviour above decides this stage. The report and handoff are scored but never
decisive: a correct implementation is not failed for a documentation slip.
