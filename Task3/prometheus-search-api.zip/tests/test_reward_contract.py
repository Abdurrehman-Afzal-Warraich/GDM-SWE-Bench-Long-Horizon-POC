"""Discoverable contract tests for the staged Harbor + RewardKit package.

Run from the task root:  python3 -m pytest tests/test_reward_contract.py -q
These pin the package's structural + scoring invariants so a regression in the
verifier is caught before release. They do not require Go, Docker, or network.
"""

from __future__ import annotations

import hashlib
import json
import re
import subprocess
import sys
import tomllib
from pathlib import Path

import pytest

import stage_check
from merge_rewardkit_scores import merge_scores
from score_formula import calculate_training_score, deterministic_components
from stage_check import (
    CORE_WEIGHTS,
    CRITICAL_CHECKS,
    DIAGNOSE_WEIGHTS,
    HARDEN_WEIGHTS,
    REVIEW_WEIGHTS,
    command_integrity_violations,
    require_go_ran,
)


TESTS = Path(__file__).resolve().parent
TASK_ROOT = TESTS.parent

GOLDEN_INTERNAL_SYMBOLS = (
    "topKByScore",
    "reverseFilterEarlyExit",
    "linearResultCap",
    "memoizingFilter",
    "caseFoldingFilter",
    "orSearchesFilter",
    "JaroWinklerMatcher",
    "SubsequenceMatcher",
    "searchResultStreamer",
    "searchMetadataCache",
)

DECLARED_PUBLIC_API = (
    "MergeSearchResultSets",
    "NewSearchResultSetFromSliceAndError",
    "NewLazySearchResultSet",
    "NewSubstringFilter",
    "NewFuzzyFilter",
    "NewSubsequenceFilter",
    "NewChainFilter",
)


def _toml() -> dict:
    return tomllib.loads((TASK_ROOT / "task.toml").read_text(encoding="utf-8"))


def flat(path: Path) -> str:
    """File text with wrapped lines joined, so phrase checks survive rewrapping."""
    return " ".join(path.read_text(encoding="utf-8").split())


def test_task_declares_multistep_go_and_inline_anthropic_judges() -> None:
    config = _toml()
    metadata = config["metadata"]
    environment = config["environment"]
    steps = config["steps"]

    assert config["multi_step_reward_strategy"] == "final"
    assert metadata["language"] == "go"
    assert metadata["repository"] == "prometheus/prometheus"
    assert metadata["base_commit"] == "ee7fea7f144c9398891b083d0a3bf010074f1bb3"
    assert metadata["judge_dimensions"] == ["process", "validity", "merge-readiness"]
    assert metadata["judge_model"] == "anthropic/claude-sonnet-4-6"
    # Agent sandbox is fully offline; live-model judges are opt-in (off by default).
    assert environment["allow_internet"] is False
    assert environment["env"]["GOWORK"] == "off"
    assert environment["env"]["RUN_LLM_JUDGES"] == "0"
    assert config["verifier"]["env"] == {
        "ANTHROPIC_API_KEY": "${ANTHROPIC_API_KEY:-}",
        "GEMINI_API_KEY": "${GEMINI_API_KEY:-}",
        "NONDETERMINISTIC_LAMBDA": "${NONDETERMINISTIC_LAMBDA:-0.0}",
    }
    assert [s["name"] for s in steps] == ["01-diagnose", "02-core", "03-review", "04-harden"]
    # Stage 01 grades investigative evidence and nothing downstream depends on
    # it being perfect, so it must stay UNGATED: a first-hour reporting miss can
    # never end a multi-hour trial. Stages 02/03 are gated because stage 04
    # re-runs those behaviors, so a critical miss there is already fatal.
    assert "min_reward" not in steps[0]
    assert steps[1]["min_reward"] == pytest.approx(1.0)
    assert steps[2]["min_reward"] == pytest.approx(1.0)
    assert "min_reward" not in steps[3]
    assert not (TASK_ROOT / "tests/Dockerfile").exists()


def test_resources_fit_the_platform_sandbox_ceiling() -> None:
    """A request above the per-sandbox ceiling is rejected before the trial runs.

    The platform caps a single sandbox at 4 vCPU / 8 GiB / 10 GiB and fails
    sandbox creation (not a downscale) when asked for more, so these are hard
    upper bounds. The measured worst case - full build plus the cgo race detector -
    peaks near 6 GiB, so 8 GiB has real headroom; this test just stops the numbers
    from drifting back over the ceiling where the failure is invisible in-package.
    """
    env = _toml()["environment"]
    assert env["cpus"] <= 4, "per-sandbox vCPU ceiling"
    assert env["memory_mb"] <= 8192, "per-sandbox memory ceiling (8 GiB)"
    assert env["storage_mb"] <= 10240, "per-sandbox disk ceiling (10 GiB)"


def test_stage_weights_normalized_and_functional_evidence_dominates() -> None:
    for weights in (DIAGNOSE_WEIGHTS, CORE_WEIGHTS, REVIEW_WEIGHTS, HARDEN_WEIGHTS):
        assert sum(weights.values()) == pytest.approx(1.0)

    # Functional evidence dominates; typed-artifact checks are a minority.
    # Diagnose is led by executable runtime reproducers (route absent, flag
    # inert, storage API undefined), not the source scan.
    assert DIAGNOSE_WEIGHTS["base_behavior_reproduced"] >= DIAGNOSE_WEIGHTS["base_absence_observed"]
    # Executable runtime reproducers dominate diagnose: route absent, flag inert,
    # storage API undefined, top-K unbounded, and merge fail-fast — all observed
    # by running the real server/primitives, not by source scanning.
    executable_diagnose = (
        DIAGNOSE_WEIGHTS["base_behavior_reproduced"]
        + DIAGNOSE_WEIGHTS["base_feature_flag_inert"]
        + DIAGNOSE_WEIGHTS["base_storage_api_absent"]
        + DIAGNOSE_WEIGHTS["base_topk_inefficient"]
        + DIAGNOSE_WEIGHTS["base_merge_failfast"]
    )
    assert executable_diagnose >= 0.55
    # Stage-4 hardening is led by the perf guard + race check (functional), not docs.
    assert HARDEN_WEIGHTS["perf_topk_guard"] >= HARDEN_WEIGHTS["docs_updated"]
    assert "perf_topk_guard" in CRITICAL_CHECKS["harden"]
    assert "race_clean" in CRITICAL_CHECKS["harden"]
    core_artifacts = CORE_WEIGHTS["handoff_consumed"] + CORE_WEIGHTS["implementation_report"]
    assert core_artifacts <= 0.25
    assert REVIEW_WEIGHTS["review_response"] <= 0.10
    assert HARDEN_WEIGHTS["final_report"] <= 0.10
    # The enabled success path plus filter + DoS behavior dominate the review stage.
    assert (
        REVIEW_WEIGHTS["http_search_success"]
        + REVIEW_WEIGHTS["http_dos_validation"]
        + REVIEW_WEIGHTS["filter_substring_decay"]
        + REVIEW_WEIGHTS["filter_fuzzy_threshold"]
        + REVIEW_WEIGHTS["filter_subsequence_contract"]
        + REVIEW_WEIGHTS["filter_substring_unicode"]
    ) >= 0.6
    # The success path is promotion-critical in both HTTP stages.
    assert "http_search_success" in CRITICAL_CHECKS["review"]
    assert "http_search_success" in CRITICAL_CHECKS["harden"]
    # Independent (verifier-owned) coverage of requirements that would otherwise
    # rely on the agent's own omittable package tests.
    assert "filter_substring_unicode" in REVIEW_WEIGHTS
    assert "openapi_updated" in REVIEW_WEIGHTS
    assert "filter_substring_unicode" in CRITICAL_CHECKS["review"]
    assert "cap_disabled_edge" in HARDEN_WEIGHTS
    assert "cap_disabled_edge" in CRITICAL_CHECKS["harden"]

    # Stage 4 is terminal and ungated: every one of its checks is stated as a
    # requirement, so every one of them is critical. A stage that fails a stated
    # requirement must not be able to record binary_reward=1.0.
    assert set(CRITICAL_CHECKS["harden"]) == set(HARDEN_WEIGHTS)
    for stated in ("docs_updated", "patch_hygiene", "final_report"):
        assert stated in CRITICAL_CHECKS["harden"]

    # The self-declaration check is GONE, not demoted: grading
    # `decisions.merge_ready == true` rewarded an agent for asserting its own
    # success, which is a reward-hacking surface rather than a behavior.
    assert "merge_ready" not in HARDEN_WEIGHTS
    assert not hasattr(stage_check, "merge_ready_declared")

    # The earlier stages still carry genuinely optional checks - and each one is
    # described as optional in its own prompt (asserted below).
    assert "implementation_report" not in CRITICAL_CHECKS["core"]
    assert "handoff_consumed" not in CRITICAL_CHECKS["core"]
    assert "review_response" not in CRITICAL_CHECKS["review"]
    assert "openapi_updated" not in CRITICAL_CHECKS["review"]
    assert "decisions_handoff" not in CRITICAL_CHECKS["diagnose"]

    # The stage-1 `reproducer_present` check is gone: it passed on ANY non-empty
    # file under /app/output/01-diagnose, so it graded paperwork rather than an
    # outcome and could not be failed by an agent that did the work.
    assert "reproducer_present" not in DIAGNOSE_WEIGHTS

    # ... while every executable base observation IS critical in diagnose.
    for hard in (
        "base_behavior_reproduced",
        "base_feature_flag_inert",
        "base_storage_api_absent",
        "base_topk_inefficient",
        "base_merge_failfast",
        "base_absence_observed",
    ):
        assert hard in CRITICAL_CHECKS["diagnose"]
    # Every critical check must be a weighted check of that same stage.
    for stage, weights in (
        ("diagnose", DIAGNOSE_WEIGHTS),
        ("core", CORE_WEIGHTS),
        ("review", REVIEW_WEIGHTS),
        ("harden", HARDEN_WEIGHTS),
    ):
        assert set(CRITICAL_CHECKS[stage]) <= set(weights)


STAGE_DIRS = {
    "diagnose": "steps/01-diagnose",
    "core": "steps/02-core",
    "review": "steps/03-review",
    "harden": "steps/04-harden",
}

# Every check that is NOT critical, and the token its own instruction must use so
# an agent can tell it is optional. This is the machine-checkable half of the rule
# "a stated requirement is a gate; a non-gate is stated as optional".
NON_CRITICAL_DISCLOSURE = {
    "diagnose": ["decisions"],
    "core": ["implementation.json", "handoff.json"],
    "review": ["OpenAPI", "review_response.json"],
    "harden": [],
}

OPTIONAL_MARKER = "scored but never decisive"


def test_every_non_critical_check_is_disclosed_as_optional_in_its_prompt() -> None:
    """The reviewer's headline defect: Stage 4 stated documentation, hygiene and
    final_report.json as requirements but graded them non-critically, so an agent
    could fail stated requirements and still record binary_reward=1.0.

    The rule now is symmetric, and both halves are asserted here:
      1. a stage with non-critical checks must mark them optional in its prompt;
      2. a stage whose checks are ALL critical must say so.
    """
    for stage, weights in (
        ("diagnose", DIAGNOSE_WEIGHTS),
        ("core", CORE_WEIGHTS),
        ("review", REVIEW_WEIGHTS),
        ("harden", HARDEN_WEIGHTS),
    ):
        text = flat(TASK_ROOT / STAGE_DIRS[stage] / "instruction.md")
        lowered = text.lower()
        non_critical = set(weights) - set(CRITICAL_CHECKS[stage])

        if non_critical:
            assert OPTIONAL_MARKER in lowered, (
                f"stage {stage} has non-critical checks {sorted(non_critical)} but its "
                f"instruction never marks anything as optional"
            )
            for token in NON_CRITICAL_DISCLOSURE[stage]:
                assert token.lower() in lowered, (
                    f"stage {stage} instruction must name {token!r} among the "
                    f"optional deliverables"
                )
        else:
            assert "everything above is graded" in lowered, (
                f"stage {stage} gates on every check, so its instruction must say so"
            )
            assert OPTIONAL_MARKER not in lowered


def test_no_prompt_still_demands_the_deleted_merge_ready_declaration() -> None:
    """`merge_ready` was removed from grading; no prompt may keep asking for it,
    and the Oracle must not model it either."""
    for rel in STAGE_DIRS.values():
        text = flat(TASK_ROOT / rel / "instruction.md")
        assert "merge_ready" not in text
    oracle = flat(TASK_ROOT / "steps/04-harden/solution/solve.sh")
    assert "merge_ready" not in oracle


def test_stage_four_states_every_token_its_docs_gate_greps_for() -> None:
    """docs_updated is critical now, so every literal it looks for has to appear in
    the Stage-4 prompt - otherwise it would be grading an unstated rule. The gate
    also has to scan all of docs/ rather than a fixed file list, so a correct
    implementation cannot fail on file placement the prompt never required."""
    text = flat(TASK_ROOT / "steps/04-harden/instruction.md")
    for token in (
        "search-api",
        "web.search.max-limit",
        "x-ndjson",
        "newline-delimited",
        "batch",
        "trailer",
        "metric_names",
        "label_names",
        "label_values",
    ):
        assert token in text, f"stage-4 prompt must name the graded docs token {token!r}"
    assert "/search/" in text or "search/metric_names" in text

    grader = (TESTS / "stage_check.py").read_text(encoding="utf-8")
    assert 'docs_root = TESTBED / "docs"' in grader
    assert "rglob" in grader, "docs gate must scan the whole docs/ tree, not a fixed list"

    # Hygiene gates only on what the prompt states (build artifacts / stray files).
    # `git diff --check` whitespace noise is reported but must not decide the stage.
    assert "whitespace_report_not_gated" in grader


def test_instructions_use_absolute_testbed_paths() -> None:
    """QC instruction_concision flagged relative paths against a /testbed root."""
    pattern = re.compile(r"(?<![\w/`.])(?:web/api/v1|storage|cmd/prometheus|docs)/")
    for stage, rel in STAGE_DIRS.items():
        path = TASK_ROOT / rel / "instruction.md"
        for line in path.read_text(encoding="utf-8").splitlines():
            # Query params, JSON bodies and endpoint paths are not filesystem paths.
            if line.lstrip().startswith(("//", "{", "GET", "POST", "|")):
                continue
            for hit in pattern.finditer(line):
                context = line[max(0, hit.start() - 10) : hit.start()]
                assert "/testbed" in context or "api/v1/search" in line, (
                    f"{stage}: repository path in {line.strip()!r} should be absolute "
                    f"under /testbed"
                )


def test_instruction_word_budgets_hold() -> None:
    """QC flagged the prompts as exceptionally long. Budgets are enforced so the
    next edit cannot quietly reinflate them."""
    budgets = {"diagnose": 305, "core": 270, "review": 545, "harden": 280}
    total = 0
    for stage, rel in STAGE_DIRS.items():
        words = len((TASK_ROOT / rel / "instruction.md").read_text(encoding="utf-8").split())
        total += words
        assert words <= budgets[stage], f"{stage}: {words} words exceeds {budgets[stage]}"
    # The honest tension, recorded so it cannot drift: the previous revision was 1289 words and QC
    # still called the prompts too long. this revision removes the process prescription and
    # the relative-path violation QC named, but ADDS the explicit graded /
    # "Scored but never decisive" split that the alignment finding requires. That
    # split is what stops a stated requirement from being ungraded, so it is worth
    # its ~75 words - but the total is capped here so it cannot creep further.
    assert total <= 1400, f"instructions total {total} words"


def test_the_binary_outcome_is_decided_by_critical_checks_only() -> None:
    """A low-weight non-critical miss must not zero a stage (review row 47)."""
    source = (TASK_ROOT / "tests/stage_check.py").read_text(encoding="utf-8")
    assert (
        "required_checks_pass = all(bool(checks.get(name, {}).get(\"passed\")) "
        "for name in critical_checks)" in source
    ), "binary_reward must be gated on critical_checks, not on every weighted check"
    # The distinction has to be visible to a reviewer reading reward-details.
    for field in ("non_critical_checks", "every_weighted_check_passed", "outcome_rule"):
        assert field in source


def test_every_stage_has_instruction_solution_and_test_entrypoint() -> None:
    for step in _toml()["steps"]:
        root = TASK_ROOT / "steps" / step["name"]
        assert (root / "instruction.md").is_file()
        assert (root / "solution/solve.sh").is_file()
        assert (root / "tests/test.sh").is_file()
        assert (root / "tests/test.sh").read_text(encoding="utf-8").strip().endswith(
            f"stage_test.sh {step['name'].split('-', 1)[1]}"
        )


def test_hidden_tests_key_on_public_contract_not_golden_internals() -> None:
    hidden = list((TESTS / "hidden").glob("*_test.go"))
    assert {p.name for p in hidden} == {
        "stage01_base_gaps_hidden_test.go",
        "stage02_storage_hidden_test.go",
        "stage03_filters_hidden_test.go",
        "stage04_perf_hidden_test.go",
    }
    blob = "\n".join(p.read_text(encoding="utf-8") for p in hidden)
    for symbol in GOLDEN_INTERNAL_SYMBOLS:
        assert symbol not in blob, f"hidden test leaks golden-internal symbol {symbol}"
    # They must exercise the DECLARED public surface.
    for symbol in DECLARED_PUBLIC_API:
        assert symbol in blob


def test_stage_check_keys_on_behavior_not_golden_internals() -> None:
    scorer = (TESTS / "stage_check.py").read_text(encoding="utf-8")
    for symbol in GOLDEN_INTERNAL_SYMBOLS:
        assert symbol not in scorer
    # It grades via public URL paths + flags + declared behavior.
    assert "/api/v1/search" in scorer
    assert "search-api" in scorer
    assert "web.search.max-limit" in scorer


def test_zero_discovered_go_tests_is_a_deterministic_failure() -> None:
    for message in ("no test files", "testing: warning: no tests to run"):
        guarded = require_go_ran(
            subprocess.CompletedProcess(args=["go", "test"], returncode=0, stdout=message, stderr="")
        )
        assert guarded.returncode != 0
        assert "did not run" in guarded.stderr


def test_integrity_allows_local_work_but_blocks_leakage_and_network() -> None:
    # Outcome-based: local server testing (curl/urllib/sockets against loopback)
    # and local tool installs are NOT integrity violations.
    assert command_integrity_violations(
        [
            "go build ./storage/...",
            "go test ./web/api/v1/ -run TestSearch",
            "git log --oneline -n 5",
            "git show --stat HEAD",
            "rg -n 'search-api' cmd/prometheus/main.go",
            "curl -s http://127.0.0.1:9090/api/v1/search/metric_names?limit=5",
            "curl -s -o /dev/null -w '%{http_code}' http://localhost:19099/-/ready",
            "python3 -c \"import urllib.request; urllib.request.urlopen('http://127.0.0.1:9090/-/ready')\"",
            "pip install pytest",
            "apt-get install -y curl",
            "go install example.com/x@latest",
        ]
    ) == []
    for command in (
        "cat /tests/stage_check.py",
        "cp /solution/golden.patch /tmp/fix",
        "git remote -v",
        "git fetch origin",
        "curl https://github.com/prometheus/prometheus/pull/18573.patch",
        "gh pr view 18573",
        "git ls-remote https://example.invalid/repo.git",
        "wget https://example.invalid/leak.tar.gz",
    ):
        assert command_integrity_violations([command]), command


def test_json_contract_requires_declared_keys_but_allows_extra_ones(tmp_path: Path) -> None:
    """The disclosed schema is a floor, not a ceiling.

    Rejecting an extra, helpful key would punish an agent for volunteering
    context, so extra keys are reported for reviewer visibility and never fail
    the check. Missing keys and wrong types still fail.
    """
    from stage_check import json_contract

    required = ("summary", "public_api", "tests_run")
    good = tmp_path / "good.json"
    good.write_text(
        json.dumps({"summary": "s", "public_api": ["A"], "tests_run": ["go test"]}),
        encoding="utf-8",
    )
    assert json_contract(good, required, exact=True)[0]

    extra = tmp_path / "extra.json"
    extra.write_text(
        json.dumps(
            {
                "summary": "s",
                "public_api": ["A"],
                "tests_run": ["go test"],
                "deferred_review_work": ["x"],
            }
        ),
        encoding="utf-8",
    )
    ok, detail = json_contract(extra, required, exact=True)
    assert ok, "an extra key must not fail a declared-schema check"
    assert detail["extra_keys_allowed"] == ["deferred_review_work"]

    missing = tmp_path / "missing.json"
    missing.write_text(json.dumps({"summary": "s", "public_api": ["A"]}), encoding="utf-8")
    ok, detail = json_contract(missing, required, exact=True)
    assert not ok and detail["missing"] == ["tests_run"]

    wrong = tmp_path / "wrong.json"
    wrong.write_text(
        json.dumps({"summary": "s", "public_api": "A", "tests_run": ["go test"]}),
        encoding="utf-8",
    )
    ok, detail = json_contract(wrong, required, types={"public_api": list}, exact=True)
    assert not ok and detail["type_mismatch"]


def test_instructions_describe_the_schemas_as_a_floor_not_a_ceiling() -> None:
    for rel in ("steps/02-core", "steps/03-review", "steps/04-harden"):
        text = flat(TASK_ROOT / rel / "instruction.md")
        assert "at least these keys" in text, rel
        assert "exactly these keys" not in text, rel


def test_golden_patch_provenance_and_disjoint_stage_boundaries() -> None:
    seen: set[str] = set()
    total = 0
    for patch in sorted(TASK_ROOT.glob("steps/*/solution/golden.patch")):
        provenance = json.loads(patch.with_name("provenance.json").read_text(encoding="utf-8"))
        assert provenance["golden_patch_sha256"] == hashlib.sha256(patch.read_bytes()).hexdigest()
        touched = {
            line.split()[2][2:]
            for line in patch.read_text(encoding="utf-8").splitlines()
            if line.startswith("diff --git a/")
        }
        assert touched
        # provenance.files must match exactly what the patch touches.
        assert set(provenance["files"]) == touched
        assert provenance["file_count"] == len(touched)
        assert not (seen & touched), f"stage file overlap: {seen & touched}"
        seen |= touched
        total += len(touched)
    # The three stage patches are file-disjoint: 24 files from PR #18573 plus one
    # author-added Stage-4 test (storage/search_perf_test.go) demonstrating the
    # required top-K performance guard + edge regressions.
    assert total == 25
    assert len(seen) == 25
    assert "storage/search_perf_test.go" in seen


def test_stage_one_never_penalises_a_reproducer_test_file() -> None:
    """Row 13: the decisive fairness bug that sank the previous submission.

    Stage 1 invites an executable reproducer, and in Go the natural place for one
    is a `*_test.go` inside the package being probed. A leftover reproducer test
    ships nothing, so it must not count as a production change - and the
    instruction has to say so out loud.
    """
    source = (TESTS / "stage_check.py").read_text(encoding="utf-8")
    marker = source.index("production_changes = [")
    window = source[marker : marker + 400]
    assert 'not item.endswith("_test.go")' in window

    text = flat(TASK_ROOT / "steps/01-diagnose/instruction.md")
    assert "*_test.go" in text
    assert "placing it in the relevant package is fine" in text
    assert "do **not** change production (non-test) code" in text


def test_every_graded_http_rule_is_disclosed_in_the_instruction() -> None:
    """Rows 9/10/58: nothing may be graded that the prompt did not state."""
    review = flat(TASK_ROOT / "steps/03-review/instruction.md")
    grader = (TESTS / "stage_check.py").read_text(encoding="utf-8")

    # The two rules the reviewer caught as graded-but-unstated.
    assert "sort_by_score_no_search_400" in grader
    assert "`sort_by=score` with no `search[]` term" in review
    assert "over_term_cap_400" in grader
    assert "more than 32 `search[]` terms" in review
    # ... and the rest of the 400 contract the grader actually probes.
    for phrase in (
        "not a valid number",
        "without the `label` parameter",
        "an unknown `fuzz_alg`",
    ):
        assert phrase in review, phrase
    assert "`0` disables the cap entirely" in review

    harden = flat(TASK_ROOT / "steps/04-harden/instruction.md")
    # docs_updated looks for these exact signals, so the prompt names them all.
    for token in (
        "search-api",
        "--web.search.max-limit",
        "/api/v1/search/",
        "metric_names",
        "label_names",
        "label_values",
        "application/x-ndjson",
        "trailer line",
    ):
        assert token in harden, token
    # The perf guard's threshold and warmup are documented rather than implied.
    assert "no more than half" in harden
    assert "warmup" in harden
    perf = (TESTS / "hidden/stage04_perf_hidden_test.go").read_text(encoding="utf-8")
    assert "topK*2 >= full" in perf, "perf guard must match the documented half-allocation rule"


def test_every_stated_stage_three_rule_has_a_verifier_owned_check() -> None:
    """The other direction of disclosure: stated, therefore graded.

    The reviewer's finding was that stage 3 spells out rules the grader never probed -
    `sort_dir` with `sort_by=score`, and the accepted side of the 32-term cap - so the
    instruction promised something the reward did not measure. Each rule the prompt
    states now maps to a black-box probe the verifier runs itself, listed here by the
    probe name that appears in the reward detail.
    """
    grader = (TESTS / "stage_check.py").read_text(encoding="utf-8")
    review = flat(TASK_ROOT / "steps/03-review/instruction.md")
    for probe, stated in {
        "sort_dir_with_score_400": "`sort_dir` combined with `sort_by=score`",
        "at_term_cap_served": "32 or fewer\nmust be accepted",
        "alpha_sort_directions": "`sort_dir` (asc|dsc",
        "score_absent_by_default": '"score" is present only when include_score=true',
        "default_limit_is_100": "`limit` (default 100)",
        "fuzz_threshold_applied": "with a caller threshold",
        # NDJSON first-batch-always-emitted framing edge (Task Review row 38).
        "empty_result_first_batch_emitted": "the first always emitted",
    }.items():
        assert probe in grader, f"{probe} is stated in the instruction but never probed"
        assert " ".join(stated.split()) in review, (
            f"{probe} probes something the prompt does not state"
        )


def test_stage_one_decision_fields_are_graded_by_name_and_the_oracle_emits_them() -> None:
    """The handoff contract has to bind the fields the stage actually names.

    "decisions is a non-empty object" let a correct-looking run through while the
    reference solution emitted entirely different key names - the instruction, the
    grader and the Oracle disagreed with each other. All three now agree.
    """
    grader = (TESTS / "stage_check.py").read_text(encoding="utf-8")
    assert "def decisions_contract(" in grader
    instruction = flat(TASK_ROOT / "steps/01-diagnose/instruction.md")
    oracle = json.loads(
        re.search(
            r"cat > \"\$OUT/handoff\.json\" <<'JSON'\n(.*?)\nJSON",
            (TASK_ROOT / "steps/01-diagnose/solution/solve.sh").read_text(encoding="utf-8"),
            re.S,
        ).group(1)
    )
    for field in ("endpoint_set", "response_framing", "default_limits"):
        assert field in grader, field
        assert field in instruction, f"{field} is graded but not disclosed"
        assert field in oracle["decisions"], f"the Oracle does not emit decisions.{field}"
    assert isinstance(oracle["decisions"]["endpoint_set"], list)
    assert isinstance(oracle["decisions"]["response_framing"], str)
    assert any(
        isinstance(v, (int, float)) for v in oracle["decisions"]["default_limits"].values()
    )


def test_the_toolchain_is_trusted_behaviourally_not_by_a_file_in_the_image() -> None:
    """Row 27: an agent with root can rewrite anything the image ships.

    So nothing in the image is treated as a trust root any more. The checksum
    manifest is gone, and in its place the verifier makes the toolchain prove it
    reports real outcomes: a test the verifier just wrote must be reported as
    failing. A `go` that fabricates success cannot satisfy that, whatever its
    digest or file mode says.
    """
    dockerfile = (TASK_ROOT / "environment/Dockerfile").read_text(encoding="utf-8")
    assert "verifier-binary-checksums" not in dockerfile
    assert "chattr" not in dockerfile, "an ignored chattr reads as a defense that is not one"
    grader = (TESTS / "stage_check.py").read_text(encoding="utf-8")
    assert "verifier-binary-checksums" not in grader
    assert "def toolchain_reports_truthfully(" in grader
    assert "def toolchain_trustworthy(" in grader
    assert "TestVerifierCanaryMustFail" in grader
    # The canary must be scoped to a throwaway package and cleaned up, so it can
    # never leave a failing test behind in the graded tree.
    canary = grader[grader.index("def toolchain_reports_truthfully(") :]
    canary = canary[: canary.index("def toolchain_trustworthy(")]
    assert "shutil.rmtree(root, ignore_errors=True)" in canary
    assert "finally:" in canary
    # Identity is still reported, just not believed on its own.
    assert '"sha256": hashlib.sha256' in grader
    assert "not root-owned" in grader and "not an ELF executable image" in grader


def test_kernel_ctime_anchor_is_enforced_and_fails_closed() -> None:
    """Row 27's residual: the structural checks and the behavioural canary can all
    be satisfied by a ROOT agent that writes its own root-owned ELF wrapper over
    `go`. The kernel ctime anchor is the control that survives that, because
    `st_ctime` cannot be backdated from userspace.

    The failure mode to avoid is the one a reviewer found in a sibling package:
    the anchor shipped but skipped itself in every real run. Inside the container
    it must FAIL rather than skip when it cannot compute the reference point.
    """
    anchor = stage_check.toolchain_ctime_anchor

    # Outside a container the anchor abstains rather than producing a false alarm.
    if not stage_check._IN_CONTAINER:
        ok, detail = anchor({"go": {"path": sys.executable}})
        assert ok is True and detail["enforced"] is False

    started = 1_000_000.0
    tools = {"go": {"path": sys.executable}}

    # In-container with no derivable start time => fail closed, and say so.
    with pytest.MonkeyPatch.context() as patch:
        patch.setattr(stage_check, "_IN_CONTAINER", True)
        patch.setattr(stage_check, "container_start_epoch", lambda: (None, {"error": "unavailable"}))
        ok, detail = anchor(tools)
        assert ok is False, "a missing anchor must fail, never skip, inside the container"
        assert detail["failed_closed"] is True
        assert detail["enforced"] is False

    # A binary whose inode changed AFTER the container started is a substitution.
    with pytest.MonkeyPatch.context() as patch:
        patch.setattr(stage_check, "_IN_CONTAINER", True)
        patch.setattr(stage_check, "container_start_epoch", lambda: (started, {}))
        patch.setattr(
            stage_check.os, "stat", lambda _p: type("S", (), {"st_ctime": started + 600})()
        )
        ok, detail = anchor(tools)
        assert ok is False
        assert detail["enforced"] is True
        assert detail["violations"] and "replaced or modified" in detail["violations"][0]["reason"]

    # An image-provided binary predates container start and passes.
    with pytest.MonkeyPatch.context() as patch:
        patch.setattr(stage_check, "_IN_CONTAINER", True)
        patch.setattr(stage_check, "container_start_epoch", lambda: (started, {}))
        patch.setattr(
            stage_check.os, "stat", lambda _p: type("S", (), {"st_ctime": started - 3600})()
        )
        ok, detail = anchor(tools)
        assert ok is True and detail["enforced"] is True and not detail["violations"]

    # The anchor votes in toolchain_trustworthy and publishes whether it ran.
    grader = (TESTS / "stage_check.py").read_text(encoding="utf-8")
    assert "ctime_anchor_enforced" in grader
    assert "anchored, anchor_detail = toolchain_ctime_anchor(digests)" in grader
    assert "and anchored" in grader


def test_container_start_epoch_parses_a_pid1_comm_containing_spaces() -> None:
    """/proc/1/stat field 2 is the executable name in parentheses and may itself
    contain spaces or a ')'. Splitting the line naively shifts every later field
    and silently yields the wrong start time, so the parser anchors on the LAST
    ')' - this pins that behaviour."""
    grader = (TESTS / "stage_check.py").read_text(encoding="utf-8")
    assert 'raw.rindex(")")' in grader, "must anchor on the last ')' in /proc/1/stat"

    fields = ["1", "(my proc)", "S"] + [str(i) for i in range(4, 53)]
    raw = " ".join(fields)
    after_comm = raw[raw.rindex(")") + 1 :].split()
    # Field 22 (starttime) is index 19 after comm; with this synthetic line the
    # value equals the field number, so a shift would show up immediately.
    assert after_comm[19] == "22"


def test_readme_rubric_tables_match_the_grader() -> None:
    """Row 29: the published rubric must be generated from the weights."""
    readme = (TASK_ROOT / "README.md").read_text(encoding="utf-8")
    stages = {
        "diagnose": (DIAGNOSE_WEIGHTS, CRITICAL_CHECKS["diagnose"]),
        "core": (CORE_WEIGHTS, CRITICAL_CHECKS["core"]),
        "review": (REVIEW_WEIGHTS, CRITICAL_CHECKS["review"]),
        "harden": (HARDEN_WEIGHTS, CRITICAL_CHECKS["harden"]),
    }
    for stage, (weights, critical) in stages.items():
        start = readme.index(f"<!-- rubric:{stage}:start")
        end = readme.index(f"<!-- rubric:{stage}:end -->")
        block = readme[start:end]
        rows = {}
        for line in block.splitlines():
            if not line.startswith("| `"):
                continue
            cells = [c.strip() for c in line.strip("|").split("|")]
            rows[cells[0].strip("`")] = (float(cells[1]), cells[2] == "yes")
        assert set(rows) == set(weights), f"{stage} rubric lists {set(rows) ^ set(weights)}"
        for name, (weight, is_critical) in rows.items():
            assert weight == pytest.approx(weights[name], abs=5e-3), f"{stage}.{name} weight"
            assert is_critical == (name in critical), f"{stage}.{name} criticality"
        assert f"| **total** | **{sum(weights.values()):.2f}** |" in block


def test_golden_slices_are_proven_against_the_upstream_merge_head() -> None:
    """Rows 33/59: completeness proven by diff, not asserted by file count.

    The equivalence run itself is author-side (it needs the upstream remote, which the
    image deliberately cannot reach). What ships is checkable without it: the union of
    the stage slices is exactly the 17 production files the claim names, no withheld
    test rides along, and the image pins the same commit *and* tree the claim was taken
    against, so a rewritten upstream ref fails the build instead of quietly changing
    the task.
    """
    config = _toml()["metadata"]
    union: set[str] = set()
    for patch in sorted(TASK_ROOT.glob("steps/*/solution/golden.patch")):
        union |= {
            line.split()[2][2:]
            for line in patch.read_text(encoding="utf-8").splitlines()
            if line.startswith("diff --git a/")
        }
    production = [p for p in sorted(union) if not p.endswith("_test.go")]
    assert len(production) == 17, f"the slices cover {len(production)} production files, the claim says 17"
    # The slices also carry the source change's own 7 test files plus one author-written
    # perf fixture. Those only ever exist in a trusted Oracle run: the agent never sees
    # them, and none of them is what grades a stage - the reward comes from the hidden
    # corpus the verifier injects and removes again.
    tests_in_slices = [p for p in sorted(union) if p.endswith("_test.go")]
    assert len(tests_in_slices) == 8, tests_in_slices
    assert "storage/search_perf_test.go" in tests_in_slices
    hidden = {p.name for p in (TESTS / "hidden").glob("*_test.go")}
    assert hidden and not ({Path(p).name for p in tests_in_slices} & hidden), (
        "a golden slice must not ship a file that is also part of the graded corpus"
    )
    dockerfile = (TASK_ROOT / "environment/Dockerfile").read_text(encoding="utf-8")
    assert f"ARG BASE_COMMIT={config['base_commit']}" in dockerfile
    assert re.search(r"^ARG BASE_TREE=[0-9a-f]{40}$", dockerfile, re.M)
    assert "git rev-parse 'HEAD^{tree}'" in dockerfile
    assert config["merge_commit"][:8] in config["solution_provenance"]


def test_the_package_install_layer_survives_a_flaky_debian_index() -> None:
    """A build must not die because a mirror blipped.

    The platform build failed once on `apt-get` exit 100 in a layer that had not
    changed, which is what a rotated InRelease, a clock-skewed builder, a hash-sum
    mismatch or a v6-only route all look like. The layer therefore retries, ignores
    the validity window, forces IPv4, and re-fetches missing archives; and only
    python3 is treated as required, because nothing in the task or the verifier
    calls jq or ripgrep.
    """
    body = (TASK_ROOT / "environment/Dockerfile").read_text(encoding="utf-8")
    layer = re.search(r"^RUN set -eux; \\\n(?:.*\\\n)*?.*python3 -c .*$", body, re.MULTILINE)
    assert layer, "the resilient apt layer is missing"
    text = layer.group(0)
    for setting in (
        'Acquire::Retries "5"',
        'Acquire::Check-Valid-Until "false"',
        'Acquire::ForceIPv4 "true"',
    ):
        assert setting in text, f"apt config must set {setting}"
    assert "for attempt in 1 2 3" in text, "apt-get update must be retried"
    assert "--fix-missing" in text, "a failed required install must be re-attempted"
    assert "FATAL: apt-get update failed three times" in text, (
        "total failure must explain itself instead of dying on exit 100"
    )
    # jq/ripgrep are conveniences: their install must be a tolerated failure, and
    # they must not appear in the required install line.
    lines = text.splitlines()
    required = [l for l in lines if "python3-venv" in l and "install" in l]
    assert required and all("jq" not in l and "ripgrep" not in l for l in required)
    optional_at = next(i for i, l in enumerate(lines) if "ripgrep" in l)
    tolerated = "||" in " ".join(lines[optional_at:optional_at + 2])
    assert tolerated, "the optional install must not be able to fail the build"
    # A '#' anywhere inside a joined RUN silently comments out the rest of it.
    assert not re.search(r"^\s*#", text, re.MULTILINE), (
        "a comment inside a line-continued RUN would swallow the remaining commands"
    )
    # The layer must prove the interpreter it installed actually works.
    assert "import sys, venv, ensurepip" in text

    # Same treatment for the other two network-dependent layers: the source fetch
    # is retried, and pip is given retries/timeouts. What must NOT be retried or
    # softened is identity - a fetch that succeeds with different content still
    # fails the build on the spot.
    fetch = re.search(r"^RUN set -eux; \\\n(?:.*\\\n)*?.*rm -rf /src$", body, re.MULTILINE)
    assert fetch, "the source-fetch layer is missing"
    fetch_text = fetch.group(0)
    assert "for attempt in 1 2 3" in fetch_text, "the source fetch must be retried"
    assert 'test "$(git rev-parse HEAD)" = "${BASE_COMMIT}"' in fetch_text
    assert "git rev-parse 'HEAD^{tree}'" in fetch_text
    assert "PIP_RETRIES" in body and "PIP_TIMEOUT" in body

    # A reviewer's deduction: the build depended on ONE transport staying
    # reachable. A second transport for the SAME commit now backs it up, and the
    # content assertion is duplicated onto that path rather than relaxed for it -
    # an archive whose tree differs from the pin still fails the build.
    assert "SOURCE_TARBALL_URL" in body, "a fallback transport for the pinned source must exist"
    assert "falling back to the pinned source archive" in fetch_text
    assert 'test "${actual_tree}" = "${BASE_TREE}"' in fetch_text, (
        "the fallback transport must assert the pinned tree, not trust the download"
    )
    assert "FATAL: archive tree" in fetch_text
    assert "the builder has no route to the source" in fetch_text, (
        "total failure must name the cause instead of dying on a bare non-zero exit"
    )


def test_merge_head_equivalence_proof_is_shipped_and_consistent() -> None:
    """Rows 35/62: the byte-for-byte proof ships as a checkable artifact AND as a
    re-runnable derivation.

    The reviewer's deduction on the previous revision was that equivalence was
    claimed in prose with nothing shipped that could re-execute it. Now
    `tools/verify_merge_head_equivalence.py` performs the whole derivation against
    the upstream repository - clone, checkout base, apply the three shipped slices,
    compare `git hash-object` per file against `git rev-parse <merge>:<path>` - and
    writes its result here. It needs network and git, which the task image
    deliberately lacks, so it is a release control rather than a graded check.

    This test is the offline half: it re-derives the production file set from the
    shipped patches and checks the recorded proof agrees with it and with
    task.toml, so a stale or hand-edited proof is caught without the network.
    """
    proof_path = TASK_ROOT / "steps/04-harden/solution/merge_head_equivalence_proof.json"
    assert proof_path.is_file(), "the merge-head equivalence proof must ship"
    proof = json.loads(proof_path.read_text(encoding="utf-8"))
    config = _toml()["metadata"]

    assert proof["byte_identical"] is True and not proof["mismatches"]
    assert proof["base_commit"] == config["base_commit"]
    assert proof["merge_commit"] == config["merge_commit"]

    union: set[str] = set()
    for patch in sorted(TASK_ROOT.glob("steps/*/solution/golden.patch")):
        union |= {
            line.split()[2][2:]
            for line in patch.read_text(encoding="utf-8").splitlines()
            if line.startswith("diff --git a/")
        }
    production = sorted(p for p in union if not p.endswith("_test.go"))
    assert proof["production_file_count"] == len(production) == 17
    assert sorted(r["file"] for r in proof["files"]) == production
    # Every recorded row must be a byte-identity match with a real blob id.
    for row in proof["files"]:
        assert row["identical"] is True, row["file"]
        assert row["applied_blob"] == row["merge_blob"]
        assert re.fullmatch(r"[0-9a-f]{40}", row["applied_blob"]), row

    # The proof must record HOW it was derived, and the derivation must be the
    # shipped tool rather than an author's note.
    tool = TASK_ROOT / "tools/verify_merge_head_equivalence.py"
    assert tool.is_file(), "the merge-head derivation tool must ship"
    assert proof.get("verified_by") == "tools/verify_merge_head_equivalence.py"
    assert "git hash-object" in proof.get("verification_method", "")

    # Completeness in the other direction: no production file touched by the merge
    # commit may be left uncovered by the stage slices.
    assert proof.get("uncovered_production_files_at_merge") == []

    # The recorded per-stage sha256 must match the patch bytes actually shipped,
    # so the proof cannot survive a patch being edited underneath it.
    for entry in proof["stage_patches"]:
        patch = TASK_ROOT / "steps" / entry["stage"] / "solution/golden.patch"
        assert hashlib.sha256(patch.read_bytes()).hexdigest() == entry["sha256"], entry["stage"]


def test_shipped_calibration_record_is_present_and_internally_consistent() -> None:
    """Rows 34/36: the local calibration record ships as a checkable artifact.

    The per-run logs and mutation patches are author-side (they name the source
    PR), so what travels with the package is this digest, referenced by README.md.
    This test re-checks it offline for the invariants the release gate depends on:
    Oracle passes every stage and repeats, the untouched base fails at functional
    gates (not infrastructure), an incomplete near-miss fails a later stage, and
    deleting the agent-visible tests still scores 1.0. It cannot be hand-loosened
    to record a passing no-op or a failing tamper without this test catching it.
    """
    path = TASK_ROOT / "steps/04-harden/solution/calibration_summary.json"
    assert path.is_file(), "the calibration record must ship"
    record = json.loads(path.read_text(encoding="utf-8"))
    controls = {c["scenario"]: c for c in record["controls"]}
    assert {"oracle", "oracle-repeat", "nop", "near-miss", "tamper"} <= set(controls)

    for name in ("oracle", "oracle-repeat", "tamper"):
        for stage in controls[name]["stages"]:
            assert stage["binary_reward"] == 1.0, (name, stage)
            assert stage["failed_critical"] == [], (name, stage)

    for name in ("nop", "near-miss"):
        stages = controls[name]["stages"]
        assert stages, name
        for stage in stages:
            assert stage["binary_reward"] == 0.0, (name, stage)
            # A functional gate, not an infrastructure/setup failure, must be named.
            assert stage["failed_critical"], (name, stage)

    # The tamper control must have actually removed the agent-visible tests.
    assert controls["tamper"]["deleted_visible_tests"] >= 1

    # --- staleness contract -------------------------------------------------
    # A calibration record describes runs of a SPECIFIC grader. this revision changed which
    # checks decide a stage, so the previous observations no longer describe what this
    # grader would record. The record may therefore be either current or openly
    # superseded, but it may never be quietly wrong - and it must always name the
    # command that regenerates it.
    assert record["status"] in {"current", "SUPERSEDED - regenerate before calling this package calibrated"}
    assert "run_calibration.sh" in record["regenerate_with"]
    assert (TASK_ROOT / "tools/run_calibration.sh").is_file(), (
        "rows 34/36 need a runner a reviewer can re-execute, not just a summary"
    )

    named = {
        check
        for control in record["controls"]
        for stage in control["stages"]
        for check in stage["failed_critical"]
    }
    known = set().union(*CRITICAL_CHECKS.values())
    if record["status"] == "current":
        assert record["applies_to_grader_revision"] == "current"
        unknown = sorted(named - known)
        assert not unknown, (
            f"record claims to be current but names checks this grader does not have: {unknown}"
        )
    else:
        # Superseded: it must say why, and the drift must be declared rather than
        # discovered. Editing the observations to fit the new grader would be
        # fabrication, so they are kept verbatim and labelled instead.
        assert record["why_superseded"]
        assert record["known_stale_fields"]
        assert sorted(named - known), (
            "record is marked superseded but nothing is actually stale - mark it current"
        )


def test_stage_dependency_contract_is_generated_and_honest() -> None:
    """Row 9: the dependency map must be generated from the grader, must not claim
    a dependency the grading does not create, and must not dress up a within-stage
    discriminator as horizon evidence."""
    contract = TASK_ROOT / "tests/contracts/stage_dependencies.json"
    assert contract.is_file(), "the stage dependency map must ship"
    data = json.loads(contract.read_text(encoding="utf-8"))

    # Generated, not hand-written: regenerating must be a no-op.
    proc = subprocess.run(
        [sys.executable, str(TASK_ROOT / "tools/render_stage_dependencies.py"), "--check"],
        capture_output=True, text=True,
    )
    assert proc.returncode == 0, f"stage_dependencies.json is stale:\n{proc.stdout}{proc.stderr}"

    # Every check named by the map must exist in the grader with the same criticality.
    weights = {
        "diagnose": DIAGNOSE_WEIGHTS, "core": CORE_WEIGHTS,
        "review": REVIEW_WEIGHTS, "harden": HARDEN_WEIGHTS,
    }
    for stage in data["stages"]:
        key = stage["stage"]
        assert sorted(stage["critical_checks"]) == sorted(CRITICAL_CHECKS[key])
        assert set(stage["critical_checks"]) | set(stage["non_critical_checks"]) == set(weights[key])

    # Cumulative closure: the terminal stage must re-verify both earlier implementation stages.
    terminal = next(s for s in data["stages"] if s["step"] == "04-harden")
    assert set(terminal["re_verifies_earlier_stages"]) >= {"02-core", "03-review"}

    # Horizon evidence: at least two shortcuts must survive one stage and die in a
    # strictly later one. Shortcuts caught inside their own stage are listed but
    # explicitly not counted.
    crossing = [s for s in data["shortcuts_rejected_later"] if s["crosses_stage_boundary"]]
    assert len(crossing) >= 2, "row 9 needs shortcuts that a LATER stage rejects"
    assert data["shortcuts_crossing_a_stage_boundary"] == len(crossing)

    # The ablation is a run, so it must be declared missing rather than described.
    ablation = data["horizon_ablation"]
    assert ablation["status"].startswith("NOT RUN"), (
        "if the ablation has been run, replace the status with its results"
    )
    assert (TASK_ROOT / ablation["runner"]).is_file()


def test_the_readme_reports_every_calibration_control() -> None:
    """Rows 32/34/55: the package must SHOW repeatability and anti-shortcut strength.

    The per-run JSON, patches and logs are author-side (they name the source PR), so
    what ships is the operator-facing summary in README.md. Every control the release
    gate requires has to appear there with its outcome, so a reviewer can see what was
    run without taking the author's word for the shape of it.
    """
    text = (TASK_ROOT / "README.md").read_text(encoding="utf-8")
    for claim in (
        "Oracle",
        "do-nothing",
        "mut-merge",
        "mut-cap",
        "mut-always400",
        "tamper",
        "merge head",
        "judge",
    ):
        assert claim.lower() in text.lower(), claim


def test_http_readiness_is_retried_rather_than_failing_the_agent() -> None:
    """Row 45: a slow self-scrape on a loaded host is infrastructure, not a miss."""
    source = (TESTS / "stage_check.py").read_text(encoding="utf-8")
    assert "def boot_scraped_prometheus(" in source
    assert "attempts: int = 3" in source
    assert "series_timeout: float = 150.0" in source
    assert "scrape_interval: 1s" in source
    # No success-path check may still use a bare single-shot boot+wait.
    assert "wait_for_head_series(port, timeout=45.0)" not in source


def test_no_graded_check_runs_the_wall_clock_flaky_upstream_suite() -> None:
    """Row 45 again: `go test ./storage/...` walks into storage/remote, whose
    remote-write suite is timing-based upstream and fails on a loaded host no matter
    what the agent wrote. Graded test runs stay on the feature packages; the wider
    tree is still required to compile."""
    source = (TESTS / "stage_check.py").read_text(encoding="utf-8")
    test_invocations = re.findall(r'\[\s*"go",\s*"test",[^\]]*\]', source, re.S)
    assert test_invocations
    for invocation in test_invocations:
        flat = " ".join(invocation.split())
        assert '"./storage/..."' not in flat, flat
        assert '"./..."' not in flat, flat
    assert 'run(["go", "build", "./..."], timeout=3000)' in source


def test_lambda_zero_uses_only_deterministic_score() -> None:
    assert calculate_training_score(
        d_num=0.7, d_den=1.0, n_num=1.0, n_den=1.0, nondeterministic_lambda=0.0
    ) == pytest.approx(0.7)


def test_nonzero_lambda_blends_rewardkit_score() -> None:
    assert calculate_training_score(
        d_num=0.7, d_den=1.0, n_num=0.4, n_den=0.5, nondeterministic_lambda=0.5
    ) == pytest.approx((0.7 + 0.5 * 0.4) / (1.0 + 0.5 * 0.5))


def test_integrity_failure_zeros_deterministic_and_training_scores() -> None:
    d_num, d_den = deterministic_components(
        {"f": {"passed": True}}, {"f": 1.0}, integrity_ok=False
    )
    assert d_num == 0.0 and d_den == 1.0
    assert calculate_training_score(
        d_num=d_num, d_den=d_den, n_num=1.0, n_den=1.0, nondeterministic_lambda=1.0, integrity_ok=False
    ) == 0.0


@pytest.mark.parametrize(
    ("d_num", "d_den", "n_num", "n_den", "weight"),
    [(0.0, 1.0, 0.0, 1.0, 0.0), (1.0, 1.0, 1.0, 1.0, 100.0), (5.0, 1.0, 5.0, 1.0, 1.0), (-5.0, 1.0, -5.0, 1.0, 1.0)],
)
def test_training_score_is_always_bounded(d_num, d_den, n_num, n_den, weight) -> None:
    score = calculate_training_score(
        d_num=d_num, d_den=d_den, n_num=n_num, n_den=n_den, nondeterministic_lambda=weight
    )
    assert 0.0 <= score <= 1.0


def test_semantic_judges_cannot_change_deterministic_gates() -> None:
    stage_runner = (TESTS / "stage_test.sh").read_text(encoding="utf-8")
    judge_runner = (TESTS / "run_optional_judges.sh").read_text(encoding="utf-8")
    merger = (TESTS / "merge_rewardkit_scores.py").read_text(encoding="utf-8")
    assert stage_runner.index("stage_check.py") < stage_runner.index("run_optional_judges.sh")
    assert 'run_optional_judges.sh "$RESULT_DIR" || true' in stage_runner
    assert '"binary_reward_affected": False' in judge_runner
    assert "dimensions=(process validity)" in judge_runner
    assert "dimensions+=(merge_readiness)" in judge_runner
    assert 'reward["reward"] = binary' in merger
    assert 'reward["binary_reward"] = binary' in merger


def test_rewardkit_files_use_declared_model_and_are_self_contained() -> None:
    model = _toml()["metadata"]["judge_model"]
    for dimension in ("process", "validity", "merge_readiness", "task_quality"):
        judge = tomllib.loads((TESTS / dimension / "judge.toml").read_text(encoding="utf-8"))
        assert judge["judge"]["judge"] == model
    packaged = "\n".join(
        p.read_text(encoding="utf-8", errors="replace")
        for p in TESTS.rglob("*")
        if p.is_file() and p.name != "test_reward_contract.py" and p.suffix in {".py", ".sh", ".toml", ".md"}
    )
    assert "from _common" not in packaged and "import _common" not in packaged


def test_agent_rewardkit_formula_preserves_binary_reward(tmp_path: Path) -> None:
    (tmp_path / "reward.json").write_text(
        json.dumps({"reward": 0.0, "binary_reward": 0.0, "training_score": 0.8, "valid_trial": 1.0}),
        encoding="utf-8",
    )
    (tmp_path / "reward-details.json").write_text(
        json.dumps({"scoring": {"D_num": 0.8, "D_den": 1.0, "integrity_passed": True}}),
        encoding="utf-8",
    )
    run = tmp_path / "judge_runs/repeat-1"
    run.mkdir(parents=True)
    (run / "reward.json").write_text(json.dumps({"process": 1.0, "validity": 0.5}), encoding="utf-8")
    detail: dict[str, object] = {}
    for dimension, value in (("process", 1.0), ("validity", 0.5)):
        judge = tomllib.loads((TESTS / dimension / "judge.toml").read_text(encoding="utf-8"))
        detail[dimension] = {
            "criteria": [
                {"name": c["name"], "value": value, "weight": c["weight"]}
                for c in judge["criterion"]
            ]
        }
    (run / "reward-details.json").write_text(json.dumps(detail), encoding="utf-8")

    summary = merge_scores(
        tmp_path,
        stage="core",
        selected_dimensions=("process", "validity"),
        judge_model="test-model",
        attempted_runs=1,
        successful_run_count=1,
        tests_dir=TESTS,
        nondeterministic_lambda=0.5,
    )
    reward = json.loads((tmp_path / "reward.json").read_text(encoding="utf-8"))
    assert reward["reward"] == reward["binary_reward"] == 0.0
    assert reward["training_score"] == pytest.approx(
        (0.8 + 0.5 * summary["N_num"]) / (1.0 + 0.5 * summary["N_den"]), abs=1e-6
    )


def test_oracle_writes_perfect_deterministic_reward(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    def passing_stage(checks: dict[str, dict[str, object]]) -> dict[str, float]:
        checks["functional"] = {"passed": True, "detail": "ok"}
        return {"functional": 1.0}

    monkeypatch.setattr(stage_check, "RESULT", tmp_path)
    monkeypatch.setattr(stage_check, "diagnose", passing_stage)
    monkeypatch.setattr(
        stage_check, "CRITICAL_CHECKS", {**stage_check.CRITICAL_CHECKS, "diagnose": frozenset({"functional"})}
    )
    monkeypatch.setattr(stage_check, "integrity", lambda: (True, {"changed_files": [], "process": {"oracle": True}}))
    monkeypatch.setattr(stage_check, "trusted_oracle", lambda: True)
    monkeypatch.setattr(sys, "argv", ["stage_check.py", "--stage", "diagnose"])

    assert stage_check.main() == 0
    reward = json.loads((tmp_path / "reward.json").read_text(encoding="utf-8"))
    details = json.loads((tmp_path / "reward-details.json").read_text(encoding="utf-8"))
    assert reward["reward"] == reward["binary_reward"] == 1.0
    assert reward["training_score"] == 1.0
    assert details["scoring"]["D_num"] == 1.0 and details["scoring"]["D_den"] == 1.0
    assert details["scoring"]["oracle"] is True
    assert details["scoring"]["rewardkit_applied"] is False


def test_qc_change_detection_is_anchored_to_the_immutable_base():
    """QC verifiable / outcome_verified / anti_cheat_robustness (first half).

    `changed_files()` compared the working tree and index against the CURRENT
    HEAD. Agents run as root and may commit, so a forbidden Stage-1 production
    edit disappeared from every repository-state check the moment it was
    committed. The comparison is now against the base commit the IMAGE recorded,
    which the agent cannot move: committing an edit makes it permanent and
    visible instead of hiding it.
    """
    source = (TESTS / "stage_check.py").read_text(encoding="utf-8")
    assert "BASE_COMMIT_ANCHOR" in source
    assert "def base_anchor(" in source
    # The diff must name the base, not be a bare working-tree diff.
    body = source[source.index("def changed_files("):]
    body = body[: body.index("\n\n\n")] if "\n\n\n" in body else body
    assert '"git", "diff", "--name-only", base' in body, (
        "changed_files must diff against the recorded base commit"
    )
    assert "untracked" in body and "deleted" in body, (
        "a never-added or removed file still has to be reported"
    )

    # Fail closed in the container: a missing or unreachable anchor is a finding,
    # not a silent downgrade to the weaker check.
    integrity_src = source[source.index("def integrity("):]
    assert "base-commit anchor missing inside the container" in integrity_src
    assert "repository replaced" in integrity_src
    assert "and anchor_ok" in integrity_src, "the anchor must vote on the outcome"

    # And the image must actually record it.
    dockerfile = (TASK_ROOT / "environment/Dockerfile").read_text(encoding="utf-8")
    assert "/opt/verifier-base-commit.txt" in dockerfile
    assert "rev-list --max-parents=0 HEAD" in dockerfile
    # It has to be recorded AFTER the sanitized commit exists, or there is no HEAD.
    assert dockerfile.index('git commit -q -m "sanitized benchmark base"') < dockerfile.index(
        "/opt/verifier-base-commit.txt"
    ), "the anchor layer must come after the sanitized commit"


def test_qc_fabricated_go_output_cannot_score():
    """QC anti_cheat_robustness (second half).

    `go_subtests()` trusted parsed `go test` output, so a package-level TestMain
    that printed matching "--- PASS: TestHidden..." lines and exited before
    m.Run() swept every check without running anything.

    The defence is a control the verifier knows the answer to: one injected test
    that MUST be reported failed. Genuine execution always fails it; fabricated
    all-PASS output reports it as passing, which is self-refuting; output that
    never mentions it did not run the corpus at all.
    """
    source = (TESTS / "stage_check.py").read_text(encoding="utf-8")
    body = source[source.index("def go_subtests("):]
    body = body[: body.index("\ndef ", 10)]

    assert "secrets.token_hex" in body, "the canary name must be unpredictable per run"
    assert "must be reported as FAILED" in body
    assert "zz_lh_canary_test.go" in body
    # Both failure modes are handled.
    assert "never appeared in the " in body
    assert "was reported as PASSING" in body
    # And a fabricated run must lose EVERY result, not merely carry a flag.
    assert "results = {name: False for name in results}" in body, (
        "detecting fabrication has to zero the graded results to be a gate"
    )
    # The canary is stripped from the graded set so it cannot be mistaken for a
    # real corpus failure.
    assert "results.pop(canary_name, None)" in body
    # It is cleaned up on every path.
    assert "finally:" in body and "path.unlink()" in body


def test_qc_unbounded_limit_allocation_is_verifier_owned():
    """QC test_instruction_alignment: stage 2 mandates bounded up-front allocation
    for astronomically large limits, but the only MaxInt coverage lived in the
    reference solution's visible test, which an alternative solution may omit."""
    hidden = (TESTS / "hidden/stage02_storage_hidden_test.go").read_text(encoding="utf-8")
    assert "func TestHiddenUnboundedLimitAllocatesByDataNotByLimit(" in hidden
    assert "math.MaxInt" in hidden
    assert '"math"' in hidden, "the probe needs the math import"
    # Correctness is asserted outside the benchmark so a panic on a huge limit is a
    # named test failure rather than a mid-measurement package abort.
    order = hidden.index("func TestHiddenUnboundedLimitAllocatesByDataNotByLimit(")
    probe = hidden[order:]
    assert probe.index("ApplySearchHints(values, huge)") < probe.index("testing.Benchmark"), (
        "call the API for correctness before benchmarking it"
    )

    # Graded, critical, and re-run at the terminal stage.
    assert "storage_unbounded_limit_alloc" in stage_check.CORE_WEIGHTS
    assert "storage_unbounded_limit_alloc" in stage_check.CRITICAL_CHECKS["core"]
    grader = (TESTS / "stage_check.py").read_text(encoding="utf-8")
    regression = grader[grader.index('checks["storage_regression"]'):]
    regression = regression[: regression.index("}")]
    assert "TestHiddenUnboundedLimitAllocatesByDataNotByLimit" in regression, (
        "the terminal stage must re-run the allocation probe"
    )

    # Disclosed: the prompt states the rule the probe grades.
    instruction = flat(TASK_ROOT / "steps/02-core/instruction.md")
    assert "astronomically large limits" in instruction

def test_qc_duplicate_collapse_is_graded_and_matches_the_stated_contract():
    """Headroom + alignment: "duplicates collapse; higher score wins" was stated in
    stage 2 and had NO coverage. It is graded now, and the probe stays inside the
    documented input contract - under score ordering a given value carries ONE
    score, so the duplicate is fed with the same score in both sets. Feeding
    different scores there would test undefined behaviour and fail a correct
    implementation."""
    hidden = (TESTS / "hidden/stage02_storage_hidden_test.go").read_text(encoding="utf-8")
    probe = hidden[hidden.index("func TestHiddenMergeCollapsesDuplicatesKeepingHigherScore("):]
    assert "OrderByValueAsc" in probe and "OrderByScoreDesc" in probe
    # Value ordering: different scores, higher one wins.
    assert 'scores["shared"]; got != 0.75' in probe
    # Score ordering: identical scores, per the contract.
    score_half = probe[probe.index("Same rule under score ordering"):]
    assert "0.25" not in score_half, (
        "under score ordering the duplicate must carry the SAME score in both sets"
    )
    assert 'seen["shared"] != 1' in score_half

    assert "storage_merge_dedup" in stage_check.CORE_WEIGHTS
    assert "storage_merge_dedup" in stage_check.CRITICAL_CHECKS["core"]
    instruction = flat(TASK_ROOT / "steps/02-core/instruction.md")
    assert "under the value orderings the higher score wins" in instruction
    assert "under score ordering a given value carries one score" in instruction
