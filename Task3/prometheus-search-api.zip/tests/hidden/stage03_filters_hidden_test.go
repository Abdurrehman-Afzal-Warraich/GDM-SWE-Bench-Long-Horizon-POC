// Hidden, protected verifier test for Stage 03 (matching engine / filters).
// Injected ephemerally into web/api/v1 as an EXTERNAL test package and removed
// afterwards. Keyed ONLY on the declared public filter constructors and their
// behavioral contract (accept <=> score>=threshold, prefix=1.0, AND semantics,
// monotonic position decay) — never on golden-internal symbols or exact score
// formulas, so any correct implementation passes.
package v1_test

import (
	"math/rand"
	"os"
	"strconv"
	"strings"
	"testing"

	"github.com/prometheus/prometheus/storage"
	v1 "github.com/prometheus/prometheus/web/api/v1"
)

func seed03() int64 {
	if v := os.Getenv("LH_SEED"); v != "" {
		if n, err := strconv.ParseInt(v, 10, 64); err == nil {
			return n
		}
	}
	return 1
}

// TestHiddenSubstringPrefixAndDecay: prefix => 1.0; non-substring => rejected;
// earlier match positions score strictly higher than later ones; scores stay
// within (0,1].
func TestHiddenSubstringPrefixAndDecay(t *testing.T) {
	f := v1.NewSubstringFilter("z")

	if ok, s := f.Accept("zaaaaaaaa"); !ok || s != 1.0 {
		t.Fatalf("prefix match: got (%v,%v), want (true,1.0)", ok, s)
	}
	if ok, s := f.Accept("aaaaaaaaa"); ok || s != 0.0 {
		t.Fatalf("non-substring: got (%v,%v), want (false,0)", ok, s)
	}

	const L = 12
	var prev float64 = 2.0
	for p := 1; p < L; p++ {
		b := []byte(strings.Repeat("a", L))
		b[p] = 'z'
		ok, s := f.Accept(string(b))
		if !ok {
			t.Fatalf("pos %d: expected accept", p)
		}
		if s <= 0 || s > 1 {
			t.Fatalf("pos %d: score %v out of (0,1]", p, s)
		}
		if s >= prev {
			t.Fatalf("pos %d: score %v not strictly less than earlier-position score %v", p, s, prev)
		}
		prev = s
	}

	empty := v1.NewSubstringFilter("")
	if ok, s := empty.Accept("anything"); !ok || s != 1.0 {
		t.Fatalf("empty query: got (%v,%v), want (true,1.0)", ok, s)
	}
}

// TestHiddenChainAndSemantics: ChainFilter accepts only if all inner filters
// accept; the reported score is the maximum inner score; empty chain accepts
// everything with score 1.0.
func TestHiddenChainAndSemantics(t *testing.T) {
	chain := v1.NewChainFilter(v1.NewSubstringFilter("ab"), v1.NewSubstringFilter("cd"))

	ok, s := chain.Accept("abXcd") // "ab" prefix => 1.0; "cd" later => <1; max => 1.0.
	if !ok || s != 1.0 {
		t.Fatalf("chain accept-all: got (%v,%v), want (true,1.0)", ok, s)
	}
	if ok, _ := chain.Accept("abXce"); ok { // "cd" absent.
		t.Fatalf("chain should reject when one filter rejects")
	}

	empty := v1.NewChainFilter()
	if ok, s := empty.Accept("whatever"); !ok || s != 1.0 {
		t.Fatalf("empty chain: got (%v,%v), want (true,1.0)", ok, s)
	}

	// The chain score is the max across its filters. Neither "b" nor "d" is a
	// prefix of "abcd", so both score < 1.0 and the chain must report the larger.
	fb := v1.NewSubstringFilter("b")
	fd := v1.NewSubstringFilter("d")
	_, sb := fb.Accept("abcd")
	_, sd := fd.Accept("abcd")
	wantMax := sb
	if sd > wantMax {
		wantMax = sd
	}
	okc, sc := v1.NewChainFilter(fb, fd).Accept("abcd")
	if !okc || sc != wantMax {
		t.Fatalf("chain max-score: got (%v,%v), want (true,%v)", okc, sc, wantMax)
	}
}

// TestHiddenFuzzyThresholdInvariant: for arbitrary query/value/threshold the
// accept decision must equal (score >= threshold), scores are bounded to
// [0,1], and an identical value scores 1.0 (accepted at any threshold<=1).
func TestHiddenFuzzyThresholdInvariant(t *testing.T) {
	r := rand.New(rand.NewSource(seed03() + 11))
	for i := 0; i < 200; i++ {
		q := randToken(r)
		v := randToken(r)
		th := r.Float64()
		f := v1.NewFuzzyFilter(q, th)
		ok, s := f.Accept(v)
		if s < 0 || s > 1 {
			t.Fatalf("fuzzy score %v out of [0,1] (q=%q v=%q)", s, q, v)
		}
		if ok != (s >= th) {
			t.Fatalf("fuzzy accept=%v but score=%v threshold=%v (q=%q v=%q): accept must equal score>=threshold", ok, s, th, q, v)
		}
	}
	f := v1.NewFuzzyFilter("http_requests_total", 1.0)
	if ok, s := f.Accept("http_requests_total"); !ok || s != 1.0 {
		t.Fatalf("identical fuzzy: got (%v,%v), want (true,1.0)", ok, s)
	}
}

// TestHiddenSubsequenceContract: prefix => 1.0; a value missing a query rune
// (not a subsequence) => rejected with score 0; and accept must equal
// (score>0 && score>=threshold).
func TestHiddenSubsequenceContract(t *testing.T) {
	if ok, s := v1.NewSubsequenceFilter("met", 0.5).Accept("metric_total"); !ok || s != 1.0 {
		t.Fatalf("subsequence prefix: got (%v,%v), want (true,1.0)", ok, s)
	}
	if ok, s := v1.NewSubsequenceFilter("xyz", 0.0).Accept("abcdef"); ok || s != 0.0 {
		t.Fatalf("non-subsequence: got (%v,%v), want (false,0)", ok, s)
	}
	r := rand.New(rand.NewSource(seed03() + 23))
	for i := 0; i < 200; i++ {
		q := randToken(r)
		v := randToken(r)
		th := r.Float64()
		ok, s := v1.NewSubsequenceFilter(q, th).Accept(v)
		if s < 0 || s > 1 {
			t.Fatalf("subsequence score %v out of [0,1] (q=%q v=%q)", s, q, v)
		}
		want := s > 0 && s >= th
		if ok != want {
			t.Fatalf("subsequence accept=%v but score=%v threshold=%v (q=%q v=%q): accept must equal (score>0 && score>=threshold)", ok, s, th, q, v)
		}
	}
}

// TestHiddenSubstringUnicode: multi-byte values are scored by RUNE position,
// not byte offset. A prefix match on a non-ASCII value is 1.0, and a match at
// rune index N scores the SAME whether the preceding runes are ASCII or
// multi-byte (a byte-offset implementation would diverge).
func TestHiddenSubstringUnicode(t *testing.T) {
	f := v1.NewSubstringFilter("z")

	if ok, s := f.Accept("zédémo"); !ok || s != 1.0 {
		t.Fatalf("unicode prefix: got (%v,%v), want (true,1.0)", ok, s)
	}
	okA, sA := f.Accept("aaz") // 'z' at rune index 2, ASCII prefix.
	okU, sU := f.Accept("ééz") // 'z' at rune index 2, each 'é' is 2 bytes.
	if !okA || !okU {
		t.Fatalf("expected accept for both (ascii=%v unicode=%v)", okA, okU)
	}
	if sA != sU {
		t.Fatalf("rune-position decay mismatch: ascii=%v unicode=%v (byte-indexing bug?)", sA, sU)
	}
}

// Compile-time assertion that the public constructors satisfy storage.Filter.
var (
	_ storage.Filter = v1.NewSubstringFilter("x")
	_ storage.Filter = v1.NewFuzzyFilter("x", 0.5)
	_ storage.Filter = v1.NewSubsequenceFilter("x", 0.5)
	_ storage.Filter = v1.NewChainFilter()
)

func randToken(r *rand.Rand) string {
	const alpha = "abcdefghijklmnopqrstuvwxyz_"
	n := 1 + r.Intn(10)
	b := make([]byte, n)
	for i := range b {
		b[i] = alpha[r.Intn(len(alpha))]
	}
	return string(b)
}
