// Hidden, protected verifier test for Stage 02 (storage search engine).
// Injected ephemerally into the storage package dir at verification time and
// removed afterwards; the agent never sees it. Keyed ONLY on the declared
// public storage API (ApplySearchHints, MergeSearchResultSets,
// NewSearchResultSetFromSlice[AndError]) — never on golden-internal symbols.
//
// Seed is injected via LH_SEED so cases differ from any example values.
package storage_test

import (
	"errors"
	"math"
	"math/rand"
	"os"
	"sort"
	"strconv"
	"strings"
	"testing"

	"github.com/prometheus/prometheus/storage"
)

func hiddenSeed() int64 {
	if v := os.Getenv("LH_SEED"); v != "" {
		if n, err := strconv.ParseInt(v, 10, 64); err == nil {
			return n
		}
	}
	return 1
}

// subFilter is an independent substring filter with a position-decay score in
// [0.1,1.0); a prefix scores 1.0. ASCII-only inputs keep byte==rune.
type subFilter struct{ q string }

func (f subFilter) Accept(v string) (bool, float64) {
	if f.q == "" {
		return true, 1.0
	}
	i := strings.Index(v, f.q)
	if i < 0 {
		return false, 0
	}
	if i == 0 {
		return true, 1.0
	}
	maxPos := len(v) - len(f.q)
	if maxPos <= 0 {
		return true, 1.0
	}
	return true, 1.0 - 0.9*float64(i)/float64(maxPos)
}

func refTopK(values []string, f storage.Filter, k int) []storage.SearchResult {
	var all []storage.SearchResult
	for _, v := range values {
		if ok, s := f.Accept(v); ok {
			all = append(all, storage.SearchResult{Value: v, Score: s})
		}
	}
	sort.SliceStable(all, func(i, j int) bool {
		if all[i].Score != all[j].Score {
			return all[i].Score > all[j].Score
		}
		return all[i].Value < all[j].Value
	})
	if k > 0 && len(all) > k {
		all = all[:k]
	}
	return all
}

func randASCII(r *rand.Rand, n int) string {
	const alpha = "abcdefghijklmnopqrstuvwxyz_0123456789"
	b := make([]byte, n)
	for i := range b {
		b[i] = alpha[r.Intn(len(alpha))]
	}
	return string(b)
}

// TestHiddenTopKEquivalence: score-ranked, limited ApplySearchHints must equal
// the full (Score desc, Value asc) sort truncated to Limit, on seeded inputs.
func TestHiddenTopKEquivalence(t *testing.T) {
	r := rand.New(rand.NewSource(hiddenSeed()))
	for trial := 0; trial < 40; trial++ {
		n := 50 + r.Intn(400)
		set := map[string]struct{}{}
		for len(set) < n {
			set[randASCII(r, 3+r.Intn(6))] = struct{}{}
		}
		values := make([]string, 0, n)
		for v := range set {
			values = append(values, v)
		}
		sort.Strings(values) // ApplySearchHints assumes ascending input.

		q := randASCII(r, 1+r.Intn(2))
		f := subFilter{q: q}
		k := 1 + r.Intn(25)

		got := storage.ApplySearchHints(values, &storage.SearchHints{Filter: f, OrderBy: storage.OrderByScoreDesc, Limit: k})
		want := refTopK(values, f, k)

		if len(got) != len(want) {
			t.Fatalf("trial %d q=%q k=%d: len(got)=%d want=%d", trial, q, k, len(got), len(want))
		}
		for i := range want {
			if got[i].Value != want[i].Value || got[i].Score != want[i].Score {
				t.Fatalf("trial %d q=%q k=%d pos %d: got %+v want %+v", trial, q, k, i, got[i], want[i])
			}
		}
	}
}

// TestHiddenValueOrderingLimit: ascending/descending value orderings with a
// limit return the correct first-K values.
func TestHiddenValueOrderingLimit(t *testing.T) {
	r := rand.New(rand.NewSource(hiddenSeed() + 7))
	set := map[string]struct{}{}
	for len(set) < 300 {
		set[randASCII(r, 4+r.Intn(5))] = struct{}{}
	}
	values := make([]string, 0, len(set))
	for v := range set {
		values = append(values, v)
	}
	sort.Strings(values)
	k := 17

	asc := storage.ApplySearchHints(values, &storage.SearchHints{OrderBy: storage.OrderByValueAsc, Limit: k})
	if len(asc) != k {
		t.Fatalf("asc len=%d want %d", len(asc), k)
	}
	for i := 0; i < k; i++ {
		if asc[i].Value != values[i] {
			t.Fatalf("asc pos %d: got %q want %q", i, asc[i].Value, values[i])
		}
	}
	dsc := storage.ApplySearchHints(values, &storage.SearchHints{OrderBy: storage.OrderByValueDesc, Limit: k})
	if len(dsc) != k {
		t.Fatalf("dsc len=%d want %d", len(dsc), k)
	}
	for i := 0; i < k; i++ {
		if dsc[i].Value != values[len(values)-1-i] {
			t.Fatalf("dsc pos %d: got %q want %q", i, dsc[i].Value, values[len(values)-1-i])
		}
	}
}

// TestHiddenPartialErrorMergePreservesResults: the discriminating check.
// A merge where one input yields results then errors must still surface the
// healthy input's results AND expose the error via Err() (keep-draining +
// errors.Join), rather than fail-fast dropping buffered results.
func TestHiddenPartialErrorMergePreservesResults(t *testing.T) {
	boom := errors.New("hidden-boom")
	// Inputs must be pre-ordered ascending by Value (merge contract).
	healthy := storage.NewSearchResultSetFromSlice(
		[]storage.SearchResult{{Value: "aaa", Score: 1}, {Value: "ccc", Score: 1}, {Value: "eee", Score: 1}}, nil)
	partial := storage.NewSearchResultSetFromSliceAndError(
		[]storage.SearchResult{{Value: "bbb", Score: 1}, {Value: "ddd", Score: 1}}, nil, boom)

	merged := storage.MergeSearchResultSets(
		[]storage.SearchResultSet{healthy, partial},
		&storage.SearchHints{OrderBy: storage.OrderByValueAsc})
	defer merged.Close()

	var got []string
	for merged.Next() {
		got = append(got, merged.At().Value)
	}
	want := []string{"aaa", "bbb", "ccc", "ddd", "eee"}
	if strings.Join(got, ",") != strings.Join(want, ",") {
		t.Fatalf("merged results = %v, want %v (healthy-side results must be preserved)", got, want)
	}
	if err := merged.Err(); err == nil || !strings.Contains(err.Error(), "hidden-boom") {
		t.Fatalf("merged.Err() = %v, want it to surface the partial error", err)
	}
}

// TestHiddenLazyNotConstructedUntilUsed: a lazy set whose init is never called
// when the merge short-circuits on limit; at minimum it must construct on use.
func TestHiddenLazyConstructsOnUse(t *testing.T) {
	called := false
	lazy := storage.NewLazySearchResultSet(func() storage.SearchResultSet {
		called = true
		return storage.NewSearchResultSetFromSlice([]storage.SearchResult{{Value: "z", Score: 1}}, nil)
	})
	defer lazy.Close()
	if lazy.Next(); !called {
		t.Fatalf("lazy set did not construct on first Next")
	}
	if lazy.At().Value != "z" {
		t.Fatalf("lazy set returned %q", lazy.At().Value)
	}
}

// TestHiddenUnboundedLimitAllocatesByDataNotByLimit closes the gap QC found:
// Stage 2 requires up-front allocation to stay bounded "for tiny and
// astronomically large limits alike", but the only MaxInt coverage lived in the
// reference solution's own visible test, which an alternative implementation is
// free to omit. This is the verifier's own probe for it, so the requirement is
// graded independently of anything the agent writes.
//
// The failure it targets is the obvious one: sizing the output buffer from the
// caller's Limit (`make([]SearchResult, 0, hints.Limit)`). With Limit=MaxInt that
// either panics outright or reserves absurd memory. A correct implementation caps
// its reservation by how much data actually exists, so asking for MaxInt costs
// about the same as asking for exactly the number of values present.
func TestHiddenUnboundedLimitAllocatesByDataNotByLimit(t *testing.T) {
	r := rand.New(rand.NewSource(hiddenSeed() + 23))
	set := map[string]struct{}{}
	for len(set) < 2000 {
		set[randASCII(r, 6+r.Intn(6))] = struct{}{}
	}
	values := make([]string, 0, len(set))
	for v := range set {
		values = append(values, v)
	}
	sort.Strings(values)

	huge := &storage.SearchHints{OrderBy: storage.OrderByValueAsc, Limit: math.MaxInt}
	exact := &storage.SearchHints{OrderBy: storage.OrderByValueAsc, Limit: len(values)}

	// Correctness first, and outside any benchmark, so an implementation that
	// panics on a huge limit fails as a named test rather than taking the whole
	// package down mid-measurement.
	got := storage.ApplySearchHints(values, huge)
	if len(got) != len(values) {
		t.Fatalf("Limit=MaxInt returned %d results, want all %d", len(got), len(values))
	}
	for i := range values {
		if got[i].Value != values[i] {
			t.Fatalf("Limit=MaxInt pos %d: got %q want %q", i, got[i].Value, values[i])
		}
	}

	steady := func(name string, hints *storage.SearchHints) int64 {
		best := int64(-1)
		for range 2 {
			res := testing.Benchmark(func(b *testing.B) {
				b.ReportAllocs()
				for b.Loop() {
					_ = storage.ApplySearchHints(values, hints)
				}
			})
			if res.N == 0 {
				t.Fatalf("%s benchmark did not run", name)
			}
			if v := res.AllocedBytesPerOp(); best < 0 || v < best {
				best = v
			}
		}
		return best
	}

	unbounded := steady("Limit=MaxInt", huge)
	bounded := steady("Limit=len(values)", exact)
	t.Logf("steady-state allocation: MaxInt=%d B/op exact=%d B/op (ratio %.3f, need <= 2.0)",
		unbounded, bounded, float64(unbounded)/float64(bounded))

	// Generous: an implementation whose reservation tracks the data allocates
	// essentially the same for both. Anything that sizes off Limit is orders of
	// magnitude worse, so 2x leaves wide room for unrelated differences.
	if bounded <= 0 {
		t.Fatalf("exact-limit benchmark reported no allocation; measurement is unusable")
	}
	if unbounded > bounded*2 {
		t.Fatalf("Limit=MaxInt allocates %d B/op against %d B/op for an exact limit: "+
			"up-front allocation is sized by the limit, not by the data", unbounded, bounded)
	}
}

// TestHiddenMergeCollapsesDuplicatesKeepingHigherScore grades a rule Stage 2
// states plainly - "Duplicates collapse in order; higher score wins" - that had
// no independent coverage at all. It is also the most discriminating merge case:
// a naive k-way merge emits the same value once per input set, and a merge that
// dedupes by first-seen keeps whichever score happened to arrive first.
//
// Both orderings are checked, because the collapse has to survive the comparator:
// under value ordering the duplicate is adjacent, under score ordering the two
// copies arrive far apart and a first-seen dedupe silently keeps the wrong score.
func TestHiddenMergeCollapsesDuplicatesKeepingHigherScore(t *testing.T) {
	// Value-ordered inputs, each internally sorted ascending by Value. "shared"
	// appears in both sets with different scores.
	left := storage.NewSearchResultSetFromSlice([]storage.SearchResult{
		{Value: "alpha", Score: 0.9},
		{Value: "shared", Score: 0.25},
		{Value: "zulu", Score: 0.1},
	}, nil)
	right := storage.NewSearchResultSetFromSlice([]storage.SearchResult{
		{Value: "bravo", Score: 0.5},
		{Value: "shared", Score: 0.75},
	}, nil)

	merged := storage.MergeSearchResultSets(
		[]storage.SearchResultSet{left, right},
		&storage.SearchHints{OrderBy: storage.OrderByValueAsc})
	defer merged.Close()

	var values []string
	scores := map[string]float64{}
	for merged.Next() {
		r := merged.At()
		values = append(values, r.Value)
		if prev, seen := scores[r.Value]; seen {
			t.Fatalf("value %q was emitted twice (scores %v then %v): duplicates must collapse",
				r.Value, prev, r.Score)
		}
		scores[r.Value] = r.Score
	}
	if err := merged.Err(); err != nil {
		t.Fatalf("value-ordered merge returned an error: %v", err)
	}

	want := []string{"alpha", "bravo", "shared", "zulu"}
	if strings.Join(values, ",") != strings.Join(want, ",") {
		t.Fatalf("value-ordered merge = %v, want %v", values, want)
	}
	if got := scores["shared"]; got != 0.75 {
		t.Fatalf("collapsed duplicate kept score %v, want the higher score 0.75", got)
	}

	// Same rule under score ordering. Note the INPUT CONTRACT: under
	// OrderByScoreDesc a given Value carries one score, so the duplicate is fed
	// with the SAME score in both sets and the copies are adjacent. Feeding
	// different scores here would be testing behaviour the contract does not
	// define. The discriminator still holds: a naive k-way merge emits the value
	// once per input set.
	leftScore := storage.NewSearchResultSetFromSlice([]storage.SearchResult{
		{Value: "alpha", Score: 0.9},
		{Value: "shared", Score: 0.75},
	}, nil)
	rightScore := storage.NewSearchResultSetFromSlice([]storage.SearchResult{
		{Value: "shared", Score: 0.75},
		{Value: "bravo", Score: 0.5},
	}, nil)
	byScore := storage.MergeSearchResultSets(
		[]storage.SearchResultSet{leftScore, rightScore},
		&storage.SearchHints{OrderBy: storage.OrderByScoreDesc})
	defer byScore.Close()

	var ordered []storage.SearchResult
	for byScore.Next() {
		ordered = append(ordered, byScore.At())
	}
	if err := byScore.Err(); err != nil {
		t.Fatalf("score-ordered merge returned an error: %v", err)
	}
	seen := map[string]int{}
	for _, r := range ordered {
		seen[r.Value]++
	}
	if seen["shared"] != 1 {
		t.Fatalf("score-ordered merge emitted %q %d times, want exactly 1", "shared", seen["shared"])
	}
	for i := 1; i < len(ordered); i++ {
		if ordered[i-1].Score < ordered[i].Score {
			t.Fatalf("score-ordered merge is not descending at %d: %v then %v",
				i, ordered[i-1], ordered[i])
		}
	}
}
