package storage

// Stage-01 diagnose: injected, package-internal behavioral reproduction of the
// two gaps the feature must close. Runs ONLY at base (pre-feature). It relies
// on the base package's own test helpers (searchQuerier / partialErrSearchQuerier)
// and public API (ApplySearchHints, NewMergeQuerier) — no source scanning.

import (
	"context"
	"errors"
	"fmt"
	"testing"
)

type lhDiagFilter struct{}

// Accept everything with a value-derived score so ApplySearchHints must rank.
func (lhDiagFilter) Accept(v string) (bool, float64) {
	return true, float64(len(v)%7) / 7.0
}

// TestHiddenBaseTopKMaterialisesFullSet reproduces the top-K INEFFICIENCY: for a
// small score-ranked limit over a large matched set, the base implementation
// allocates on the order of the whole input (it sorts everything, then slices)
// rather than keeping only ~K. A real bounded top-K would allocate far less
// than the input size.
func TestHiddenBaseTopKMaterialisesFullSet(t *testing.T) {
	const n = 40000
	values := make([]string, n)
	for i := range values {
		values[i] = fmt.Sprintf("metric_series_%07d", i)
	}
	hints := &SearchHints{Filter: lhDiagFilter{}, OrderBy: OrderByScoreDesc, Limit: 10}

	br := testing.Benchmark(func(b *testing.B) {
		b.ReportAllocs()
		for i := 0; i < b.N; i++ {
			_ = ApplySearchHints(values, hints)
		}
	})
	perOp := br.AllocedBytesPerOp()
	t.Logf("base ApplySearchHints score-desc limit=10 over N=%d allocates %d B/op", n, perOp)
	// Base materialises ~O(N); assert it is at least the input count in bytes —
	// dramatically more than a bounded top-K (~limit) would need.
	if perOp < int64(n) {
		t.Fatalf("expected base to materialise ~O(N) bytes (inefficient top-K); got only %d B/op for N=%d", perOp, n)
	}
}

// TestHiddenBaseMergeIsFailFast reproduces the FAIL-FAST merge gap: when one
// side errors mid-stream after yielding partial results, the base k-way merge
// surfaces the error AND drops the already-available healthy side entirely.
func TestHiddenBaseMergeIsFailFast(t *testing.T) {
	boom := errors.New("lh-diag-boom")
	primary := &partialErrSearchQuerier{
		names: []SearchResult{{Value: "alpha"}, {Value: "beta"}},
		err:   boom,
	}
	secondary := &searchQuerier{
		names: []SearchResult{{Value: "gamma"}, {Value: "delta"}, {Value: "epsilon"}},
	}
	merged, ok := NewMergeQuerier([]Querier{primary, secondary}, nil, ChainedSeriesMerge).(Searcher)
	if !ok {
		t.Fatalf("merged querier is not a Searcher at base")
	}
	rs := merged.SearchLabelNames(context.Background(), nil)
	got := map[string]bool{}
	for rs.Next() {
		got[rs.At().Value] = true
	}
	err := rs.Err()
	t.Logf("base merge on mid-stream error: results=%v err=%v", keysOf(got), err)

	if err == nil {
		t.Fatalf("expected base merge to surface the mid-stream error")
	}
	// Fail-fast: at least one healthy-side value is dropped (not kept-draining).
	dropped := !got["gamma"] || !got["delta"] || !got["epsilon"]
	if !dropped {
		t.Fatalf("base unexpectedly preserved the whole healthy side %v; not fail-fast", keysOf(got))
	}
}

func keysOf(m map[string]bool) []string {
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	return out
}
