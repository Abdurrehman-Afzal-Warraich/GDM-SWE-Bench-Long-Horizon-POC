// Hidden, protected verifier test for Stage 04 (performance guard). Injected
// ephemerally into the storage package dir at verification time and removed
// afterwards; the agent never sees it. Keyed ONLY on the declared public
// storage API (ApplySearchHints + SearchHints + OrderByScoreDesc + Filter),
// never on golden-internal symbols.
//
// It asserts BOTH correctness (top-K == full-sort truncated) and that the
// top-K path is materially cheaper in allocated bytes than a full sort — so a
// naive implementation that sorts the whole matched set fails the guard.
package storage_test

import (
	"fmt"
	"sort"
	"testing"

	"github.com/prometheus/prometheus/storage"
)

type perfHiddenFilter struct{}

func (perfHiddenFilter) Accept(v string) (bool, float64) {
	b := v[len(v)-1]
	return true, float64(b%64) / 64.0
}

func hiddenFullSortTopK(values []string, f storage.Filter, k int) []storage.SearchResult {
	out := make([]storage.SearchResult, 0, len(values))
	for _, v := range values {
		if ok, s := f.Accept(v); ok {
			out = append(out, storage.SearchResult{Value: v, Score: s})
		}
	}
	sort.SliceStable(out, func(i, j int) bool {
		if out[i].Score != out[j].Score {
			return out[i].Score > out[j].Score
		}
		return out[i].Value < out[j].Value
	})
	if k > 0 && len(out) > k {
		out = out[:k]
	}
	return out
}

// TestHiddenTopKPerfMateriallyCheaper is the Stage-4 performance guard.
func TestHiddenTopKPerfMateriallyCheaper(t *testing.T) {
	const n, k = 40_000, 100
	values := make([]string, n)
	for i := range values {
		values[i] = fmt.Sprintf("m_%07d", i)
	}
	f := perfHiddenFilter{}
	hints := &storage.SearchHints{Filter: f, OrderBy: storage.OrderByScoreDesc, Limit: k}

	got := storage.ApplySearchHints(values, hints)
	want := hiddenFullSortTopK(values, f, k)
	if len(got) != len(want) {
		t.Fatalf("top-K len=%d want=%d", len(got), len(want))
	}
	for i := range want {
		if got[i] != want[i] {
			t.Fatalf("top-K pos %d: got %+v want %+v", i, got[i], want[i])
		}
	}

	// Measured twice and reported on the steady-state (cheapest) run, so a cold
	// first iteration cannot decide the outcome. Allocation counts, unlike
	// wall-clock, are deterministic under load.
	steady := func(name string, body func()) int64 {
		best := int64(-1)
		for range 2 {
			res := testing.Benchmark(func(b *testing.B) {
				b.ReportAllocs()
				for b.Loop() {
					body()
				}
			})
			if res.N == 0 {
				t.Fatalf("%s benchmark did not run", name)
			}
			if got := res.AllocedBytesPerOp(); best < 0 || got < best {
				best = got
			}
		}
		return best
	}

	topK := steady("top-K", func() { _ = storage.ApplySearchHints(values, hints) })
	full := steady("full sort", func() { _ = hiddenFullSortTopK(values, f, k) })
	// Always reported so the achieved margin is visible in the verifier log.
	t.Logf("steady-state allocation: topK=%d B/op full=%d B/op (ratio %.3f, need <= 0.5)",
		topK, full, float64(topK)/float64(full))

	// Documented in the stage-4 instruction: the top-K path must allocate no
	// more than HALF the bytes/op of the equivalent full sort. A bounded top-K
	// is normally an order of magnitude cheaper, so this leaves wide margin for
	// implementations that differ from the reference in other respects.
	if topK*2 >= full {
		t.Fatalf("top-K is not materially cheaper than full sort: topK=%d B/op "+
			"full=%d B/op (need topK <= full/2)", topK, full)
	}
}
