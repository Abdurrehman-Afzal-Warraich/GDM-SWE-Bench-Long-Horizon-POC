#!/usr/bin/env bash
# Optional, non-authoritative RewardKit judges. Never changes reward/binary_reward.
set -uo pipefail

RESULT_DIR="${1:-${RESULT_DIR:-/logs/verifier}}"
TESTS_DIR="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SUITE_DIR="$RESULT_DIR/judge_suite"
RUNS_DIR="$RESULT_DIR/judge_runs"
STATUS_FILE="$RESULT_DIR/judge_status.json"
WORKSPACE="${JUDGE_WORKSPACE:-/testbed}"
STAGE="${TASK_STAGE:-unknown}"
JUDGE_MODEL="${JUDGE_MODEL:-anthropic/claude-sonnet-4-6}"

write_status() {
  local reason="$1"
  local applicable="${2:-true}"
  python3 -S - "$STATUS_FILE" "$reason" "$STAGE" "$applicable" <<'PY'
import json, sys
from pathlib import Path
Path(sys.argv[1]).write_text(json.dumps({
    "available": False,
    "applicable": sys.argv[4].lower() == "true",
    "stage": sys.argv[3],
    "reason": sys.argv[2],
    "binary_reward_affected": False,
}, indent=2, sort_keys=True) + "\n", encoding="utf-8")
PY
}

if [ -f /logs/agent/oracle.txt ] || [ "${TRUSTED_ORACLE:-0}" = "1" ]; then
  write_status "trusted Oracle: RewardKit skipped; non-deterministic reward is N/A" false
  exit 0
fi

[ -f "$RESULT_DIR/judge_inputs/trajectory.json" ] || {
  write_status "agent trajectory unavailable; deterministic score only"
  exit 0
}
case "${ANTHROPIC_API_KEY:-}" in
  ''|'${ANTHROPIC_API_KEY}'|'${ANTHROPIC_API_KEY:-}'|'$ANTHROPIC_API_KEY')
    write_status "ANTHROPIC_API_KEY unavailable; deterministic score only"
    exit 0
    ;;
esac
command -v rewardkit >/dev/null 2>&1 || {
  write_status "RewardKit unavailable; deterministic score only"
  exit 0
}

repeats="${JUDGE_REPEATS:-2}"
case "$repeats" in
  ''|*[!0-9]*) repeats=2 ;;
esac
[ "$repeats" -ge 1 ] || repeats=1
[ "$repeats" -le 3 ] || repeats=3

timeout_sec="${JUDGE_TIMEOUT_SEC:-300}"
case "$timeout_sec" in
  ''|*[!0-9]*) timeout_sec=300 ;;
esac
[ "$timeout_sec" -ge 30 ] || timeout_sec=30
[ "$timeout_sec" -le 900 ] || timeout_sec=900

dimensions=(process validity)
binary="$(
  python3 -S - "$RESULT_DIR/reward.json" <<'PY'
import json, sys
try:
    payload = json.load(open(sys.argv[1], encoding="utf-8"))
    print("1" if float(payload.get("binary_reward", 0.0) or 0.0) == 1.0 else "0")
except Exception:
    print("0")
PY
)"
case "$STAGE:$binary" in
  harden:1|04-harden:1)
    dimensions+=(merge_readiness)
    ;;
esac

rm -rf "$SUITE_DIR" "$RUNS_DIR"
mkdir -p "$SUITE_DIR" "$RUNS_DIR"
cp "$TESTS_DIR/judge_prompt.md" "$SUITE_DIR/judge_prompt.md"
for dimension in "${dimensions[@]}"; do
  mkdir -p "$SUITE_DIR/$dimension"
  cp "$TESTS_DIR/$dimension/judge.toml" "$SUITE_DIR/$dimension/judge.toml"
done

successful=0
for index in $(seq 1 "$repeats"); do
  run_dir="$RUNS_DIR/repeat-$index"
  mkdir -p "$run_dir"
  if timeout --signal=TERM --kill-after=15s "${timeout_sec}s" \
      rewardkit "$SUITE_DIR" --workspace "$WORKSPACE" --output "$run_dir/reward.json" \
      > "$run_dir/rewardkit.log" 2>&1; then
    successful=$((successful + 1))
  fi
done

[ "$successful" -gt 0 ] || {
  reason="all RewardKit judge calls failed; deterministic score only; inspect judge_runs"
  if grep -Eqi 'name resolution|temporary failure|cannot connect|connection (refused|timed out)|network is unreachable' "$RUNS_DIR"/repeat-*/rewardkit.log 2>/dev/null; then
    reason="judge provider is unreachable; deterministic score only"
  elif grep -Eqi '401|403|unauthori[sz]ed|permission denied|invalid.*api.*key|api.*key.*invalid' "$RUNS_DIR"/repeat-*/rewardkit.log 2>/dev/null; then
    reason="judge provider rejected ANTHROPIC_API_KEY; deterministic score only"
  elif grep -Eqi '404|model.*not found|unknown model|unsupported model' "$RUNS_DIR"/repeat-*/rewardkit.log 2>/dev/null; then
    reason="configured judge model is unavailable; deterministic score only"
  elif grep -Eqi 'timed out|timeout|terminated' "$RUNS_DIR"/repeat-*/rewardkit.log 2>/dev/null; then
    reason="all RewardKit calls exceeded the timeout; deterministic score only"
  fi
  write_status "$reason"
  exit 0
}

selected="$(IFS=,; echo "${dimensions[*]}")"
python3 -S "$TESTS_DIR/merge_rewardkit_scores.py" \
  "$RESULT_DIR" \
  --stage "$STAGE" \
  --dimensions "$selected" \
  --judge-model "$JUDGE_MODEL" \
  --attempted-runs "$repeats" \
  --successful-runs "$successful"

exit 0
