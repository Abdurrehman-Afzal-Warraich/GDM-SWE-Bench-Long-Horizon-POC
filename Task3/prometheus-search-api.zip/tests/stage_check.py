#!/usr/bin/env python3
"""Deterministic per-stage grader for the Prometheus Search API Tier-2 task.

The trial reward is a strict deterministic binary; RewardKit (if enabled) only
nudges the continuous training_score and never the binary outcome. All
functional checks are behavior-based and keyed on the DECLARED public contract
(exported constructors, storage API, HTTP URL paths, feature-flag names) — never
on golden-internal symbols — so any correct implementation passes. Hidden Go
tests are injected ephemerally into the package under test and removed after.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import os
import re
import secrets
import shutil
import socket
import subprocess
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

from score_formula import (
    binary_outcome,
    calculate_training_score,
    deterministic_components,
    formula_text,
    parse_lambda,
)


TESTBED = Path(os.environ.get("TESTBED_DIR", "/testbed"))
RESULT = Path(os.environ.get("RESULT_DIR", "/logs/verifier"))
OUTPUT = Path(os.environ.get("OUTPUT_DIR", "/app/output"))
HIDDEN = Path(os.environ.get("HIDDEN_DIR", "/tests/hidden"))
PROM_BIN = Path("/tmp/lh-prom")

# Fixed per-stage seeds: cases are novel vs any example, but reproducible.
STAGE_SEEDS = {"diagnose": "70211", "core": "70212", "review": "70213", "harden": "70214"}

# --- Anti-tamper: harden the verifier's OWN PATH. ---------------------------
# This module is injected fresh at grade time from an agent-inaccessible mount
# (/tests), so it is a trustworthy root the agent cannot edit. We PREPEND the
# canonical, root-owned toolchain directories to PATH before running any tool,
# so a wrapper an agent dropped into a writable directory earlier on PATH can
# NEVER shadow the real go/git/python (the trusted copies always resolve first).
# Nonexistent entries (e.g. host-side validation, where go lives elsewhere) are
# harmless — resolution falls through to the rest of PATH. This makes the
# PATH-shadow defense independent of any writable in-image manifest.
TRUSTED_PATH_DIRS = (
    "/opt/verifier-venv/bin",
    "/usr/local/go/bin",
    "/usr/local/sbin",
    "/usr/local/bin",
    "/usr/sbin",
    "/usr/bin",
    "/sbin",
    "/bin",
)
# Only harden inside the built container (where the attack is relevant and the
# canonical dirs exist); leave host-side validation PATH untouched so the pinned
# host Go toolchain still resolves.
_IN_CONTAINER = Path("/opt/verifier-venv/bin/python3").exists()
if _IN_CONTAINER:
    _existing = os.environ.get("PATH", "")
    os.environ["PATH"] = os.pathsep.join(TRUSTED_PATH_DIRS) + (
        os.pathsep + _existing if _existing else ""
    )

DIAGNOSE_WEIGHTS = {
    "base_behavior_reproduced": 0.18,
    "base_feature_flag_inert": 0.13,
    "base_storage_api_absent": 0.12,
    "base_topk_inefficient": 0.12,
    "base_merge_failfast": 0.13,
    "base_absence_observed": 0.10,
    "diagnosis_handoff": 0.15,
    "decisions_handoff": 0.07,
}

CORE_WEIGHTS = {
    "incremental_build": 0.10,
    "storage_topk_equivalence": 0.20,
    "storage_value_ordering_limit": 0.10,
    "storage_partial_error_merge": 0.23,
    "storage_lazy_construction": 0.05,
    # QC test_instruction_alignment: stage 2 requires bounded up-front allocation
    # for astronomically large limits, and the only MaxInt coverage used to live in
    # the reference solution's own visible test - which an alternative solution may
    # simply not write. This is the verifier's own probe for that requirement.
    "storage_unbounded_limit_alloc": 0.06,
    # "Duplicates collapse in order; higher score wins" is stated in the stage-2
    # prompt and previously had NO coverage. It is also the sharpest merge
    # discriminator: a naive k-way merge emits the value once per input set, and a
    # first-seen dedupe keeps whichever score arrived first.
    "storage_merge_dedup": 0.06,
    "handoff_consumed": 0.10,
    "implementation_report": 0.10,
}

REVIEW_WEIGHTS = {
    "incremental_build": 0.05,
    "filter_substring_decay": 0.10,
    "filter_chain_and_semantics": 0.07,
    "filter_fuzzy_threshold": 0.10,
    "filter_subsequence_contract": 0.10,
    "filter_substring_unicode": 0.06,
    "http_search_success": 0.20,
    "http_dos_validation": 0.08,
    "http_feature_gate": 0.04,
    "openapi_updated": 0.05,
    "review_package_tests": 0.05,
    "core_regression": 0.07,
    "review_response": 0.03,
}

HARDEN_WEIGHTS = {
    "incremental_build": 0.03,
    "vet_clean": 0.05,
    "storage_regression": 0.07,
    "filter_regression": 0.07,
    "http_search_success": 0.16,
    "http_dos_validation": 0.08,
    "http_feature_gate": 0.03,
    "perf_topk_guard": 0.11,
    "race_clean": 0.09,
    "cap_disabled_edge": 0.06,
    "package_tests": 0.11,
    "docs_updated": 0.08,
    "patch_hygiene": 0.03,
    "final_report": 0.03,
}

# Critical == "this stage did not happen without it". These decide the pass/fail
# outcome and promotion.
#
# The governing rule, and the one a reviewer should be able to check mechanically:
# EVERY requirement an instruction states as mandatory is critical, and every
# non-critical check is described in the instruction as optional. There is no
# third category. test_reward_contract.py enforces both directions, so the prompt
# and the gate cannot drift apart again.
#
# This is a deliberate change from the previous revision, which stated user
# documentation, patch hygiene and the final report as Stage-4 requirements while
# grading them non-critically. A run could then fail stated requirements and still
# record binary_reward=1.0 - which is exactly what the shipped agent trial did.
# The three are objective (token presence in the repo's own docs, `git diff
# --check` plus a build-artifact scan, and a typed JSON contract), and every token
# and key they look for is spelled out in the Stage-4 instruction, so promoting
# them cannot fail an implementation that did what it was told.
#
# The old `merge_ready` check is GONE rather than promoted. It graded
# `decisions.merge_ready == true` in the agent's own handoff - a self-assessment,
# not a behavior. Rewarding an agent for asserting its own success is a reward
# hacking surface, and no reviewer can distinguish an earned `true` from a typed
# one. Nothing replaces it: merge readiness is what the merge_readiness JUDGE is
# for, and that judge is training-only.
#
# Non-critical (partial credit only, and labelled optional in the prompts):
# openapi_updated, review_response, implementation_report, handoff_consumed,
# decisions_handoff.
CRITICAL_CHECKS = {
    "diagnose": frozenset(
        {
            "base_behavior_reproduced",
            "base_feature_flag_inert",
            "base_storage_api_absent",
            "base_topk_inefficient",
            "base_merge_failfast",
            "base_absence_observed",
            "diagnosis_handoff",
        }
    ),
    "core": frozenset(
        {
            "incremental_build",
            "storage_topk_equivalence",
            "storage_value_ordering_limit",
            "storage_partial_error_merge",
            "storage_lazy_construction",
            "storage_merge_dedup",
            # Stated as mandatory in the stage-2 prompt ("up-front allocation stays
            # bounded for tiny and astronomically large limits alike"), so it gates.
            "storage_unbounded_limit_alloc",
        }
    ),
    "review": frozenset(
        {
            "incremental_build",
            "filter_substring_decay",
            "filter_chain_and_semantics",
            "filter_fuzzy_threshold",
            "filter_subsequence_contract",
            "filter_substring_unicode",
            "http_search_success",
            "http_dos_validation",
            "http_feature_gate",
            "review_package_tests",
            "core_regression",
        }
    ),
    # Every Stage-4 check is critical: the instruction states all of them as
    # requirements, so all of them decide the outcome. Stage 04 is terminal and
    # ungated, so this costs no trial an early abort - it only makes the final
    # binary_reward tell the truth about whether the stage was finished.
    "harden": frozenset(HARDEN_WEIGHTS),
}


def go_env(extra: dict[str, str] | None = None) -> dict[str, str]:
    env = dict(os.environ)
    env.setdefault("GOWORK", "off")
    env.setdefault("GOTOOLCHAIN", "local")
    env.setdefault("GOFLAGS", "")
    if extra:
        env.update(extra)
    return env


def run(
    command: list[str],
    timeout: int = 1800,
    cwd: Path = TESTBED,
    env: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    try:
        return subprocess.run(
            command,
            cwd=cwd,
            text=True,
            capture_output=True,
            timeout=timeout,
            env=env or go_env(),
        )
    except subprocess.TimeoutExpired as exc:
        return subprocess.CompletedProcess(
            args=command,
            returncode=124,
            stdout=(exc.stdout or "") if isinstance(exc.stdout, str) else "",
            stderr=((exc.stderr or "") if isinstance(exc.stderr, str) else "")
            + f"\n[verifier] command timed out after {timeout}s\n",
        )


def record(
    checks: dict[str, dict[str, object]],
    name: str,
    completed: subprocess.CompletedProcess[str],
) -> None:
    checks[name] = {
        "passed": completed.returncode == 0,
        "detail": (completed.stderr + completed.stdout)[-12000:],
    }


def require_go_ran(
    completed: subprocess.CompletedProcess[str],
) -> subprocess.CompletedProcess[str]:
    """Treat "no tests ran / no test files" as a deterministic failure so a
    swallowed or deleted hidden test cannot masquerade as success."""
    output = completed.stderr + completed.stdout
    if completed.returncode == 0 and re.search(
        r"no test files|no tests to run|warning: no tests to run", output, re.I
    ):
        return subprocess.CompletedProcess(
            args=completed.args,
            returncode=2,
            stdout=completed.stdout,
            stderr=completed.stderr + "\n[verifier] hidden Go test did not run.\n",
        )
    return completed


# --------------------------------------------------------------------------
# Hidden Go test injection (ephemeral): copy protected test into the package
# dir, run it, then always remove it.
# --------------------------------------------------------------------------
def go_subtests(
    pkg: str,
    hidden_file: str,
    seed: str,
    timeout: int = 1200,
) -> tuple[dict[str, bool], str]:
    source = HIDDEN / hidden_file
    dest = TESTBED / pkg / "zz_lh_hidden_test.go"
    canary_dest = TESTBED / pkg / "zz_lh_canary_test.go"
    dest.parent.mkdir(parents=True, exist_ok=True)

    # QC anti_cheat_robustness: parsed `go test` output was trusted outright, so a
    # package-level TestMain that printed matching "--- PASS: TestHidden..." lines
    # and exited before m.Run() scored a clean sweep without running anything.
    #
    # The answer is a control the verifier already knows the answer to. Alongside
    # the real corpus we inject ONE test that must be reported FAILED. Genuine
    # execution always reports it failed; fabricated output that reports everything
    # as passing reports this as passing too, and that is self-refuting. A run that
    # never mentions it at all did not execute the corpus either.
    #
    # The nonce makes the canary's identity unpredictable within a run, so output
    # cannot be pre-baked against a fixed name.
    nonce = secrets.token_hex(8)
    package_clause = ""
    for line in source.read_text(encoding="utf-8", errors="replace").splitlines():
        if line.startswith("package "):
            package_clause = line.strip()
            break
    canary_name = f"TestHiddenVerifierCanary{nonce}"
    canary_src = (
        "// Injected by the verifier for one run and deleted immediately after.\n"
        f"{package_clause}\n\n"
        'import "testing"\n\n'
        f"func {canary_name}(t *testing.T) {{\n"
        f'\tt.Fatalf("verifier canary {nonce}: this test must be reported as FAILED")\n'
        "}\n"
    )

    try:
        shutil.copyfile(source, dest)
        if package_clause:
            canary_dest.write_text(canary_src, encoding="utf-8")
        completed = require_go_ran(
            run(
                ["go", "test", f"./{pkg}/", "-run", "TestHidden", "-count=1", "-v"],
                timeout=timeout,
                env=go_env({"LH_SEED": seed}),
            )
        )
    finally:
        for path in (dest, canary_dest):
            try:
                path.unlink()
            except FileNotFoundError:
                pass

    output = completed.stdout + completed.stderr
    results: dict[str, bool] = {}
    for match in re.finditer(r"^--- (PASS|FAIL): (TestHidden\w+)", output, re.M):
        results[match.group(2)] = match.group(1) == "PASS"

    canary_verdict = results.pop(canary_name, None)
    fabricated = False
    if package_clause:
        if canary_verdict is None:
            fabricated = True
            output += (
                f"\n[verifier] the injected canary {canary_name} never appeared in the "
                f"output: the corpus was not executed.\n"
            )
        elif canary_verdict is True:
            fabricated = True
            output += (
                f"\n[verifier] the injected canary {canary_name} is designed to fail and "
                f"was reported as PASSING: this output was fabricated, not produced by "
                f"running the tests.\n"
            )

    if fabricated:
        # Every graded result from this run is untrustworthy, so none of them may
        # count. Flipping them to False is what makes the canary a gate rather than
        # a note nobody reads.
        results = {name: False for name in results}
        results["__fabricated_output__"] = False

    build_ok = not re.search(
        r"build failed|undefined:|cannot find|does not|expected|no required module",
        output,
    ) or bool(results)
    if not build_ok:
        results.setdefault("__build__", False)
    return results, output[-12000:]


def subtest_check(
    checks: dict[str, dict[str, object]],
    name: str,
    results: dict[str, bool],
    test_name: str,
    output: str,
) -> None:
    checks[name] = {
        "passed": bool(results.get(test_name, False)),
        "detail": {"test": test_name, "ran": test_name in results, "log_tail": output[-4000:]},
    }


# --------------------------------------------------------------------------
# HTTP end-to-end contract (offline, empty TSDB): route registration, request
# validation, DoS caps, and feature gating. Keyed only on public URL paths and
# the --enable-feature / --web.search.max-limit flags.
# --------------------------------------------------------------------------
def free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def http_status(url: str, timeout: float = 8.0) -> int:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:  # noqa: S310
            return resp.status
    except urllib.error.HTTPError as exc:
        return exc.code
    except Exception:
        return 0


def build_prometheus() -> subprocess.CompletedProcess[str]:
    return run(
        ["go", "build", "-o", str(PROM_BIN), "./cmd/prometheus"],
        timeout=1800,
    )


def race_clean() -> tuple[bool, dict[str, object]]:
    """Run the feature packages under the race detector. Requires cgo + a C
    compiler (the shipped golang image provides gcc). If NO C compiler is
    present (host-side validation outside the container), skip rather than
    false-fail; but a detected DATA RACE always fails."""
    if not any(shutil.which(c) for c in ("gcc", "cc", "clang")):
        return True, {"skipped": "no C compiler; -race requires cgo (validated in-container)"}
    r = run(
        ["go", "test", "-race", "-count=1", "./storage/", "./web/api/v1/"],
        timeout=2400,
        env=go_env({"CGO_ENABLED": "1"}),
    )
    out = r.stderr + r.stdout
    if "DATA RACE" in out:
        return False, {"data_race": True, "detail": out[-6000:]}
    return r.returncode == 0, {"returncode": r.returncode, "detail": out[-6000:]}


def boot_prometheus(
    enable_search: bool, max_limit: int, self_scrape: bool = False, include_max_limit: bool = True
) -> tuple[subprocess.Popen | None, int, str, list[str]]:
    port = free_port()
    tsdb = tempfile.mkdtemp(prefix="lh-tsdb-")
    cfg = Path(tempfile.mkstemp(prefix="lh-prom-", suffix=".yml")[1])
    if self_scrape:
        # Self-scrape the server's own /metrics so the head fills with real
        # series (go_*, prometheus_*, up, ...) WITHOUT any external network.
        # This lets us exercise the enabled success path deterministically.
        cfg.write_text(
            "global:\n"
            "  scrape_interval: 1s\n"
            "  scrape_timeout: 1s\n"
            "scrape_configs:\n"
            "  - job_name: self\n"
            "    static_configs:\n"
            f"      - targets: ['127.0.0.1:{port}']\n",
            encoding="utf-8",
        )
    else:
        cfg.write_text("global: {}\n", encoding="utf-8")
    cleanup = [tsdb, str(cfg)]
    args = [
        str(PROM_BIN),
        f"--config.file={cfg}",
        f"--storage.tsdb.path={tsdb}",
        f"--web.listen-address=127.0.0.1:{port}",
    ]
    if enable_search:
        args += ["--enable-feature=search-api"]
        # The --web.search.max-limit flag is introduced BY the feature, so it is
        # absent at base. Omit it when we want a not-ready result to be
        # attributable solely to the unknown --enable-feature=search-api.
        if include_max_limit:
            args += [f"--web.search.max-limit={max_limit}"]
    proc = subprocess.Popen(
        args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, cwd=TESTBED, env=go_env()
    )
    ready = False
    for _ in range(60):
        if proc.poll() is not None:
            break
        if http_status(f"http://127.0.0.1:{port}/-/ready") in (200, 503):
            ready = True
            break
        time.sleep(0.5)
    return (proc if ready else None), port, ("ready" if ready else "not-ready"), cleanup


def boot_scraped_prometheus(
    max_limit: int, attempts: int = 3, series_timeout: float = 150.0
) -> tuple[subprocess.Popen | None, int, str, list[str]]:
    """Boot a self-scraping server and only return once real series have landed.

    Startup plus one scrape is normally a couple of seconds, but a loaded CI host
    can be much slower, so the wait is generous and a stalled attempt is retried
    from scratch rather than being reported as an agent failure. The caller still
    owns stop() for the returned process.
    """
    last = "not-ready"
    for attempt in range(1, attempts + 1):
        proc, port, state, cleanup = boot_prometheus(
            enable_search=True, max_limit=max_limit, self_scrape=True
        )
        if proc is not None and wait_for_head_series(port, timeout=series_timeout):
            return proc, port, "ok", cleanup
        last = state if proc is None else "no-series"
        stop(proc, cleanup)
        if attempt < attempts:
            time.sleep(2.0)
    return None, 0, last, []


def stop(proc: subprocess.Popen | None, cleanup: list[str]) -> None:
    if proc is not None:
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except Exception:
            proc.kill()
    for path in cleanup:
        shutil.rmtree(path, ignore_errors=True)
        try:
            Path(path).unlink()
        except (FileNotFoundError, IsADirectoryError, PermissionError):
            pass


def http_dos_validation() -> tuple[bool, dict[str, object]]:
    build = build_prometheus()
    if build.returncode != 0:
        return False, {"reason": "prometheus build failed", "detail": (build.stderr + build.stdout)[-4000:]}
    proc, port, state, cleanup = boot_prometheus(enable_search=True, max_limit=50)
    if proc is None:
        stop(proc, cleanup)
        return False, {"reason": f"server {state}"}
    try:
        base = f"http://127.0.0.1:{port}/api/v1/search"
        # >32 search[] terms must be rejected (bounded fan-out DoS control). The
        # ACCEPTED side of the same rules - exactly 32 terms, and sort_dir paired with
        # the ordering it is valid for - is graded in http_search_success, because
        # those requests reach the streaming success path and so need a head with
        # series in it rather than this bare validation-only boot.
        over_terms = "&".join(f"search%5B%5D=term{i}" for i in range(40))
        cases = {
            "bad_limit_400": (f"{base}/metric_names?limit=abc", 400),
            "over_max_limit_400": (f"{base}/metric_names?limit=99999", 400),
            "missing_label_400": (f"{base}/label_values", 400),
            "bad_fuzz_alg_400": (f"{base}/metric_names?fuzz_alg=bogus", 400),
            "over_term_cap_400": (f"{base}/metric_names?{over_terms}", 400),
            "sort_by_score_no_search_400": (f"{base}/metric_names?sort_by=score", 400),
            # sort_dir applies to alpha ordering only, so pairing it with
            # sort_by=score is invalid even when there IS something to score.
            "sort_dir_with_score_400": (
                f"{base}/metric_names?search%5B%5D=go&sort_by=score&sort_dir=asc",
                400,
            ),
        }
        observed = {name: http_status(url) for name, (url, _) in cases.items()}
        failed = {
            name: {"got": observed[name], "want": want}
            for name, (_, want) in cases.items()
            if observed[name] != want
        }
        return not failed, {"observed": observed, "failed": failed, "max_limit": 50}
    finally:
        stop(proc, cleanup)


def http_feature_gate() -> tuple[bool, dict[str, object]]:
    if not PROM_BIN.exists():
        build = build_prometheus()
        if build.returncode != 0:
            return False, {"reason": "prometheus build failed"}
    proc, port, state, cleanup = boot_prometheus(enable_search=False, max_limit=0)
    if proc is None:
        stop(proc, cleanup)
        return False, {"reason": f"server {state}"}
    try:
        # With the flag OFF the endpoint must NOT serve results: either the
        # route is not registered (404/405) or the handler reports the feature
        # unavailable (501/503). Any 2xx here means the gate leaks.
        code = http_status(f"http://127.0.0.1:{port}/api/v1/search/metric_names")
        ready = http_status(f"http://127.0.0.1:{port}/-/ready")
        # Not registered (404/405) or reported unavailable (500/501/503). The
        # enabled-path 400 DoS checks + hidden tests separately prove the
        # handler actually works, so a blanket-error impl cannot pass those.
        ok = 400 <= code < 600 and ready in (200, 503)
        return ok, {"metric_names_status_when_disabled": code, "ready": ready, "want": ">=400 while server healthy"}
    finally:
        stop(proc, cleanup)


def http_cap_disabled() -> tuple[bool, dict[str, object]]:
    """Independent stage-4 edge check: with --web.search.max-limit=0 the cap is
    DISABLED, so a very large client limit is NOT rejected (contrast with
    http_dos_validation, which uses a finite cap and rejects over-limit with
    400), and limit=0 is likewise accepted. Uses a self-scraped head so the
    streaming success path is exercised rather than an empty-head edge."""
    build = build_prometheus()
    if build.returncode != 0:
        return False, {"reason": "prometheus build failed", "detail": (build.stderr + build.stdout)[-2000:]}
    proc, port, state, cleanup = boot_scraped_prometheus(max_limit=0)
    if proc is None:
        return False, {"reason": f"server {state}"}
    try:
        base = f"http://127.0.0.1:{port}/api/v1/search"
        st_big, _, body_big = http_body(f"{base}/metric_names?limit=100000")
        _, tr_big = parse_ndjson(body_big)
        big_ok = st_big == 200 and isinstance(tr_big, dict) and tr_big.get("status") == "success"
        st_zero, _, _ = http_body(f"{base}/metric_names?limit=0")
        zero_ok = st_zero == 200
        return (big_ok and zero_ok), {
            "big_limit_status": st_big,
            "zero_limit_status": st_zero,
            "want": "200 (cap disabled: no over-limit rejection)",
        }
    finally:
        stop(proc, cleanup)


def openapi_search_documented() -> tuple[bool, dict[str, object]]:
    """Independent check that the OpenAPI surface was updated for the search
    endpoints. The package's own conformance test compares generated-vs-committed
    spec, but an agent could omit that test; here we confirm the COMMITTED spec
    (or the spec-builder source) references the search paths regardless."""
    hits: list[str] = []
    candidates = [
        "web/api/v1/testdata/openapi_3.1_golden.yaml",
        "web/api/v1/testdata/openapi_3.2_golden.yaml",
    ]
    for rel in candidates:
        path = TESTBED / rel
        if path.is_file() and "/search/metric_names" in path.read_text(encoding="utf-8", errors="replace"):
            hits.append(rel)
    if not hits:
        api_dir = TESTBED / "web/api/v1"
        if api_dir.is_dir():
            for p in api_dir.glob("openapi*.go"):
                if "/search/metric_names" in p.read_text(encoding="utf-8", errors="replace"):
                    hits.append(p.name)
    return bool(hits), {"openapi_refs": hits, "want": "committed OpenAPI references /search/metric_names"}


# NOTE: a `merge_ready_declared()` check used to live here and graded
# `decisions.merge_ready == true` from the agent's own handoff. It was deleted
# rather than promoted to critical: a self-declaration of success is not a
# behavior, and an agent that types `true` scores exactly like one that earned it.
# Merge readiness is assessed by the merge_readiness judge, which is training-only
# and cannot move binary_reward.


def http_body(
    url: str, method: str = "GET", data: dict[str, str] | None = None, timeout: float = 12.0
) -> tuple[int, str, str]:
    body_bytes = urllib.parse.urlencode(data).encode() if data is not None else None
    req = urllib.request.Request(url, method=method)  # noqa: S310
    if body_bytes is not None:
        req.add_header("Content-Type", "application/x-www-form-urlencoded")
    try:
        with urllib.request.urlopen(req, data=body_bytes, timeout=timeout) as resp:  # noqa: S310
            return resp.status, resp.headers.get("Content-Type", ""), resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as exc:
        ct = exc.headers.get("Content-Type", "") if exc.headers else ""
        try:
            payload = exc.read().decode("utf-8", "replace")
        except Exception:
            payload = ""
        return exc.code, ct, payload
    except Exception as exc:
        return 0, "", repr(exc)


def parse_ndjson(body: str) -> tuple[list[dict], dict | None]:
    """Split an NDJSON search response into (result records, trailer)."""
    records: list[dict] = []
    trailer: dict | None = None
    for line in body.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except Exception:
            continue
        if not isinstance(obj, dict):
            continue
        if "results" in obj:
            batch = obj.get("results")
            if isinstance(batch, list):
                records.extend(r for r in batch if isinstance(r, dict))
        elif "status" in obj:
            trailer = obj
    return records, trailer


def count_ndjson_batches(body: str) -> int:
    """Count NDJSON *batch* lines (objects carrying a 'results' array)."""
    n = 0
    for line in body.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except Exception:
            continue
        if isinstance(obj, dict) and isinstance(obj.get("results"), list):
            n += 1
    return n


def wait_for_head_series(port: int, timeout: float = 40.0) -> bool:
    """Poll the instant-query API until the self-scrape has landed series."""
    deadline = time.time() + timeout
    url = f"http://127.0.0.1:{port}/api/v1/query?query=up"
    while time.time() < deadline:
        status, _, body = http_body(url, timeout=6.0)
        if status == 200:
            try:
                data = json.loads(body).get("data", {})
                if data.get("result"):
                    return True
            except Exception:
                pass
        time.sleep(1.0)
    return False


def probe_client_disconnect(port: int) -> bool:
    """Open a streaming search, read only a few bytes, then abruptly close the
    socket mid-stream (client disconnect). The server must survive it and keep
    serving: a follow-up request must still return 200 and /-/ready stay
    healthy. A handler that panics on a broken pipe fails this."""
    try:
        sock = socket.create_connection(("127.0.0.1", port), timeout=6)
        req = (
            "GET /api/v1/search/label_values?label=__name__&limit=10000&batch_size=1 "
            "HTTP/1.1\r\nHost: 127.0.0.1\r\nConnection: close\r\n\r\n"
        )
        sock.sendall(req.encode())
        sock.recv(16)  # read a little of the stream ...
        sock.close()  # ... then abandon it mid-flight.
    except Exception:
        pass  # a failed/half-open connection is itself a disconnect.
    time.sleep(0.5)
    follow = http_status(f"http://127.0.0.1:{port}/api/v1/search/metric_names?limit=1")
    ready = http_status(f"http://127.0.0.1:{port}/-/ready")
    return follow == 200 and ready in (200, 503)


def http_search_success() -> tuple[bool, dict[str, object]]:
    """Enabled success path over a real (self-scraped) head: proves the
    endpoints actually SERVE search results with correct NDJSON framing,
    GET+POST, metadata/label results, has_more, and score ordering. Without
    this, a handler that always returns HTTP 400 could pass the DoS checks."""
    build = build_prometheus()  # always rebuild the CURRENT tree (no stale bin)
    if build.returncode != 0:
        return False, {"reason": "prometheus build failed", "detail": (build.stderr + build.stdout)[-2000:]}
    proc, port, state, cleanup = boot_scraped_prometheus(max_limit=10000)
    if proc is None:
        return False, {"reason": f"server {state}"}
    try:
        base = f"http://127.0.0.1:{port}/api/v1/search"
        results: dict[str, bool] = {}

        st, ct, body = http_body(f"{base}/metric_names?limit=5")
        recs, tr = parse_ndjson(body)
        results["metric_names_get"] = (
            st == 200 and ct.startswith("application/x-ndjson")
            and len(recs) >= 1 and all("name" in r for r in recs)
            and isinstance(tr, dict) and tr.get("status") == "success"
        )

        st2, _, body2 = http_body(f"{base}/metric_names", method="POST", data={"limit": "5"})
        recs2, tr2 = parse_ndjson(body2)
        results["metric_names_post"] = (
            st2 == 200 and len(recs2) >= 1
            and isinstance(tr2, dict) and tr2.get("status") == "success"
        )

        st3, _, body3 = http_body(f"{base}/label_names?limit=10")
        recs3, _ = parse_ndjson(body3)
        results["label_names_get"] = st3 == 200 and len(recs3) >= 1 and all("name" in r for r in recs3)

        st3p, _, body3p = http_body(f"{base}/label_names", method="POST", data={"limit": "10"})
        recs3p, tr3p = parse_ndjson(body3p)
        results["label_names_post"] = (
            st3p == 200 and len(recs3p) >= 1 and all("name" in r for r in recs3p)
            and isinstance(tr3p, dict) and tr3p.get("status") == "success"
        )

        st4, _, body4 = http_body(f"{base}/label_values?label=__name__&limit=5")
        recs4, _ = parse_ndjson(body4)
        results["label_values_get"] = st4 == 200 and len(recs4) >= 1 and all("value" in r for r in recs4)

        st4p, _, body4p = http_body(
            f"{base}/label_values", method="POST", data={"label": "__name__", "limit": "5"}
        )
        recs4p, tr4p = parse_ndjson(body4p)
        results["label_values_post"] = (
            st4p == 200 and len(recs4p) >= 1 and all("value" in r for r in recs4p)
            and isinstance(tr4p, dict) and tr4p.get("status") == "success"
        )

        st5, _, body5 = http_body(f"{base}/label_values?label=__name__&limit=1")
        recs5, tr5 = parse_ndjson(body5)
        results["has_more_true"] = (
            st5 == 200 and len(recs5) == 1 and isinstance(tr5, dict) and tr5.get("has_more") is True
        )

        # sort_by=score is inherently descending; pairing it with sort_dir is a
        # 400 per the contract, so we omit sort_dir and assert the scores come
        # back non-increasing with include_score set.
        st6, _, body6 = http_body(
            f"{base}/metric_names?search%5B%5D=go&sort_by=score"
            "&include_score=true&fuzz_alg=subsequence&limit=20"
        )
        recs6, _ = parse_ndjson(body6)
        scores = [r.get("score") for r in recs6 if "score" in r]
        ordered = (
            len(scores) == len(recs6) and len(scores) >= 1
            and all(isinstance(s, (int, float)) for s in scores)
            and all(scores[i] >= scores[i + 1] for i in range(len(scores) - 1))
        )
        results["score_ordering_desc"] = st6 == 200 and len(recs6) >= 1 and ordered

        # --- Independent black-box coverage of requirements that would else only
        # be exercised by the agent's OWN (omittable) package tests. -----------

        # OR composition: two search[] terms return the UNION (names matching
        # either term). go_* and prometheus_* both exist in the self-scrape.
        _, _, body_or = http_body(f"{base}/metric_names?search%5B%5D=go&search%5B%5D=prometheus&limit=500")
        recs_or, _ = parse_ndjson(body_or)
        names_or = [str(r.get("name", "")) for r in recs_or]
        results["or_union"] = (
            any(n.startswith("go") for n in names_or)
            and any(n.startswith("prometheus") for n in names_or)
        )

        # Case-insensitive matching: an UPPERCASE query matches lowercase metric
        # names only when case_sensitive=false; case_sensitive=true matches none.
        _, _, body_ci = http_body(f"{base}/metric_names?search%5B%5D=GO&case_sensitive=false&limit=500")
        recs_ci, _ = parse_ndjson(body_ci)
        _, _, body_cs = http_body(f"{base}/metric_names?search%5B%5D=GO&case_sensitive=true&limit=500")
        recs_cs, _ = parse_ndjson(body_cs)
        results["case_insensitive"] = len(recs_ci) >= 1 and len(recs_ci) > len(recs_cs)

        # Metadata fields: with include_metadata=true, metric_names results expose
        # type/help/unit for scraped series (gathered without per-result scrape
        # locking). Without the flag, results carry only the name.
        _, _, body_md = http_body(f"{base}/metric_names?limit=500&include_metadata=true")
        recs_md, tr_md = parse_ndjson(body_md)
        results["metadata_fields"] = any(
            r.get("type") or r.get("help") or r.get("unit") for r in recs_md
        )
        # Explicit NDJSON framing: a success trailer terminates the stream.
        results["ndjson_framing"] = isinstance(tr_md, dict) and tr_md.get("status") == "success"

        # batch_size BOUNDARIES (not just value 1): a small batch_size chunks the
        # stream into many batch lines; a batch_size >= result count collapses to
        # a single batch. Granularity must respond monotonically to batch_size.
        _, _, body_bs = http_body(f"{base}/label_values?label=__name__&limit=5&batch_size=1")
        recs_bs, _ = parse_ndjson(body_bs)
        n_small = count_ndjson_batches(body_bs)
        _, _, body_bl = http_body(f"{base}/label_values?label=__name__&limit=5&batch_size=1000")
        recs_bl, _ = parse_ndjson(body_bl)
        n_large = count_ndjson_batches(body_bl)
        results["batch_size_streams"] = len(recs_bs) >= 2 and n_small >= 2
        results["batch_size_boundaries"] = (
            len(recs_bs) >= 2 and len(recs_bl) >= 2
            and n_small >= 2 and n_large <= 2 and n_small > n_large
        )

        # Metadata concurrency safety: hammer include_metadata=true from many
        # goroutines/clients at once. Per-result scrape locking or an unsafe
        # metadata cache would deadlock, serialize to failure, or panic; the
        # server must answer every request with metadata and stay healthy. This
        # independently exercises the "gather metadata concurrency-safely"
        # requirement (complemented by the package-level -race run in stage 4).
        def _meta_probe(_: int) -> bool:
            st_m, _ct, body_m = http_body(
                f"{base}/metric_names?include_metadata=true&limit=200", timeout=20.0
            )
            recs_m, tr_m = parse_ndjson(body_m)
            return (
                st_m == 200
                and any(r.get("type") or r.get("help") or r.get("unit") for r in recs_m)
                and isinstance(tr_m, dict) and tr_m.get("status") == "success"
            )

        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            meta_oks = list(pool.map(_meta_probe, range(12)))
        ready_after = http_status(f"http://127.0.0.1:{port}/-/ready")
        results["metadata_concurrent_safe"] = all(meta_oks) and ready_after in (200, 503)

        # start/end time-range FILTERING semantics (deterministic, no wall-clock
        # race): a full window returns data; a far-future window returns an empty
        # (but successful) stream — proving the range actually filters series.
        now = int(time.time())
        st_all, _, body_all = http_body(
            f"{base}/label_values?label=__name__&start=1&end={now + 86400}&limit=50"
        )
        recs_all, _ = parse_ndjson(body_all)
        st_fut, _, body_fut = http_body(
            f"{base}/label_values?label=__name__&start={now + 100000}&end={now + 200000}&limit=50"
        )
        recs_fut, tr_fut = parse_ndjson(body_fut)
        results["start_end_filters"] = (
            st_all == 200 and len(recs_all) >= 1
            and st_fut == 200 and len(recs_fut) == 0
            and isinstance(tr_fut, dict) and tr_fut.get("status") == "success"
        )

        # NDJSON framing edge (instruction: "the first always emitted, so warnings
        # are observable"): even an EMPTY result must still put a batch line on the
        # wire before the trailer, not collapse to a bare trailer. The far-future
        # window is genuinely empty, so this is the deterministic, verifier-owned
        # probe for that first-batch-always-emitted contract - previously only the
        # empty record list + success trailer were checked, never that a batch line
        # was actually written. count_ndjson_batches counts objects carrying a
        # "results" array, so {"results":[]} counts and a trailer-only stream fails.
        results["empty_result_first_batch_emitted"] = (
            st_fut == 200
            and count_ndjson_batches(body_fut) >= 1
            and isinstance(tr_fut, dict) and tr_fut.get("status") == "success"
        )

        # The accepted side of the fan-out cap: 32 terms is inside it, so the request
        # must be served rather than refused. (Over the cap is rejected in
        # http_dos_validation; both halves of the stated rule are therefore graded.)
        at_cap_terms = "&".join(f"search%5B%5D=term{i}" for i in range(32))
        st_cap, _, body_cap = http_body(f"{base}/metric_names?{at_cap_terms}&limit=50")
        _, tr_cap = parse_ndjson(body_cap)
        results["at_term_cap_served"] = (
            st_cap == 200 and isinstance(tr_cap, dict) and tr_cap.get("status") == "success"
        )

        # sort_dir on the ordering it is valid for: asc and dsc must both be honoured
        # and must be exact reverses of one another over the same window. The rule is
        # stated in the instruction, so it is graded here rather than left to the
        # agent's own tests.
        _, _, body_asc = http_body(f"{base}/metric_names?sort_by=alpha&sort_dir=asc&limit=25")
        recs_asc, _ = parse_ndjson(body_asc)
        _, _, body_dsc = http_body(f"{base}/metric_names?sort_by=alpha&sort_dir=dsc&limit=25")
        recs_dsc, _ = parse_ndjson(body_dsc)
        names_asc = [str(r.get("name", "")) for r in recs_asc]
        names_dsc = [str(r.get("name", "")) for r in recs_dsc]
        results["alpha_sort_directions"] = (
            len(names_asc) >= 2
            and names_asc == sorted(names_asc)
            and len(names_dsc) >= 2
            and names_dsc == sorted(names_dsc, reverse=True)
        )

        # include_score is opt-in: the score field must be absent unless asked for.
        _, _, body_nos = http_body(f"{base}/metric_names?search%5B%5D=go&limit=20")
        recs_nos, _ = parse_ndjson(body_nos)
        results["score_absent_by_default"] = (
            len(recs_nos) >= 1 and all("score" not in r for r in recs_nos)
        )

        # The stated default limit is 100. Only assert it when the head genuinely has
        # more than 100 names, so a small scrape cannot turn this into a false failure.
        _, _, body_many = http_body(f"{base}/metric_names?limit=5000")
        recs_many, _ = parse_ndjson(body_many)
        if len(recs_many) > 100:
            _, _, body_def = http_body(f"{base}/metric_names")
            recs_def, tr_def = parse_ndjson(body_def)
            results["default_limit_is_100"] = (
                len(recs_def) == 100
                and isinstance(tr_def, dict)
                and tr_def.get("has_more") is True
            )
        else:
            results["default_limit_is_100"] = True

        # fuzz_threshold has to reach the matcher: a demanding threshold cannot return
        # more than a permissive one, and the permissive one must return something.
        _, _, body_low = http_body(
            f"{base}/metric_names?search%5B%5D=gooo&fuzz_alg=jarowinkler"
            "&fuzz_threshold=10&limit=500"
        )
        recs_low, _ = parse_ndjson(body_low)
        _, _, body_high = http_body(
            f"{base}/metric_names?search%5B%5D=gooo&fuzz_alg=jarowinkler"
            "&fuzz_threshold=99&limit=500"
        )
        recs_high, _ = parse_ndjson(body_high)
        results["fuzz_threshold_applied"] = (
            len(recs_low) >= 1 and len(recs_high) <= len(recs_low)
        )

        # Client-disconnect tolerance: abandon a stream mid-flight; the server
        # must survive and keep serving.
        results["disconnect_tolerated"] = probe_client_disconnect(port)

        failed = [name for name, ok in results.items() if not ok]
        return (not failed), {
            "results": results,
            "failed": failed,
            "sample_metric_names": body[:400],
            "sample_has_more": body5[:300],
        }
    finally:
        stop(proc, cleanup)


def base_search_surface_absent() -> tuple[bool, dict[str, object]]:
    """Executable diagnose evidence: build and boot the tree AS-IS and confirm
    the /api/v1/search/* HTTP surface is genuinely absent at runtime (404) while
    the server is healthy. This is behavioral proof, not a source scan; a tree
    that already serves the route (feature not actually absent, or production
    changed during diagnose) yields a non-404 and fails."""
    build = build_prometheus()
    if build.returncode != 0:
        return False, {"reason": "prometheus build failed", "detail": (build.stderr + build.stdout)[-2000:]}
    proc, port, state, cleanup = boot_prometheus(enable_search=False, max_limit=0)
    if proc is None:
        stop(proc, cleanup)
        return False, {"reason": f"server {state}"}
    try:
        code = http_status(f"http://127.0.0.1:{port}/api/v1/search/metric_names")
        ready = http_status(f"http://127.0.0.1:{port}/-/ready")
        ok = code == 404 and ready in (200, 503)
        return ok, {
            "search_route_status": code,
            "ready": ready,
            "want": "404 (route absent) while server healthy",
        }
    finally:
        stop(proc, cleanup)


def base_feature_flag_inert() -> tuple[bool, dict[str, object]]:
    """Executable diagnose evidence: even WITH --enable-feature=search-api the
    base tree must not serve the search surface. Either the base binary refuses
    the unknown feature (never becomes ready) or it ignores the flag and the
    route stays 404. A 2xx here would mean the feature is not actually absent."""
    if not PROM_BIN.exists():
        build = build_prometheus()
        if build.returncode != 0:
            return False, {"reason": "prometheus build failed", "detail": (build.stderr + build.stdout)[-2000:]}
    # Pass ONLY --enable-feature=search-api (not --web.search.max-limit, which is
    # itself introduced by the feature) so a not-ready outcome is attributable
    # solely to the unknown search-api feature, not a different absent flag.
    proc, port, state, cleanup = boot_prometheus(
        enable_search=True, max_limit=10000, include_max_limit=False
    )
    try:
        if proc is None:
            return True, {
                "note": "base did not become ready with only --enable-feature=search-api",
                "state": state,
                "want": "flag unknown/inert at base",
            }
        code = http_status(f"http://127.0.0.1:{port}/api/v1/search/metric_names")
        ready = http_status(f"http://127.0.0.1:{port}/-/ready")
        ok = code == 404 and ready in (200, 503)
        return ok, {
            "search_route_status_with_flag": code,
            "ready": ready,
            "want": "404 even with --enable-feature=search-api (flag inert at base)",
        }
    finally:
        stop(proc, cleanup)


def base_storage_api_absent() -> tuple[bool, dict[str, object]]:
    """Executable diagnose evidence for the storage-layer gap: the public
    top-K / partial-error search API the feature introduces must be UNDEFINED at
    base. `go doc` on each symbol must report it absent (non-zero / "not
    present"). This behaviorally reproduces the missing storage surface without
    a source scan."""
    symbols = ("MergeSearchResultSets", "NewSearchResultSetFromSliceAndError", "NewLazySearchResultSet")
    absent: dict[str, bool] = {}
    for sym in symbols:
        r = run(["go", "doc", "./storage", sym], timeout=300)
        out = (r.stdout + r.stderr).lower()
        absent[sym] = r.returncode != 0 or "not present" in out or "no symbol" in out
    ok = all(absent.values())
    return ok, {"symbol_absent": absent, "want": "storage top-K/partial-error public API undefined at base"}


# --------------------------------------------------------------------------
# Typed artifact contracts.
# --------------------------------------------------------------------------
def _meaningful(value: object) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, (list, dict, tuple, set)):
        return bool(value)
    return True


def json_contract(
    path: Path,
    required: tuple[str, ...],
    types: dict[str, type | tuple[type, ...]] | None = None,
    exact: bool = False,
) -> tuple[bool, dict[str, object]]:
    """Validate a JSON artifact against the schema DISCLOSED in instruction.md.

    Enforces presence (non-empty) AND the declared value type for every key in
    `types`. Extra keys are always ALLOWED: the disclosed schema is a floor, not
    a ceiling, so an agent that records additional useful context is never
    penalised for it. `exact` only controls whether those extra keys are listed
    in the reported detail (for reviewer visibility), never the outcome."""
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return False, {"failed_requirements": ["valid_json"], "detail": repr(exc)}
    if not isinstance(payload, dict):
        return False, {"failed_requirements": ["json_object"]}
    missing = [key for key in required if not _meaningful(payload.get(key))]
    type_mismatch: list[dict[str, str]] = []
    for key, expected in (types or {}).items():
        if key in payload and payload.get(key) is not None and not isinstance(payload[key], expected):
            names = expected.__name__ if isinstance(expected, type) else "/".join(t.__name__ for t in expected)
            type_mismatch.append({"key": key, "want": names, "got": type(payload[key]).__name__})
    extra = sorted(set(payload) - set(required)) if exact else []
    ok = not missing and not type_mismatch
    return ok, {
        "required": list(required),
        "missing": missing,
        "type_mismatch": type_mismatch,
        "extra_keys_allowed": extra,
    }


# The cross-stage handoff is authored in prose-derived JSON by the agent. To
# avoid failing a CORRECT diagnosis on key-naming or array-vs-object formatting
# (which the schema in 01-diagnose/instruction.md documents but which a model may
# reasonably vary), we resolve a small set of obvious synonyms to canonical keys
# and treat the descriptive collections as either a JSON array OR object. Content
# presence is still required; this only removes brittle naming/shape rejections.
HANDOFF_KEY_SYNONYMS = {
    "invariant": ("invariant", "core_invariant", "main_invariant"),
    "evidence": ("evidence", "evidences"),
    "boundaries": ("boundaries", "boundary", "scope", "constraints"),
    "risks": ("risks", "risk"),
    "next_stage_checks": (
        "next_stage_checks", "next_stage_check", "next_checks", "next_stage",
        "next_stage_verification",
    ),
    "decisions": ("decisions", "typed_decisions", "locked_decisions", "decision"),
}


def load_handoff() -> dict | None:
    try:
        payload = json.loads((OUTPUT / "handoff.json").read_text(encoding="utf-8"))
    except Exception:
        return None
    if not isinstance(payload, dict):
        return None
    norm = dict(payload)
    for canon, alts in HANDOFF_KEY_SYNONYMS.items():
        if not _meaningful(norm.get(canon)):
            for alt in alts:
                if alt != canon and _meaningful(payload.get(alt)):
                    norm[canon] = payload[alt]
                    break
    return norm


def handoff_contract(
    required: tuple[str, ...],
    string_keys: tuple[str, ...] = (),
    collection_keys: tuple[str, ...] = (),
) -> tuple[bool, dict[str, object]]:
    """Validate the cross-stage handoff tolerantly (synonyms + array-or-object)."""
    norm = load_handoff()
    if norm is None:
        return False, {"failed": ["valid_json_object"]}
    missing = [key for key in required if not _meaningful(norm.get(key))]
    type_mismatch: list[dict[str, str]] = []
    for key in string_keys:
        if key in norm and norm[key] is not None and not isinstance(norm[key], str):
            type_mismatch.append({"key": key, "want": "str", "got": type(norm[key]).__name__})
    for key in collection_keys:
        if key in norm and norm[key] is not None and not isinstance(norm[key], (list, dict)):
            type_mismatch.append({"key": key, "want": "list|object", "got": type(norm[key]).__name__})
    ok = not missing and not type_mismatch
    return ok, {
        "required": list(required),
        "missing": missing,
        "type_mismatch": type_mismatch,
        "resolved_keys": sorted(norm.keys()),
    }


def decisions_contract() -> tuple[bool, dict[str, object]]:
    """The three typed decisions stage 1 asks for, checked field by field.

    "decisions is a non-empty object" was not enough: the stage names
    `endpoint_set`, `response_framing` and `default_limits` and later stages are
    written against them, so each one is validated by the name and shape the
    instruction publishes. Nothing else about the object is constrained - extra
    keys are welcome, and the values themselves are the agent's design choice.
    """
    norm = load_handoff()
    if norm is None:
        return False, {"failed": ["valid_json_object"]}
    decisions = norm.get("decisions")
    if not isinstance(decisions, dict):
        return False, {
            "failed": ["decisions_object"],
            "want": "decisions is a JSON object carrying endpoint_set, response_framing, default_limits",
            "got": type(decisions).__name__,
        }
    problems: list[str] = []

    endpoints = decisions.get("endpoint_set")
    if not (
        isinstance(endpoints, list)
        and endpoints
        and all(isinstance(e, str) and e.strip() for e in endpoints)
    ):
        problems.append("endpoint_set must be a non-empty list of strings")

    framing = decisions.get("response_framing")
    if not (isinstance(framing, str) and framing.strip()):
        problems.append("response_framing must be a non-empty string")

    limits = decisions.get("default_limits")
    if not isinstance(limits, dict) or not limits:
        problems.append("default_limits must be a non-empty JSON object")
    elif not any(isinstance(v, (int, float)) and not isinstance(v, bool) for v in limits.values()):
        problems.append("default_limits must carry at least one numeric limit")

    return not problems, {
        "decisions": decisions,
        "problems": problems,
        "required": ["endpoint_set", "response_framing", "default_limits"],
    }


BASE_COMMIT_ANCHOR = Path(os.environ.get("BASE_COMMIT_ANCHOR", "/opt/verifier-base-commit.txt"))
BASE_TREE_ANCHOR = Path(os.environ.get("BASE_TREE_ANCHOR", "/opt/verifier-base-tree.txt"))


def _read_anchor(path: Path) -> str | None:
    try:
        value = path.read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        return None
    return value if re.fullmatch(r"[0-9a-f]{40}", value) else None


def base_anchor() -> str | None:
    """The sanitized base commit the IMAGE recorded, not whatever HEAD is now."""
    recorded = _read_anchor(BASE_COMMIT_ANCHOR)
    if recorded and run(["git", "cat-file", "-e", recorded], timeout=60).returncode == 0:
        return recorded
    if recorded:
        return None  # recorded but unreachable: the repository was replaced
    # Host-side validation has no anchor file; fall back to the root commit.
    proc = run(["git", "rev-list", "--max-parents=0", "HEAD"], timeout=120)
    if proc.returncode != 0:
        return None
    shas = [line.strip() for line in proc.stdout.splitlines() if line.strip()]
    return shas[-1] if shas else None


def changed_files() -> list[str]:
    """Every path that differs from the IMMUTABLE base, including committed work.

    QC found the previous implementation bypassable: it compared the working tree
    and index against the current HEAD, so an agent - which runs as root and may
    commit - could hide a forbidden Stage-1 production edit simply by committing
    it. Diffing against the recorded base commit instead means committing an edit
    makes it permanent and visible rather than invisible.

    Untracked and deleted paths are still collected, because a file that was never
    added, or was removed outright, does not show up in a commit-to-worktree diff
    on its own.
    """
    base = base_anchor()
    if base:
        # Working tree AND every commit the agent made, in one comparison.
        against_base = run(
            ["git", "diff", "--name-only", base], timeout=120
        ).stdout.splitlines()
    else:
        # No usable anchor: fall back to the old behaviour rather than silently
        # reporting "nothing changed". integrity() raises this separately as a
        # finding, so the run is not quietly graded on a weaker check.
        against_base = run(["git", "diff", "--name-only"], timeout=60).stdout.splitlines()
        against_base += run(["git", "diff", "--cached", "--name-only"], timeout=60).stdout.splitlines()
    untracked = run(
        ["git", "ls-files", "--others", "--exclude-standard"], timeout=60
    ).stdout.splitlines()
    deleted = run(["git", "ls-files", "--deleted"], timeout=60).stdout.splitlines()
    return sorted(set(filter(None, against_base + untracked + deleted)))


# --------------------------------------------------------------------------
# Integrity (repository leakage + trajectory command audit).
# --------------------------------------------------------------------------
_EXTERNAL_URL_RE = re.compile(r"https?://([^/\s'\"]+)", re.I)
_LOCAL_HOST_RE = re.compile(
    r"^(?:localhost|127(?:\.\d+){3}|0\.0\.0\.0|\[?::1\]?)(?::\d+)?$", re.I
)


def _references_external_host(command: str) -> bool:
    """True only if the command contains an http(s) URL whose host is NOT
    loopback. Local testing against 127.0.0.1/localhost is legitimate."""
    for match in _EXTERNAL_URL_RE.finditer(command):
        host = match.group(1).split("@")[-1]  # drop any user:pass@
        if not _LOCAL_HOST_RE.match(host):
            return True
    return False


# Network tools/APIs that constitute egress when pointed at a non-local host.
_NETWORK_TOOL_RE = re.compile(
    r"(^|\s)(?:curl|wget|aria2c|nc|ncat|scp|sftp|ssh|telnet|rsync|ftp)(\s|$)"
    r"|\brequests\.(?:get|post|request|Session)\b|\bhttpx\b|\baiohttp\b"
    r"|\burllib\.request\.urlopen\b|\bhttp\.client\b|\bnet/http\b"
    r"|\bInvoke-WebRequest\b|\bInvoke-RestMethod\b",
    re.I,
)


def command_integrity_violations(commands: list[str]) -> list[dict[str, str]]:
    """Outcome-based integrity: the sandbox is fully offline (allow_internet=
    false) and we grade the resulting repository, not the agent's process. We do
    NOT penalise legitimate local server testing (curl/urllib/sockets against
    127.0.0.1/localhost) nor local tool installation. We ONLY flag attempts to
    (a) read the reference solution / verifier assets, (b) leak repository
    history or query the hosted repo, or (c) reach a NON-local host."""
    leak_rules = {
        "reference/verifier path access": re.compile(
            r"(?<![A-Za-z0-9_.-])/(?:tests|solution)(?:/|\b)", re.I
        ),
        "repository history or remote leakage": re.compile(
            r"\bgit\s+(?:remote|reflog|fetch|pull|clone|ls-remote)\b", re.I
        ),
        "hosted-repo lookup": re.compile(r"\bgh\s+(?:api|repo|pr|issue|search)\b", re.I),
    }
    violations: list[dict[str, str]] = []
    for command in commands:
        for name, pattern in leak_rules.items():
            if pattern.search(command):
                violations.append({"rule": name, "command": command.strip()[:500]})
        if _references_external_host(command) and _NETWORK_TOOL_RE.search(command):
            violations.append(
                {"rule": "external network egress", "command": command.strip()[:500]}
            )
    return violations


def trusted_oracle() -> bool:
    return (
        Path("/logs/agent/oracle.txt").is_file()
        or os.environ.get("TRUSTED_ORACLE", "") == "1"
    )


def process_integrity() -> tuple[bool, dict[str, object]]:
    candidates = [
        Path(os.environ.get("TRAJECTORY_PATH", "")),
        Path("/logs/agent/trajectory.json"),
        Path("/logs/artifacts/trajectory.json"),
        Path("/logs/trajectory.json"),
        Path("/app/trajectory.json"),
    ]
    trajectory = next((p for p in candidates if str(p) and p.is_file()), None)
    if trajectory is None:
        if trusted_oracle():
            return True, {"trajectory": "not applicable for trusted Oracle", "commands_audited": 0, "violations": [], "oracle": True}
        return False, {"trajectory": "not available", "commands_audited": 0, "violations": [{"rule": "missing agent trajectory"}], "oracle": False}
    try:
        payload = json.loads(trajectory.read_text(encoding="utf-8", errors="replace"))
    except Exception as exc:
        return False, {"trajectory": str(trajectory), "error": repr(exc)}
    commands: list[str] = []
    for step in payload.get("steps", []):
        if not isinstance(step, dict) or step.get("source") != "agent":
            continue
        for call in step.get("tool_calls", []):
            if not isinstance(call, dict):
                continue
            arguments = call.get("arguments", {})
            if isinstance(arguments, dict):
                command = arguments.get("keystrokes") or arguments.get("command")
                if isinstance(command, str):
                    commands.append(command)
    violations = command_integrity_violations(commands)
    return not violations, {"trajectory": str(trajectory), "commands_audited": len(commands), "violations": violations}


CANARY_DIR = "lh_verifier_canary"
# Two tests the verifier writes itself: one that must be reported as passing and one
# that must be reported as failing. Their names are irrelevant to the task; what
# matters is that a truthful toolchain cannot report the same outcome for both.
CANARY_PASS = """package canary

import "testing"

func TestVerifierCanaryPasses(t *testing.T) {
\tif 2+2 != 4 {
\t\tt.Fatal("arithmetic")
\t}
}
"""
CANARY_FAIL = """package canary

import "testing"

func TestVerifierCanaryMustFail(t *testing.T) {
\tt.Fatal("this test exists to be reported as failing")
}
"""


def toolchain_reports_truthfully() -> tuple[bool, dict[str, object]]:
    """Make the toolchain prove it reports real outcomes, on work the agent never saw.

    The attack this closes is a `go` that answers "ok" for tests it did not run. It
    cannot be caught by comparing the binary against anything stored in the image,
    because an agent with root can change the image. So the verifier does not ask who
    `go` is; it asks `go` to run two tests it just wrote - one that must pass and one
    that must fail - and requires both verdicts to come back. A tool that fabricates
    success reports the failing one as passing and is caught; a tool that fabricates
    failure loses the passing one. The canary lives in a temporary directory inside
    the module and is removed again, so it never touches the graded tree.
    """
    root = TESTBED / CANARY_DIR
    shutil.rmtree(root, ignore_errors=True)
    detail: dict[str, object] = {}
    try:
        root.mkdir(parents=True, exist_ok=True)
        (root / "canary_pass_test.go").write_text(CANARY_PASS, encoding="utf-8")
        good = run(["go", "test", "-count=1", "-run", "TestVerifierCanaryPasses", f"./{CANARY_DIR}/"], timeout=900)
        (root / "canary_fail_test.go").write_text(CANARY_FAIL, encoding="utf-8")
        bad = run(["go", "test", "-count=1", "-run", "TestVerifierCanaryMustFail", f"./{CANARY_DIR}/"], timeout=900)
        good_out = good.stdout + good.stderr
        bad_out = bad.stdout + bad.stderr
        pass_reported = good.returncode == 0 and "FAIL" not in good_out
        fail_reported = bad.returncode != 0 and "FAIL" in bad_out
        detail = {
            "passing_canary_rc": good.returncode,
            "failing_canary_rc": bad.returncode,
            "passing_canary_reported_pass": pass_reported,
            "failing_canary_reported_fail": fail_reported,
            "tail": (good_out[-400:], bad_out[-400:]),
        }
        return (pass_reported and fail_reported), detail
    except OSError as exc:
        return False, {"error": repr(exc), **detail}
    finally:
        shutil.rmtree(root, ignore_errors=True)


def container_start_epoch() -> tuple[float | None, dict[str, object]]:
    """Wall-clock epoch at which this container's PID 1 started.

    Derived from two kernel-owned numbers: `btime` in /proc/stat (boot epoch) and
    field 22 of /proc/1/stat (PID 1 start, in clock ticks since boot). Neither is
    writable from userspace, so an agent cannot move this reference point.
    """
    detail: dict[str, object] = {}
    try:
        btime = None
        for line in Path("/proc/stat").read_text(encoding="utf-8").splitlines():
            if line.startswith("btime "):
                btime = float(line.split()[1])
                break
        if btime is None:
            return None, {"error": "no btime in /proc/stat"}
        raw = Path("/proc/1/stat").read_text(encoding="utf-8")
        # Field 2 (comm) may contain spaces inside parentheses; split after it so
        # the positional fields that follow are counted correctly.
        after_comm = raw[raw.rindex(")") + 1 :].split()
        # After comm, index 0 is field 3 (state), so field 22 is index 19.
        starttime_ticks = float(after_comm[19])
        hz = os.sysconf("SC_CLK_TCK") or 100
        started = btime + (starttime_ticks / hz)
        detail = {"btime": btime, "pid1_starttime_ticks": starttime_ticks, "clock_ticks_per_sec": hz}
        return started, detail
    except (OSError, ValueError, IndexError, AttributeError) as exc:
        return None, {"error": repr(exc), **detail}


# A tool whose inode changed at most this long after PID 1 started is treated as
# part of the image rather than as a runtime substitution. It only absorbs
# start-up ordering jitter; a real swap happens minutes into a trial.
CTIME_ANCHOR_SLACK_SEC = 5.0


def toolchain_ctime_anchor(tools: dict[str, dict[str, object]]) -> tuple[bool, dict[str, object]]:
    """Kernel trust root: no critical tool's inode may have changed after the
    container started.

    This is the control the previous revision lacked. The structural checks (root
    owned, ELF, under a trusted directory) and the behavioural canary can all be
    satisfied by a ROOT agent that writes its own root-owned ELF wrapper over
    /usr/local/go/bin/go - the reviewer said so explicitly, and they were right.
    What such an agent cannot do is backdate an inode: `st_ctime` is maintained by
    the kernel and there is no userspace call that sets it. Replacing, chmod-ing or
    rewriting the binary all move it forward, and the substitution becomes visible
    here.

    It is FAIL-CLOSED inside the container. An earlier package shipped the same
    idea but skipped when the anchor could not be computed, and a reviewer found it
    inert in every real run (`ctime_anchor_enforced: false`) - a control that
    silently disables itself is not a control. Outside the container (host-side
    self-tests, where there is no /proc/1 to speak of) it reports not-enforced and
    does not vote.
    """
    if not _IN_CONTAINER:
        return True, {"enforced": False, "reason": "not in container; anchor does not vote"}

    started, anchor_detail = container_start_epoch()
    if started is None:
        return False, {
            "enforced": False,
            "failed_closed": True,
            "reason": "container start time unavailable inside the container",
            "anchor": anchor_detail,
        }

    cutoff = started + CTIME_ANCHOR_SLACK_SEC
    violations = []
    observed = {}
    for tool, info in tools.items():
        path = str(info.get("path", ""))
        try:
            ctime = os.stat(path).st_ctime
        except OSError as exc:
            violations.append({"tool": tool, "path": path, "error": repr(exc)})
            continue
        observed[tool] = {"ctime": ctime, "seconds_after_container_start": ctime - started}
        if ctime > cutoff:
            violations.append(
                {
                    "tool": tool,
                    "path": path,
                    "ctime": ctime,
                    "container_start_epoch": started,
                    "reason": "inode changed after the container started - the binary was "
                    "replaced or modified at runtime",
                }
            )
    return (not violations), {
        "enforced": True,
        "container_start_epoch": started,
        "slack_sec": CTIME_ANCHOR_SLACK_SEC,
        "anchor": anchor_detail,
        "observed": observed,
        "violations": violations,
    }


def toolchain_trustworthy() -> tuple[bool, dict[str, object]]:
    """Decide whether the tools this verifier is about to run can be believed.

    Three independent controls, none of which relies on a file the agent could
    rewrite:

    1. This module is injected fresh at grade time from a mount the agent cannot
       reach, and it prepends the canonical toolchain directories to its OWN PATH
       (TRUSTED_PATH_DIRS), so a wrapper dropped somewhere else on PATH is never
       consulted.
    2. Every critical tool must resolve to a regular file under one of those
       directories, owned by root, not group- or other-writable, and be a real
       executable image rather than a script - a dropped-in shim is rejected on
       shape alone.
    3. The behavioural control, and the one that does not care who `go` is: the
       toolchain has to report a verifier-written passing test as passing and a
       verifier-written failing test as failing (toolchain_reports_truthfully).
       Fabricated output fails this no matter what the binary looks like.

    The digest of each resolved tool is published in the stage's reward.json, so a
    substitution between stages is visible from outside the container as well.
    """
    trusted_dirs = tuple(d for d in TRUSTED_PATH_DIRS if os.path.isdir(d))
    path_shadowing: list[dict[str, object]] = []
    digests: dict[str, dict[str, object]] = {}
    for tool in ("go", "git", "python3"):
        found = shutil.which(tool)
        if not found:
            continue
        real = os.path.realpath(found)
        under_trusted = any(
            real == os.path.realpath(os.path.join(d, os.path.basename(real)))
            or real.startswith(os.path.realpath(d) + os.sep)
            for d in trusted_dirs
        )
        try:
            st = os.stat(real)
            world_writable = bool(st.st_mode & 0o022)  # group- or other-writable
            root_owned = st.st_uid == 0
            with open(real, "rb") as handle:
                magic = handle.read(4)
            digests[tool] = {
                "path": real,
                "sha256": hashlib.sha256(Path(real).read_bytes()).hexdigest(),
                "uid": st.st_uid,
                "mode": oct(st.st_mode & 0o7777),
            }
        except OSError as exc:
            path_shadowing.append({"tool": tool, "resolved": found, "error": repr(exc)})
            continue
        # In-container, resolution MUST land under a trusted dir; on host-side
        # validation the pinned Go toolchain lives elsewhere ($HOME/go-sdk), so we
        # enforce only the invariants that hold in both places.
        if _IN_CONTAINER and trusted_dirs and not under_trusted:
            path_shadowing.append({"tool": tool, "resolved": found, "realpath": real, "reason": "outside trusted dirs"})
        elif world_writable:
            path_shadowing.append({"tool": tool, "resolved": found, "realpath": real, "reason": "group/other-writable"})
        elif _IN_CONTAINER and not root_owned:
            path_shadowing.append({"tool": tool, "resolved": found, "realpath": real, "reason": f"not root-owned (uid {st.st_uid})"})
        elif _IN_CONTAINER and magic != b"\x7fELF":
            # A wrapper is almost always a script; a real toolchain binary is an ELF
            # image. python3 is the one legitimate exception (it is a symlink chain to
            # an ELF, which realpath already followed).
            path_shadowing.append({"tool": tool, "resolved": found, "realpath": real, "reason": "not an ELF executable image"})

    truthful, truthful_detail = toolchain_reports_truthfully()
    anchored, anchor_detail = toolchain_ctime_anchor(digests)
    ok = not path_shadowing and truthful and anchored
    return ok, {
        "path_hardened": _IN_CONTAINER,
        "tools": digests,
        "path_shadowing": path_shadowing,
        "reports_truthfully": truthful,
        "canary": truthful_detail,
        # Published so a reviewer can confirm from the outside that the kernel
        # anchor actually ran, rather than having quietly skipped.
        "ctime_anchor_enforced": bool(anchor_detail.get("enforced")),
        "ctime_anchor": anchor_detail,
    }


def integrity() -> tuple[bool, dict[str, object]]:
    changed = changed_files()
    config_path = TESTBED / ".git/config"
    config = config_path.read_text(encoding="utf-8", errors="replace") if config_path.is_file() else ""
    forbidden = [item for item in changed if item.startswith((".git/", "solution/", "tests/"))]
    repository_ok = (
        not forbidden
        and '[remote "' not in config
        and not re.search(r"^\s*url\s*=", config, re.M)
        and not (TESTBED / "solution").exists()
        and not (TESTBED / "tests").exists()
    )
    # The base anchor has to resolve, or every "what changed" answer is guesswork.
    # In the container this FAILS CLOSED: a recorded commit that no longer exists
    # means the repository was replaced (re-clone, restored archive, fresh
    # `git init`), and a missing anchor means the control the image was supposed to
    # install is not running.
    anchor = base_anchor()
    recorded = _read_anchor(BASE_COMMIT_ANCHOR)
    anchor_notes: list[str] = []
    anchor_ok = True
    if _IN_CONTAINER:
        if recorded is None:
            anchor_ok = False
            anchor_notes.append("base-commit anchor missing inside the container")
        elif anchor is None:
            anchor_ok = False
            anchor_notes.append(
                f"repository replaced: the recorded base commit {recorded[:12]} is unreachable"
            )
    elif anchor is None:
        anchor_notes.append("no base anchor available (host-side validation)")

    process_ok, process_detail = process_integrity()
    toolchain_ok, toolchain_detail = toolchain_trustworthy()
    return repository_ok and process_ok and toolchain_ok and anchor_ok, {
        "changed_files": changed,
        "forbidden": forbidden,
        "repository_ok": repository_ok,
        # Published so a reviewer can confirm from outside the container that the
        # change set was computed against the immutable base rather than a HEAD the
        # agent controls.
        "base_anchor": {
            "recorded": recorded,
            "resolved": anchor,
            "enforced": _IN_CONTAINER,
            "ok": anchor_ok,
            "notes": anchor_notes,
            "comparison": "git diff --name-only <recorded base> (plus untracked and deleted)",
        },
        "process_ok": process_ok,
        "process": process_detail,
        "toolchain_ok": toolchain_ok,
        "toolchain": toolchain_detail,
    }


# --------------------------------------------------------------------------
# Stages.
# --------------------------------------------------------------------------
def diagnose(checks: dict[str, dict[str, object]]) -> dict[str, float]:
    # Independent verification: at the diagnose stage the production tree is
    # still at base, so the search feature must be genuinely absent.
    main_go = (TESTBED / "cmd/prometheus/main.go").read_text(encoding="utf-8", errors="replace")
    search_go = TESTBED / "web/api/v1/search.go"
    absence = {
        "no_search_go": not search_go.exists(),
        "no_search_feature_flag": '"search-api"' not in main_go,
        "no_max_limit_flag": "web.search.max-limit" not in main_go,
    }
    # "No production change" means no PRODUCTION (non-test) code was touched. A
    # reproducer *_test.go — which the instruction explicitly invites, and which
    # the Oracle itself uses — is behavior-neutral (it never ships in the binary),
    # so it must NOT count as a production change regardless of where it lives.
    # Premature implementation (a new search.go, edits to generic.go/api.go, a new
    # flag, doc changes, etc.) is still flagged.
    production_changes = [
        item
        for item in changed_files()
        if item.startswith(("storage/", "web/", "cmd/", "util/", "docs/"))
        and not item.endswith("_test.go")
    ]
    absence["no_production_changes"] = not production_changes
    checks["base_absence_observed"] = {
        "passed": all(absence.values()),
        "detail": {"absence": absence, "production_changes": production_changes},
    }

    # Executable runtime evidence (not just a source scan): the built server does
    # not serve the search surface at base, the feature flag is inert, and the
    # storage-layer public API the feature introduces is genuinely undefined.
    repro_ok, repro_detail = base_search_surface_absent()
    checks["base_behavior_reproduced"] = {"passed": repro_ok, "detail": repro_detail}
    flag_ok, flag_detail = base_feature_flag_inert()
    checks["base_feature_flag_inert"] = {"passed": flag_ok, "detail": flag_detail}
    api_ok, api_detail = base_storage_api_absent()
    checks["base_storage_api_absent"] = {"passed": api_ok, "detail": api_detail}

    # Executable behavioral gaps at base (injected, package-internal tests): the
    # score+limit path materialises the WHOLE matched set instead of a bounded
    # top-K, and the k-way merge is FAIL-FAST (drops already-buffered healthy
    # results on a mid-stream error). These reproduce, at runtime, the two gaps
    # the later stages must close.
    gap_results, gap_output = go_subtests(
        "storage", "stage01_base_gaps_hidden_test.go", STAGE_SEEDS["diagnose"]
    )
    subtest_check(
        checks, "base_topk_inefficient", gap_results,
        "TestHiddenBaseTopKMaterialisesFullSet", gap_output,
    )
    subtest_check(
        checks, "base_merge_failfast", gap_results,
        "TestHiddenBaseMergeIsFailFast", gap_output,
    )

    # A `reproducer_present` check used to sit here and passed on ANY non-empty
    # file under /app/output/01-diagnose. It graded the existence of paperwork, not
    # an outcome: the authoritative evidence for every gap is produced
    # independently above by the verifier itself (base_behavior_reproduced /
    # base_feature_flag_inert / base_storage_api_absent / base_topk_inefficient /
    # base_merge_failfast), all of which boot the real binary or run the real
    # storage primitives. A check that any file exists adds no signal and cannot
    # be failed by an agent that did the work, so it was removed and its weight
    # returned to the three runtime-evidence checks. The Stage-1 instruction no
    # longer asks for a stored reproducer artifact either.
    handoff_ok, handoff_detail = handoff_contract(
        ("invariant", "evidence", "boundaries", "risks", "next_stage_checks"),
        string_keys=("invariant",),
        collection_keys=("evidence", "boundaries", "risks", "next_stage_checks"),
    )
    checks["diagnosis_handoff"] = {"passed": handoff_ok, "detail": handoff_detail}
    decisions_ok, decisions_detail = decisions_contract()
    checks["decisions_handoff"] = {"passed": decisions_ok, "detail": decisions_detail}
    return dict(DIAGNOSE_WEIGHTS)


def core(checks: dict[str, dict[str, object]]) -> dict[str, float]:
    record(checks, "incremental_build", run(["go", "build", "./storage/..."], timeout=1800))
    results, output = go_subtests("storage", "stage02_storage_hidden_test.go", STAGE_SEEDS["core"])
    subtest_check(checks, "storage_topk_equivalence", results, "TestHiddenTopKEquivalence", output)
    subtest_check(checks, "storage_value_ordering_limit", results, "TestHiddenValueOrderingLimit", output)
    subtest_check(checks, "storage_partial_error_merge", results, "TestHiddenPartialErrorMergePreservesResults", output)
    subtest_check(checks, "storage_lazy_construction", results, "TestHiddenLazyConstructsOnUse", output)

    subtest_check(
        checks,
        "storage_unbounded_limit_alloc",
        results,
        "TestHiddenUnboundedLimitAllocatesByDataNotByLimit",
        output,
    )
    subtest_check(
        checks,
        "storage_merge_dedup",
        results,
        "TestHiddenMergeCollapsesDuplicatesKeepingHigherScore",
        output,
    )
    handoff_ok, handoff_detail = handoff_contract(
        ("invariant", "next_stage_checks"),
        string_keys=("invariant",),
        collection_keys=("next_stage_checks",),
    )
    checks["handoff_consumed"] = {"passed": handoff_ok, "detail": handoff_detail}
    report_ok, report_detail = json_contract(
        OUTPUT / "02-core/implementation.json",
        ("summary", "public_api", "tests_run"),
        types={"summary": str, "public_api": list, "tests_run": list},
        exact=True,
    )
    checks["implementation_report"] = {"passed": report_ok, "detail": report_detail}
    return dict(CORE_WEIGHTS)


def review(checks: dict[str, dict[str, object]]) -> dict[str, float]:
    record(
        checks,
        "incremental_build",
        run(["go", "build", "./cmd/prometheus", "./web/..."], timeout=2400),
    )
    results, output = go_subtests("web/api/v1", "stage03_filters_hidden_test.go", STAGE_SEEDS["review"])
    subtest_check(checks, "filter_substring_decay", results, "TestHiddenSubstringPrefixAndDecay", output)
    subtest_check(checks, "filter_chain_and_semantics", results, "TestHiddenChainAndSemantics", output)
    subtest_check(checks, "filter_fuzzy_threshold", results, "TestHiddenFuzzyThresholdInvariant", output)
    subtest_check(checks, "filter_subsequence_contract", results, "TestHiddenSubsequenceContract", output)
    # Independent Unicode scoring coverage (rune-position, not byte-offset).
    subtest_check(checks, "filter_substring_unicode", results, "TestHiddenSubstringUnicode", output)

    # Belt-and-suspenders: also run the package's own visible suite. This is NOT
    # relied on for the requirements below (an agent could omit its reference
    # tests); those are independently proven by the verifier-owned HTTP probes
    # and hidden Go tests.
    record(
        checks,
        "review_package_tests",
        run(["go", "test", "./web/api/v1/", "-count=1"], timeout=2400),
    )

    # http_search_success now also independently exercises OR union, case-
    # insensitive matching, metadata fields, NDJSON framing, batch_size
    # streaming, and start/end acceptance (verifier-owned black-box probes).
    success_ok, success_detail = http_search_success()
    checks["http_search_success"] = {"passed": success_ok, "detail": success_detail}
    dos_ok, dos_detail = http_dos_validation()
    checks["http_dos_validation"] = {"passed": dos_ok, "detail": dos_detail}
    gate_ok, gate_detail = http_feature_gate()
    checks["http_feature_gate"] = {"passed": gate_ok, "detail": gate_detail}
    # Independent OpenAPI coverage: the committed spec references the endpoints.
    openapi_ok, openapi_detail = openapi_search_documented()
    checks["openapi_updated"] = {"passed": openapi_ok, "detail": openapi_detail}

    # Cumulative: the stage-02 storage partial-error behavior must still hold.
    core_results, core_output = go_subtests("storage", "stage02_storage_hidden_test.go", STAGE_SEEDS["review"])
    subtest_check(checks, "core_regression", core_results, "TestHiddenPartialErrorMergePreservesResults", core_output)

    response_ok, response_detail = json_contract(
        OUTPUT / "03-review/review_response.json",
        ("feedback", "changes", "verification"),
        types={"feedback": str, "changes": list, "verification": list},
        exact=True,
    )
    checks["review_response"] = {"passed": response_ok, "detail": response_detail}
    return dict(REVIEW_WEIGHTS)


def harden(checks: dict[str, dict[str, object]]) -> dict[str, float]:
    record(checks, "incremental_build", run(["go", "build", "./..."], timeout=3000))
    # Scope vet to the feature package only: prometheus/storage carries
    # pre-existing vet heuristics (Seek signature) unrelated to this task.
    record(checks, "vet_clean", run(["go", "vet", "./web/api/v1/..."], timeout=2400))

    storage_results, storage_output = go_subtests("storage", "stage02_storage_hidden_test.go", STAGE_SEEDS["harden"])
    checks["storage_regression"] = {
        "passed": bool(storage_results) and all(
            storage_results.get(t, False)
            for t in (
                "TestHiddenTopKEquivalence",
                "TestHiddenValueOrderingLimit",
                "TestHiddenPartialErrorMergePreservesResults",
                "TestHiddenLazyConstructsOnUse",
                "TestHiddenUnboundedLimitAllocatesByDataNotByLimit",
                "TestHiddenMergeCollapsesDuplicatesKeepingHigherScore",
            )
        ),
        "detail": {"results": storage_results, "log_tail": storage_output[-4000:]},
    }
    filter_results, filter_output = go_subtests("web/api/v1", "stage03_filters_hidden_test.go", STAGE_SEEDS["harden"])
    checks["filter_regression"] = {
        "passed": bool(filter_results) and all(
            filter_results.get(t, False)
            for t in (
                "TestHiddenSubstringPrefixAndDecay",
                "TestHiddenChainAndSemantics",
                "TestHiddenFuzzyThresholdInvariant",
                "TestHiddenSubsequenceContract",
                "TestHiddenSubstringUnicode",
            )
        ),
        "detail": {"results": filter_results, "log_tail": filter_output[-4000:]},
    }

    success_ok, success_detail = http_search_success()
    checks["http_search_success"] = {"passed": success_ok, "detail": success_detail}
    dos_ok, dos_detail = http_dos_validation()
    checks["http_dos_validation"] = {"passed": dos_ok, "detail": dos_detail}
    gate_ok, gate_detail = http_feature_gate()
    checks["http_feature_gate"] = {"passed": gate_ok, "detail": gate_detail}

    # Performance guard: the score-desc top-K path must be materially cheaper in
    # allocated bytes than a full sort of the matched set (deterministic, keyed
    # only on the public storage API). A naive full-sort implementation fails.
    perf_results, perf_output = go_subtests("storage", "stage04_perf_hidden_test.go", STAGE_SEEDS["harden"])
    subtest_check(checks, "perf_topk_guard", perf_results, "TestHiddenTopKPerfMateriallyCheaper", perf_output)

    # Bounded concurrency exercise under the race detector across the two feature
    # packages (metadata cache readers, streaming). Requires cgo; the shipped
    # image provides gcc. Tolerant only when NO C compiler exists (host-side
    # validation outside the container) so it never yields a false failure there,
    # but a genuine DATA RACE always fails.
    race_ok, race_detail = race_clean()
    checks["race_clean"] = {"passed": race_ok, "detail": race_detail}

    # Independent edge coverage: --web.search.max-limit=0 disables the cap, so a
    # very large limit (and limit=0) is accepted rather than 400-rejected.
    cap_ok, cap_detail = http_cap_disabled()
    checks["cap_disabled_edge"] = {"passed": cap_ok, "detail": cap_detail}

    # Cumulative regression guard over the two packages the feature lives in. Scoped
    # to ./storage/ rather than ./storage/... on purpose: the latter pulls in
    # storage/remote, whose remote-write suite is wall-clock based upstream
    # (TestSendSamplesWithBackoffWithSampleAgeLimit) and fails on a loaded host
    # regardless of the search work - that would zero the terminal stage for
    # something the agent neither caused nor can fix. The whole tree still has to
    # compile (incremental_build runs `go build ./...`), and race_clean already
    # covers the same two packages under the race detector.
    record(
        checks,
        "package_tests",
        run(["go", "test", "./web/api/v1/...", "./storage/", "-count=1"], timeout=2400),
    )

    # Scan the WHOLE docs/ tree, not a fixed list of three files. The instruction
    # names the natural homes (HTTP API / feature flags / command line) as a
    # pointer, but it never says the prose must live in those exact files - and
    # since this check is critical, a file-placement assumption would be an
    # unstated requirement that could fail a correct implementation. What is
    # graded is that the user-facing documentation says these things SOMEWHERE
    # under docs/.
    docs_root = TESTBED / "docs"
    docs_files = sorted(p for p in docs_root.rglob("*.md") if p.is_file()) if docs_root.is_dir() else []
    docs_blob = "".join(p.read_text(encoding="utf-8", errors="replace") for p in docs_files)
    docs_lower = docs_blob.lower()
    docs_signals = {
        "feature_flag": "search-api" in docs_blob,
        "max_limit_flag": "web.search.max-limit" in docs_blob,
        "endpoint_path": ("/search/" in docs_blob or "search/metric_names" in docs_blob),
        # The user-facing docs must actually describe the behavior, not merely
        # name-drop the flag: the NDJSON streaming contract and all three
        # searchable dimensions have to appear.
        "ndjson_stream": ("x-ndjson" in docs_lower or "newline-delimited" in docs_lower),
        "batch_trailer_contract": ("batch" in docs_lower and "trailer" in docs_lower),
        "all_dimensions": all(
            token in docs_blob for token in ("metric_names", "label_names", "label_values")
        ),
    }
    checks["docs_updated"] = {
        "passed": all(docs_signals.values()),
        "detail": {
            "signals": docs_signals,
            "missing": [name for name, ok in docs_signals.items() if not ok],
            "docs_files_scanned": len(docs_files),
            "want": "every signal true; each token is listed verbatim in the stage-4 instruction",
        },
    }

    # Hygiene grades exactly what the instruction states: no build artifacts and no
    # stray generated files in the change set. `git diff --check` (whitespace-error
    # detection) is REPORTED for the reviewer but deliberately does NOT gate - the
    # instruction never asks for whitespace-clean diffs, and this check is critical,
    # so failing a correct patch on an unstated style rule would be exactly the kind
    # of false negative the fairness rule forbids.
    diff_check = run(["git", "diff", "--check"], timeout=120)
    changed = changed_files()
    generated = [
        item
        for item in changed
        if item.endswith((".o", ".a", ".so", ".exe", ".test"))
        or item.startswith(("bin/", "prometheus", "/tmp"))
    ]
    checks["patch_hygiene"] = {
        "passed": not generated,
        "detail": {
            "generated": generated,
            "changed_count": len(changed),
            "want": "no build artifacts or stray generated files in the change set",
            "whitespace_report_not_gated": (diff_check.stderr + diff_check.stdout)[-2000:],
        },
    }

    report_ok, report_detail = json_contract(
        OUTPUT / "04-harden/final_report.json",
        ("invariant", "changed_boundaries", "verification", "remaining_risk"),
        types={"invariant": str, "changed_boundaries": list, "verification": list, "remaining_risk": str},
        exact=True,
    )
    checks["final_report"] = {"passed": report_ok, "detail": report_detail}
    return dict(HARDEN_WEIGHTS)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", required=True, choices=["diagnose", "core", "review", "harden"])
    args = parser.parse_args()
    RESULT.mkdir(parents=True, exist_ok=True)
    # Scaffolding from an earlier stage's toolchain canary, if that run was killed
    # between writing it and its cleanup. A leftover package would fail `go build
    # ./...` and would otherwise look like the agent's doing.
    shutil.rmtree(TESTBED / CANARY_DIR, ignore_errors=True)
    checks: dict[str, dict[str, object]] = {}
    started = time.time()
    weights = {"diagnose": diagnose, "core": core, "review": review, "harden": harden}[args.stage](checks)

    integrity_ok, integrity_detail = integrity()
    checks["integrity"] = {"passed": integrity_ok, "detail": integrity_detail}

    d_num, d_den = deterministic_components(checks, weights, integrity_ok=integrity_ok)
    configured_lambda = parse_lambda(os.environ.get("NONDETERMINISTIC_LAMBDA", "0.0"))
    training_score = round(
        calculate_training_score(
            d_num=d_num,
            d_den=d_den,
            nondeterministic_lambda=configured_lambda,
            integrity_ok=integrity_ok,
            rewardkit_available=False,
        ),
        6,
    )
    critical_checks = CRITICAL_CHECKS[args.stage]
    # The pass/fail outcome is decided by the CRITICAL checks only, so the
    # critical/non-critical split is real rather than cosmetic: a stage is not
    # lost over a low-weight report/prose check. Non-critical checks still move
    # training_score (partial credit) and are reported per check, and
    # `stage_complete` below still records whether EVERY weighted check passed.
    critical_pass = all(bool(checks.get(name, {}).get("passed")) for name in critical_checks) and integrity_ok
    required_checks_pass = all(bool(checks.get(name, {}).get("passed")) for name in critical_checks)
    binary_reward = binary_outcome(required_checks_pass=required_checks_pass, integrity_ok=integrity_ok)
    every_check_passed = all(bool(checks.get(name, {}).get("passed")) for name in weights)
    strict = every_check_passed and integrity_ok
    oracle = trusted_oracle()

    reward = {
        "reward": binary_reward,
        "binary_reward": binary_reward,
        "training_score": training_score,
        "valid_trial": 1.0 if integrity_ok else 0.0,
        "stage_complete": 1.0 if strict else 0.0,
        "critical_pass": 1.0 if critical_pass else 0.0,
        "promotion_ready": binary_reward,
    }

    details = {
        "stage": args.stage,
        "duration_sec": round(time.time() - started, 3),
        "checks": checks,
        "weights": weights,
        "critical_checks": sorted(critical_checks),
        "critical_pass": critical_pass,
        "non_critical_checks": sorted(set(weights) - set(critical_checks)),
        "every_weighted_check_passed": every_check_passed,
        "outcome_rule": (
            "binary_reward = 1.0 iff every CRITICAL check passes and the integrity "
            "audit passes; non-critical checks affect training_score only"
        ),
        "changed_files": integrity_detail["changed_files"],
        "scoring": {
            "D_num": round(d_num, 6),
            "D_den": round(d_den, 6),
            "N_num": 0.0,
            "N_den": 0.0,
            "lambda": configured_lambda,
            "effective_lambda": 0.0,
            "training_score": training_score,
            "calculation": (
                "integrity hard gate failed => training_score = 0.000000"
                if not integrity_ok
                else formula_text(
                    d_num=d_num, d_den=d_den, n_num=0.0, n_den=0.0,
                    nondeterministic_lambda=configured_lambda, result=training_score,
                )
            ),
            "integrity_passed": integrity_ok,
            "integrity_hard_gate": True,
            "oracle": oracle,
            "rewardkit_available": False,
            "rewardkit_applied": False,
            "calculation_mode": ("integrity hard gate" if not integrity_ok else "deterministic-only fallback"),
            "deterministic_weights": weights,
            "required_checks_passed": required_checks_pass,
        },
    }
    (RESULT / "reward.json").write_text(json.dumps(reward, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (RESULT / "reward-details.json").write_text(json.dumps(details, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (RESULT / "reward.txt").write_text(f"{reward['reward']:.4f}\n", encoding="utf-8")
    events = [
        {
            "stage": args.stage,
            "check": name,
            "passed": bool(value.get("passed")),
            "weight": round(float(weights.get(name, 0.0)), 6),
            "deterministic": True,
            "critical": name in critical_checks,
        }
        for name, value in checks.items()
    ]
    (RESULT / "reward-events.json").write_text(json.dumps(events, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (RESULT / "training_export_manifest.json").write_text(
        json.dumps(
            {
                "schema": "repo-engineering-training-v2",
                "task_family": "prometheus-search-api-tier2",
                "stage": args.stage,
                "eligible_for_eval": integrity_ok,
                "eligible_for_training": False,
                "training_candidate": integrity_ok,
                "artifacts": ["patch.diff", "changed_files.txt", "reward-details.json", "reward-events.json", "test_output.log", "agent_output", "judge_inputs"],
                "failure_labels": [name for name, value in checks.items() if not value.get("passed")],
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "stage": args.stage,
                "reward": reward,
                "failed_checks": {
                    name: value.get("detail", "failed")
                    for name, value in checks.items()
                    if not value.get("passed")
                },
            },
            indent=2,
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
