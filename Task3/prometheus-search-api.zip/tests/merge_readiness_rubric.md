# Merge-readiness rubric (harden stage)

This rubric is supplied to the optional merge-readiness judge at the final
(harden) stage only, and only after the deterministic binary reward is already
`1.0`. It never changes the binary reward; it informs the continuous
`training_score` and offline review.

A change is **merge-ready** when a senior Prometheus maintainer would accept it
with routine review:

- **Scope & hygiene** — the diff is confined to the search feature
  (`storage/`, `web/api/v1/`, `cmd/prometheus/`, `web/`, `docs/`); no build
  artifacts, generated files, unrelated refactors, or debug scratch; `gofmt`
  clean and `go vet ./web/api/v1/...` clean.
- **API & docs coherence** — exported storage/API surface is coherent and
  documented; the `search-api` feature flag and `--web.search.max-limit` are
  wired through `cmd`/`web`; OpenAPI is regenerated in sync; user docs describe
  the endpoints, the flag, and the DoS cap.
- **Safety & edges** — DoS surfaces bounded (limit cap + `search[]`-term cap);
  rune-correct scoring for non-ASCII values; metadata gathering does not lock
  the scrape subsystem per result; the merge never drops healthy-side results
  on a partial error; `limit=0` (cap disabled) and `batch_size` bounds handled.
- **Reviewer burden** — clear structure, behavior-pinning tests, and a final
  report stating the invariant, changed boundaries, verification, and remaining
  risk.

Score each dimension on the evidence under `/logs/verifier/judge_inputs`; if
evidence is missing, fail the dimension and say what is absent.
