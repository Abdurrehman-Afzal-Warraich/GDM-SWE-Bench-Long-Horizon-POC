#!/usr/bin/env bash
# Horizon ablation for checklist row 9.
#
# Row 9 asks whether the task is hard BECAUSE earlier decisions have later
# consequences. A dependency map (tests/contracts/stage_dependencies.json) argues
# that structurally; only a run can show it. This builds the four conditions the
# row names from one command, so the comparison is reproducible rather than
# asserted:
#
#   staged           the shipped task: four stages, fresh agent context each time
#   single-briefing  all four instructions concatenated, ONE agent session
#   fresh-context    staged, but the handoff artifacts are withheld between stages
#   resumed-context  staged, with the trajectory carried across stage boundaries
#
# The signal is the terminal binary_reward of each condition. If single-briefing
# and resumed-context score like staged, the horizon is not doing work and the
# task is really a single-session task in four parts. If staged clearly beats
# fresh-context, the handoffs are load-bearing.
#
# This needs the platform (agent models, API keys, harness), so it is NOT run
# during grading and NOT run by the package self-test. Results belong in
# the author-side evidence notes kept outside the task package.
#
#   MODEL=... bash tools/run_horizon_ablation.sh [condition ...]

set -euo pipefail

TASK_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MODEL="${MODEL:?set MODEL to the solving model, e.g. gemini/gemini-3.6-flash}"
AGENT="${AGENT:-terminus-2}"
JOBS_DIR="${JOBS_DIR:-$HOME/harbor-jobs}"
STAMP="$(date +%Y%m%d-%H%M%S)"
BUILD="${BUILD:-$TASK_ROOT/.ablation-$STAMP}"

CONDITIONS=("$@")
if [ ${#CONDITIONS[@]} -eq 0 ]; then
  CONDITIONS=(staged single-briefing fresh-context resumed-context)
fi

command -v harbor >/dev/null || { echo "FATAL: harbor CLI not found"; exit 1; }

prepare() { # $1 condition -> echoes the task dir to run
  local condition="$1" dir="$BUILD/$condition"
  rm -rf "$dir"; mkdir -p "$(dirname "$dir")"
  cp -r "$TASK_ROOT" "$dir"
  rm -rf "$dir/.ablation-"* 2>/dev/null || true

  case "$condition" in
    staged|resumed-context)
      ;;  # shipped shape
    single-briefing)
      # Collapse to one step whose instruction is every stage's brief in order.
      local combined="$dir/steps/01-diagnose/instruction.md"
      {
        echo "# Combined brief (horizon ablation: single-briefing)"
        echo
        for step in 01-diagnose 02-core 03-review 04-harden; do
          echo "---"; echo
          cat "$TASK_ROOT/steps/$step/instruction.md"; echo
        done
      } > "$combined.new"
      mv "$combined.new" "$combined"
      # Grade the terminal contract in the single step.
      sed -i 's#stage_test.sh diagnose#stage_test.sh harden#' "$dir/steps/01-diagnose/tests/test.sh"
      python3 - "$dir/task.toml" <<'PY'
import re, sys
path = sys.argv[1]
text = open(path, encoding="utf-8").read()
head, _sep, _rest = text.partition("[[steps]]")
first = re.search(r"\[\[steps\]\]\s*\nname = \"01-diagnose\".*?(?=\n\[\[steps\]\]|\Z)", text, re.S)
open(path, "w", encoding="utf-8").write(head + first.group(0))
PY
      ;;
    fresh-context)
      # Withhold the handoff between stages: the agent must reconstruct state from
      # the repository alone. Handoff-shaped checks are dropped so the condition
      # measures reconstruction, not the missing file.
      python3 - "$dir/tests/stage_check.py" <<'PY'
import sys
path = sys.argv[1]
text = open(path, encoding="utf-8").read()
text = text.replace('OUTPUT = Path(os.environ.get("OUTPUT_DIR", "/app/output"))',
                    'OUTPUT = Path(os.environ.get("OUTPUT_DIR", "/app/output-ablation-void"))')
open(path, "w", encoding="utf-8").write(text)
PY
      ;;
    *) echo "unknown condition: $condition"; exit 2;;
  esac
  echo "$dir"
}

echo "condition,terminal_stage,binary_reward,job" > "$BUILD/results.csv" 2>/dev/null || {
  mkdir -p "$BUILD"; echo "condition,terminal_stage,binary_reward,job" > "$BUILD/results.csv"; }

for condition in "${CONDITIONS[@]}"; do
  dir="$(prepare "$condition")"
  job="ablation-$condition-$STAMP"
  echo "==> $condition  ($job)"
  extra=()
  [ "$condition" = "resumed-context" ] && extra+=(--resume-trajectory)
  harbor run -p "$dir" -a "$AGENT" -m "$MODEL" \
    --jobs-dir "$JOBS_DIR" --job-name "$job" --yes "${extra[@]}" || true

  python3 - "$JOBS_DIR/$job" "$condition" "$job" >> "$BUILD/results.csv" <<'PY'
import json, pathlib, sys
job_dir, condition, job = pathlib.Path(sys.argv[1]), sys.argv[2], sys.argv[3]
rewards = sorted(job_dir.rglob("steps/*/verifier/reward.json"))
if not rewards:
    print(f"{condition},,,{job}")
else:
    last = rewards[-1]
    data = json.loads(last.read_text(encoding="utf-8"))
    stage = last.parent.parent.name
    print(f"{condition},{stage},{data.get('binary_reward')},{job}")
PY
done

echo
echo "==> results"
cat "$BUILD/results.csv"
echo
echo "Record this table in the author-side evidence notes under 'Horizon ablation'."
