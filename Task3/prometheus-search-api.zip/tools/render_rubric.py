#!/usr/bin/env python3
"""Regenerate the README rubric tables from the grader's own weight maps.

The rubric is documentation that must never drift from the code it describes, so
it is GENERATED here rather than hand-maintained, and
`test_readme_rubric_tables_match_the_grader` fails the package if README and
grader disagree. Run after changing any *_WEIGHTS or CRITICAL_CHECKS entry:

    python3 tools/render_rubric.py           # rewrite README.md in place
    python3 tools/render_rubric.py --check    # exit 1 if README is stale

Only the text between the `<!-- rubric:<stage>:start ... -->` and
`<!-- rubric:<stage>:end -->` markers is touched.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

TASK_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(TASK_ROOT / "tests"))

from stage_check import (  # noqa: E402
    CORE_WEIGHTS,
    CRITICAL_CHECKS,
    DIAGNOSE_WEIGHTS,
    HARDEN_WEIGHTS,
    REVIEW_WEIGHTS,
)

STAGES = {
    "diagnose": (DIAGNOSE_WEIGHTS, "DIAGNOSE_WEIGHTS"),
    "core": (CORE_WEIGHTS, "CORE_WEIGHTS"),
    "review": (REVIEW_WEIGHTS, "REVIEW_WEIGHTS"),
    "harden": (HARDEN_WEIGHTS, "HARDEN_WEIGHTS"),
}

# One line per graded check, describing what must pass. Keys must exactly cover
# the union of the weight maps; render() fails loudly if a check has no entry, so
# adding a check without documenting it cannot silently ship.
DESCRIPTIONS = {
    "base_behavior_reproduced": "Live base binary: `/api/v1/search/metric_names` is 404 while the server is healthy.",
    "base_feature_flag_inert": "Live base binary: still 404 even with `--enable-feature=search-api` (the flag does not exist yet).",
    "base_storage_api_absent": "The declared storage top-K / partial-error constructors are undefined at the base.",
    "base_topk_inefficient": "Seeded hidden test: the base score-desc path materialises the whole candidate set.",
    "base_merge_failfast": "Seeded hidden test: the base merge abandons buffered results on a mid-stream error.",
    "base_absence_observed": "The feature is genuinely absent at the base and no production (non-test) file was modified. Reproducer `*_test.go` files are explicitly allowed.",
    "diagnosis_handoff": "`handoff.json` carries invariant, evidence, boundaries, risks and next-stage checks (synonym- and shape-tolerant).",
    "decisions_handoff": "Typed decisions (endpoints, framing, default limit) are recorded for later stages.",
    "incremental_build": "The stage's packages compile (`go build`).",
    "storage_topk_equivalence": "Seeded: score-ranked limited output equals the full `(Score desc, Value asc)` sort truncated to the limit.",
    "storage_value_ordering_limit": "Ascending/descending value orderings with a limit return the correct first-K.",
    "storage_partial_error_merge": "A mid-stream error preserves the healthy side's buffered results and still exposes the error.",
    "storage_lazy_construction": "A lazy result set constructs on first use.",
    "storage_merge_dedup": "Verifier-owned probe: a value present in two merged sets is emitted exactly once, keeping the HIGHER score, under both value and score ordering.",
    "storage_unbounded_limit_alloc": "Verifier-owned probe: `Limit=math.MaxInt` returns every value in order and allocates no more than twice what an exact limit allocates, so up-front allocation is sized by the data rather than by the caller's limit.",
    "handoff_consumed": "The persistent diagnosis handoff is still valid and was carried forward.",
    "implementation_report": "`implementation.json` records the summary, public API and tests run.",
    "filter_substring_decay": "Seeded: prefix -> 1.0, non-match rejected, earlier positions score strictly higher.",
    "filter_chain_and_semantics": "AND: reject if any rejects; score is the max sub-score; empty chain accepts all.",
    "filter_fuzzy_threshold": "Seeded: accept iff score >= threshold, scores in [0,1], identical -> 1.0.",
    "filter_subsequence_contract": "Prefix -> 1.0; accept iff score > 0 and score >= threshold.",
    "filter_substring_unicode": "Multi-byte values decay by rune position, not byte offset.",
    "http_search_success": "Live binary over a self-scraped head: GET+POST on all three endpoints stream real NDJSON batches plus a success trailer, with `has_more`, score ordering, metadata, `start`/`end` filtering and a batch line emitted even for an empty result.",
    "http_dos_validation": "Live binary: bad/over-cap `limit`, missing `label`, unknown `fuzz_alg`, over-32 `search[]` terms and `sort_by=score` without `search[]` all return HTTP 400.",
    "http_feature_gate": "With the flag off the endpoints serve no results while the server stays healthy.",
    "openapi_updated": "The committed OpenAPI surface describes the search endpoints.",
    "review_package_tests": "The agent's own `go test` for the touched packages passes.",
    "core_regression": "The stage-2 storage behavior still holds.",
    "review_response": "`review_response.json` records feedback, changes and verification.",
    "vet_clean": "`go vet` is clean on the touched packages.",
    "storage_regression": "Every stage-2 storage behavior still passes.",
    "filter_regression": "Every stage-3 filter behavior still passes.",
    "perf_topk_guard": "Seeded allocation guard: the top-K path allocates at most half the bytes/op of the equivalent full sort (steady-state measurement).",
    "race_clean": "A bounded `-race` exercise of the concurrent metadata path reports no data race.",
    "cap_disabled_edge": "With `--web.search.max-limit=0` the cap is disabled: a huge `limit` and `limit=0` are both served.",
    "package_tests": "`go test ./web/api/v1/... ./storage/` passes (the whole tree still has to compile).",
    "docs_updated": "User docs anywhere under `/testbed/docs` name the feature flag and cap flag, show the endpoint path, cover all three dimensions and describe the NDJSON batch/trailer stream. Every token is listed in the stage-4 prompt.",
    "patch_hygiene": "The change set carries no build artifacts and no stray generated files. Whitespace is reported but does not gate.",
    "final_report": "`final_report.json` records invariant, changed boundaries, verification and remaining risk.",
}


def render_block(stage: str) -> str:
    weights, var = STAGES[stage]
    critical = CRITICAL_CHECKS[stage]
    missing = sorted(set(weights) - set(DESCRIPTIONS))
    if missing:
        raise SystemExit(f"{stage}: no rubric description for {missing}")
    rows = sorted(weights.items(), key=lambda kv: (-kv[1], kv[0]))
    lines = [
        f"<!-- rubric:{stage}:start (generated from {var} by tools/render_rubric.py - do not hand-edit) -->",
        "| Deterministic check | Weight | Critical | What must pass |",
        "|---|---:|:-:|---|",
    ]
    for name, weight in rows:
        flag = "yes" if name in critical else "-"
        lines.append(f"| `{name}` | {weight:.2f} | {flag} | {DESCRIPTIONS[name]} |")
    lines.append(f"| **total** | **{sum(weights.values()):.2f}** | | |")
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true", help="exit 1 if README is stale")
    args = parser.parse_args()

    readme_path = TASK_ROOT / "README.md"
    original = readme_path.read_text(encoding="utf-8")
    updated = original
    for stage in STAGES:
        start = updated.index(f"<!-- rubric:{stage}:start")
        end = updated.index(f"<!-- rubric:{stage}:end -->")
        updated = updated[:start] + render_block(stage) + updated[end:]

    if updated == original:
        print("README rubric tables are up to date.")
        return 0
    if args.check:
        print("README rubric tables are STALE - run: python3 tools/render_rubric.py")
        return 1
    readme_path.write_text(updated, encoding="utf-8")
    print("README rubric tables regenerated.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
