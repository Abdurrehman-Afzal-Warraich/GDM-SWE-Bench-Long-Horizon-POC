#!/usr/bin/env python3
"""Generate tests/contracts/stage_dependencies.json from the grader itself.

Checklist row 9 asks for a stage-dependency map, at least one later evidence item
that invalidates a plausible shortcut, and a horizon ablation. This produces the
first two from the code that actually does the grading, so the map cannot claim a
dependency the verifier does not create. The ablation is a run, not a document -
see tools/run_horizon_ablation.sh.

    python3 tools/render_stage_dependencies.py            # write the contract
    python3 tools/render_stage_dependencies.py --check    # fail if stale
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

TASK_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(TASK_ROOT / "tests"))

from stage_check import (  # noqa: E402
    CORE_WEIGHTS,
    CRITICAL_CHECKS,
    DIAGNOSE_WEIGHTS,
    HARDEN_WEIGHTS,
    REVIEW_WEIGHTS,
)

CONTRACT = TASK_ROOT / "tests/contracts/stage_dependencies.json"

ORDER = [
    ("01-diagnose", "diagnose", DIAGNOSE_WEIGHTS),
    ("02-core", "core", CORE_WEIGHTS),
    ("03-review", "review", REVIEW_WEIGHTS),
    ("04-harden", "harden", HARDEN_WEIGHTS),
]

# Checks whose whole purpose is to re-run an EARLIER stage's behavior. Each maps
# to the stage whose work it re-verifies.
REGRESSION_OF = {
    "core_regression": "02-core",
    "storage_regression": "02-core",
    "filter_regression": "03-review",
    "package_tests": "03-review",
}

# Plausible shortcuts, each paired with the check that rejects it. `crosses_stage_
# boundary` is computed below and is the honest part: only a shortcut that survives
# one stage and dies in a LATER one demonstrates a horizon. The two that are caught
# inside their own stage are listed because they are real discriminators, but they
# are not counted as horizon evidence.
SHORTCUTS = [
    {
        "shortcut": "Implement the score+limit path as a full sort truncated to the limit.",
        "survives_until": "02-core",
        "why_it_survives": "storage_topk_equivalence only compares OUTPUT, and a full sort produces the same ordering.",
        "rejected_by": "perf_topk_guard",
        "rejected_at": "04-harden",
        "how": "The stage-4 allocation guard requires the top-K path to allocate at most half the bytes/op of the full sort, which a full sort cannot do against itself.",
    },
    {
        "shortcut": "Make the merge fail fast on the first source error (keep the base behavior).",
        "survives_until": "01-diagnose",
        "why_it_survives": "Fail-fast IS the base behavior, so nothing before stage 2 objects to it.",
        "rejected_by": "storage_partial_error_merge",
        "rejected_at": "02-core",
        "how": "The partial-error merge check requires the healthy source's already-buffered results to survive and the error to surface at the end.",
    },
    {
        "shortcut": "Validate requests but return HTTP 400 for everything, so the DoS rules pass trivially.",
        "survives_until": "03-review (DoS half)",
        "why_it_survives": "Every rejection case in http_dos_validation expects a 400, so a handler that always 400s satisfies all of them.",
        "rejected_by": "http_search_success",
        "rejected_at": "03-review",
        "how": "The success path boots a real self-scraped server and requires streamed NDJSON batches, a success trailer, has_more, score ordering and metadata - none of which a blanket 400 can produce.",
    },
    {
        "shortcut": "Score substrings by byte offset instead of rune position.",
        "survives_until": "03-review (ASCII cases)",
        "why_it_survives": "For ASCII input byte offset and rune position are identical, so the main decay check passes.",
        "rejected_by": "filter_substring_unicode",
        "rejected_at": "03-review",
        "how": "Multi-byte values make the two diverge, and the unicode check requires decay by rune position.",
    },
    {
        "shortcut": "Ship the feature but skip the user documentation.",
        "survives_until": "03-review",
        "why_it_survives": "Nothing before the terminal stage looks at docs/, and every behavioral gate is already green.",
        "rejected_by": "docs_updated",
        "rejected_at": "04-harden",
        "how": "docs_updated is critical in this revision: the terminal stage fails unless the documentation states the flags, the endpoint path, all three dimensions and the NDJSON batch/trailer contract.",
    },
]


STEP_INDEX = {"01-diagnose": 0, "02-core": 1, "03-review": 2, "04-harden": 3}


def annotate_shortcuts() -> list[dict]:
    out = []
    for entry in SHORTCUTS:
        survives = entry["survives_until"].split(" ")[0]
        crosses = STEP_INDEX[entry["rejected_at"]] > STEP_INDEX[survives]
        out.append({**entry, "crosses_stage_boundary": crosses})
    return out


def build() -> dict:
    stages = []
    seen: set[str] = set()
    for step, key, weights in ORDER:
        critical = CRITICAL_CHECKS[key]
        new = sorted(set(weights) - seen)
        seen |= set(weights)
        stages.append(
            {
                "step": step,
                "stage": key,
                "checks_total": len(weights),
                "checks_introduced_here": new,
                "critical_checks": sorted(critical),
                "non_critical_checks": sorted(set(weights) - set(critical)),
                "re_verifies_earlier_stages": sorted(
                    {REGRESSION_OF[c] for c in weights if c in REGRESSION_OF}
                ),
            }
        )
    return {
        "description": (
            "Generated from stage_check.py by tools/render_stage_dependencies.py. "
            "Shows what each stage adds, what it re-verifies from earlier stages, and "
            "which plausible shortcuts are only rejected by a strictly later stage."
        ),
        "reward_strategy": "final - the terminal stage's reward is the trial's reward",
        "stages": stages,
        "shortcuts_rejected_later": annotate_shortcuts(),
        "shortcuts_crossing_a_stage_boundary": sum(
            1 for s in annotate_shortcuts() if s["crosses_stage_boundary"]
        ),
        "horizon_ablation": {
            "status": "NOT RUN - requires four agent campaigns on the platform",
            "runner": "tools/run_horizon_ablation.sh",
            "conditions": ["staged", "single-briefing", "fresh-context", "resumed-context"],
            "note": (
                "Row 9 asks for the four conditions to be COMPARED. That is agent-run "
                "evidence, not something the package can assert about itself, so it is "
                "declared missing here rather than described as if it had happened."
            ),
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    built = build()
    CONTRACT.parent.mkdir(parents=True, exist_ok=True)
    current = json.loads(CONTRACT.read_text(encoding="utf-8")) if CONTRACT.is_file() else None
    if current == built:
        print("stage_dependencies.json is up to date.")
        return 0
    if args.check:
        print("stage_dependencies.json is STALE - run tools/render_stage_dependencies.py")
        return 1
    CONTRACT.write_text(json.dumps(built, indent=1) + "\n", encoding="utf-8")
    print(f"wrote {CONTRACT.relative_to(TASK_ROOT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
