#!/usr/bin/env python3
"""Re-derive the merge-head equivalence claim from scratch, against the upstream repo.

The claim under test, stated in `task.toml:solution_provenance` and recorded in
`steps/04-harden/solution/merge_head_equivalence_proof.json`:

    applying the stage golden patches in order onto the base commit reproduces
    every non-test production file byte-for-byte as it exists at the upstream
    merge commit.

Previous revisions asserted this in prose, and a reviewer correctly marked it
PARTIAL: nothing shipped could re-execute it. This does. It needs network and a
`git` binary, which the task image deliberately does NOT have, so it is a
release-time control run by the author or a reviewer - never part of grading.

    python3 tools/verify_merge_head_equivalence.py                 # clone + verify
    python3 tools/verify_merge_head_equivalence.py --repo-dir DIR  # reuse a clone
    python3 tools/verify_merge_head_equivalence.py --write-proof   # refresh the JSON

Exit status is 0 only when every production file matches. The offline half - that
the shipped proof is internally consistent with the shipped patches and their
recorded sha256 - is asserted by tests/test_reward_contract.py on every run.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path

TASK_ROOT = Path(__file__).resolve().parent.parent
PROOF_PATH = TASK_ROOT / "steps/04-harden/solution/merge_head_equivalence_proof.json"
REPO_URL = "https://github.com/prometheus/prometheus.git"
STAGE_ORDER = ("02-core", "03-review", "04-harden")


def git(*args: str, cwd: Path, check: bool = True) -> str:
    proc = subprocess.run(
        ["git", *args], cwd=cwd, capture_output=True, text=True, check=False
    )
    if check and proc.returncode != 0:
        raise SystemExit(f"git {' '.join(args)} failed:\n{proc.stdout}\n{proc.stderr}")
    return proc.stdout


def patch_files(patch: Path) -> list[str]:
    """Paths touched by a unified diff, in first-appearance order."""
    seen: list[str] = []
    for line in patch.read_text(encoding="utf-8", errors="replace").splitlines():
        match = re.match(r"^\+\+\+ b/(.+)$", line)
        if match and match.group(1) not in seen:
            seen.append(match.group(1))
    return seen


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-dir", type=Path, default=None)
    parser.add_argument("--write-proof", action="store_true")
    args = parser.parse_args()

    proof = json.loads(PROOF_PATH.read_text(encoding="utf-8"))
    base, merge = proof["base_commit"], proof["merge_commit"]

    tmp = None
    if args.repo_dir is None:
        tmp = tempfile.TemporaryDirectory(prefix="lh-mergehead-")
        repo = Path(tmp.name)
        print(f"cloning {REPO_URL} (blobless) into {repo} ...")
        git("init", "-q", ".", cwd=repo)
        git("remote", "add", "origin", REPO_URL, cwd=repo)
        git("fetch", "-q", "--filter=blob:none", "--depth", "1", "origin", base, merge, cwd=repo)
    else:
        repo = args.repo_dir.resolve()

    for commit in (base, merge):
        if git("cat-file", "-t", commit, cwd=repo).strip() != "commit":
            raise SystemExit(f"{commit} is not available in {repo}")

    print(f"checking out base {base[:12]} ...")
    git("checkout", "-q", "--force", "--detach", base, cwd=repo)
    git("clean", "-qfdx", cwd=repo)

    applied: list[dict] = []
    touched: list[str] = []
    for stage in STAGE_ORDER:
        patch = TASK_ROOT / "steps" / stage / "solution/golden.patch"
        digest = hashlib.sha256(patch.read_bytes()).hexdigest()
        recorded = next(p for p in proof["stage_patches"] if p["stage"] == stage)
        if digest != recorded["sha256"]:
            raise SystemExit(
                f"{stage}: shipped patch sha256 {digest} != recorded {recorded['sha256']}"
            )
        print(f"applying {stage} ({digest[:12]}) ...")
        git("apply", "--index", "--whitespace=nowarn", str(patch), cwd=repo)
        files = patch_files(patch)
        applied.append({"stage": stage, "sha256": digest, "files": files})
        touched.extend(f for f in files if f not in touched)

    production = [f for f in touched if not f.endswith("_test.go")]
    withheld = sorted(f for f in touched if f.endswith("_test.go"))

    results = []
    mismatches = []
    for rel in sorted(production):
        applied_blob = git("hash-object", rel, cwd=repo).strip()
        merge_blob = git("rev-parse", f"{merge}:{rel}", cwd=repo, check=False).strip()
        identical = bool(merge_blob) and applied_blob == merge_blob
        results.append(
            {
                "file": rel,
                "applied_blob": applied_blob,
                "merge_blob": merge_blob or None,
                "identical": identical,
            }
        )
        if not identical:
            mismatches.append(rel)

    # The other direction: the merge commit must not touch a production file the
    # stage slices leave behind, or the decomposition would be incomplete.
    changed_at_merge = [
        line
        for line in git(
            "diff", "--name-only", f"{base}..{merge}", cwd=repo
        ).splitlines()
        if line.strip()
    ]
    missed = sorted(
        f for f in changed_at_merge if not f.endswith("_test.go") and f not in production
    )

    print()
    print(f"production files compared : {len(results)}")
    print(f"byte-identical            : {len(results) - len(mismatches)}")
    print(f"mismatches                : {mismatches or 'none'}")
    print(f"production files at merge not covered by any slice: {missed or 'none'}")

    proof.update(
        {
            "claim": (
                "applying 02-core + 03-review + 04-harden onto base reproduces every "
                "non-test production file byte-for-byte at the merge commit"
            ),
            "stage_patches": applied,
            "production_file_count": len(results),
            "test_files_withheld": withheld,
            "byte_identical": not mismatches and not missed,
            "mismatches": mismatches,
            "uncovered_production_files_at_merge": missed,
            "files": results,
            "verified_by": "tools/verify_merge_head_equivalence.py",
            "verification_method": (
                "blobless clone of the upstream repository; checkout of the base commit; "
                "the three shipped golden patches applied in order with `git apply --index`; "
                "`git hash-object` of each production file compared against "
                "`git rev-parse <merge>:<path>`; plus a reverse sweep of "
                "`git diff --name-only base..merge` to prove no production file the merge "
                "touches is left uncovered by the slices"
            ),
        }
    )

    if args.write_proof:
        PROOF_PATH.write_text(json.dumps(proof, indent=1) + "\n", encoding="utf-8")
        print(f"\nwrote {PROOF_PATH.relative_to(TASK_ROOT)}")

    if tmp is not None:
        tmp.cleanup()
    return 0 if (not mismatches and not missed) else 1


if __name__ == "__main__":
    sys.exit(main())
