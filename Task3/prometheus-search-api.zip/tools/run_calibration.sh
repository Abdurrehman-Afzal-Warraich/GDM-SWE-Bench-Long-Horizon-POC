#!/usr/bin/env bash
# Regenerate steps/04-harden/solution/calibration_summary.json by actually running
# the controls, rather than describing them.
#
# Review rows 34 and 36 were marked PARTIAL because the calibration campaign was
# author-side: the package asserted that the Oracle repeats, that a no-op fails at
# functional gates, that a near-miss fails a later stage, and that deleting the
# agent-visible tests changes nothing - but shipped nothing a reviewer could
# re-execute. This is that script.
#
# It needs Docker and roughly 20-40 minutes: a full Go build plus the race
# detector runs several times over. It is a RELEASE control, never part of
# grading, and it is deliberately not run automatically.
#
#   bash tools/run_calibration.sh              # all controls
#   bash tools/run_calibration.sh oracle nop   # a subset
#
# Controls:
#   oracle         solve every stage in order; expect binary_reward 1.0 at each
#   oracle-repeat  re-grade the terminal stage without re-solving; expect 1.0
#   nop            grade the untouched sanitized base; expect 0.0 at a NAMED
#                  functional gate, never an infrastructure error
#   near-miss      solve stage 2 only, then grade stage 3; expect 0.0
#   tamper         solve everything, delete every agent-visible *_test.go in the
#                  graded packages, re-grade; expect 1.0 (the graded corpus is
#                  injected ephemerally, so deleting visible tests gains nothing)
#
# Each control records the stage, its binary_reward and its failed critical checks
# straight out of the grader's own reward.json - never a hand-written summary.

set -euo pipefail

TASK_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
IMAGE="${IMAGE:-lh-prometheus-search-api:calibration}"
OUT="$TASK_ROOT/steps/04-harden/solution/calibration_summary.json"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

CONTROLS=("$@")
if [ ${#CONTROLS[@]} -eq 0 ]; then
  CONTROLS=(oracle oracle-repeat nop near-miss tamper)
fi

command -v docker >/dev/null || { echo "FATAL: docker is required"; exit 1; }

echo "==> building $IMAGE (this is the slow part)"
docker build -t "$IMAGE" -f "$TASK_ROOT/environment/Dockerfile" "$TASK_ROOT/environment"

# Run one stage's grader inside a container and echo its reward.json.
# $1 container name, $2 stage name
grade() {
  docker exec "$1" bash -lc \
    "RESULT_DIR=/logs/verifier bash /tests/stage_test.sh $2 >/dev/null 2>&1; cat /logs/verifier/reward.json"
}

solve() { # $1 container, $2 step dir name
  docker exec "$1" bash -lc \
    "cp -r /task/steps/$2/solution/. /solution/ 2>/dev/null || true; bash /solution/solve.sh"
}

start_container() { # $1 name
  docker rm -f "$1" >/dev/null 2>&1 || true
  docker run -d --name "$1" \
    -v "$TASK_ROOT/tests:/tests:ro" \
    -v "$TASK_ROOT:/task:ro" \
    "$IMAGE" sleep infinity >/dev/null
  docker exec "$1" bash -lc 'mkdir -p /solution /app/output /logs/verifier'
}

echo "[" > "$WORK/controls.jsonl"

run_control() {
  local name="$1"
  local container="lh-cal-$name"
  echo "==> control: $name"
  start_container "$container"
  case "$name" in
    oracle|oracle-repeat|tamper)
      for step in 01-diagnose 02-core 03-review 04-harden; do
        solve "$container" "$step"
      done
      ;;
    near-miss)
      solve "$container" 01-diagnose
      solve "$container" 02-core
      ;;
    nop) : ;;  # untouched base
  esac

  if [ "$name" = "tamper" ]; then
    docker exec "$container" bash -lc \
      'cd /testbed && find web/api/v1 -maxdepth 1 -name "*_test.go" -delete && find storage -maxdepth 1 -name "*_test.go" -delete && git add -A && git -c user.email=a@b -c user.name=a commit -qm tamper'
  fi

  local stages
  case "$name" in
    oracle|nop)      stages="diagnose core review harden" ;;
    near-miss)       stages="review" ;;
    *)               stages="harden" ;;
  esac

  python3 - "$container" "$name" "$stages" >> "$WORK/controls.jsonl" <<'PY'
import json, subprocess, sys
container, name, stages = sys.argv[1], sys.argv[2], sys.argv[3].split()
rows = []
for stage in stages:
    raw = subprocess.run(
        ["docker", "exec", container, "bash", "-lc",
         f"RESULT_DIR=/logs/verifier bash /tests/stage_test.sh {stage} >/dev/null 2>&1; "
         f"cat /logs/verifier/reward.json"],
        capture_output=True, text=True, check=True).stdout
    reward = json.loads(raw)
    details = json.loads(subprocess.run(
        ["docker", "exec", container, "bash", "-lc", "cat /logs/verifier/reward-details.json"],
        capture_output=True, text=True, check=True).stdout)
    failed = sorted(
        c for c in details.get("critical_checks", [])
        if not details.get("checks", {}).get(c, {}).get("passed", False)
    )
    rows.append({"stage": stage, "binary_reward": reward["binary_reward"], "failed_critical": failed})
print(json.dumps({"scenario": name, "stages": rows}) + ",")
PY
  docker rm -f "$container" >/dev/null 2>&1 || true
}

for control in "${CONTROLS[@]}"; do
  run_control "$control"
done

python3 - "$WORK/controls.jsonl" "$OUT" <<'PY'
import json, sys
raw = open(sys.argv[1], encoding="utf-8").read().strip().lstrip("[").rstrip(",")
controls = [json.loads(line.rstrip(",")) for line in raw.splitlines() if line.strip().startswith("{")]
out = json.load(open(sys.argv[2], encoding="utf-8"))
by_name = {c["scenario"]: c for c in out["controls"]}
for got in controls:
    prior = by_name.get(got["scenario"], {})
    got["run"] = prior.get("run", "")
    got["expectation"] = prior.get("expectation", "")
    if "deleted_visible_tests" in prior:
        got["deleted_visible_tests"] = prior["deleted_visible_tests"]
    by_name[got["scenario"]] = got
out["controls"] = list(by_name.values())
out["status"] = "current"
out["applies_to_grader_revision"] = "current"
out.pop("why_superseded", None)
out.pop("known_stale_fields", None)
json.dump(out, open(sys.argv[2], "w", encoding="utf-8"), indent=1)
print(f"wrote {sys.argv[2]}")
PY

echo "==> done. Re-run tests/test_reward_contract.py to re-check the record."
