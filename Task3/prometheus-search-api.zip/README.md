# Tier 2: Prometheus experimental Search API engineering task

## What this task is

A four-stage, full-repository **Go** task built on the Prometheus server. Each
stage gets a fresh agent call, but the Prometheus worktree, its warm build
cache, and explicit typed handoff files persist. The task asks an agent to build
an experimental **Search API** — fuzzy/substring/subsequence matching with
relevance scoring, a storage-layer top-K and partial-error merge engine, and
feature-gated NDJSON-streaming HTTP endpoints for searching metric names, label
names, and label values, with denial-of-service caps.

It is based on [prometheus/prometheus PR #18573, "web/api: add search API
endpoint"](https://github.com/prometheus/prometheus/pull/18573). The source
repository starts at the exact pre-change commit
`ee7fea7f144c9398891b083d0a3bf010074f1bb3` (merge `e1f4380b2ae6…`). The public
change touched 24 files (+6,225 / −54) across storage, the v1 API, the web/CLI
wiring, OpenAPI, and docs.

The solving agent is **not** shown the PR number, title, solution patches, or
upstream tests.

## Why it is genuinely long horizon

The base commit already contains the low-level storage search primitives
(`storage.Searcher`, `SearchResultSet`, `ApplySearchHints`, the merge machinery)
and the `util/strutil` fuzzy matchers. This task builds the *user-facing feature*
on top, and one behavioral contract must survive several layers:

```text
score-ranked top-K (Score desc, Value asc) + partial-error merge that never
drops the healthy side  ->  substring/fuzzy/subsequence/chain matching  ->
feature-gated NDJSON endpoints with DoS caps
```

A capable engineer needs sustained diagnosis, a storage-engine implementation,
an HTTP/streaming integration with review feedback, and adversarial hardening —
not a single edit.

```mermaid
flowchart LR
    A["Stage 1: diagnose (no prod changes)"] -->|strict 1.00| B["Stage 2: storage top-K + partial-error merge"]
    B -->|binary reward 1| C["Stage 3: filters + NDJSON endpoints + DoS + gating"]
    C -->|binary reward 1| D["Stage 4: harden + docs + cumulative closure"]
    D --> E{"Every final deterministic check passes?"}
    E -- Yes --> F["Binary reward 1"]
    E -- No --> G["Binary reward 0 plus partial training vector"]
```

## Stage 1: diagnose

The agent must not change production code. It produces an executable reproducer
proving the base has no `/api/v1/search/*` surface, no `search-api` feature
toggle, no storage top-K path, and a fail-fast merge; plus a typed handoff.

<!-- rubric:diagnose:start (generated from DIAGNOSE_WEIGHTS by tools/render_rubric.py - do not hand-edit) -->
| Deterministic check | Weight | Critical | What must pass |
|---|---:|:-:|---|
| `base_behavior_reproduced` | 0.18 | yes | Live base binary: `/api/v1/search/metric_names` is 404 while the server is healthy. |
| `diagnosis_handoff` | 0.15 | yes | `handoff.json` carries invariant, evidence, boundaries, risks and next-stage checks (synonym- and shape-tolerant). |
| `base_feature_flag_inert` | 0.13 | yes | Live base binary: still 404 even with `--enable-feature=search-api` (the flag does not exist yet). |
| `base_merge_failfast` | 0.13 | yes | Seeded hidden test: the base merge abandons buffered results on a mid-stream error. |
| `base_storage_api_absent` | 0.12 | yes | The declared storage top-K / partial-error constructors are undefined at the base. |
| `base_topk_inefficient` | 0.12 | yes | Seeded hidden test: the base score-desc path materialises the whole candidate set. |
| `base_absence_observed` | 0.10 | yes | The feature is genuinely absent at the base and no production (non-test) file was modified. Reproducer `*_test.go` files are explicitly allowed. |
| `decisions_handoff` | 0.07 | - | Typed decisions (endpoints, framing, default limit) are recorded for later stages. |
| **total** | **1.00** | | |
<!-- rubric:diagnose:end -->

Not gated: promotion out of stage 1 is unconditional, so a reporting miss in the
first hour cannot end the trial.

## Stage 2: storage search engine (core)

Self-contained and independently testable (`go test ./storage/`). Implements the
score-ranked bounded top-K path, value-ordering early exit, and a partial-error
merge that preserves the healthy side and surfaces `errors.Join` via `Err()`.

<!-- rubric:core:start (generated from CORE_WEIGHTS by tools/render_rubric.py - do not hand-edit) -->
| Deterministic check | Weight | Critical | What must pass |
|---|---:|:-:|---|
| `storage_partial_error_merge` | 0.23 | yes | A mid-stream error preserves the healthy side's buffered results and still exposes the error. |
| `storage_topk_equivalence` | 0.20 | yes | Seeded: score-ranked limited output equals the full `(Score desc, Value asc)` sort truncated to the limit. |
| `handoff_consumed` | 0.10 | - | The persistent diagnosis handoff is still valid and was carried forward. |
| `implementation_report` | 0.10 | - | `implementation.json` records the summary, public API and tests run. |
| `incremental_build` | 0.10 | yes | The stage's packages compile (`go build`). |
| `storage_value_ordering_limit` | 0.10 | yes | Ascending/descending value orderings with a limit return the correct first-K. |
| `storage_merge_dedup` | 0.06 | yes | Verifier-owned probe: a value present in two merged sets is emitted exactly once, keeping the HIGHER score, under both value and score ordering. |
| `storage_unbounded_limit_alloc` | 0.06 | yes | Verifier-owned probe: `Limit=math.MaxInt` returns every value in order and allocates no more than twice what an exact limit allocates, so up-front allocation is sized by the data rather than by the caller's limit. |
| `storage_lazy_construction` | 0.05 | yes | A lazy result set constructs on first use. |
| **total** | **1.00** | | |
<!-- rubric:core:end -->

## Stage 3: filters + HTTP endpoints (review / integration)

Review feedback adds the matching engine and the user-facing API: substring
(prefix=1.0, position decay), Jaro-Winkler fuzzy, subsequence, AND-chain; the six
NDJSON endpoints behind the `search-api` flag; DoS caps; and OpenAPI.

<!-- rubric:review:start (generated from REVIEW_WEIGHTS by tools/render_rubric.py - do not hand-edit) -->
| Deterministic check | Weight | Critical | What must pass |
|---|---:|:-:|---|
| `http_search_success` | 0.20 | yes | Live binary over a self-scraped head: GET+POST on all three endpoints stream real NDJSON batches plus a success trailer, with `has_more`, score ordering, metadata, `start`/`end` filtering and a batch line emitted even for an empty result. |
| `filter_fuzzy_threshold` | 0.10 | yes | Seeded: accept iff score >= threshold, scores in [0,1], identical -> 1.0. |
| `filter_subsequence_contract` | 0.10 | yes | Prefix -> 1.0; accept iff score > 0 and score >= threshold. |
| `filter_substring_decay` | 0.10 | yes | Seeded: prefix -> 1.0, non-match rejected, earlier positions score strictly higher. |
| `http_dos_validation` | 0.08 | yes | Live binary: bad/over-cap `limit`, missing `label`, unknown `fuzz_alg`, over-32 `search[]` terms and `sort_by=score` without `search[]` all return HTTP 400. |
| `core_regression` | 0.07 | yes | The stage-2 storage behavior still holds. |
| `filter_chain_and_semantics` | 0.07 | yes | AND: reject if any rejects; score is the max sub-score; empty chain accepts all. |
| `filter_substring_unicode` | 0.06 | yes | Multi-byte values decay by rune position, not byte offset. |
| `incremental_build` | 0.05 | yes | The stage's packages compile (`go build`). |
| `openapi_updated` | 0.05 | - | The committed OpenAPI surface describes the search endpoints. |
| `review_package_tests` | 0.05 | yes | The agent's own `go test` for the touched packages passes. |
| `http_feature_gate` | 0.04 | yes | With the flag off the endpoints serve no results while the server stays healthy. |
| `review_response` | 0.03 | - | `review_response.json` records feedback, changes and verification. |
| **total** | **1.00** | | |
<!-- rubric:review:end -->

## Stage 4: harden / close

<!-- rubric:harden:start (generated from HARDEN_WEIGHTS by tools/render_rubric.py - do not hand-edit) -->
| Deterministic check | Weight | Critical | What must pass |
|---|---:|:-:|---|
| `http_search_success` | 0.16 | yes | Live binary over a self-scraped head: GET+POST on all three endpoints stream real NDJSON batches plus a success trailer, with `has_more`, score ordering, metadata, `start`/`end` filtering and a batch line emitted even for an empty result. |
| `package_tests` | 0.11 | yes | `go test ./web/api/v1/... ./storage/` passes (the whole tree still has to compile). |
| `perf_topk_guard` | 0.11 | yes | Seeded allocation guard: the top-K path allocates at most half the bytes/op of the equivalent full sort (steady-state measurement). |
| `race_clean` | 0.09 | yes | A bounded `-race` exercise of the concurrent metadata path reports no data race. |
| `docs_updated` | 0.08 | yes | User docs anywhere under `/testbed/docs` name the feature flag and cap flag, show the endpoint path, cover all three dimensions and describe the NDJSON batch/trailer stream. Every token is listed in the stage-4 prompt. |
| `http_dos_validation` | 0.08 | yes | Live binary: bad/over-cap `limit`, missing `label`, unknown `fuzz_alg`, over-32 `search[]` terms and `sort_by=score` without `search[]` all return HTTP 400. |
| `filter_regression` | 0.07 | yes | Every stage-3 filter behavior still passes. |
| `storage_regression` | 0.07 | yes | Every stage-2 storage behavior still passes. |
| `cap_disabled_edge` | 0.06 | yes | With `--web.search.max-limit=0` the cap is disabled: a huge `limit` and `limit=0` are both served. |
| `vet_clean` | 0.05 | yes | `go vet` is clean on the touched packages. |
| `final_report` | 0.03 | yes | `final_report.json` records invariant, changed boundaries, verification and remaining risk. |
| `http_feature_gate` | 0.03 | yes | With the flag off the endpoints serve no results while the server stays healthy. |
| `incremental_build` | 0.03 | yes | The stage's packages compile (`go build`). |
| `patch_hygiene` | 0.03 | yes | The change set carries no build artifacts and no stray generated files. Whitespace is reported but does not gate. |
| **total** | **1.00** | | |
<!-- rubric:harden:end -->

A stage scores 1.0 when every **critical** check passes and the integrity audit
passes. Non-critical checks still move `training_score`, so partial work earns
partial credit, but they never cost a stage on their own.

**The prompt and the gate are locked together.** Every requirement an
instruction states as mandatory is critical, and every non-critical check is
described in its own prompt as *"Scored but never decisive"*. There is no third
category, and `test_every_non_critical_check_is_disclosed_as_optional_in_its_prompt`
asserts both directions.

This closed the defect a reviewer found in the previous revision: stage 4 stated documentation,
patch hygiene and `final_report.json` as requirements while grading them
non-critically, so an agent run failed stated requirements and still recorded
`binary_reward = 1.0`. All three are critical now. Stage 4 is terminal and
ungated, so this aborts no trial early — it only makes the final reward tell the
truth about whether the stage was finished.

Two checks were deleted rather than promoted. `merge_ready` graded
`decisions.merge_ready == true` from the agent's own handoff — a self-assessment,
not a behaviour, and an agent that types `true` scored like one that earned it.
`reproducer_present` passed on any non-empty file under `/app/output/01-diagnose`,
so it graded paperwork while the verifier's own runtime probes were already the
authoritative evidence.

## Deterministic and non-deterministic evaluation

Deterministic checks decide stage promotion and final binary success: they
compile the source, run seeded hidden Go behavior tests, drive the built binary
over HTTP, validate typed artifacts, and audit integrity.

RewardKit (Anthropic Claude Sonnet 4.6) runs separate, **non-authoritative**
reviews of engineering process, trial validity / anti-cheating, and final merge
readiness. It only feeds the continuous `training_score`:

```text
D_num = sum(passed deterministic weight)
D_den = sum(deterministic weight)
training_score = (D_num + lambda * N_num) / (D_den + lambda * N_den)
```

`NONDETERMINISTIC_LAMBDA=0` (default) yields the deterministic score only.
RewardKit never changes `reward` or `binary_reward`, which stay identical and
binary. Trusted Oracle runs skip RewardKit; a correct Oracle scores `1.0`.

## Anti-contamination boundary

The Docker build downloads only the base commit, archives it into `/testbed`,
removes the clone, and re-creates a single sanitized Git commit (no remotes,
history, tags, or PR identifiers). The verifier rejects access to `/solution` or
`/tests`, Git remotes/fetch/clone, network downloaders and runtime installs, and
reward/test tampering. Read-only `git log`/`git show` on the sanitized base are
allowed. Hidden tests are seeded (`LH_SEED`) with values distinct from any
example, and grading keys on behavior + the declared public contract, never on
golden-internal symbol names.

The toolchain is trusted behaviourally, not by any file in the image. Since an
agent with root can rewrite anything the image ships, the verifier never asks who
`go` is by comparing it against a stored manifest. Instead it prepends the
canonical tool directories to its own `PATH`, requires each critical tool to
resolve to a root-owned, non-world-writable ELF image inside them, and then makes
the toolchain prove it reports real outcomes: it writes one test that must pass
and one that must fail into a scratch package and requires both verdicts to come
back. A `go` that fabricates success reports the failing test as passing and is
caught; a `go` that fabricates failure loses the passing one. The resolved path
and digest of every tool are published in the stage's `reward.json`, so a
substitution between stages is visible from outside the container too.

## Package layout

```text
prometheus-search-api/
|-- task.toml
|-- README.md
|-- environment/
|   `-- Dockerfile
|-- steps/
|   |-- 01-diagnose/          instruction.md · solution/ · tests/
|   |-- 02-core/
|   |-- 03-review/
|   `-- 04-harden/
|-- tests/
|   |-- stage_check.py        # deterministic grader (sole reward source)
|   |-- stage_test.sh         # stage entrypoint
|   |-- score_formula.py · merge_rewardkit_scores.py · stage_judge_inputs.py
|   |-- run_optional_judges.sh · test_reward_contract.py
|   |-- judge_prompt.md · merge_readiness_rubric.md
    |-- hidden/               # seeded, protected Go behavior tests
    `-- process|validity|merge_readiness|task_quality/judge.toml
```

Author-only stage golden patches (under `steps/*/solution/`) are split by stage,
are file-disjoint, and together cover all 24 upstream files. They are mounted
only for trusted Oracle runs and are never available to the solving agent.

The package folder holds exactly the five entries above. Author-side material —
the design notes, the self-review, the per-run validation write-up, the
merge-head equivalence proof and the upstream diffs — lives outside it, so
nothing that names the source change can travel with the task.

## Validation performed

Every row was produced by re-running this package's own grader, invoked exactly
as `tests/stage_test.sh` invokes it. Two artifacts now **ship** so a reviewer can
recheck the strongest claims without the upstream remote or a frontier account:
the byte-for-byte merge-head proof (`steps/04-harden/solution/merge_head_equivalence_proof.json`)
and a local calibration record (`steps/04-harden/solution/calibration_summary.json`,
covering repeated Oracle, no-op, an incomplete near-miss, and the tamper control).
The remaining per-run JSON, per-mutation patches and full logs are author-side.

> **The table below records the previous grader and is SUPERSEDED.** this revision changed which
> checks decide a stage (stage-4 docs/hygiene/report promoted to critical,
> `merge_ready` and `reproducer_present` deleted), so these outcomes no longer
> describe what this grader would record. The rows are kept verbatim rather than
> edited to fit the new code, because rewriting observed results to match changed
> code is fabrication, not calibration. Regenerate with
> `bash tools/run_calibration.sh`. What *is* current and reproducible on any host
> is listed under "Calibration status" below — including the merge-head equivalence
> proof, which is now derived rather than asserted.

| Control | Outcome (previous grader) |
|---|---|
| Oracle, two local full runs | all four stages `binary_reward = 1.0`, `training_score = 1.0`; wall clock 23/3/50/106 s and 20/3/47/103 s |
| Oracle on the evaluation platform | all four stages `1.0` — the reference solution closes the task on a second substrate |
| Do-nothing agent (`nop`) | `0.0` at stage 1 (`reproducer_present` — a check this revision removes — and `diagnosis_handoff`) and stage 2 (all four storage behaviours), `valid_trial = 1.0` |
| `mut-merge` — partial-error merge drops the healthy side again | `0.0`, caught by `storage_partial_error_merge` |
| `mut-cap` — `search[]` term cap raised from 32 to 100000 | `0.0`, caught by `http_dos_validation` |
| `mut-always400` — every request refused, which satisfies naive rejection probing | `0.0`, caught by `http_search_success` |
| Tamper — all 19 agent-visible `*_test.go` in the two graded packages (`web/api/v1/` and `storage/` top level, including the stage-1 reproducer) deleted and committed, then `harden` re-graded | still `1.0`: the graded corpus is injected ephemerally, so deleting visible tests gains nothing |
| Toolchain canary — a `go` that reports success for work it did not do | invalid trial: the verifier requires a test it authored to be reported as failing |
| Handoff contract — stage 1 renames the graded decision fields | `decisions_handoff` fails and `training_score` drops to 0.93, while the stage still passes: the fields are measured by name without being a hard gate |
| Judge merge (synthetic repeats, lambda 0.25) | `binary_reward` unchanged at `0.0`, `training_score` 0.92 → 0.903; a favourable judge cannot rescue a functional failure |
| Merge head | applying the three slices onto the base commit reproduces all 17 non-test files of the source change byte-for-byte, zero residual diff. The proof now **ships** as `steps/04-harden/solution/merge_head_equivalence_proof.json` (author-only), recording each file's git blob id under the applied slices and under merge `e1f4380b`; equal content-addressed ids are byte identity, so a reviewer verifies completeness without the upstream remote. `test_merge_head_equivalence_proof_is_shipped_and_consistent` re-checks it against the shipped patches offline |
| Performance guard margin | `topK=5376 B/op` vs `full=966752 B/op` (ratio 0.006, threshold 0.5) — an allocation metric, so host load cannot flake it |
| Terminal stage insulated from upstream timing tests | `package_tests` grades `./web/api/v1/... ./storage/`, not `./storage/...`: the wider tree contains upstream's remote-write suite, which asserts sample-age behaviour against wall-clock with a 5 ms margin and failed 1 of 3 runs on a CPU-saturated host while passing 3 of 3 idle. The whole tree must still compile (`go build ./...`), and the package self-test fails if any graded `go test` reaches that tree again |
| Image build under a flaky Debian index | five stubbed scenarios: three recover, the unreachable-mirror case fails with its own message |
| Package self-test | `pytest -q tests/test_reward_contract.py` |

## Headroom and horizon-ablation plan (pre-frontier step)

A single light model (`terminus-2` / `gemini-3.6-flash`, `reasoning_effort=medium`)
solved the critical path, so the 5–20 % frontier band is not yet proven and is the
one remaining pre-frontier step. Both procedures below now ship as runners —
`tools/run_horizon_ablation.sh` builds all four ablation conditions from one
command — but the runs themselves need the platform and have **not** been done;
`tests/contracts/stage_dependencies.json` records the ablation status as `NOT RUN`
and a self-test fails if that is quietly changed to a claim.

One change in this revision bears on headroom directly: the light model's single miss was
`patch_hygiene`, which was non-critical, so it scored 1.0 while failing a stated
requirement. Under this revision that trajectory records `binary_reward = 0.0` at the
terminal stage. That is an expectation to be confirmed by a re-run, not a result.

- **Multi-model solve-rate.** Run the same package under at least three models
  spanning capability (e.g. a Gemini and a Claude frontier tier plus one mid
  model), several attempts each, and report per-model final `binary_reward`. The
  target is a strict frontier solve rate in roughly the 5–20 % band; a model that
  one-shots every stage means the task needs more headroom.
- **Horizon ablation.** Run four configurations and compare final solve rate to
  show the difficulty comes from the *horizon*, not any single edit: (1) staged
  with fresh context per stage (the shipping design); (2) a single briefing that
  states all four stages up front; (3) fresh context with no handoff carried;
  (4) resumed context across stages. A dependency that is real should make the
  staged/fresh configurations materially harder than the single-briefing one.

This rework raised the bar since the shipped light-model run: the review/harden
success gate now includes a verifier-owned empty-first-batch NDJSON probe, and the
calibration record adds an incomplete near-miss control (stage-02 only fails the
stage-03 HTTP gates).

## Run locally

Use Harbor 0.8 or newer with Docker. The first build compiles Prometheus and
warms the Go module + test cache; later runs reuse it.

```bash
harbor run -p ./prometheus-search-api -a nop    --job-name prom-search-nop
harbor run -p ./prometheus-search-api -a oracle --job-name prom-search-oracle
```

The Oracle passes every stage with `binary_reward = 1.0`; the no-op fails at the
Stage-1 functional gate with `reward = 0.0`.

The optional RewardKit judges are **off by default** (`RUN_LLM_JUDGES=0`) and never
affect `reward`/`binary_reward`. A reviewer who wants the non-authoritative
process/validity/merge-readiness signals runs a separate pass that provides its
own network egress and provider key (`RUN_LLM_JUDGES=1`, `JUDGE_MODEL`,
`ANTHROPIC_API_KEY`).

## Source record

- [Prometheus repository](https://github.com/prometheus/prometheus) (Apache-2.0)
- [Base pull request](https://github.com/prometheus/prometheus/pull/18573)
- Base commit: `ee7fea7f144c9398891b083d0a3bf010074f1bb3`
- Merge commit: `e1f4380b2ae6dfcb008dfce773c70d37c39333b7`
