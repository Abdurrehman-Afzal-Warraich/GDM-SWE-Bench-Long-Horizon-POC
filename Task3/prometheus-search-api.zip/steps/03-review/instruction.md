# Stage 3 — Integrate: the Search API endpoints

Deliver the user-facing Search API on top of stage 2's storage engine, in
`/testbed`. `/app/output/handoff.json` carries the inherited context.

Matching lives in `/testbed/web/api/v1`: **substring** scoring that decays by rune
position so multi-byte text ranks correctly, **fuzzy** matching (subsequence by
default, plus Jaro-Winkler) with a caller threshold, and **AND** composition. A
request **OR**s across its `search[]` terms, case-sensitive unless
`case_sensitive=false`.

Endpoints serve only while the `search-api` feature is enabled — with it off they
yield no results (a feature-unavailable status such as 503, or routes never
registered):

```
GET|POST /api/v1/search/metric_names
GET|POST /api/v1/search/label_names
GET|POST /api/v1/search/label_values   (requires a label query parameter)
```

Responses stream **newline-delimited JSON** (`application/x-ndjson`): one or more
**batch** lines (the first always emitted, so warnings are observable), then a
**trailer** line on success.

```jsonc
// batch line, repeatable ("warnings" optional throughout):
{"results": [ /* records for the queried endpoint */ ], "warnings": ["..."]}
//   metric_names: {"name": string, "score": number?, "type": string?, "help": string?, "unit": string?}
//   label_names:  {"name": string, "score": number?}
//   label_values: {"value": string, "score": number?}
//   ("score" is present only when include_score=true)
// trailer line, last, on success:
{"status": "success", "has_more": bool, "warnings": ["..."]}
// error object:
{"status": "error", "errorType": string, "error": string}
```

- Query parameters: `match[]`, `search[]` (OR terms), `fuzz_threshold` (0–100),
  `fuzz_alg` (subsequence|jarowinkler), `case_sensitive` (default true),
  `sort_by` (alpha|score) with `sort_dir` (asc|dsc, valid only with alpha),
  `include_score`, `include_metadata` (metric_names only), `start`/`end`,
  `limit` (default 100), `batch_size`. `has_more` reflects whether more than
  `limit` results existed.
- **Rejected requests (all → HTTP 400)**, graded exactly as written: a `limit`
  that is not a valid number or exceeds the max; `label_values` without the
  `label` parameter; an unknown `fuzz_alg` (or any unparseable value); **more
  than 32 `search[]`
  terms** (the cap is 32; 32 or fewer must be accepted); **`sort_by=score` with
  no `search[]` term**; `sort_dir` combined with `sort_by=score` (direction is
  alpha-only).
- **Configurable max `limit`** (`--web.search.max-limit`, default 10000; `0`
  disables the cap entirely, so a huge `limit` and `limit=0` are both accepted).
  The default `limit` is clamped under the cap.
- `include_metadata=true` adds type/help/unit to metric_names results, gathered
  concurrency-safely under many simultaneous requests.

Hidden checks construct these **exported** filters by name in
`/testbed/web/api/v1`; each returns a type implementing `storage.Filter`
(`Accept(value string) (bool, float64)`). Scoring internals are yours:

```go
// Substring; prefix => 1.0, later positions decay into [0.1,1.0), non-match => (false,0).
func NewSubstringFilter(query string) *SubstringFilter
// Jaro-Winkler; Accept => (score>=threshold, score), score in [0,1].
func NewFuzzyFilter(query string, threshold float64) *FuzzyFilter
// Subsequence; prefix => 1.0; Accept => (score>0 && score>=threshold, score).
func NewSubsequenceFilter(query string, threshold float64) *SubsequenceFilter
// AND; accept iff all accept; score = max sub-score; empty chain => (true,1.0).
func NewChainFilter(filters ...storage.Filter) *ChainFilter
```

Wire the feature through web/API/CLI behind the flag.

**Scored but never decisive**, so neither can end the trial: keeping the
committed OpenAPI surface in sync with the generated one, and writing
`/app/output/03-review/review_response.json` with at least these keys —
`feedback` (string), `changes` (array), `verification` (array). Extras are fine.

**Not graded:** how a failure *after* streaming began is framed. The contract
above states it because clients need it, but no check injects a storage fault
through HTTP, so nothing depends on it. The partial-error semantics behind it are
graded at the storage layer, in stage 2 and stage 4.
