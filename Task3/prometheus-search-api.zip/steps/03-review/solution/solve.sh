#!/usr/bin/env bash
# Oracle solver — Stage 03 (full web/api/v1 search feature). Applies the stage
# golden patch on top of the persisted stage-02 state, proves the API package
# and the prometheus binary build+test green, emits handoff. Oracle only.
set -euo pipefail
export GOWORK=off
OUT=/app/output
STAGE_OUT="$OUT/03-review"
mkdir -p "$STAGE_OUT"
cd /testbed

git apply --index --whitespace=nowarn /solution/golden.patch
git -c user.email=a@b.c -c user.name=oracle commit -q -m "stage03: search filters + HTTP endpoints" || true

go build ./cmd/prometheus ./web/... > "$STAGE_OUT/build.log" 2>&1
go test ./web/api/v1/ -count=1     > "$STAGE_OUT/test.log"  2>&1
tail -4 "$STAGE_OUT/test.log" || true

cat > "$OUT/handoff.json" <<'JSON'
{
  "stage": "03-review",
  "invariant": "GET/POST /api/v1/search/{metric_names,label_names,label_values} are registered only when search-api is enabled, stream application/x-ndjson (>=1 batch then trailer or mid-stream error line), score/sort/limit/has_more correctly, reject invalid params and over-cap limits (>--web.search.max-limit) and >32 search[] terms with HTTP 400, and the generated OpenAPI matches the golden.",
  "evidence": [
    "go test ./web/api/v1/ passes (see 03-review/test.log)",
    "go build ./cmd/prometheus succeeds with the search-api feature + --web.search.max-limit flag",
    "OpenAPI golden conformance tests pass"
  ],
  "boundaries": [
    "feature gated; disabled => endpoints report unavailable (HTTP 503)",
    "no pagination cursor; has_more is informational",
    "metadata cache TTL 5s; treated read-only by concurrent requests"
  ],
  "risks": [
    "mid-stream backend error must produce an NDJSON error line, not a pre-stream JSON error",
    "default limit 100 must be clamped when the operator sets a smaller cap"
  ],
  "next_stage_checks": [
    "cumulative rerun of storage + endpoint behavior still green",
    "bounded concurrency (metadata cache under -race) and perf threshold hold",
    "non-ASCII scoring, limit=0 (cap disabled), batch_size boundaries"
  ],
  "decisions": {
    "ndjson_first_batch_always_emitted": true,
    "over_cap_limit_status": 400,
    "too_many_terms_status": 400,
    "disabled_feature_status": 503
  }
}
JSON
echo "wrote $OUT/handoff.json"

cat > "$STAGE_OUT/review_response.json" <<'JSON'
{
  "feedback": "Register search routes only behind the search-api feature flag; enforce DoS caps (--web.search.max-limit and a fixed search[]-term cap) with HTTP 400; stream NDJSON with a first batch always emitted; keep OpenAPI in sync.",
  "changes": [
    "web/api/v1/search_filters.go: exported Substring/Fuzzy/Subsequence/Chain filters + case-folding + bounded memoization",
    "web/api/v1/search.go: NDJSON streamer, param parsing/validation, has_more probe, metadata cache",
    "web/api/v1/api.go: gated route registration; cmd/prometheus/main.go + web/web.go: feature flag + --web.search.max-limit",
    "web/api/v1/openapi*.go + testdata: spec kept in sync"
  ],
  "verification": ["go build ./cmd/prometheus ./web/...", "go test ./web/api/v1/ -count=1"]
}
JSON
echo "wrote $STAGE_OUT/review_response.json"
