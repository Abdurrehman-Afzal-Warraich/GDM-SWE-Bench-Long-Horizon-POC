#!/usr/bin/env bash
# Oracle solver — Stage 02 core (storage search engine). Applies the stage
# golden patch, proves the storage package builds+tests green, emits handoff.
# Trusted Oracle run only; /solution/golden.patch is mounted only here.
set -euo pipefail
export GOWORK=off
OUT=/app/output
STAGE_OUT="$OUT/02-core"
mkdir -p "$STAGE_OUT"
cd /testbed

git apply --index --whitespace=nowarn /solution/golden.patch
git -c user.email=a@b.c -c user.name=oracle commit -q -m "stage02: storage search engine" || true

go build ./storage/... > "$STAGE_OUT/build.log" 2>&1
go test ./storage/ -count=1  > "$STAGE_OUT/test.log"  2>&1
tail -3 "$STAGE_OUT/test.log" || true

cat > "$OUT/handoff.json" <<'JSON'
{
  "stage": "02-core",
  "invariant": "storage.ApplySearchHints returns the top-K results under (Score desc, Value asc) via a bounded min-heap when Filter+OrderByScoreDesc+Limit is set, uses early-exit for value orderings, and the merge preserves the healthy side's results on a partial error, surfacing errors.Join via Err().",
  "evidence": [
    "go test ./storage/ passes (see 02-core/test.log)",
    "topKByScore, reverseFilterEarlyExit, linearResultCap present in storage/generic.go",
    "NewSearchResultSetFromSliceAndError + partial-error mergingSearchResultSet present"
  ],
  "boundaries": [
    "storage layer only; no web/api dependency",
    "single-goroutine iteration contract for filters preserved"
  ],
  "risks": [
    "int overflow on limit+1 / 2*limit when the operator disables the cap",
    "duplicate collapse must keep the higher score under value orderings"
  ],
  "next_stage_checks": [
    "web/api/v1 filters build atop storage.Filter and produce correct scores",
    "endpoints translate sort_by/limit to storage.Ordering + storage limit (limit+1 has_more probe)"
  ],
  "decisions": {
    "orderings": ["OrderByValueAsc", "OrderByValueDesc", "OrderByScoreDesc"],
    "topk_total_order": "Score desc, then Value asc",
    "partial_error_policy": "keep-draining surviving side; errors.Join at end"
  }
}
JSON
echo "wrote $OUT/handoff.json"

cat > "$STAGE_OUT/implementation.json" <<'JSON'
{
  "summary": "Added a bounded min-heap top-K path (Score desc, Value asc) to ApplySearchHints for Filter+OrderByScoreDesc+Limit, an early-exit path for value orderings, and a partial-error-preserving k-way merge with lazy result-set construction.",
  "public_api": [
    "func MergeSearchResultSets(sets []storage.SearchResultSet, hints *storage.SearchHints) storage.SearchResultSet",
    "func NewLazySearchResultSet(init func() storage.SearchResultSet) storage.SearchResultSet",
    "func NewSearchResultSetFromSliceAndError(results []storage.SearchResult, warns annotations.Annotations, err error) storage.SearchResultSet"
  ],
  "tests_run": ["go build ./storage/...", "go test ./storage/ -count=1"]
}
JSON
echo "wrote $STAGE_OUT/implementation.json"
