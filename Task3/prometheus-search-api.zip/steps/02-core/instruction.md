# Stage 2 — Core: the storage search engine

Build the storage-layer engine the search API relies on, in `/testbed/storage`.
`/app/output/handoff.json` carries stage 1's invariant and decisions.

1. **Score-ranked top-K.** The best `K` (score desc, then value asc) without
   fully sorting every match: output identical to a full sort truncated to `K`,
   but bounded work.
2. **Ordered, limited paths.** Value-ordered limited queries return the correct
   first `K` (asc/desc) without materializing the full set, and up-front
   allocation stays bounded for tiny and astronomically large limits alike.
3. **Partial results, then the error.** When one source errors mid-stream, keep
   draining the healthy ones, emit their buffered results, and surface the joined
   error only at the end. Duplicates collapse in order: under the value orderings
   the higher score wins; under score ordering a given value carries one score, so
   duplicates tie and are adjacent.

Stage 3 links against these **exported** names; internals are yours:

```go
// Merge pre-ordered result sets under hints.OrderBy / hints.Limit.
func MergeSearchResultSets(sets []SearchResultSet, hints *SearchHints) SearchResultSet
// Defer building a result set until first use.
func NewLazySearchResultSet(init func() SearchResultSet) SearchResultSet
// Model "these results, then this error" (partial-results-then-error).
func NewSearchResultSetFromSliceAndError(results []SearchResult, warns annotations.Annotations, err error) SearchResultSet
```

`ApplySearchHints(values []string, hints *SearchHints) []SearchResult` keeps its
signature; only its internals change.

**Graded:** the three behaviors above, through the exported storage API, plus an
incremental build.

**Scored but never decisive:** carrying `/app/output/handoff.json` forward
(`invariant` string; `evidence`, `boundaries`, `risks`, `next_stage_checks`
arrays; `decisions` object), and writing
`/app/output/02-core/implementation.json` with at least these keys — `summary`
(string), `public_api` (array), `tests_run` (array). Extras are fine.

```json
{ "summary": "...", "public_api": ["..."], "tests_run": ["..."] }
```
