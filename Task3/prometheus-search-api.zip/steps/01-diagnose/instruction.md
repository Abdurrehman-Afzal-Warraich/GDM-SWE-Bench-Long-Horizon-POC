# Stage 1 — Diagnose the missing search capability

The repository root is `/testbed` (run `go` there). Operators want an experimental
Search API so UIs can autocomplete **metric names**, **label names** and **label
values** with fuzzy matching. Prometheus has no such capability, and the storage
layer that would back it has two gaps.

Establish, by running the code rather than reading it, that:

1. there is no HTTP search surface — no `/api/v1/search/...` endpoints, and no
   search toggle via `--enable-feature`;
2. the storage helper that ranks and limits candidate strings has no efficient
   top-K path for score-ranked, limited queries;
3. the result-set merge fails fast when one source errors, discarding results
   already buffered from the healthy ones.

Investigate however you like — a reproducer `*_test.go` (placing it in the
relevant package is fine), a throwaway program, a recorded command sequence. A
reproducer test left behind ships nothing — but do **not** change production
(non-test) code under `/testbed/storage`, `/testbed/web`, `/testbed/cmd`,
`/testbed/util` or `/testbed/docs`, add the feature flag, or create the endpoints
yet.

Write `/app/output/handoff.json`, which stage 2 inherits:

```json
{
  "invariant": "the core property later stages must establish",
  "evidence": ["what you observed for each gap"],
  "boundaries": ["offline", "feature-gated", "backs an autocomplete UI"],
  "risks": ["DoS surfaces", "multi-byte scoring", "hot-subsystem locking"],
  "next_stage_checks": ["how you'd confirm the fix"],
  "decisions": {
    "endpoint_set": ["/api/v1/search/metric_names", "..."],
    "response_framing": "ndjson",
    "default_limits": {"default_limit": 100, "max_candidates": 10000}
  }
}
```

**Graded:** the three gaps, confirmed independently by this stage's own runtime
probes; that no production file was modified; and `handoff.json` carrying
`invariant` (string) plus `evidence`, `boundaries`, `risks`, `next_stage_checks`
(arrays).

**Scored but never decisive:** the `decisions` object — `endpoint_set` (non-empty
list of strings), `response_framing` (non-empty string), `default_limits` (object
with at least one numeric limit). The values are your design call.

Nothing else under `/app/output` is graded, and this stage cannot end the trial.
