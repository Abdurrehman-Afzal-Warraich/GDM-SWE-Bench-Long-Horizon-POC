// Oracle Stage-01 reproducer (author-only; mounted at /solution during a trusted
// Oracle run and copied into /testbed/storage as zz_lh_diag_repro_test.go).
//
// It ships nothing: a *_test.go file never enters the binary, which is why the
// Stage-1 instruction explicitly allows leaving a reproducer test behind and why
// the verifier does not count one as a production change. The Oracle deliberately
// takes the same path an agent would.
//
// Both cases are RUNTIME observations of the base tree:
//   - TestLHDiagTopKAlloc      the score+limit path allocates ~O(N) for limit=10,
//                              i.e. it materialises the whole matched set instead
//                              of keeping a bounded top-K.
//   - TestLHDiagMergeFailFast  the k-way merge is fail-fast: a mid-stream error on
//                              one source discards results already buffered from
//                              the healthy one.
package storage

import (
	"context"
	"errors"
	"fmt"
	"testing"
)

type lhDiagReproFilter struct{}

func (lhDiagReproFilter) Accept(v string) (bool, float64) { return true, float64(len(v)%7) / 7.0 }

func TestLHDiagTopKAlloc(t *testing.T) {
	const n = 40000
	values := make([]string, n)
	for i := range values {
		values[i] = fmt.Sprintf("metric_series_%07d", i)
	}
	hints := &SearchHints{Filter: lhDiagReproFilter{}, OrderBy: OrderByScoreDesc, Limit: 10}
	br := testing.Benchmark(func(b *testing.B) {
		b.ReportAllocs()
		for i := 0; i < b.N; i++ {
			_ = ApplySearchHints(values, hints)
		}
	})
	fmt.Printf("LHDIAG topk_alloc_bytes_per_op=%d n=%d\n", br.AllocedBytesPerOp(), n)
}

func TestLHDiagMergeFailFast(t *testing.T) {
	boom := errors.New("lh-diag-boom")
	primary := &partialErrSearchQuerier{names: []SearchResult{{Value: "alpha"}, {Value: "beta"}}, err: boom}
	secondary := &searchQuerier{names: []SearchResult{{Value: "gamma"}, {Value: "delta"}, {Value: "epsilon"}}}
	rs := NewMergeQuerier([]Querier{primary, secondary}, nil, ChainedSeriesMerge).(Searcher).
		SearchLabelNames(context.Background(), nil)
	var got []string
	for rs.Next() {
		got = append(got, rs.At().Value)
	}
	fmt.Printf("LHDIAG merge_failfast_results=%v merge_failfast_err=%v\n", got, rs.Err())
}
