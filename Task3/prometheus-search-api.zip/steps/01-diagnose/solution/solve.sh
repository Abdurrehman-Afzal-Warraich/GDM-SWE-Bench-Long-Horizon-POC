#!/usr/bin/env bash
# Oracle solver — Stage 01 diagnose. NO production changes: build an executable
# reproducer proving the search feature is absent at base, and emit the typed
# handoff the later stages consume. Trusted Oracle run only.
set -euo pipefail
export GOWORK=off
OUT=/app/output
STAGE_OUT="$OUT/01-diagnose"
mkdir -p "$STAGE_OUT"
cd /testbed

# --- Executable reproducer of the base (pre-feature) behavior. -------------
# All evidence below is RUNTIME OBSERVATION (booting the real server and running
# the real storage primitives), not source reading.
go build -o /tmp/lh-prom-diag ./cmd/prometheus
TSDB="$(mktemp -d)"; CFG="$(mktemp --suffix=.yml)"; echo 'global: {}' > "$CFG"

# (1) HTTP surface absent, and the feature flag is INERT even when supplied:
#     boot once plain, then boot again WITH --enable-feature=search-api and show
#     the search route is still 404 (or the binary rejects the unknown feature).
boot_and_probe() { # args: extra flags... ; echoes "ready search"
  local port="$1"; shift
  /tmp/lh-prom-diag --config.file="$CFG" --storage.tsdb.path="$TSDB" \
    --web.listen-address="127.0.0.1:${port}" "$@" >>"$STAGE_OUT/server.log" 2>&1 &
  local pid=$! ready=000
  for _ in $(seq 1 60); do
    ready="$(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:${port}/-/ready" || echo 000)"
    { [ "$ready" = "200" ] || [ "$ready" = "503" ]; } && break
    sleep 0.5
  done
  local search
  search="$(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:${port}/api/v1/search/metric_names" || echo 000)"
  kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true
  echo "${ready} ${search}"
}
read -r r0 s0 <<<"$(boot_and_probe 19099)"
read -r r1 s1 <<<"$(boot_and_probe 19100 --enable-feature=search-api)"

# (2) Storage-layer gaps, reproduced by RUNNING the base primitives from an
#     in-package test:
#       - top-K path materialises ~O(N) instead of a bounded heap;
#       - the k-way merge is fail-fast (drops the healthy side on a partial error).
#     The Oracle deliberately LEAVES this file in the tree, exactly as an agent
#     would, to keep the reference run on the same path a real agent takes: a
#     reproducer *_test.go ships nothing and is never a production change.
cp /solution/reproducer_storage_test.go storage/zz_lh_diag_repro_test.go
go test ./storage/ -run 'TestLHDiag' -v > "$STAGE_OUT/storage_repro.log" 2>&1 || true
cp storage/zz_lh_diag_repro_test.go "$STAGE_OUT/reproducer_storage_test.go"
topk_line="$(grep -o 'topk_alloc_bytes_per_op=[0-9]*' "$STAGE_OUT/storage_repro.log" 2>/dev/null | head -1 || true)"
merge_line="$(grep -o 'merge_failfast_results=.*' "$STAGE_OUT/storage_repro.log" 2>/dev/null | head -1 || true)"
[ -n "$topk_line" ] || topk_line="topk_alloc_bytes_per_op=unknown"
[ -n "$merge_line" ] || merge_line="merge_failfast_results=unknown"

{
  echo "reproducer: base behavior for prometheus search API (runtime observation)"
  echo "server_ready_status=${r0}"
  echo "search_route_status=${s0}   # 404 == no search surface at base"
  echo "search_route_status_with_flag=${s1} ready_with_flag=${r1}   # flag inert: still 404 (or refused)"
  echo "${topk_line}   # ~O(N) bytes for limit=10 => no bounded top-K at base"
  echo "${merge_line}   # healthy side dropped + error surfaced => fail-fast merge"
} > "$STAGE_OUT/base_behavior.txt"
cat "$STAGE_OUT/base_behavior.txt"
rm -rf "$TSDB" "$CFG" /tmp/lh-prom-diag

# --- Typed handoff consumed by stage 02+. ----------------------------------
cat > "$OUT/handoff.json" <<'JSON'
{
  "stage": "01-diagnose",
  "invariant": "Prometheus exposes no metric/label search API; the storage search primitive lacks a top-K path and fails fast on mid-stream merge errors (dropping already-buffered results from the healthy side).",
  "evidence": [
    "cmd/prometheus/main.go does not register the 'search-api' feature nor a --web.search.max-limit flag",
    "web/api/v1/search.go is absent; no /api/v1/search/* routes are registered",
    "storage/generic.go has no topKByScore and no NewSearchResultSetFromSliceAndError partial-error path"
  ],
  "boundaries": [
    "offline only; tests use in-memory storage fixtures",
    "feature is gated behind --enable-feature=search-api",
    "no pagination cursor in this version (has_more is informational)"
  ],
  "risks": [
    "unbounded search[] terms and unbounded limit are DoS surfaces",
    "score computation must be rune-correct for non-ASCII values",
    "metadata lookups must not lock the scrape manager per-result"
  ],
  "next_stage_checks": [
    "topKByScore == full-sort-by-(score desc, value asc) then limit",
    "partial-error merge preserves healthy-side results and joins errors",
    "endpoints stream NDJSON: >=1 batch then trailer or mid-stream error line",
    "limit above --web.search.max-limit -> HTTP 400; >32 search[] terms -> 400"
  ],
  "decisions": {
    "endpoint_set": [
      "/api/v1/search/metric_names",
      "/api/v1/search/label_names",
      "/api/v1/search/label_values"
    ],
    "response_framing": "ndjson: repeatable batch lines then a success trailer, application/x-ndjson",
    "default_limits": {
      "default_limit": 100,
      "max_limit_default": 10000,
      "max_search_terms": 32
    },
    "methods": ["GET", "POST"],
    "fuzz_algorithms": ["subsequence", "jarowinkler"],
    "default_fuzz_alg": "subsequence",
    "case_sensitive_default": true
  }
}
JSON
echo "wrote $OUT/handoff.json"
