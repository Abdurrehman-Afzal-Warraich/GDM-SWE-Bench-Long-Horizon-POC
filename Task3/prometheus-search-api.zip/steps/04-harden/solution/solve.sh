#!/usr/bin/env bash
# Oracle solver — Stage 04 harden/close. Applies the stage golden patch (bench
# harness + docs) on top of persisted stages 02-03, reruns the cumulative
# scoped suite, emits the final merge-readiness handoff. Oracle only.
set -euo pipefail
export GOWORK=off
OUT=/app/output
STAGE_OUT="$OUT/04-harden"
mkdir -p "$STAGE_OUT"
cd /testbed

git apply --index --whitespace=nowarn /solution/golden.patch
git -c user.email=a@b.c -c user.name=oracle commit -q -m "stage04: harden + docs" || true

# Cumulative closure: these are hard gates for the reference solution — no
# failure masking, so the Oracle only passes if vet, tests, benchmarks, the
# performance guard, and the bounded race exercise genuinely succeed.
go vet ./web/api/v1/                        > "$STAGE_OUT/vet.log"   2>&1
go test ./web/api/v1/ ./storage/ -count=1   > "$STAGE_OUT/test.log"  2>&1
# Fixed performance guard: top-K must be materially cheaper than a full sort;
# plus the non-ASCII / limit=0 edge regressions.
go test ./storage/ -count=1 -v \
    -run 'TestTopKMateriallyCheaperThanFullSort|TestSearchEdgeRegressions' \
    > "$STAGE_OUT/perf_guard.log" 2>&1
# Bounded concurrency exercise under the race detector (metadata cache readers,
# streaming). Scoped to the two feature packages so it stays bounded. Requires
# cgo + a C compiler (the shipped image provides gcc); if none is present (e.g.
# host-side validation) skip rather than fail — the verifier applies the same
# rule and a genuine DATA RACE still fails there.
if command -v gcc >/dev/null 2>&1 || command -v cc >/dev/null 2>&1 || command -v clang >/dev/null 2>&1; then
  CGO_ENABLED=1 go test -race -count=1 ./storage/ ./web/api/v1/ > "$STAGE_OUT/race.log" 2>&1
else
  echo "skip -race: no C compiler (cgo unavailable in this env)" > "$STAGE_OUT/race.log"
fi
# Perf smoke: bench must compile and run one iteration.
go test ./web/api/v1/ -run '^$' -bench 'Search|Filter' -benchtime 1x \
    > "$STAGE_OUT/bench.log" 2>&1
tail -5 "$STAGE_OUT/test.log" || true

cat > "$OUT/handoff.json" <<'JSON'
{
  "stage": "04-harden",
  "invariant": "The full search feature is closed out: the cumulative storage + web/api/v1 suite is green, the benchmark harness compiles and runs, edge cases (non-ASCII scoring, limit=0, batch_size bounds) hold, and the user-facing docs describe the endpoints, feature flag, and --web.search.max-limit.",
  "evidence": [
    "go test ./web/api/v1/ ./storage/ passes (see 04-harden/test.log)",
    "benchmark harness runs (see 04-harden/bench.log)",
    "docs/querying/api.md + docs/feature_flags.md + docs/command-line/prometheus.md updated"
  ],
  "boundaries": ["no new production packages; hardening + documentation only"],
  "risks": ["future cursor-based pagination is out of scope for this version"],
  "next_stage_checks": [],
  "decisions": {}
}
JSON
echo "wrote $OUT/handoff.json"

cat > "$STAGE_OUT/final_report.json" <<'JSON'
{
  "invariant": "The experimental Search API is complete and merge-ready: storage top-K + partial-error merge, exported fuzzy/substring/subsequence/chain filters, feature-gated NDJSON endpoints with DoS caps, OpenAPI in sync, and user docs updated. The cumulative storage + web/api/v1 suite is green.",
  "changed_boundaries": ["storage", "web/api/v1", "cmd/prometheus", "web", "docs"],
  "verification": [
    "go build ./...",
    "go vet ./web/api/v1/...",
    "go test ./web/api/v1/... ./storage/ -count=1",
    "search API HTTP DoS/validation + feature-gate contract"
  ],
  "remaining_risk": "cursor-based pagination is out of scope; has_more is informational only in this version."
}
JSON
echo "wrote $STAGE_OUT/final_report.json"
