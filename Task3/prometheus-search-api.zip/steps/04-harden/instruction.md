# Stage 4 — Harden & close

Close the feature out in `/testbed`. `/app/output/handoff.json` carries the
context.

- **Cumulative correctness.** All stage 2–3 behavior still holds — the storage
  engine and the full `/testbed/web/api/v1` search behavior.
- **Performance, measured by allocation rather than wall-clock.** On a seeded
  corpus of tens of thousands of values with a small `limit`, the score-ranked
  top-K path must allocate **no more than half** the bytes per operation of the
  equivalent full sort, taken after a warmup iteration so only steady-state
  allocation counts.
- **Concurrency safety.** The shared metric-metadata cache is race-free under
  concurrent readers, and the single-goroutine assumption for the memoizing
  matcher holds.
- **Edges.** Non-ASCII values score correctly, `limit=0` follows the cap-disabled
  path, and `batch_size` boundaries and a mid-stream client disconnect are
  tolerated.
- **User docs.** Documentation anywhere under `/testbed/docs` (no particular file
  is required) must let a user adopt the feature from the docs alone, and must
  name: the `search-api` feature flag; `--web.search.max-limit`; the endpoint path
  `/api/v1/search/...`; `metric_names`, `label_names`, `label_values`; the stream
  as `application/x-ndjson` or `newline-delimited`, described as `batch` lines
  followed by a `trailer line`.
- **Hygiene.** No build artifacts or stray generated files in the change set
  (nothing ending `.o`, `.a`, `.so`, `.exe`, `.test`, nothing under `bin/`, no
  committed `prometheus` binary).

Write `/app/output/04-harden/final_report.json` with at least these keys (extras
are fine; only these are graded):

```json
{ "invariant": "...", "changed_boundaries": ["..."], "verification": ["..."], "remaining_risk": "..." }
```

`invariant` and `remaining_risk` are strings; `changed_boundaries` and
`verification` are arrays.

**Everything above is graded and every item decides this stage's outcome.** This
is the terminal stage, so its result is the trial's. Refreshing
`/app/output/handoff.json` is optional and not graded.
