package storage

import (
    "errors"
    "fmt"
    "testing"

    "github.com/stretchr/testify/require"
)

func TestReproduceGap2_EfficientTopK(t *testing.T) {
    candidates := make([]string, 10000)
    for i := 0; i < 10000; i++ {
        candidates[i] = fmt.Sprintf("metric_%06d", i)
    }
    hints := &SearchHints{
        Limit:   5,
        OrderBy: OrderByScoreDesc,
    }
    results := ApplySearchHints(candidates, hints)
    require.Equal(t, 5, len(results))
}

func TestReproduceGap3_PartialResultsThenError(t *testing.T) {
    healthySet := NewSearchResultSetFromSlice([]SearchResult{
        {Value: "a", Score: 1.0},
        {Value: "b", Score: 1.0},
        {Value: "c", Score: 1.0},
    }, nil)
    errSet := ErrSearchResultSet(errors.New("failing source error"))

    merged := MergeSearchResultSets([]SearchResultSet{healthySet, errSet}, &SearchHints{OrderBy: OrderByValueAsc})

    yielded := 0
    for merged.Next() {
        yielded++
    }

    t.Logf("Yielded %d items from merged set when 1 source failed", yielded)
    require.Equal(t, 3, yielded, "Expected 3 partial items yielded from healthy source despite single error")
    require.Error(t, merged.Err())
}
