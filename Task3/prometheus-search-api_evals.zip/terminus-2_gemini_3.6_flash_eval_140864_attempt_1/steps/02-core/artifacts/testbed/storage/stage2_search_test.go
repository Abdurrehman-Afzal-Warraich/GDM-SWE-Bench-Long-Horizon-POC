package storage

import (
    "errors"
    "testing"

    "github.com/stretchr/testify/require"
)

func TestStage2_ApplySearchHints_TopKScoreDesc(t *testing.T) {
    candidates := []string{"alpha", "beta", "gamma", "delta", "epsilon"}
    hints := &SearchHints{
        Limit:   2,
        OrderBy: OrderByScoreDesc,
    }
    results := ApplySearchHints(candidates, hints)
    require.Len(t, results, 2)
    require.Equal(t, "alpha", results[0].Value)
    require.Equal(t, "beta", results[1].Value)
}

func TestStage2_ApplySearchHints_ValueAscAndDesc(t *testing.T) {
    candidates := []string{"a", "b", "c", "d", "e"}

    // Ascending limit 3
    resAsc := ApplySearchHints(candidates, &SearchHints{Limit: 3, OrderBy: OrderByValueAsc})
    require.Len(t, resAsc, 3)
    require.Equal(t, "a", resAsc[0].Value)
    require.Equal(t, "b", resAsc[1].Value)
    require.Equal(t, "c", resAsc[2].Value)

    // Descending limit 3
    resDesc := ApplySearchHints(candidates, &SearchHints{Limit: 3, OrderBy: OrderByValueDesc})
    require.Len(t, resDesc, 3)
    require.Equal(t, "e", resDesc[0].Value)
    require.Equal(t, "d", resDesc[1].Value)
    require.Equal(t, "c", resDesc[2].Value)
}

func TestStage2_PartialResultsThenError(t *testing.T) {
    s1 := NewSearchResultSetFromSliceAndError([]SearchResult{
        {Value: "a", Score: 0.5},
        {Value: "c", Score: 0.9},
    }, nil, nil)

    err1 := errors.New("source 2 failed mid-stream")
    s2 := NewSearchResultSetFromSliceAndError([]SearchResult{
        {Value: "b", Score: 0.7},
    }, nil, err1)

    merged := MergeSearchResultSets([]SearchResultSet{s1, s2}, &SearchHints{OrderBy: OrderByValueAsc})
    defer merged.Close()

    var got []SearchResult
    for merged.Next() {
        got = append(got, merged.At())
    }

    require.Len(t, got, 3)
    require.Equal(t, "a", got[0].Value)
    require.Equal(t, "b", got[1].Value)
    require.Equal(t, "c", got[2].Value)

    require.Error(t, merged.Err())
    require.Contains(t, merged.Err().Error(), "source 2 failed mid-stream")
}

func TestStage2_DuplicateCollapseScoreWinner(t *testing.T) {
    s1 := NewSearchResultSetFromSlice([]SearchResult{
        {Value: "a", Score: 0.5},
    }, nil)
    s2 := NewSearchResultSetFromSlice([]SearchResult{
        {Value: "a", Score: 0.9},
    }, nil)

    merged := MergeSearchResultSets([]SearchResultSet{s1, s2}, &SearchHints{OrderBy: OrderByValueAsc})
    defer merged.Close()

    var got []SearchResult
    for merged.Next() {
        got = append(got, merged.At())
    }

    require.Len(t, got, 1)
    require.Equal(t, "a", got[0].Value)
    require.Equal(t, 0.9, got[0].Score)
}

func TestStage2_NewLazySearchResultSet(t *testing.T) {
    called := false
    lazy := NewLazySearchResultSet(func() SearchResultSet {
        called = true
        return NewSearchResultSetFromSlice([]SearchResult{{Value: "x", Score: 1.0}}, nil)
    })

    require.False(t, called)
    require.True(t, lazy.Next())
    require.True(t, called)
    require.Equal(t, "x", lazy.At().Value)
    require.False(t, lazy.Next())
    require.NoError(t, lazy.Err())
    require.NoError(t, lazy.Close())
}
