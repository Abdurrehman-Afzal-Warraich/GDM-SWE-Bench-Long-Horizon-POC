package v1

import (
    "net/http"
    "net/http/httptest"
    "testing"

    "github.com/prometheus/common/route"
    "github.com/stretchr/testify/require"
)

func TestReproduceGap1_NoSearchEndpoints(t *testing.T) {
    api := &API{
        ready: func(h http.HandlerFunc) http.HandlerFunc { return h },
        openAPIBuilder: NewOpenAPIBuilder(OpenAPIOptions{}, nil),
    }
    r := route.New()
    api.Register(r.WithPrefix("/api/v1"))

    endpoints := []string{
        "/api/v1/search/metric_names",
        "/api/v1/search/label_names",
        "/api/v1/search/label_values",
    }

    for _, ep := range endpoints {
        req := httptest.NewRequest(http.MethodGet, ep, nil)
        rec := httptest.NewRecorder()
        r.ServeHTTP(rec, req)
        require.Equal(t, http.StatusNotFound, rec.Code, "Expected 404 Not Found for missing search endpoint %s", ep)
    }
}
