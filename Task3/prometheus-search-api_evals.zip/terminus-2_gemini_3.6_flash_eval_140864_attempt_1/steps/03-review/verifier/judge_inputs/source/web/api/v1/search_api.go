// Copyright The Prometheus Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package v1

import (
"encoding/json"
"errors"
"fmt"
"net/http"
"strconv"
"strings"
"time"

"github.com/prometheus/prometheus/model/labels"
"github.com/prometheus/prometheus/model/timestamp"
"github.com/prometheus/prometheus/storage"
)

type searchEndpointType int

const (
searchEndpointMetricNames searchEndpointType = iota
searchEndpointLabelNames
searchEndpointLabelValues
)

type metricNameRecord struct {
Name  string   `json:"name"`
Score *float64 `json:"score,omitempty"`
Type  string   `json:"type,omitempty"`
Help  string   `json:"help,omitempty"`
Unit  string   `json:"unit,omitempty"`
}

type labelNameRecord struct {
Name  string   `json:"name"`
Score *float64 `json:"score,omitempty"`
}

type labelValueRecord struct {
Value string   `json:"value"`
Score *float64 `json:"score,omitempty"`
}

type batchLine struct {
Results  any      `json:"results"`
Warnings []string `json:"warnings,omitempty"`
}

type trailerLine struct {
Status   string   `json:"status"`
HasMore  bool     `json:"has_more"`
Warnings []string `json:"warnings,omitempty"`
}

type searchRequest struct {
endpoint        searchEndpointType
label           string
searchTerms     []string
fuzzThreshold   float64
hasFuzzThresh   bool
fuzzAlg         string
caseSensitive   bool
sortBy          string
sortDir         string
includeScore    bool
includeMetadata bool
limit           int
batchSize       int
matchers        [][]*labels.Matcher
startTime       time.Time
endTime         time.Time
}

func (api *API) isSearchAPIEnabled(r *http.Request) bool {
if api.enableSearchAPI || api.EnableSearchAPI {
return true
}
if api.featureRegistry != nil {
feats := api.featureRegistry.Get()
for _, catMap := range feats {
if catMap["search-api"] || catMap["search_api"] {
return true
}
}
}
return false
}

func (api *API) handleSearch(w http.ResponseWriter, r *http.Request, endpoint searchEndpointType) {
if !api.isSearchAPIEnabled(r) {
w.Header().Set("Content-Type", "application/json")
w.WriteHeader(http.StatusServiceUnavailable)
_ = json.NewEncoder(w).Encode(map[string]string{
"status":    "error",
"errorType": "unavailable",
"error":     "search API feature is disabled",
})
return
}

if err := r.ParseForm(); err != nil {
writeSearchError(w, http.StatusBadRequest, "bad_data", fmt.Sprintf("invalid form data: %v", err))
return
}

sReq, err := api.parseSearchRequest(r, endpoint)
if err != nil {
writeSearchError(w, http.StatusBadRequest, "bad_data", err.Error())
return
}

api.executeSearchStream(w, r, sReq)
}

func (api *API) searchMetricNames(w http.ResponseWriter, r *http.Request) {
api.handleSearch(w, r, searchEndpointMetricNames)
}

func (api *API) searchLabelNames(w http.ResponseWriter, r *http.Request) {
api.handleSearch(w, r, searchEndpointLabelNames)
}

func (api *API) searchLabelValues(w http.ResponseWriter, r *http.Request) {
api.handleSearch(w, r, searchEndpointLabelValues)
}

func writeSearchError(w http.ResponseWriter, statusCode int, errorType, msg string) {
w.Header().Set("Content-Type", "application/json")
w.WriteHeader(statusCode)
_ = json.NewEncoder(w).Encode(map[string]string{
"status":    "error",
"errorType": errorType,
"error":     msg,
})
}

func (api *API) parseSearchRequest(r *http.Request, endpoint searchEndpointType) (*searchRequest, error) {
req := &searchRequest{
endpoint:      endpoint,
caseSensitive: true,
batchSize:     100,
}

if endpoint == searchEndpointLabelValues {
req.label = r.FormValue("label")
if req.label == "" {
return nil, errors.New("label parameter is required for label_values endpoint")
}
}

searchTerms := r.Form["search[]"]
if len(searchTerms) == 0 {
searchTerms = r.Form["search"]
}
if len(searchTerms) > 32 {
return nil, errors.New("exceeded maximum search[] terms limit of 32")
}
req.searchTerms = searchTerms

maxLimit := api.searchMaxLimit
if maxLimit == 0 && api.SearchMaxLimit > 0 {
maxLimit = api.SearchMaxLimit
}
if maxLimit == 0 && !api.searchMaxLimitSet {
maxLimit = 10000
}
limitStr := r.FormValue("limit")
if limitStr != "" {
limitVal, err := strconv.Atoi(limitStr)
if err != nil || limitVal < 0 {
return nil, errors.New("invalid limit parameter")
}
if maxLimit > 0 && limitVal > maxLimit {
return nil, fmt.Errorf("limit exceeds maximum configured limit of %d", maxLimit)
}
req.limit = limitVal
} else {
if maxLimit > 0 && 100 > maxLimit {
req.limit = maxLimit
} else {
req.limit = 100
}
}

threshStr := r.FormValue("fuzz_threshold")
if threshStr != "" {
val, err := strconv.ParseFloat(threshStr, 64)
if err != nil || val < 0 || val > 100 {
return nil, errors.New("fuzz_threshold must be a float between 0 and 100")
}
req.fuzzThreshold = val / 100.0
req.hasFuzzThresh = true
}

fuzzAlg := r.FormValue("fuzz_alg")
if fuzzAlg != "" && fuzzAlg != "subsequence" && fuzzAlg != "jarowinkler" {
return nil, fmt.Errorf("unknown fuzz_alg: %s", fuzzAlg)
}
if fuzzAlg == "" {
fuzzAlg = "subsequence"
}
req.fuzzAlg = fuzzAlg

csStr := r.FormValue("case_sensitive")
if csStr != "" {
csVal, err := strconv.ParseBool(csStr)
if err != nil {
return nil, errors.New("invalid case_sensitive parameter")
}
req.caseSensitive = csVal
}

sortBy := r.FormValue("sort_by")
if sortBy != "" && sortBy != "alpha" && sortBy != "score" {
return nil, fmt.Errorf("invalid sort_by parameter: %s", sortBy)
}
if sortBy == "score" && len(searchTerms) == 0 {
return nil, errors.New("sort_by=score requires at least one search[] term")
}
req.sortBy = sortBy

sortDir := r.FormValue("sort_dir")
if sortDir != "" && sortDir != "asc" && sortDir != "dsc" {
return nil, fmt.Errorf("invalid sort_dir parameter: %s", sortDir)
}
if sortBy == "score" && sortDir != "" {
return nil, errors.New("sort_dir cannot be combined with sort_by=score")
}
req.sortDir = sortDir

incScoreStr := r.FormValue("include_score")
if incScoreStr != "" {
incVal, err := strconv.ParseBool(incScoreStr)
if err != nil {
return nil, errors.New("invalid include_score parameter")
}
req.includeScore = incVal
}

incMetaStr := r.FormValue("include_metadata")
if incMetaStr != "" {
incMetaVal, err := strconv.ParseBool(incMetaStr)
if err != nil {
return nil, errors.New("invalid include_metadata parameter")
}
req.includeMetadata = incMetaVal
}

bsStr := r.FormValue("batch_size")
if bsStr != "" {
bsVal, err := strconv.Atoi(bsStr)
if err != nil || bsVal <= 0 {
return nil, errors.New("invalid batch_size parameter")
}
req.batchSize = bsVal
}

matchParams := r.Form["match[]"]
if len(matchParams) == 0 {
matchParams = r.Form["match"]
}
if len(matchParams) > 0 {
matcherSets, err := api.parseMatchersParam(matchParams)
if err != nil {
return nil, fmt.Errorf("invalid match[] parameter: %w", err)
}
req.matchers = matcherSets
}

if startStr := r.FormValue("start"); startStr != "" {
t, err := parseTime(startStr)
if err != nil {
return nil, fmt.Errorf("invalid start time: %w", err)
}
req.startTime = t
}
if endStr := r.FormValue("end"); endStr != "" {
t, err := parseTime(endStr)
if err != nil {
return nil, fmt.Errorf("invalid end time: %w", err)
}
req.endTime = t
}

return req, nil
}

func (sReq *searchRequest) buildFilter() storage.Filter {
if len(sReq.searchTerms) == 0 {
return nil
}
termFilters := make([]storage.Filter, 0, len(sReq.searchTerms))
for _, term := range sReq.searchTerms {
tokens := strings.Fields(term)
if len(tokens) == 0 {
continue
}
tokenFilters := make([]storage.Filter, 0, len(tokens))
for _, tok := range tokens {
var subFilter storage.Filter
qTok := tok
if !sReq.caseSensitive {
qTok = strings.ToLower(tok)
}
if sReq.hasFuzzThresh {
if sReq.fuzzAlg == "jarowinkler" {
subFilter = NewFuzzyFilter(qTok, sReq.fuzzThreshold)
} else {
subFilter = NewSubsequenceFilter(qTok, sReq.fuzzThreshold)
}
} else {
subFilter = NewSubstringFilter(qTok)
}
if !sReq.caseSensitive {
subFilter = NewCaseFoldFilter(subFilter)
}
tokenFilters = append(tokenFilters, subFilter)
}
if len(tokenFilters) == 1 {
termFilters = append(termFilters, tokenFilters[0])
} else if len(tokenFilters) > 1 {
termFilters = append(termFilters, NewChainFilter(tokenFilters...))
}
}
if len(termFilters) == 1 {
return termFilters[0]
} else if len(termFilters) > 1 {
return NewOrFilter(termFilters...)
}
return nil
}

func (sReq *searchRequest) getOrdering() storage.Ordering {
if sReq.sortBy == "score" {
return storage.OrderByScoreDesc
} else if sReq.sortBy == "alpha" {
if sReq.sortDir == "dsc" {
return storage.OrderByValueDesc
}
return storage.OrderByValueAsc
}
if len(sReq.searchTerms) > 0 {
return storage.OrderByScoreDesc
}
return storage.OrderByValueAsc
}

func (api *API) executeSearchStream(w http.ResponseWriter, r *http.Request, sReq *searchRequest) {
if api.now == nil {
api.now = time.Now
}
ctx := r.Context()
startMs := timestamp.FromTime(sReq.startTime)
endMs := timestamp.FromTime(sReq.endTime)
if sReq.endTime.IsZero() {
endMs = timestamp.FromTime(api.now())
}

q, err := api.Queryable.Querier(startMs, endMs)
if err != nil {
writeSearchError(w, http.StatusInternalServerError, "execution", err.Error())
return
}
defer q.Close()

searcher, ok := q.(storage.Searcher)
if !ok {
writeSearchError(w, http.StatusInternalServerError, "execution", "querier does not support Searcher interface")
return
}

filter := sReq.buildFilter()
fetchLimit := 0
if sReq.limit > 0 {
fetchLimit = sReq.limit + 1
}
hints := &storage.SearchHints{
Filter:  filter,
Limit:   fetchLimit,
OrderBy: sReq.getOrdering(),
}

var matcherList []*labels.Matcher
if len(sReq.matchers) == 1 {
matcherList = sReq.matchers[0]
}

var resultSet storage.SearchResultSet
switch sReq.endpoint {
case searchEndpointMetricNames:
resultSet = searcher.SearchLabelValues(ctx, "__name__", hints, matcherList...)
case searchEndpointLabelNames:
resultSet = searcher.SearchLabelNames(ctx, hints, matcherList...)
case searchEndpointLabelValues:
resultSet = searcher.SearchLabelValues(ctx, sReq.label, hints, matcherList...)
}
if resultSet == nil {
writeSearchError(w, http.StatusInternalServerError, "execution", "failed to obtain result set")
return
}
defer resultSet.Close()

w.Header().Set("Content-Type", "application/x-ndjson")
w.WriteHeader(http.StatusOK)

flusher, _ := w.(http.Flusher)
enc := json.NewEncoder(w)
enc.SetEscapeHTML(false)

var currentBatch []any
count := 0
hasMore := false
batchEmitted := false

for resultSet.Next() {
count++
if sReq.limit > 0 && count > sReq.limit {
hasMore = true
break
}
res := resultSet.At()
var rec any
switch sReq.endpoint {
case searchEndpointMetricNames:
mRec := metricNameRecord{Name: res.Value}
if sReq.includeScore {
sc := res.Score
mRec.Score = &sc
}
if sReq.includeMetadata && api.targetRetriever != nil {
targets := api.targetRetriever(ctx).TargetsActive()
for _, tt := range targets {
found := false
for _, t := range tt {
if md, ok := t.GetMetadata(res.Value); ok {
mRec.Type = string(md.Type)
mRec.Help = md.Help
mRec.Unit = md.Unit
found = true
break
}
}
if found {
break
}
}
}
rec = mRec
case searchEndpointLabelNames:
lRec := labelNameRecord{Name: res.Value}
if sReq.includeScore {
sc := res.Score
lRec.Score = &sc
}
rec = lRec
case searchEndpointLabelValues:
vRec := labelValueRecord{Value: res.Value}
if sReq.includeScore {
sc := res.Score
vRec.Score = &sc
}
rec = vRec
}
currentBatch = append(currentBatch, rec)

if len(currentBatch) >= sReq.batchSize {
_ = enc.Encode(batchLine{Results: currentBatch})
if flusher != nil {
flusher.Flush()
}
currentBatch = nil
batchEmitted = true
}
}

var warningStrs []string
if warns := resultSet.Warnings(); len(warns) > 0 {
for _, warn := range warns {
warningStrs = append(warningStrs, warn.Error())
}
}

if !batchEmitted || len(currentBatch) > 0 {
if currentBatch == nil {
currentBatch = []any{}
}
_ = enc.Encode(batchLine{
Results:  currentBatch,
Warnings: warningStrs,
})
if flusher != nil {
flusher.Flush()
}
}

_ = enc.Encode(trailerLine{
Status:   "success",
HasMore:  hasMore,
Warnings: warningStrs,
})
if flusher != nil {
flusher.Flush()
}
}
