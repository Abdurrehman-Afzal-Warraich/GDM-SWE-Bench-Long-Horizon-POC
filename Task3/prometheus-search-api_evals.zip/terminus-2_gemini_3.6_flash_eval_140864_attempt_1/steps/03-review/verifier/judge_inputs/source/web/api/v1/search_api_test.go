package v1

import (
"bufio"
"context"
"encoding/json"
"net/http"
"net/http/httptest"
"strings"
"testing"

"github.com/prometheus/common/route"
"github.com/stretchr/testify/require"

"github.com/prometheus/prometheus/model/labels"
"github.com/prometheus/prometheus/storage"
"github.com/prometheus/prometheus/util/annotations"
)

type mockSearchQuerier struct {
results []storage.SearchResult
}

func (m *mockSearchQuerier) Select(context.Context, bool, *storage.SelectHints, ...*labels.Matcher) storage.SeriesSet {
return storage.NoopSeriesSet()
}

func (m *mockSearchQuerier) LabelValues(context.Context, string, *storage.LabelHints, ...*labels.Matcher) ([]string, annotations.Annotations, error) {
return nil, nil, nil
}

func (m *mockSearchQuerier) LabelNames(context.Context, *storage.LabelHints, ...*labels.Matcher) ([]string, annotations.Annotations, error) {
return nil, nil, nil
}

func (m *mockSearchQuerier) Close() error {
return nil
}

func (m *mockSearchQuerier) SearchLabelNames(_ context.Context, hints *storage.SearchHints, _ ...*labels.Matcher) storage.SearchResultSet {
var filtered []storage.SearchResult
for _, r := range m.results {
if hints != nil && hints.Filter != nil {
acc, sc := hints.Filter.Accept(r.Value)
if acc {
filtered = append(filtered, storage.SearchResult{Value: r.Value, Score: sc})
}
} else {
filtered = append(filtered, r)
}
}
return storage.NewSearchResultSetFromSlice(filtered, nil)
}

func (m *mockSearchQuerier) SearchLabelValues(_ context.Context, _ string, hints *storage.SearchHints, _ ...*labels.Matcher) storage.SearchResultSet {
return m.SearchLabelNames(context.Background(), hints)
}

type mockQueryable struct {
querier storage.Querier
}

func (m *mockQueryable) Querier(mint, maxt int64) (storage.Querier, error) {
return m.querier, nil
}

func (m *mockQueryable) ChunkQuerier(mint, maxt int64) (storage.ChunkQuerier, error) {
return storage.NoopChunkedQuerier(), nil
}

func setupSearchAPITest(t *testing.T, searchEnabled bool) (*API, *route.Router) {
querier := &mockSearchQuerier{
results: []storage.SearchResult{
{Value: "http_requests_total", Score: 1.0},
{Value: "http_requests_created", Score: 0.8},
{Value: "node_cpu_seconds_total", Score: 0.5},
},
}
q := &mockQueryable{querier: querier}
api := &API{
		openAPIBuilder:  NewOpenAPIBuilder(OpenAPIOptions{}, nil),
Queryable:       q,
enableSearchAPI: searchEnabled,
EnableSearchAPI: searchEnabled,
searchMaxLimit:  100,
}
r := route.New()
api.Register(r)
return api, r
}

func TestSearchAPIFeatureDisabled(t *testing.T) {
_, r := setupSearchAPITest(t, false)

req := httptest.NewRequest("GET", "/search/metric_names", nil)
w := httptest.NewRecorder()
r.ServeHTTP(w, req)

require.Equal(t, http.StatusServiceUnavailable, w.Code)
var errResp map[string]string
require.NoError(t, json.Unmarshal(w.Body.Bytes(), &errResp))
require.Equal(t, "error", errResp["status"])
require.Equal(t, "unavailable", errResp["errorType"])
}

func TestSearchAPIRejections(t *testing.T) {
_, r := setupSearchAPITest(t, true)

tests := []struct {
name   string
method string
url    string
errMsg string
}{
{
name:   "label_values without label parameter",
method: "GET",
url:    "/search/label_values",
errMsg: "label parameter is required",
},
{
name:   "limit exceeds max limit",
method: "GET",
url:    "/search/metric_names?limit=200",
errMsg: "limit exceeds maximum",
},
{
name:   "limit not a number",
method: "GET",
url:    "/search/metric_names?limit=abc",
errMsg: "invalid limit",
},
{
name:   "unknown fuzz_alg",
method: "GET",
url:    "/search/metric_names?fuzz_alg=invalid",
errMsg: "unknown fuzz_alg",
},
{
name:   "fuzz_threshold out of range",
method: "GET",
url:    "/search/metric_names?fuzz_threshold=150",
errMsg: "fuzz_threshold must be a float between 0 and 100",
},
{
name:   "more than 32 search terms",
method: "GET",
url:    "/search/metric_names?" + func() string {
var params []string
for i := 0; i < 33; i++ {
params = append(params, "search[]=term")
}
return strings.Join(params, "&")
}(),
errMsg: "exceeded maximum search[] terms limit of 32",
},
{
name:   "sort_by=score with no search terms",
method: "GET",
url:    "/search/metric_names?sort_by=score",
errMsg: "sort_by=score requires at least one search[] term",
},
{
name:   "sort_dir combined with sort_by=score",
method: "GET",
url:    "/search/metric_names?search[]=foo&sort_by=score&sort_dir=asc",
errMsg: "sort_dir cannot be combined with sort_by=score",
},
}

for _, tt := range tests {
t.Run(tt.name, func(t *testing.T) {
req := httptest.NewRequest(tt.method, tt.url, nil)
w := httptest.NewRecorder()
r.ServeHTTP(w, req)

require.Equal(t, http.StatusBadRequest, w.Code)
var errResp map[string]string
require.NoError(t, json.Unmarshal(w.Body.Bytes(), &errResp))
require.Equal(t, "error", errResp["status"])
require.Equal(t, "bad_data", errResp["errorType"])
require.Contains(t, errResp["error"], tt.errMsg)
})
}
}

func TestSearchAPIStreamingSuccess(t *testing.T) {
_, r := setupSearchAPITest(t, true)

req := httptest.NewRequest("GET", "/search/metric_names?search[]=requests", nil)
w := httptest.NewRecorder()
r.ServeHTTP(w, req)

require.Equal(t, http.StatusOK, w.Code)
require.Equal(t, "application/x-ndjson", w.Header().Get("Content-Type"))

scanner := bufio.NewScanner(w.Body)
var lines []string
for scanner.Scan() {
lines = append(lines, scanner.Text())
}
require.GreaterOrEqual(t, len(lines), 2)

var batch map[string]any
require.NoError(t, json.Unmarshal([]byte(lines[0]), &batch))
require.Contains(t, batch, "results")
results := batch["results"].([]any)
require.Equal(t, 2, len(results))

var trailer map[string]any
require.NoError(t, json.Unmarshal([]byte(lines[len(lines)-1]), &trailer))
require.Equal(t, "success", trailer["status"])
require.Equal(t, false, trailer["has_more"])
}
