package v1

import (
"testing"

"github.com/stretchr/testify/require"
)

func TestSubstringFilter(t *testing.T) {
f := NewSubstringFilter("bar")
acc, score := f.Accept("barbaz")
require.True(t, acc)
require.Equal(t, 1.0, score)

acc, score = f.Accept("foobarbaz")
require.True(t, acc)
require.Greater(t, score, 0.1)
require.Less(t, score, 1.0)

// Multi-byte test: "€" is 3 bytes, 1 rune.
f2 := NewSubstringFilter("bar")
acc, score2 := f2.Accept("€bar")
require.True(t, acc)
// rune index of "bar" in "€bar" is 1 rune.
require.InDelta(t, 0.1+0.9/2.0, score2, 1e-6)

acc, _ = f.Accept("nomatch")
require.False(t, acc)
}

func TestFuzzyFilter(t *testing.T) {
f := NewFuzzyFilter("prometheus", 0.7)
acc, score := f.Accept("prometheus")
require.True(t, acc)
require.Equal(t, 1.0, score)

acc, _ = f.Accept("xyz")
require.False(t, acc)
}

func TestSubsequenceFilter(t *testing.T) {
f := NewSubsequenceFilter("prom", 0.01)
acc, score := f.Accept("prometheus")
require.True(t, acc)
require.Equal(t, 1.0, score)

acc, score = f.Accept("p_r_o_m")
require.True(t, acc)
require.Greater(t, score, 0.0)
}

func TestChainFilter(t *testing.T) {
f1 := NewSubstringFilter("foo")
f2 := NewSubstringFilter("bar")
chain := NewChainFilter(f1, f2)

acc, _ := chain.Accept("foobar")
require.True(t, acc)

acc, _ = chain.Accept("foo")
require.False(t, acc)
}
