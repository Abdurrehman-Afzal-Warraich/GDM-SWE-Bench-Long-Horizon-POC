// Copyright The Prometheus Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package v1

import (
"strings"
"unicode/utf8"

"github.com/prometheus/prometheus/storage"
"github.com/prometheus/prometheus/util/strutil"
)

// SubstringFilter filters strings based on substring inclusion with rune-position decay scoring.
type SubstringFilter struct {
query string
}

// NewSubstringFilter returns a new SubstringFilter.
func NewSubstringFilter(query string) *SubstringFilter {
return &SubstringFilter{query: query}
}

func (f *SubstringFilter) Accept(value string) (bool, float64) {
if f.query == "" {
return true, 1.0
}
idx := strings.Index(value, f.query)
if idx < 0 {
return false, 0.0
}
runeIdx := utf8.RuneCountInString(value[:idx])
if runeIdx == 0 {
return true, 1.0
}
score := 0.1 + 0.9/(1.0+float64(runeIdx))
return true, score
}

// FuzzyFilter filters strings using Jaro-Winkler similarity score.
type FuzzyFilter struct {
query     string
threshold float64
matcher   *strutil.JaroWinklerMatcher
}

// NewFuzzyFilter returns a new FuzzyFilter.
func NewFuzzyFilter(query string, threshold float64) *FuzzyFilter {
return &FuzzyFilter{
query:     query,
threshold: threshold,
matcher:   strutil.NewJaroWinklerMatcher(query),
}
}

func (f *FuzzyFilter) Accept(value string) (bool, float64) {
score := f.matcher.Score(value)
if score >= f.threshold {
return true, score
}
return false, score
}

// SubsequenceFilter filters strings matching subsequence criteria.
type SubsequenceFilter struct {
query     string
threshold float64
matcher   *strutil.SubsequenceMatcher
}

// NewSubsequenceFilter returns a new SubsequenceFilter.
func NewSubsequenceFilter(query string, threshold float64) *SubsequenceFilter {
return &SubsequenceFilter{
query:     query,
threshold: threshold,
matcher:   strutil.NewSubsequenceMatcher(query),
}
}

func (f *SubsequenceFilter) Accept(value string) (bool, float64) {
if f.query == "" {
return true, 1.0
}
if strings.HasPrefix(value, f.query) {
return true, 1.0
}
score := f.matcher.Score(value)
if score > 0 && score >= f.threshold {
return true, score
}
return false, score
}

// ChainFilter combines multiple storage.Filter instances with AND logic.
type ChainFilter struct {
filters []storage.Filter
}

// NewChainFilter returns a new ChainFilter.
func NewChainFilter(filters ...storage.Filter) *ChainFilter {
valid := make([]storage.Filter, 0, len(filters))
for _, flt := range filters {
if flt != nil {
valid = append(valid, flt)
}
}
return &ChainFilter{filters: valid}
}

func (f *ChainFilter) Accept(value string) (bool, float64) {
if len(f.filters) == 0 {
return true, 1.0
}
maxScore := 0.0
for _, filter := range f.filters {
accepted, score := filter.Accept(value)
if !accepted {
return false, 0.0
}
if score > maxScore {
maxScore = score
}
}
return true, maxScore
}

// OrFilter combines multiple storage.Filter instances with OR logic.
type OrFilter struct {
filters []storage.Filter
}

// NewOrFilter returns a new OrFilter.
func NewOrFilter(filters ...storage.Filter) *OrFilter {
valid := make([]storage.Filter, 0, len(filters))
for _, flt := range filters {
if flt != nil {
valid = append(valid, flt)
}
}
return &OrFilter{filters: valid}
}

func (f *OrFilter) Accept(value string) (bool, float64) {
if len(f.filters) == 0 {
return true, 1.0
}
anyAccepted := false
maxScore := 0.0
for _, filter := range f.filters {
accepted, score := filter.Accept(value)
if accepted {
anyAccepted = true
if score > maxScore {
maxScore = score
}
}
}
if anyAccepted {
return true, maxScore
}
return false, 0.0
}

// CaseFoldFilter wraps a storage.Filter to perform case-insensitive evaluation.
type CaseFoldFilter struct {
inner storage.Filter
}

// NewCaseFoldFilter returns a CaseFoldFilter.
func NewCaseFoldFilter(inner storage.Filter) storage.Filter {
if inner == nil {
return nil
}
return &CaseFoldFilter{inner: inner}
}

func (f *CaseFoldFilter) Accept(value string) (bool, float64) {
return f.inner.Accept(strings.ToLower(value))
}
