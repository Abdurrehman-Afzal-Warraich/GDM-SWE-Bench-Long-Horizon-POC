# long-horizon/gitea-multi-project

A Tier-2 stateful Go task derived from a real, recently-merged go-gitea/gitea pull
request under MIT (exact upstream identity is author-only — see `PROVENANCE.md`,
never mounted into a solving container). It turns Gitea's issue-to-project
association from one-to-many into many-to-many and threads that change through
the model layer, all four issue-search indexer backends, the wire structs, the
REST API, the web routers and the services.

## Four-stage horizon

The worktree and warm Go caches persist; each stage starts with a fresh briefing
and only the previous `/app/output/handoff.json`.

| Stage | Capability | Critical gate |
| --- | --- | --- |
| `01-diagnose` | Executable proof the association is single-valued end to end. | compiler probes + reproducer, ungated |
| `02-multi-project-model` | Plural loader, per-project column map, set-reconciling assignment, set-difference helper. | model build + injected corpus + vet |
| `03-search-and-indexing` | Set-valued project filter across db/bleve/elasticsearch/meilisearch; plural wire structs. | cumulative build + corpus + vet |
| `04-api-web-and-harden` | API/web/service projection, template helpers, cumulative closure. | full build + corpus + vet + race + gofmt |

Intermediate build scopes follow the dependency direction. Stage 02 changes the
shape of methods stage-04 callers use, so the whole tree does not compile until
those callers are migrated; building only the changed packages makes that
transition observable instead of forcing the whole change into one patch.

## Scope and provenance

The implementation is split into disjoint model, indexer/wire, and
API/web/service/template patches. Exact upstream provenance, merge comparison,
scope classification and their generated results are author-side release
records. They are deliberately excluded from this operator README and from the
solving environment.

## Promotion gates

Stages 02 and 03 gate at `min_reward = 1.0`; stage 01 and the terminal stage are
ungated. `reward` is strictly binary, so any threshold in (0, 1] means "every
critical check passed" — 1.0 is written literally rather than a fraction implying
partial credit can promote. Stage 04 re-runs stages 02–03 cumulatively, so a
critical miss there is already fatal.

## Fairness of the protected corpus

The corpus is upstream's own withheld test material, placed inside the packages
under test so it can exercise package behavior. `tools/render_requirement_map.py`
checks that every non-base identifier linked by protected tests is disclosed in
the stage briefing or its `/app/contracts/<stage>.md` contract. Generated counts
and outcomes belong in author-side release evidence, not this README.

The corpus is **not purely additive**. Some `*_test.go` files already exist in the
base tree and are invalidated by the change, so the corpus must replace them —
a Go package that fails to compile takes every test in it down.
`tests/contracts/stale_base_tests.json` is derived from the repository and the
self-test fails if any of the five stops being overlaid.


## Long-horizon design

- **Stages gate cumulatively.** 02 and 03 promote only at `min_reward = 1.0`, so a run
  cannot reach a later stage without having actually completed the earlier one.
- **Later stages re-run the earlier corpus.** `corpusIsCumulative` is asserted by the
  package self-test; the terminal stage re-runs every earlier stage's graded corpus
  cumulatively, so a stage-02 decision that was wrong surfaces again at stage 04.
- **Earlier decisions constrain later ones concretely.** The stage-02 model choice (a
  per-project column map replacing a single id) is what stage 03's four indexer
  backends and stage 04's API and template helpers are written against.

This README is static operator documentation and does not report run outcomes, scores,
or calibration status for any revision — see "Where the calibration evidence lives"
below for how to regenerate and inspect that evidence directly.

## LLM judges

Judges are **training-only and never decisive**: `judge_status.json` records
`"binary_reward_affected": false` for every stage, so an uncalibrated or disagreeing
judge cannot move official success. That is a structural property of the scoring
pipeline (`merge_rewardkit_scores.py`, `score_formula.py`), not something tuned per
run. Configured judge: `openai/gpt-5.6-terra`, enabled via `RUN_LLM_JUDGES=1` with
`OPENAI_API_KEY` provided to the verifier only. A trusted Oracle run always skips
judging (`"applicable": false`); an agent run without a usable provider key falls
back to deterministic-only scoring with an explicit, inspectable reason in
`judge_status.json` rather than silently scoring zero.

## Generating author-side release evidence

This README deliberately carries no evaluation outcomes, provenance results,
scores or calibration status. Release evidence is generated outside the task
package against the exact candidate revision and delivered separately to the
reviewer. The author-side commands are:

- `tools/run_controls.sh` -> CALIBRATION.json: repeated Oracle and no-op passes, the seeded
  mutation suite, and the shuffle control.
- `tools/run_boundary_checks.sh` -> BOUNDARY.json: runtime negative-access probes against a
  built agent container, plus the resource envelope.
- `tools/run_adversarial_controls.sh` -> ADVERSARIAL.json: grader-independence controls —
  an alternate-correct implementation (must pass), an Oracle-shaped-but-wrong patch, a
  fabricated `TestMain` bootstrap, a silently-skipped invalid id, a non-atomic reconcile,
  and an adapter that stops consuming the plural filter (all five must fail).
- `tools/diag_shuffle_scope.sh` classifies each test that fails under `-shuffle=on` as authored
  corpus or upstream gitea, which is how the residual order dependence was attributed.

All three control scripts need Docker and build from `environment/` (same image tag,
`lh-gitea-multi-project:rework` by default). None of them run during grading.
