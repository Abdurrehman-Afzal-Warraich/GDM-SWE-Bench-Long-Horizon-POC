# Provenance — author and reviewer only

**Never mounted into a solving container.** The image builds `/testbed` from the
base commit alone (`environment/Dockerfile` has no `COPY` of the task root), so
nothing here reaches an agent. It exists because a previous review asked for
upstream identity to be kept out of `task.toml` metadata.

## Upstream source

| Field | Value |
|---|---|
| Repository | `go-gitea/gitea` (MIT) |
| Pull request | <https://github.com/go-gitea/gitea/pull/36784> |
| Title | Allow multiple projects per issue and pull requests |
| Merged | 2026-04-30T14:38:05Z by `wxiaoguang` |
| Author | `icyavocado` |
| Base commit | `52d6baf5a816b294662a6b2da26b82425d320930` |
| Base tree | `7df7ece8cd81f2d046df9b4286ecaaf6ff780783` |
| Merge commit | `81692ceafaa6540f9ea80f86642b255dcb7efc36` |
| Merge tree | `c312b5917d9441b0c573ba9bb5776de6c41c6563` |
| Upstream size | 58 files changed, +1590 / −423 |

## Graded scope, and what is excluded

Derived, not asserted — `tools/verify_merge_head.py` reproduces this and writes
`MERGE_HEAD_PROOF.json`:

- **32 production files** are covered by the three staged patches, and all **32
  are byte-identical** to the same paths at the merge commit.
- The merge touches **58** files. The **26** not covered are each classified:

| Count | Category | Why excluded |
|---:|---|---|
| 9 | upstream `*_test.go` | The grading corpus, injected ephemerally so an agent cannot read it. |
| 7 | `templates/` | Server-side HTML; no rendering gate in an offline container. |
| 4 | `tests/integration`, `tests/e2e` | Need a live Gitea and a browser. |
| 3 | `web_src/` | Browser sources. |
| 2 | build tooling | `Makefile`, `.gitignore` — unrelated to graded behaviour. |
| 1 | `options/locale` | Translation catalogue; wording, not behaviour. |

**Unjustified omissions: none.** The derivation fails if any merge-touched file
matches no declared category.
