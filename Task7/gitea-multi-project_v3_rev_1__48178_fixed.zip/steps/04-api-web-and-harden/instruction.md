# Stage 4 — Carry the set through the API, services and templates, then harden

Expose the plural association through the API payloads, the services and the
template helpers in `/testbed`, then harden the whole change.

- The API issue payload carries every project the issue belongs to, and the
  create and edit payloads accept the set of project ids the caller wants. On
  edit, omitting the field leaves the association unchanged.
- The services reconcile an issue against a **set** of project ids through one
  entry point.
- The template helpers can render an id set and compute the result of toggling
  one id in it, which is what a multi-select control needs.
- **Cumulative correctness.** Everything stages 2 and 3 established still holds.
- **The whole tree builds**, `go vet` is clean over the changed packages, the
  race detector is clean on the model and indexer packages, and `gofmt -l`
  reports nothing for the files you changed.

Identifiers the protected tests link against are listed in
`/app/contracts/04-api-web-and-harden.md`.

Write `/app/output/04-api-web-and-harden/final_report.json` (≤ 256 KiB) with at
least: `feature_summary` (string), `api_surface` (array),
`verification_performed` (array), `residual_risks` (array), `packages_touched`
(array).

`/testbed/templates`, `/testbed/web_src` and `/testbed/options/locale` are out of
scope: this container has no browser gate, and nothing there is graded.

**Graded:** the full build, the hidden tests, vet, race and gofmt.

**Scored but never decisive:** `final_report.json`. This
is the terminal stage, so its result is the trial's result. Refreshing
`/app/output/handoff.json` is optional here and is not graded.

The handoff at `/app/output/handoff.json` carries `stage` (string), `summary`
(string) and `next_steps` (array).

Go tests run as an unprivileged account: use the `gitea-test` wrapper, e.g.
`gitea-test go test ./models/issues/`. Artifacts are bounded at 256 KiB.
