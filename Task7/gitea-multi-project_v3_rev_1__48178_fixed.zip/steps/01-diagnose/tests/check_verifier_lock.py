"""Fail the image build if the verifier venv drifted from its pinned closure.

Pinning pytest and harbor-rewardkit is not enough to make the image
reproducible: their transitive closure moves on PyPI. The Dockerfile therefore
installs under `-c verifier-constraints.txt`, and this runs afterwards to prove
the constraint actually bound - a lock recorded after an unconstrained
resolution documents drift rather than preventing it, which is what QC
`deterministic_reproducible` objected to.

An empty constraints file is a bootstrap, allowed so the first build can
resolve the closure at all; STRICT_VERIFIER_LOCK=1 turns that off for release
builds. Refresh the pins with tools/freeze_verifier_env.sh.
"""

import os
import sys

CONSTRAINTS = "/opt/verifier-constraints.txt"
LOCK = "/opt/verifier-requirements.lock"


def load(path: str) -> dict[str, str]:
    out: dict[str, str] = {}
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#") or "==" not in line:
                continue
            name, _, version = line.partition("==")
            out[name.strip().lower().replace("_", "-")] = version.strip()
    return out


def main() -> int:
    pinned, installed = load(CONSTRAINTS), load(LOCK)

    if not pinned:
        if os.environ.get("STRICT_VERIFIER_LOCK") == "1":
            print(
                f"{CONSTRAINTS} holds no pins and STRICT_VERIFIER_LOCK=1.\n"
                "Run tools/freeze_verifier_env.sh before a release build.",
                file=sys.stderr,
            )
            return 1
        print(
            f"verifier venv: bootstrap build, {len(installed)} packages resolved "
            "but not yet pinned (run tools/freeze_verifier_env.sh)"
        )
        return 0

    problems = [
        f"{name}: pinned {pinned[name]}, installed {version}"
        for name, version in sorted(installed.items())
        if name in pinned and pinned[name] != version
    ] + [
        f"{name} {version}: installed but not pinned"
        for name, version in sorted(installed.items())
        if name not in pinned
    ]
    if problems:
        print(
            "verifier venv drifted from the pinned closure:\n  "
            + "\n  ".join(problems)
            + "\nRe-run tools/freeze_verifier_env.sh.",
            file=sys.stderr,
        )
        return 1

    print(f"verifier venv: {len(installed)} packages, every one pinned")
    return 0


if __name__ == "__main__":
    sys.exit(main())
