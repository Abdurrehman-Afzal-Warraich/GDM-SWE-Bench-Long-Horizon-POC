#!/usr/bin/env python3
"""Deterministic stage grader for long-horizon/gitea-multi-project.

Every graded signal is produced by executing the Go toolchain against the agent's
tree. The behavioural backbone is the upstream PR's own test corpus, which the
agent never sees: it lives under /tests/hidden/<stage>/ (an agent-inaccessible
mount that Harbor injects fresh at grade time), is copied into /testbed for the
duration of a `go test` run, and is byte-for-byte restored afterwards so the
agent's tree is never polluted for the next stage.

Discrimination is proven, not assumed: the injected tests fail to compile at the
pre-stage tree (undefined symbols) and pass once the stage's work is correct.
The exported and unexported identifiers those tests require are disclosed in each
stage's instruction, so the contract is solvable without guessing.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import score_formula  # noqa: E402
from score_formula import (  # noqa: E402
    REWARD_JSON_CORE_KEYS,
    REWARD_JSON_JUDGED_KEYS,
    binary_outcome,
    calculate_training_score,
    clamp01,
    deterministic_components,
    formula_text,
    parse_lambda,
    reward_json_shape_ok,
)

# Roots are overridable so the author can validate the grader outside the image;
# inside the container these always resolve to the canonical Harbor paths.
TESTBED = Path(os.environ.get("TESTBED_DIR", "/testbed"))
OUTPUT = Path(os.environ.get("AGENT_OUTPUT_DIR", "/app/output"))
AGENT_LOGS = Path(os.environ.get("AGENT_LOGS_DIR", "/logs/agent"))
HIDDEN_ROOT = Path(os.environ.get("HIDDEN_TESTS_DIR", "/tests/hidden"))
RESULT_DIR = Path(os.environ.get("RESULT_DIR", "/logs/verifier"))
# The verifier package itself: this file's directory inside the image (/tests).
TESTS = Path(__file__).resolve().parent
CHECKSUM_MANIFEST = Path("/opt/verifier-binary-checksums.txt")

STAGES = [
    "01-diagnose",
    "02-multi-project-model",
    "03-search-and-indexing",
    "04-api-web-and-harden",
]

# Package sets graded per stage. Cumulative from stage 02 onward.
# The build tags gitea's own test bootstrap requires. Defined once: the graded runs
# and the agent's reproducer must use the SAME tags, or a reproducer dies on "sqlite3
# requires: -tags sqlite,sqlite_unlock_notify" and is scored as though it failed to
# demonstrate anything.
GO_TEST_TAGS = "-tags=sqlite,sqlite_unlock_notify"

STAGE_PKGS = {
    "02-multi-project-model": [
        "./models/issues",
        "./models/project",
        "./modules/util",
    ],
    "03-search-and-indexing": [
        "./models/issues",
        "./models/project",
        "./modules/util",
        "./modules/indexer/issues",
        # bleve indexes into a temp dir in-process, so a SECOND backend runs the
        # shared suite here with no external service. elasticsearch and
        # meilisearch execute the identical suite when a server is configured
        # and self-skip otherwise, which is why the suite is the graded unit.
        "./modules/indexer/issues/bleve",
        # No live service exists in this image either, but each backend now carries
        # its OWN hidden test that runs its real Search() against a local, hermetic
        # httptest fake and inspects the outgoing query -- this is what proves the
        # plural filter is actually consumed rather than merely compiled against,
        # replacing a source-text regex check that a comment or a dead read could
        # satisfy.
        "./modules/indexer/issues/elasticsearch",
        "./modules/indexer/issues/meilisearch",
        "./modules/structs",
    ],
    "04-api-web-and-harden": [
        "./models/issues",
        "./models/project",
        "./modules/util",
        "./modules/indexer/issues",
        "./modules/indexer/issues/bleve",
        "./modules/indexer/issues/elasticsearch",
        "./modules/indexer/issues/meilisearch",
        "./modules/structs",
        "./modules/templates",
        # the router's own parse of the project filter, exercised through
        # services/context rather than through a stand-in
        "./services/context",
        "./services/projects",
        "./services/convert",
        "./services/issue",
        "./routers/web/repo",
        # The terminal stage changes these three and previously graded neither their
        # build nor their vet, so an agent could leave the API handler, the form
        # binding or the pull service broken and still finish the task.
        "./routers/api/v1/repo",
        "./services/forms",
        "./services/pull",
    ],
}

# Intermediate build scopes follow the dependency direction. Stage 02 changes the
# shape of methods that stage-04 callers use, so the whole tree does not compile
# until those callers are migrated - building only the changed packages is what
# makes an intermediate transition observable instead of forcing the entire change
# into the first patch. Stage 04 restores the full-tree build.
STAGE_BUILD = {
    "02-multi-project-model": ["./models/...", "./modules/util/..."],
    "03-search-and-indexing": ["./models/...", "./modules/..."],
    "04-api-web-and-harden": ["./..."],
}

RACE_PKGS = ["./models/issues", "./modules/indexer/issues"]

TRUSTED_DIRS = [
    "/opt/verifier-venv/bin",
    "/usr/local/go/bin",
    "/usr/local/sbin",
    "/usr/local/bin",
    "/usr/sbin",
    "/usr/bin",
    "/sbin",
    "/bin",
]

# base_gap_observed and no_production_changes are VERIFIER-owned facts: a run that does
# nothing at all satisfies both, which is exactly how the no-op banked 0.32 here. They remain
# critical gates -- a stage cannot pass without them -- but they no longer carry training
# credit the agent did not earn. The weight moves onto evidence the agent actually produced.
DIAGNOSE_WEIGHTS = {
    "base_gap_observed": 0.05,
    "reproducer_present": 0.05,
    "reproducer_runs": 0.25,
    "reproducer_demonstrates_gap": 0.45,
    # The briefing says plainly "do not change production (non-test) code yet".
    # An earlier revision stated that and never graded it, which QC flagged as the
    # verifier contradicting its own instruction.
    "no_production_changes": 0.02,
    "diagnosis_report": 0.13,
    "handoff": 0.05,
}

MODEL_WEIGHTS = {
    "build_clean": 0.20,
    "hidden_tests_pass": 0.55,
    "vet_clean": 0.15,
    "implementation_report": 0.07,
    "handoff": 0.03,
}

SEARCH_WEIGHTS = {
    "build_clean": 0.15,
    # elasticsearch and meilisearch routing is now proved by their own hidden tests
    # (hermetic httptest fakes asserting the real Search() request), folded into this
    # weight like every other backend's behaviour rather than carrying a separate
    # source-text check.
    "hidden_tests_pass": 0.62,
    "vet_clean": 0.15,
    "review_report": 0.05,
    "handoff": 0.03,
}

HARDEN_WEIGHTS = {
    "full_build": 0.20,
    "hidden_tests_pass": 0.45,
    "vet_clean": 0.10,
    "race_clean": 0.15,
    "gofmt_clean": 0.05,
    "final_report": 0.05,
}

WEIGHTS = {
    "01-diagnose": DIAGNOSE_WEIGHTS,
    "02-multi-project-model": MODEL_WEIGHTS,
    "03-search-and-indexing": SEARCH_WEIGHTS,
    "04-api-web-and-harden": HARDEN_WEIGHTS,
}

# Checks that must pass for binary_reward == 1.0.
#
# The rule is behaviour first: build, the injected upstream corpus, vet and race
# decide the outcome. Reporting artefacts (implementation.json, review_response.json,
# final_report.json), the documented setting, the migration registration, gofmt and
# the merge-ready declaration are weighted -- they shape training_score -- but none
# of them can fail a stage on its own, because a correct implementation must not be
# rejected over paperwork. This matters most at the terminal stage: the trial reward
# is that stage's reward (multi_step_reward_strategy = "final"), so making a report
# key critical there would let a JSON typo zero an entire correct trial.
#
# Stage 01 is executable evidence rather than a source-scope gate. Its compiler
# probes and reproducer decide binary success; report and handoff shape remain
# useful training signals but cannot reject otherwise valid diagnostic evidence.
CRITICAL_CHECKS = {
    # The rule, asserted in both directions by the package self-test: every
    # requirement a briefing states as mandatory is critical, and every
    # non-critical check is described in its prompt as "Scored but never
    # decisive". There is no third category.
    #
    # Stage 01 states the reproducer, the no-production-change rule and both
    # artifacts as graded, so all of them gate. Stage 04 says outright that every
    # item decides the outcome, so its critical set is its whole weight map -
    # including gofmt and the final report, which an earlier revision left
    # non-critical while the prompt still demanded them.
    # Diagnosis_report and handoff are SCHEMA checks on prose. They keep
    # their training weight but no longer gate, so a run with a working reproducer and a
    # correctly unchanged tree cannot be zeroed by a missing JSON key. What remains
    # critical here is all executable: the verifier's own base probes, and the agent's
    # reproducer actually failing on the unfixed tree.
    "01-diagnose": [
        "base_gap_observed",
        "reproducer_present",
        "reproducer_runs",
        "reproducer_demonstrates_gap",
        "no_production_changes",
    ],
    "02-multi-project-model": ["build_clean", "hidden_tests_pass", "vet_clean"],
    "03-search-and-indexing": ["build_clean", "hidden_tests_pass", "vet_clean"],
    # Everything executable gates; final_report.json does not. It keeps
    # its 0.15 training weight, but a stage whose build, hidden tests, vet, race and
    # gofmt all pass is a functional success and is scored as one.
    "04-api-web-and-harden": [k for k in HARDEN_WEIGHTS if k != "final_report"],
}

# Reference-solution leakage and non-local egress. Local work is explicitly OK.
LEAK_PATTERNS = [
    r"\b(?:cat|less|more|head|tail|bat|nl|od|xxd|strings)\b[^|;&\n]*\s/(?:tests|solution)\b",
    r"\b(?:cp|rsync|install)\b[^|;&\n]*\s/(?:tests|solution)\b",
    r"\b(?:grep|rg|ag|ack|awk|sed)\b[^|;&\n]*\s/(?:tests|solution)\b",
    r"\bfind\s+/(?:tests|solution)\b",
    r"\bls\b[^|;&\n]*\s/(?:tests|solution)\b",
    r"\bpython[0-9.]*\b[^\n]*\bopen\(\s*['\"]/(?:tests|solution)",
    r"\bgit\s+(?:remote|fetch|clone|pull|ls-remote)\b",
    r"\bgithub\.com/go-gitea\b",
    r"\bpulls?/36784\b",
    # INDIRECT reads of the protected trees. Copying, linking,
    # archiving or mounting them is the same disclosure as cat-ing them, and the
    # direct-read patterns above do not cover it.
    r"\b(?:ln|mount|tar|zip|7z|cpio|dd)\b[^|;&\n]*\s/(?:tests|solution)\b",
    r"\b(?:xargs|parallel)\b[^\n]*\s/(?:tests|solution)\b",
    r"/(?:tests|solution)/[^\s]*\s*(?:>|>>)\s*\S+",
]

# Runtime package installation. The image ships every dependency
# the task needs and the agent has no network, so any of these is either an
# attempt to reach the outside or an attempt to shim a tool the grader trusts.
RUNTIME_INSTALL = re.compile(
    r"\b(?:"
    r"go\s+(?:install|get)"
    r"|(?:apt|apt-get|apk|yum|dnf|zypper)\s+(?:install|add)"
    r"|(?:pip|pip3|python[0-9.]*\s+-m\s+pip)\s+install"
    r"|(?:npm|pnpm|yarn)\s+(?:install|add|i)\b"
    r"|cargo\s+install"
    r"|gem\s+install"
    r"|curl[^\n]*\|\s*(?:sh|bash)"
    r")\b",
    re.IGNORECASE,
)

# "fetch-then-remove" - retrieve something, then delete the trace.
# Matched only when both halves appear in ONE executed command line, which is what
# makes it an attempt to hide rather than two unrelated actions.
FETCH_THEN_REMOVE = re.compile(
    r"\b(?:curl|wget|git\s+(?:clone|fetch)|scp)\b[^\n]*(?:;|&&|\|\|)[^\n]*\brm\b",
    re.IGNORECASE,
)

# Non-local egress detection.
#
# This replaces a raw regex that produced a REAL false positive on a real agent
# trial: terminus-2 wrote its stage-01 reproducer with
#     python3 -c 'import os; content = "...\ncat << \"GOEOF\" > \"$TMP_TEST\"...'
# and the old pattern flagged it as network egress. Two independent defects
# combined, and both are fixed here:
#
#   1. In the stored command the escape is the two literal characters `\` + `n`.
#      `\` is a non-word character, so `\b` matched and `n` + `cat` read as the
#      netcat binary `ncat`. Escape sequences are now normalised to whitespace
#      BEFORE anything is matched, so a literal `\n` can never fuse with the next
#      word to invent a tool name.
#   2. The old pattern accepted any dotted token as a hostname, so the filename
#      `stage01_capability_check_test.go` satisfied `[a-z0-9-]+\.[a-z]{2,}`
#      ("test" "." "go"). A dotted token whose final label is a known file
#      extension is now treated as a path, not a host.
#
# The tool must also appear as its own token, not as a substring of prose, and a
# local address is still explicitly allowed - the agent is expected to talk to
# 127.0.0.1.
NETWORK_TOOLS = frozenset(
    {"curl", "wget", "nc", "ncat", "netcat", "telnet", "ssh", "scp", "sftp", "ftp", "rsync"}
)

LOCAL_HOSTS = frozenset({"127.0.0.1", "localhost", "::1", "0.0.0.0", "[::1]"})

# Final labels that mean "this is a path", not "this is a host".
PATH_SUFFIXES = frozenset(
    {
        "go", "mod", "sum", "md", "json", "yml", "yaml", "toml", "ini", "txt", "log",
        "sh", "bash", "py", "pyc", "tmpl", "html", "css", "js", "ts", "vue", "sql",
        "patch", "diff", "xml", "csv", "gz", "tgz", "tar", "zip", "bak", "orig",
        "example", "lock", "cfg", "conf", "test", "out", "tmp", "so", "a", "o",
        "proto", "pb", "svg", "png", "jpg", "gif", "ico", "env", "d", "in", "old",
    }
)

_ESCAPE_SEQUENCES = re.compile(r"\\[nrtfv0]")
_TOKEN_SPLIT = re.compile(r"[\s;&|<>()'\"`,]+")
_SCHEME = re.compile(r"^(?:https?|ftp|ftps|sftp|ssh|scp)://(.+)$", re.IGNORECASE)
_DOTTED_HOST = re.compile(r"^[a-z0-9][a-z0-9-]*(?:\.[a-z0-9-]+)+\.?$", re.IGNORECASE)


def egress_target(line: str) -> str | None:
    """The non-local host a command line reaches, or None.

    Returns the offending token so a finding can name it, instead of quoting 120
    characters of whatever happened to sit near the match.
    """
    normalised = _ESCAPE_SEQUENCES.sub(" ", line)
    tokens = [tok for tok in _TOKEN_SPLIT.split(normalised) if tok]
    if not tokens:
        return None
    # The tool has to be an actual argv token (allowing a path like /usr/bin/curl).
    if not any(tok.rsplit("/", 1)[-1].lower() in NETWORK_TOOLS for tok in tokens):
        return None
    for tok in tokens:
        scheme = _SCHEME.match(tok)
        if scheme:
            host = scheme.group(1).split("/")[0].split("@")[-1].split(":")[0]
            if host and host.lower() not in LOCAL_HOSTS:
                # The HOST, not the whole token, so both branches report the same
                # thing and a finding names what was actually contacted.
                return host
            continue
        # A bare dotted token only counts as a host when its last label is not a
        # file extension and it is not obviously a path. An absolute or relative
        # path is never a host, but `wget example.com/payload` and
        # `ssh user@build.internal.net` are, so userinfo, path and port are peeled
        # off before the token is judged.
        if tok.startswith(("/", "./", "../", "-")):
            continue
        candidate = tok.split("@")[-1].split("/")[0].split(":")[0]
        if not candidate or candidate.lower() in LOCAL_HOSTS:
            continue
        if _DOTTED_HOST.match(candidate):
            if candidate.rstrip(".").rsplit(".", 1)[-1].lower() not in PATH_SUFFIXES:
                return candidate
    return None

HANDOFF_FIELDS = {
    "stage": str,
    "summary": str,
    "next_steps": list,
}

# The per-stage report each stage hands to the next, as required key -> required
# type. This is the single definition: the graders below read it, the instructions
# state it, and tests/contracts/artifacts.schema.json is generated from it, so a
# schema a reviewer reads can never drift from the one that grades.
#
# Typed and bounded, in the checklist's sense: every field has a declared type, a
# non-empty requirement, and a size cap; extra keys are always allowed, so a later
# stage checks structure rather than the author's wording.
ARTIFACT_SCHEMAS: dict[str, dict[str, object]] = {
    "01-diagnose": {
        "file": "diagnosis.json",
        "fields": {
            "missing_capabilities": list,
            "affected_packages": list,
            "reproducer": str,
            "root_cause": str,
        },
    },
    "02-multi-project-model": {
        "file": "implementation.json",
        "fields": {
            "association_shape": str,
            "column_mapping": str,
            "single_project_compatibility": str,
            "packages_touched": list,
        },
    },
    "03-search-and-indexing": {
        "file": "review_response.json",
        "fields": {
            "filter_shape": str,
            "backends_covered": list,
            "wire_shape": str,
            "packages_touched": list,
        },
    },
    "04-api-web-and-harden": {
        "file": "final_report.json",
        "fields": {
            "feature_summary": str,
            "api_surface": list,
            "verification_performed": list,
            "residual_risks": list,
            "packages_touched": list,
        },
    },
}

# Handoffs are bounded as well as typed: a stage may not pass megabytes of context
# forward, and a verifier that reads one must not have to parse an unbounded file.
MAX_ARTIFACT_BYTES = 256 * 1024


def artifact_schema_document() -> dict:
    """The published JSON-Schema view of the contracts graded above."""
    type_names = {str: "string", list: "array", dict: "object", bool: "boolean"}

    def properties(fields: dict) -> dict:
        out = {}
        for key, want in fields.items():
            entry: dict[str, object] = {"type": type_names[want]}
            if want is str:
                entry["minLength"] = 1
            elif want is list:
                entry["minItems"] = 1
            out[key] = entry
        return out

    stages = {}
    for stage, spec in ARTIFACT_SCHEMAS.items():
        fields = spec["fields"]
        stages[stage] = {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "title": f"{stage} :: /app/output/{stage}/{spec['file']}",
            "type": "object",
            "additionalProperties": True,
            "required": sorted(fields),
            "properties": properties(fields),
        }
    return {
        "maxBytes": MAX_ARTIFACT_BYTES,
        "handoff": {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "title": "/app/output/handoff.json",
            "type": "object",
            "additionalProperties": True,
            "required": sorted(HANDOFF_FIELDS),
            "properties": properties(HANDOFF_FIELDS),
        },
        "stageReports": stages,
    }


# --------------------------------------------------------------------------- #
# process helpers
# --------------------------------------------------------------------------- #
GRADED_TEST_UID = int(os.environ.get("GRADED_TEST_UID", "2000"))


def in_container() -> bool:
    """True inside the task image.

    Deliberately NOT keyed on the checksum manifest: that file is a grading input,
    and an agent that deleted it would otherwise switch off every structural
    toolchain check at once. /testbed and the verifier venv are both created by the
    Dockerfile, and the literal paths are used so that redirecting TESTBED_DIR for
    an author-side self-test cannot make the host look like the image.
    """
    return Path("/testbed").is_dir() and Path("/opt/verifier-venv").is_dir()


def unprivileged_user() -> tuple[int, str] | None:
    """The uid to run gitea's own tests as, or None if we are already unprivileged.

    gitea's test bootstrap (modules/setting/testenv.go) unsets every GITEA_* env
    var that is not GITEA_TEST_* and then log.Fatal's if euid is 0, so its unit
    tests genuinely cannot run as root -- there is no env or config escape hatch
    once cleanUpEnv() has run. The image therefore ships an unprivileged account
    that owns /testbed and the Go caches, and every graded Go command drops to it.
    """
    if os.geteuid() != 0:
        return None
    try:
        import pwd

        entry = pwd.getpwuid(GRADED_TEST_UID)
    except (KeyError, ImportError):
        return None
    if drop_to(GRADED_TEST_UID) is None:
        return None
    return GRADED_TEST_UID, entry.pw_dir


def trusted_path() -> str:
    """PATH for graded subprocesses: canonical root-owned directories only.

    VERIFIER_EXTRA_PATH is an author-only affordance for validating this grader
    outside the image; it is ignored inside the container, and the agent cannot
    influence the verifier's environment in any case.
    """
    dirs = list(TRUSTED_DIRS)
    extra = os.environ.get("VERIFIER_EXTRA_PATH", "")
    if extra and not in_container():
        dirs = [d for d in extra.split(":") if d] + dirs
    return ":".join(dirs)


def hardened_env(extra: dict[str, str] | None = None) -> dict[str, str]:
    """Env for every graded subprocess.

    PATH is rebuilt from canonical root-owned directories so a wrapper the agent
    dropped earlier on PATH is never consulted. Go's caches are pinned to the
    image-warmed locations and the toolchain may not self-upgrade.
    """
    env = {
        "PATH": trusted_path(),
        "HOME": os.environ.get("HOME", "/root"),
        "LANG": "C.UTF-8",
        "GOWORK": "off",
        "GOTOOLCHAIN": "local",
        "GOFLAGS": "",
        "GOPROXY": "off",
        # Deliberately NOT setting GITEA_TEST_CONF. modules/setting/testenv.go
        # gives unit tests a private temp config when it is unset, so concurrent
        # tests cannot data-race over one file. Setting it is right for a task that
        # grades MIGRATION tests; this task grades unit tests, and pointing them at
        # tests/sqlite.ini made every one of them abort in
        # InitWorkPathAndCfgProvider. Confirmed in the built image: unset, the
        # graded packages all pass on the pristine base; set, they all die.
        # Helps any non-test gitea invocation that runs as root. It does NOT help
        # `go test`: the test bootstrap unsets GITEA_* vars before the root check,
        # which is why graded Go commands drop privileges instead.
        "GITEA_I_AM_BEING_UNSAFE_RUNNING_AS_ROOT": "true",
        # The image guarantees a C toolchain (needed by -race); only enable cgo
        # when one is actually present so a missing compiler cannot masquerade as
        # a broken submission.
        "CGO_ENABLED": "1" if cgo_available() else "0",
    }
    if in_container():
        env.update({"GOPATH": "/go", "GOMODCACHE": "/go/pkg/mod", "GOCACHE": "/gocache"})
    else:
        for key in ("GOPATH", "GOMODCACHE", "GOCACHE"):
            if os.environ.get(key):
                env[key] = os.environ[key]
    if extra:
        env.update(extra)
    return env


def drop_to(uid: int):
    """A preexec hook that becomes `uid` in the child, or None if not possible.

    Used instead of exec'ing a helper such as setpriv: a launcher binary would be
    one more root-owned image file on the graded path, and therefore one more file
    a root agent could replace with something that fabricates the run's output.
    setresuid/setresgid are syscalls made by the already-running verifier process,
    so there is nothing on disk between the decision and the exec.
    """
    if os.name != "posix" or not hasattr(os, "setresuid"):
        return None

    def hook() -> None:
        os.setgroups([])
        os.setresgid(uid, uid, uid)
        os.setresuid(uid, uid, uid)

    return hook


def run(
    cmd: list[str],
    *,
    cwd: Path = TESTBED,
    timeout: int = 900,
    env: dict[str, str] | None = None,
    as_uid: int | None = None,
) -> tuple[int, str]:
    preexec = drop_to(as_uid) if as_uid is not None else None
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(cwd),
            env=env or hardened_env(),
            capture_output=True,
            text=True,
            timeout=timeout,
            preexec_fn=preexec,
        )
    except subprocess.TimeoutExpired:
        return 124, f"TIMEOUT after {timeout}s: {' '.join(cmd)}"
    except (OSError, ValueError) as exc:  # missing binary, bad args
        return 127, f"EXEC FAILED: {exc}"
    return proc.returncode, (proc.stdout or "") + (proc.stderr or "")


def tail(text: str, limit: int = 3000) -> str:
    text = text or ""
    return text if len(text) <= limit else text[-limit:]


def atomic_write_text(path: Path, content: str) -> None:
    """Replace an artifact without exposing a truncated destination file.

    Harbor may terminate the verifier at any instruction boundary. Writing beside
    the destination and replacing it only after close keeps the early zero-reward
    sentinel valid until a complete final document is ready.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    temporary.write_text(content, encoding="utf-8")
    os.replace(temporary, path)


_SIGNAL_PREFIXES = ("--- FAIL", "FAIL", "ok  ", "ok\t", "panic:", "# ", "?   ")
_SIGNAL_SUBSTRINGS = (
    "undefined:",
    "cannot use",
    "unknown field",
    "no field or method",
    "Error Trace:",
    "Error:",
    "Test:",
    "expected",
    "DATA RACE",
    "build failed",
)


def summarize_go(out: str, limit: int = 2500) -> str:
    """Keep the lines that explain a Go failure.

    Gitea's packages log heavily at startup, so a raw tail is usually deprecation
    notices rather than the actual error.
    """
    kept = [
        line
        for line in (out or "").splitlines()
        if line.startswith(_SIGNAL_PREFIXES)
        or any(token in line for token in _SIGNAL_SUBSTRINGS)
    ]
    return tail("\n".join(kept) if kept else (out or ""), limit)


# --------------------------------------------------------------------------- #
# hidden test injection
# --------------------------------------------------------------------------- #
def stages_upto(stage: str) -> list[str]:
    idx = STAGES.index(stage)
    return [s for s in STAGES[1 : idx + 1]]


def git_show(base: str, rel: str) -> bytes | None:
    """The base commit's exact bytes for one path, or None if it is not there."""
    try:
        proc = subprocess.run(
            ["git", "-C", str(TESTBED), "show", f"{base}:{rel}"],
            env=hardened_env(),
            capture_output=True,
            timeout=120,
        )
    except (subprocess.TimeoutExpired, OSError):
        return None
    return proc.stdout if proc.returncode == 0 else None


def _is_test_bootstrap(rel: str) -> bool:
    """Whether this test file governs whether OTHER tests in its package run at all.

    gitea puts `unittest.MainTest` in per-package `main_test.go`, so that file (and anything
    declaring TestMain) decides if the package's database fixture exists. Those are the files
    a submission could rewrite to suppress graded execution, so they are verifier-owned.
    """
    name = rel.rsplit("/", 1)[-1]
    if name in {"main_test.go", "test_main.go"}:
        return True
    try:
        return "func TestMain(" in (TESTBED / rel).read_text(encoding="utf-8", errors="replace")
    except OSError:
        return False


def restore_deleted_tests(backups: dict[str, bytes | None]) -> int:
    """Put back in-tree test files the agent deleted, for the graded run only.

    Deleting test files can never help an agent: the graded corpus is injected from a
    mount the agent cannot reach. But it *can* remove a package's own test bootstrap
    -- gitea's `main_test.go` files call unittest.MainTest, which builds the in-memory
    database every test in that package needs -- and a correct implementation would
    then be failed by nil-pointer panics that have nothing to do with its work. The
    grader therefore restores what was removed before it grades, and undoes that
    afterwards like every other injection.

    Only DELETED paths are touched. A test file the agent legitimately rewrote (which
    the instructions expect after a disclosed signature change) is graded exactly as
    the agent left it.
    """
    base = base_commit()
    if not base:
        return 0
    # D = deleted, M = modified. Modified matters as much as deleted: a package's TestMain
    # IS a test file, so leaving modifications in place lets the submission rewrite the
    # bootstrap that every graded test in that package runs through -- it can skip, exit 0,
    # or print pass-looking lines. Bootstrap files are verifier-owned for the graded run and
    # are restored to their base content, then undone afterwards like any other injection.
    rc, out = run(
        ["git", "-C", str(TESTBED), "diff", "--diff-filter=DM", "--name-only", base,
         "--", "*_test.go"],
        timeout=300,
    )
    if rc != 0:
        return 0
    restored = 0
    for rel in sorted({line.strip() for line in out.splitlines() if line.strip()}):
        dst = TESTBED / rel
        content = git_show(base, rel)
        if content is None:
            continue
        if dst.exists():
            # Only bootstrap files are forced back. A test the agent legitimately rewrote
            # after a disclosed signature change is still graded as the agent left it.
            if not _is_test_bootstrap(rel):
                continue
            try:
                if dst.read_bytes() == content:
                    continue
            except OSError:
                pass
        if str(dst) not in backups:
            backups[str(dst)] = None  # absent before us, so remove it again afterwards
        dst.parent.mkdir(parents=True, exist_ok=True)
        try:
            dst.write_bytes(content)
        except OSError:
            continue
        restored += 1
    return restored


def corpus_files(root: Path) -> list[Path]:
    """Every protected file for a stage.

    Almost all of them are `*_test.go`. The exception is the issue-indexer's
    shared suite, which lives in a plain `.go` file because the four backend
    packages import it; it is still test-only code and is still authoritative,
    so it is injected and restored exactly like the rest of the corpus.
    """
    files = set(root.rglob("*_test.go"))
    files |= {q for q in root.rglob("*.go") if "/internal/tests/" in q.as_posix()}
    return sorted(files)


def inject_hidden(
    stages: list[str], backups: dict[str, bytes | None] | None = None
) -> dict[str, bytes | None]:
    """Copy the upstream test corpus into /testbed, remembering exact originals."""
    backups = {} if backups is None else backups
    for st in stages:
        root = HIDDEN_ROOT / st
        if not root.is_dir():
            continue
        for src in corpus_files(root):
            rel = src.relative_to(root)
            dst = TESTBED / rel
            if str(dst) not in backups:
                backups[str(dst)] = dst.read_bytes() if dst.is_file() else None
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(src, dst)
    return backups


def restore_hidden(backups: dict[str, bytes | None]) -> None:
    for path_str, original in backups.items():
        path = Path(path_str)
        try:
            if original is None:
                path.unlink(missing_ok=True)
            else:
                path.write_bytes(original)
        except OSError:
            pass


def hidden_corpus_size(stages: list[str]) -> int:
    return sum(
        len(corpus_files(HIDDEN_ROOT / st))
        for st in stages
        if (HIDDEN_ROOT / st).is_dir()
    )


# --------------------------------------------------------------------------- #
# go gates
# --------------------------------------------------------------------------- #
def go_cmd(args: list[str], timeout: int) -> tuple[int, str]:
    """Run a go command, unprivileged when we hold root (see unprivileged_user).

    The privilege drop happens in the forked child via setresuid, so `go` is the
    only executable on this path and the whole path is covered by the toolchain
    checks. Nothing is exec'd to arrange the drop.
    """
    info = unprivileged_user()
    if info is None:
        return run(["go", *args], timeout=timeout)
    uid, home = info
    return run(
        ["go", *args],
        timeout=timeout,
        env=hardened_env({"HOME": home}),
        as_uid=uid,
    )


def go_build(pkgs: list[str], timeout: int = 1500) -> tuple[bool, str]:
    rc, out = go_cmd(["build", *pkgs], timeout)
    return rc == 0, summarize_go(out)


def go_vet(pkgs: list[str], timeout: int = 1200) -> tuple[bool, str]:
    rc, out = go_cmd(["vet", *pkgs], timeout)
    return rc == 0, summarize_go(out, 2000)


# Every `--- PASS/FAIL/SKIP:` line seen across this stage's Go runs, in order, so
# the stage can publish one CTRF entry per real test function rather than only the
# grader's own check names. See write_ctrf.
GO_TEST_EVENTS: list[dict] = []

_GO_RESULT_LINE = re.compile(
    r"^(?P<indent>[ \t]*)--- (?P<status>PASS|FAIL|SKIP): (?P<name>\S+) \((?P<secs>[\d.]+)s\)",
    re.MULTILINE,
)
_GO_CTRF_STATUS = {"PASS": "passed", "FAIL": "failed", "SKIP": "skipped"}


def record_go_events(out: str, suite: str) -> None:
    """Collect per-function results from a `go test -json` run for the CTRF report.

    go_test() always passes -json, whose output is one JSON object per line
    ({"Action":"pass"|"fail"|"skip", "Test":"TestFoo", "Elapsed":0.01, ...}), never
    the `--- PASS: TestFoo (0.01s)` verbose-text lines _GO_RESULT_LINE was written to
    match. That regex silently matched nothing against real -json output, so every
    CTRF report populated from it carried zero Go test cases -- a green stage with
    real, executed tests looked identical to one where the grader never ran anything.
    Falls back to the text regex only for output that genuinely isn't JSON (e.g. a
    harness-level bootstrap failure with no encoded events at all), so a caller that
    somehow still hands this verbose text is not silently dropped either.
    """
    raw = out or ""
    saw_json_event = False
    for line in raw.splitlines():
        line = line.strip()
        if not line.startswith("{"):
            continue
        try:
            event = json.loads(line)
        except ValueError:
            continue
        action = event.get("Action")
        test = event.get("Test")
        # Package-level summary events (Action=pass/fail with no "Test" key) are not
        # individual test cases; only per-test/per-subtest events belong in the report.
        if not isinstance(test, str) or not test or action not in ("pass", "fail", "skip"):
            continue
        saw_json_event = True
        GO_TEST_EVENTS.append(
            {
                "name": test,
                "status": _GO_CTRF_STATUS[action.upper()],
                "duration": int(float(event.get("Elapsed") or 0.0) * 1000),
                "suite": suite,
            }
        )
    if saw_json_event:
        return
    for match in _GO_RESULT_LINE.finditer(raw):
        GO_TEST_EVENTS.append(
            {
                "name": match.group("name"),
                "status": _GO_CTRF_STATUS[match.group("status")],
                "duration": int(float(match.group("secs")) * 1000),
                "suite": suite,
            }
        )


def excuse_go_events(excused: list[str]) -> None:
    """Re-label an excused failure in the report as skipped, with the reason.

    The report is the reviewer's view of the run, so it must agree with the
    verdict. Leaving `TestPullRequestMergeable/*-MergeTree` marked failed on a run
    the grader scored 1.0 would show a passing stage as having failing tests --
    which is the same class of contradiction that made four green stages read as
    FAILED. Only a failure the verdict already excused is touched; a blocking
    failure keeps its status, and this is never called when anything blocks.
    """
    if not excused:
        return
    reasons = {
        entry["test"]: entry["requires"]
        for entry in ENV_DEPENDENT_FAILURES
        if not entry["supported"]()
    }
    names = set(excused)
    for event in GO_TEST_EVENTS:
        if event["name"] not in names or event["status"] != "failed":
            continue
        event["status"] = "skipped"
        event["message"] = (
            "excused: this image cannot run it -- "
            f"{reasons.get(event['name'].split('/')[0], 'unsupported environment')}"
        )


def graded_pkg_dirs(pkgs: list[str]) -> list[Path]:
    """The /testbed directories behind a concrete graded package list."""
    dirs: list[Path] = []
    for pkg in pkgs:
        rel = pkg.lstrip("./")
        if not rel or "..." in rel:
            continue
        directory = TESTBED / rel
        if directory.is_dir():
            dirs.append(directory)
    return dirs


def ensure_graded_pkgs_writable(pkgs: list[str]) -> list[str]:
    """Return ownership of the graded package directories to the test account.

    The image ships /testbed owned by GRADED_TEST_UID on purpose: gitea's
    generated sqlite test config sets a *relative* `PATH = gitea.db`, and
    `go test` runs every test binary with its own package directory as the
    working directory, so each DB-backed package creates and deletes its scratch
    database beside its sources. Graded Go commands must drop to that account
    because gitea's test bootstrap refuses to run as root.

    Anything root creates in the tree during a trial breaks that invariant --
    a package the submission adds (modules/indexer/issues/... does not
    exist at the base commit), or the protected corpus this verifier copies in.
    The directory then lands root-owned 0755 and sqlite fails to open its
    database, which would fail the stage for an environment reason rather than a
    behavioural one. Repairing ownership first keeps the graded surface
    behavioural.

    Ownership is never an assertion in this grader, so this cannot mask a real
    failure or manufacture a pass; it only removes a permission-denied artefact
    of running the tree as two different users.
    """
    if os.geteuid() != 0:
        return []
    repaired: list[str] = []
    for directory in graded_pkg_dirs(pkgs):
        for path in (directory, *directory.rglob("*")):
            try:
                if path.stat().st_uid == GRADED_TEST_UID:
                    continue
                os.chown(path, GRADED_TEST_UID, GRADED_TEST_UID)
            except OSError:
                continue
            try:
                repaired.append(str(path.relative_to(TESTBED)))
            except ValueError:
                repaired.append(str(path))
    return repaired


def readable_from_json(raw: str) -> str:
    """Reconstruct human-readable go test output from a -json event stream.

    Everything a developer needs to diagnose a failure lives in the Output events; without
    this, switching to -json would leave the failure log full of JSON objects.
    """
    if "{" not in raw:
        return raw
    chunks: list[str] = []
    saw_event = False
    for line in raw.splitlines():
        line = line.strip()
        if not line.startswith("{"):
            if line:
                chunks.append(line + "\n")
            continue
        try:
            event = json.loads(line)
        except ValueError:
            continue
        saw_event = True
        text = event.get("Output")
        if isinstance(text, str):
            chunks.append(text)
    return "".join(chunks) if saw_event else raw


def go_test(
    pkgs: list[str], timeout: int = 1800, race: bool = False, verbose: bool = False
) -> tuple[bool, str, str]:
    """Run the tests. Returns (passed, summary, raw output)."""
    # Graded Go commands run unprivileged, so the packages under test have to be
    # owned by that account before the sqlite-backed ones can open a database in
    # their own directory. See ensure_graded_pkgs_writable.
    repaired = ensure_graded_pkgs_writable(pkgs)
    if repaired:
        RESULT_DIR.mkdir(parents=True, exist_ok=True)
        (RESULT_DIR / "ownership_repairs.txt").write_text(
            "\n".join(repaired) + "\n", encoding="utf-8"
        )
    # Match Gitea's upstream TEST_TAGS and migration target exactly. Without both
    # sqlite tags the configured driver is intentionally absent and every DB-backed
    # package aborts before protected tests can run. Migration packages also share
    # one sqlite work path, so serialize package execution to avoid DB races.
    # -json makes the test binary's own harness emit structured {Package, Test, Action}
    # records. Pass/fail is decided from those rather than from printed text, which a
    # modified TestMain could fabricate. -json implies -v, so verbosity is no longer a
    # separate switch; the readable text is reconstructed from Output events below.
    args = [
        "test",
        "-json",
        "-count=1",
        "-p=1",
        GO_TEST_TAGS,
    ]
    # -v intentionally not added: -json already implies it, and passing both muddies the
    # stream without adding information.
    if race:
        args.append("-race")
    # Order-independence has to be PROVABLE. The shuffle control used to export
    # GOFLAGS='-shuffle=on', but hardened_env deliberately clears GOFLAGS, so the flag never
    # reached the toolchain and the control was silently a no-op that proved nothing. Honour an
    # explicit control variable and pass it as a real argument instead.
    shuffle = os.environ.get("STAGE_TEST_SHUFFLE", "").strip()
    if shuffle:
        args.append(f"-shuffle={shuffle}")
    args.extend(pkgs)
    rc, out = go_cmd(args, timeout)
    record_go_events(out or "", "go test" + (" -race" if race else ""))
    # With -json the raw stream is one JSON record per line, which is unreadable in a
    # failure log and useless in a summary. Reconstruct the developer-facing text once
    # and use it for both. A build failure never reaches the JSON harness at all, so
    # readable_from_json returns that output unchanged and the compile error survives --
    # which is the failure a run with no implementation actually produces.
    readable = readable_from_json(out or "")
    if rc == 0:
        return True, summarize_go(readable, 800), out or ""
    RESULT_DIR.mkdir(parents=True, exist_ok=True)
    (RESULT_DIR / "go_test_failure.log").write_text(readable, encoding="utf-8")
    return False, summarize_go(readable, 4000), out or ""


def expected_graded_tests(stages: list[str]) -> set[str]:
    """The top-level test functions the injected corpus is supposed to run."""
    names: set[str] = set()
    for st in stages:
        root = HIDDEN_ROOT / st
        if not root.is_dir():
            continue
        for src in corpus_files(root):
            try:
                text = src.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            # A top-level test takes exactly one parameter. The shared indexer suite
            # exports `TestIndexer(t *testing.T, indexer internal.Indexer)`, which is a
            # helper the backends call - `go test` never reports it under that name, so
            # counting it would make the graded-test check unsatisfiable.
            names.update(re.findall(
                r"^func (Test[A-Za-z0-9_]*)\s*\(\s*[A-Za-z_]\w*\s+\*testing\.T\s*\)",
                text, re.MULTILINE))
    names.discard("TestMain")
    return names


def observed_test_outcomes(out: str) -> tuple[set[str], set[str]]:
    """(passed, not-passed) top-level test names, read from `go test -v` output.

    The name pattern stops at "/", so a subtest line credits its PARENT. A parent with
    one passing and one failing subtest therefore lands in both sets, and subtracting
    the wrong way round ("other - passed") silently DELETED the failure. Failure wins.
    """
    passed = set(re.findall(r"^\s*--- PASS: (Test[A-Za-z0-9_]+)", out, re.MULTILINE))
    other = set(re.findall(r"^\s*--- (?:FAIL|SKIP): (Test[A-Za-z0-9_]+)", out, re.MULTILINE))
    return passed - other, other


def observed_test_outcomes_json(raw: str) -> tuple[set[str], set[str]]:
    """Pass/fail decided from `go test -json` action events, not from printed lines.

    `--- PASS:` in combined output is just text on stdout, and a modified TestMain or helper
    can print it without running anything. The JSON stream emits structured {Package, Test,
    Action} records produced by the test binary's own harness, and a test is credited only
    when a "run" event and a terminal "pass" event are both seen for the same identity.
    """
    started: set[str] = set()
    passed: set[str] = set()
    not_passed: set[str] = set()
    for line in raw.splitlines():
        line = line.strip()
        if not line.startswith("{"):
            continue
        try:
            event = json.loads(line)
        except ValueError:
            continue
        name = event.get("Test")
        action = event.get("Action")
        if not name or not action:
            continue
        top = name.split("/", 1)[0]
        if action == "run":
            started.add(top)
        elif action == "pass":
            passed.add(top)
        elif action in {"fail", "skip"}:
            not_passed.add(top)
    # A pass with no matching run event is not evidence that the test executed.
    passed &= started
    # Subtests collapse onto their parent identity, so a top-level name can appear in
    # BOTH sets: one subtest passes, another fails. Without this the parent counted as
    # passed and the check reported "all graded test functions ran and passed" for a run
    # whose subtest had failed -- a real submission was only caught by the separate text
    # verdict. A parent is credited only when nothing under it failed or skipped.
    passed -= not_passed
    return passed, not_passed


def graded_tests_all_ran(stages: list[str], out: str) -> tuple[bool, str]:
    """Every graded test must be seen passing, not merely leave `go test` exit 0.

    `go test` reports success for a package whose tests never ran -- a TestMain that
    exits 0, a build tag that excludes the file, a t.Skip. The corpus is the reward, so
    a silent non-run is treated exactly like a failure.
    """
    expected = expected_graded_tests(stages)
    if not expected:
        return True, "no graded test functions expected"
    # Prefer the structured stream; fall back to text only when no JSON events exist
    # (older invocation paths), and say so in the detail rather than silently.
    passed, not_passed = observed_test_outcomes_json(out)
    evidence = "go test -json events"
    if not passed and not not_passed:
        passed, not_passed = observed_test_outcomes(out)
        evidence = "printed output (no JSON events seen)"
    missing = sorted(expected - passed)
    if not missing:
        return True, f"all {len(expected)} graded test functions ran and passed ({evidence})"
    skipped_or_failed = sorted(set(missing) & not_passed)
    never_ran = sorted(set(missing) - not_passed)
    parts = []
    if never_ran:
        parts.append(f"never ran: {never_ran[:8]}")
    if skipped_or_failed:
        parts.append(f"skipped or failed: {skipped_or_failed[:8]}")
    return False, (
        f"{len(missing)} of {len(expected)} graded test functions did not pass ("
        + "; ".join(parts)
        + ")"
    )


# --------------------------------------------------------------------------- #
# environment capability probes
# --------------------------------------------------------------------------- #
def git_version() -> tuple[int, int] | None:
    rc, out = run(["git", "--version"], timeout=60)
    if rc != 0:
        return None
    match = re.search(r"git version (\d+)\.(\d+)", out or "")
    return (int(match.group(1)), int(match.group(2))) if match else None


def git_supports_merge_base() -> bool:
    """`git merge-tree --merge-base=<oid>` was added in git 2.40."""
    version = git_version()
    return version is not None and version >= (2, 40)


# Upstream failures in the graded packages that this image causes and the agent
# cannot fix.
#
# gitea's services/pull conflict detection shells out to
# `git merge-tree --merge-base=<oid>`, an option git only understands from 2.40.
# The pinned base is Debian bookworm (git 2.39), so TestPullRequestMergeable's
# MergeTree subtests fail identically at the base commit and under upstream's own
# production code -- the Oracle proved that twice. Failing a stage on them grades
# the image, not the agent.
#
# These tests are deliberately NOT filtered out with `go test -skip`. Two reasons.
# Go's filter grammar splits a pattern on `/` into one regexp per subtest level and
# ignores a `/` inside a group, so a grouped `A/B` pattern silently degrades to a
# top-level match that never fires -- which is exactly how the v3 attempt failed.
# More importantly, a skipped test proves nothing: letting it run and requiring the
# failure to carry `signature` means the excuse is evidence-backed. If the agent
# breaks that test some other way, the signature will not match and the stage still
# fails.
#
# Every excuse is conditional on a probe (`supported`), so a newer-git image
# removes it automatically, and no graded corpus function can ever be excused.
ENV_DEPENDENT_FAILURES: tuple[dict, ...] = (
    {
        "test": "TestPullRequestMergeable",
        "subtests": r"^TestPullRequestMergeable/[^/]*-MergeTree$",
        "packages": ("code.gitea.io/gitea/services/pull",),
        "signature": r"unknown option `merge-base",
        "requires": "git >= 2.40 for `git merge-tree --merge-base`",
        "supported": git_supports_merge_base,
    },
)

# `[ \t]`, never `\s`: with re.MULTILINE, `\s` swallows the newline, so go test's
# bare trailing "FAIL" line reads as a package named by whatever follows it.
_FAIL_LINE = re.compile(r"^[ \t]*--- FAIL: (\S+)", re.MULTILINE)
_PKG_FAIL_LINE = re.compile(r"^FAIL[ \t]+(\S+)", re.MULTILINE)
_UNSCORABLE = (
    "[build failed]",
    "[setup failed]",
    "panic: test timed out",
    "cannot find package",
)


def active_env_failures(out: str) -> list[dict]:
    """Entries whose capability is genuinely missing and whose evidence is present."""
    return [
        entry
        for entry in ENV_DEPENDENT_FAILURES
        if not entry["supported"]() and re.search(entry["signature"], out or "")
    ]


def _recorded_base_failures(path: str) -> frozenset[str]:
    """One of the lists the image built by testing the pristine base commit.

    The image records these while the worktree is still the untouched base and
    before any protected test exists in it, so an entry is evidence that this
    environment cannot run that upstream test -- never evidence about a
    submission. A missing file simply means no excuse is available.
    """
    try:
        text = Path(path).read_text(encoding="utf-8", errors="replace")
    except OSError:
        return frozenset()
    return frozenset(line.strip() for line in text.splitlines() if line.strip())


_BASE_FAILING_TESTS: frozenset[str] | None = None
_BASE_FAILING_PACKAGES: frozenset[str] | None = None


def base_failing_tests() -> frozenset[str]:
    global _BASE_FAILING_TESTS
    if _BASE_FAILING_TESTS is None:
        _BASE_FAILING_TESTS = _recorded_base_failures(
            os.environ.get("BASE_FAILING_TESTS", "/opt/base-failing-tests.txt")
        )
    return _BASE_FAILING_TESTS


def base_failing_packages() -> frozenset[str]:
    global _BASE_FAILING_PACKAGES
    if _BASE_FAILING_PACKAGES is None:
        _BASE_FAILING_PACKAGES = _recorded_base_failures(
            os.environ.get("BASE_FAILING_PACKAGES", "/opt/base-failing-packages.txt")
        )
    return _BASE_FAILING_PACKAGES


def failed_on_pristine_base(name: str) -> bool:
    recorded = base_failing_tests()
    return name in recorded or name.split("/")[0] in recorded


def graded_run_verdict(
    exit_ok: bool, out: str, stages: list[str]
) -> tuple[bool, list[str], list[str]]:
    """Decide a graded `go test` run. Returns (passed, excused, blocking).

    A clean exit passes outright. A dirty exit passes only when every reported
    failure is one this image causes: named by ENV_DEPENDENT_FAILURES, evidenced by
    its signature, never part of the graded corpus, and confined to the package
    that owns it. Anything else -- a compile error, a package that failed without
    naming a test, a graded function, any other test -- blocks.
    """
    if exit_ok:
        return True, [], []

    # Callers hand this the raw `go test -json` stream, where every line starts with
    # '{"Time":...' and the printed "--- FAIL:"/"FAIL\tpkg" lines exist only inside
    # Output events. Both patterns below are line-anchored, so against the raw stream
    # they matched NOTHING: every dirty run looked like "failed without naming a test",
    # no environmental failure could ever be excused, and a real failure was reported
    # with the wrong reason. Normalise to the readable text first. readable_from_json
    # returns non-JSON input unchanged, so plain text callers are unaffected.
    text = readable_from_json(out or "")
    blocking: list[str] = []
    for marker in _UNSCORABLE:
        if marker in text:
            blocking.append(f"unscorable run: {marker}")

    entries = active_env_failures(text)
    graded = expected_graded_tests(stages)
    allowed_pkgs = {pkg for entry in entries for pkg in entry["packages"]}
    allowed_pkgs |= set(base_failing_packages())

    failures = sorted(set(_FAIL_LINE.findall(text)))
    if not failures:
        blocking.append("`go test` failed without naming a failing test")

    excused: list[str] = []
    for name in failures:
        if name in graded or name.split("/")[0] in graded:
            blocking.append(f"graded test failed: {name}")
            continue
        if any(
            name == entry["test"] or re.match(entry["subtests"], name)
            for entry in entries
        ):
            excused.append(name)
        elif failed_on_pristine_base(name):
            # Already red on the untouched base commit in this image, so it
            # cannot be evidence about the submission.
            excused.append(name)
        else:
            blocking.append(f"unexpected test failure: {name}")

    for pkg in sorted(set(_PKG_FAIL_LINE.findall(text))):
        if pkg not in allowed_pkgs:
            blocking.append(f"package failed outside the excused set: {pkg}")

    if not blocking:
        excuse_go_events(excused)
    return not blocking, excused, blocking


def env_failure_notes() -> list[str]:
    """What this image cannot run, for the check detail."""
    notes = [
        f"{entry['test']} needs {entry['requires']}"
        for entry in ENV_DEPENDENT_FAILURES
        if not entry["supported"]()
    ]
    recorded = sorted(base_failing_tests())
    if recorded:
        notes.append(
            "already failing on the pristine base commit in this image: "
            + ", ".join(recorded)
        )
    return notes


def cgo_available() -> bool:
    """Whether a C toolchain exists (required by `go test -race`).

    Resolved with a direct PATH lookup rather than by running a subprocess, since
    hardened_env() consults this while building its own environment.
    """
    path = trusted_path()
    return any(shutil.which(cc, path=path) for cc in ("gcc", "cc", "clang"))


# --------------------------------------------------------------------------- #
# repository state
# --------------------------------------------------------------------------- #
# Written by the image while /testbed is still pristine; read back by integrity()
# to prove the tree being graded is still the tree the image built.
REPO_IDENTITY_ANCHOR = Path(
    os.environ.get("REPO_IDENTITY_ANCHOR", "/opt/verifier-base-commit.txt")
)

# Executable bits are not enough on Windows-authored trees and not meaningful for
# scripts, so a "generated executable" means an ELF image the agent added.
def generated_executables() -> list[str]:
    """Untracked ELF binaries inside the graded worktree.

    Restricted to UNTRACKED files so a legitimate edit to a tracked file can never
    trip it, and to the ELF magic so a shell script the agent wrote as part of its
    reproducer is not mistaken for a smuggled binary.
    """
    rc, out = run(
        ["git", "-C", str(TESTBED), "ls-files", "--others", "--exclude-standard"],
        timeout=300,
    )
    if rc != 0:
        return []
    found: list[str] = []
    for rel in out.splitlines():
        rel = rel.strip()
        if not rel:
            continue
        path = TESTBED / rel
        try:
            if not path.is_file() or path.is_symlink() or path.stat().st_size < 4:
                continue
            with path.open("rb") as handle:
                if handle.read(4) == b"\x7fELF":
                    found.append(rel)
        except OSError:
            continue
        if len(found) >= 20:
            break
    return sorted(found)


def base_commit() -> str | None:
    """The sanitized synthetic base commit (the repository's root commit)."""
    rc, out = run(
        ["git", "-C", str(TESTBED), "rev-list", "--max-parents=0", "HEAD"], timeout=180
    )
    if rc != 0:
        return None
    shas = [line.strip() for line in out.splitlines() if line.strip()]
    return shas[-1] if shas else None


def changed_files() -> list[str]:
    """Every path changed since the base, including staged, untracked and deleted.

    Diffing against the base commit rather than HEAD means work stays visible
    whether or not it was committed.
    """
    seen: set[str] = set()
    base = base_commit()
    arg_sets: list[list[str]] = [
        ["ls-files", "--others", "--exclude-standard"],
        ["ls-files", "--deleted"],
    ]
    if base:
        arg_sets.append(["diff", "--name-only", base])
        arg_sets.append(["diff", "--cached", "--name-only", base])
    else:  # no history to compare against; fall back to the working tree
        arg_sets.append(["diff", "--name-only"])
        arg_sets.append(["diff", "--cached", "--name-only"])
    for args in arg_sets:
        rc, out = run(["git", "-C", str(TESTBED), *args], timeout=180)
        if rc == 0:
            seen.update(line.strip() for line in out.splitlines() if line.strip())
    return sorted(seen)


def gofmt_offenders(paths: list[str]) -> tuple[bool, str]:
    go_files = [p for p in paths if p.endswith(".go") and (TESTBED / p).is_file()]
    if not go_files:
        return True, "no changed .go files"
    rc, out = run(["gofmt", "-l", *go_files], timeout=300)
    if rc != 0:
        return False, tail(out)
    offenders = [line for line in out.splitlines() if line.strip()]
    return (not offenders), ("unformatted: " + ", ".join(offenders) if offenders else "clean")


# --------------------------------------------------------------------------- #
# integrity
# --------------------------------------------------------------------------- #
def sha256_file(path: Path) -> str | None:
    try:
        h = hashlib.sha256()
        with path.open("rb") as fh:
            for chunk in iter(lambda: fh.read(1 << 20), b""):
                h.update(chunk)
        return h.hexdigest()
    except OSError:
        return None


# Every binary the graded path can reach. `go` and `gofmt` produce the verdicts;
# `git`, `python3`, `bash`, `sh`, `sha256sum` and `gcc` are reachable from the
# grader or from the toolchain it drives. `setpriv`, `env` and `sudo` are not used
# by this verifier -- privileges are dropped with setresuid inside the forked child
# (see drop_to) rather than by exec'ing a helper -- but they are listed so that a
# launcher reintroduced here, or one already present in the image, is covered by
# the same ownership/ELF/ctime checks as the compiler itself. Absent tools are
# skipped, so naming one that the image does not ship costs nothing.
CRITICAL_TOOLS = (
    "go",
    "gofmt",
    "git",
    "python3",
    "bash",
    "sh",
    "gcc",
    "sha256sum",
    "setpriv",
    "env",
    "sudo",
)


def is_elf(path: Path) -> bool:
    """True for a real executable; False for a shell/python wrapper script."""
    try:
        with path.open("rb") as fh:
            return fh.read(4) == b"\x7fELF"
    except OSError:
        return False


# Clock slack for the ctime anchor below. Every image file is unpacked before the
# container's init exists, so a correct trial's binaries have a ctime comfortably
# *before* the anchor and need no allowance at all; the slack covers only the
# sub-second skew between /proc/uptime arithmetic and stat(). It is deliberately
# small: each second of slack is a second at the start of the trial during which a
# swapped binary would still look original.
CTIME_SLACK_SEC = 5.0


def container_start_epoch() -> float | None:
    """Wall-clock instant PID 1 started, or None if it cannot be established.

    This is the one trust anchor that does not live in the image. A file's ctime
    cannot be backdated from userspace -- utime()/`touch` move atime and mtime and
    set ctime to *now* -- and every file in the image was unpacked before the
    container's init existed. So a graded binary whose ctime is after this instant
    was written during the trial, which is precisely what replacing `go` (or
    rewriting the checksum manifest to match it) requires. The agent is root and can
    edit any file in the image, but it cannot make the edit look old.

    /proc/1/stat field 22 is the process start in clock ticks since boot and
    /proc/uptime is seconds since that same boot, so the difference is a wall-clock
    instant no in-container write can move. Anything unreadable or implausible
    yields None and the caller records a note instead of a finding: a missing anchor
    must never fail a correct trial.
    """
    try:
        with open("/proc/uptime", encoding="utf-8") as fh:
            uptime = float(fh.read().split()[0])
        with open("/proc/1/stat", encoding="utf-8", errors="replace") as fh:
            raw = fh.read()
        # comm (field 2) is parenthesised and may itself contain spaces or a ')',
        # so fields are read after the LAST ')': index 0 is field 3 (state), and
        # starttime is field 22.
        fields = raw[raw.rindex(")") + 1:].split()
        ticks = float(fields[19])
        hz = float(os.sysconf("SC_CLK_TCK") or 100)
        started = time.time() - (uptime - ticks / hz)
    except (OSError, ValueError, IndexError, AttributeError):
        return None
    if not math.isfinite(started) or started <= 0 or started > time.time() + 1:
        return None
    return started


def toolchain_inventory() -> tuple[bool, list[str], dict]:
    """Inspect the toolchain the verifier is about to use, and enforce what it saw.

    The agent runs as root, so every *file* in the image -- the binaries, and the
    manifest that lists their digests -- is writable by it. Substituting `go` with a
    root-owned ELF and rewriting the manifest to match therefore defeats any check
    that compares one image file against another. This function does not rely on
    that comparison:

      * The anchor is the kernel, not a file. Every image file was unpacked before
        the container's init existed, and ctime cannot be backdated from userspace,
        so any critical binary -- or the manifest itself -- whose ctime is after the
        container started was written during the trial. That is an integrity
        FAILURE, not a note, and it is what makes the substitution above detectable
        from inside. When the anchor cannot be established it is skipped rather than
        guessed -- `ctime_anchor_enforced` records which happened -- so it can never
        fail a correct trial.
      * Structural checks a substituted tool cannot satisfy without replacing a
        root-owned ELF binary in place: every critical tool must resolve inside a
        canonical root-owned directory, be owned by uid 0, not be group- or
        other-writable, and be an ELF image rather than a wrapper script. The
        cheap attack -- dropping a shell script named `go` -- is rejected here.
        Deleting the manifest to switch these off does not work either: containment
        is detected from the image layout, and a missing manifest is itself a
        failure.
      * The manifest remains a second, weaker tripwire: a digest mismatch fails,
        while a match proves nothing on its own.
      * Publication. The digest of the manifest and of every resolved binary is
        returned so the caller can publish it: the full map and a stable fold of it
        (toolchain_fingerprint) both land in reward-details.json, which the platform
        retains per stage, so a swap is also visible from outside by comparing
        stages.
    """
    notes: list[str] = []
    ok = True
    contained = in_container()
    started = container_start_epoch() if contained else None

    def written_during_trial(path: Path) -> float | None:
        """The file's ctime when it post-dates container start, else None."""
        if started is None:
            return None
        try:
            ctime = path.stat().st_ctime
        except OSError:
            return None
        return ctime if ctime > started + CTIME_SLACK_SEC else None

    expected: dict[str, str] = {}
    manifest_present = CHECKSUM_MANIFEST.is_file()
    if manifest_present:
        for line in CHECKSUM_MANIFEST.read_text(encoding="utf-8", errors="replace").splitlines():
            parts = line.split(None, 1)
            if len(parts) == 2:
                expected[parts[1].strip()] = parts[0].strip()
    if contained:
        if not manifest_present:
            ok = False
            notes.append(
                f"the toolchain checksum manifest is missing: {CHECKSUM_MANIFEST}"
            )
        elif written_during_trial(CHECKSUM_MANIFEST) is not None:
            ok = False
            notes.append(
                "the toolchain checksum manifest was rewritten after the container started"
            )

    tools: dict[str, dict] = {}
    unverified: list[str] = []
    for tool in CRITICAL_TOOLS:
        resolved = shutil.which(tool, path=trusted_path())
        if not resolved:
            continue
        real = str(Path(resolved).resolve())
        digest = sha256_file(Path(real))
        entry: dict = {"path": real, "sha256": digest}
        if contained:
            parent = Path(real).parent
            if not any(str(parent).startswith(d) for d in TRUSTED_DIRS):
                ok = False
                notes.append(f"{tool} resolves outside trusted dirs: {real}")
            try:
                st = Path(real).stat()
                entry["uid"] = st.st_uid
                entry["ctime"] = st.st_ctime
                if st.st_uid != 0:
                    ok = False
                    notes.append(f"{tool} is not root-owned (uid {st.st_uid}): {real}")
                if st.st_mode & 0o022:
                    ok = False
                    notes.append(f"{tool} is group/other-writable: {real}")
            except OSError:
                pass
            if not is_elf(Path(real)):
                ok = False
                notes.append(f"{tool} is not an ELF binary (wrapper script?): {real}")
            swapped = written_during_trial(Path(real))
            if swapped is not None:
                ok = False
                notes.append(
                    f"{tool} was written after the container started "
                    f"(ctime {swapped:.0f} > start {started:.0f}): {real}"
                )
            if real not in expected:
                unverified.append(tool)
        want = expected.get(real)
        if want and digest and digest != want:
            ok = False
            notes.append(f"{tool} checksum mismatch at {real}")
        tools[tool] = entry


    # A wrapper earlier on the agent's PATH would shadow the real tool for the
    # agent but never for us; flag it so reviewers see the attempt.
    agent_path = os.environ.get("PATH", "")
    for tool in ("go", "git", "gofmt"):
        shadow = shutil.which(tool, path=agent_path)
        if shadow:
            real_shadow = str(Path(shadow).resolve())
            trusted = shutil.which(tool, path=trusted_path())
            if trusted and str(Path(trusted).resolve()) != real_shadow:
                notes.append(f"PATH-shadow detected for {tool}: {real_shadow} (ignored)")

    inventory = {
        "manifest": str(CHECKSUM_MANIFEST),
        "manifest_present": manifest_present,
        "manifest_sha256": sha256_file(CHECKSUM_MANIFEST) if manifest_present else None,
        "verifier_sha256": sha256_file(Path(__file__).resolve()),
        "container_start_epoch": started,
        "ctime_anchor_enforced": contained and started is not None,
        "tools_without_manifest_entry": sorted(unverified),
        "tools": tools,
    }
    return ok, notes, inventory


def read_trajectory() -> str:
    chunks: list[str] = []
    for base in (AGENT_LOGS, OUTPUT):
        if not base.is_dir():
            continue
        for path in sorted(base.rglob("*")):
            if not path.is_file() or path.stat().st_size > 8 << 20:
                continue
            if path.suffix.lower() in {".png", ".jpg", ".jpeg", ".gif", ".zip", ".gz", ".test"}:
                continue
            try:
                chunks.append(path.read_text(encoding="utf-8", errors="replace"))
            except OSError:
                continue
    return "\n".join(chunks)


# Keys whose values are something the agent actually executed, rather than
# something it or the harness merely said. Harbor's ATIF trajectories put shell
# input at steps[].tool_calls[].arguments.keystrokes; the rest are insurance
# against a differently-shaped runner.
COMMAND_KEYS = {
    "keystrokes", "command", "commands", "cmd", "input", "script",
    "shell", "bash", "code", "argv",
}

# Markers that identify a parsed document as an agent conversation, as opposed to
# some other JSON the agent happened to write into /app/output.
CONVERSATION_KEYS = {"steps", "messages", "trajectory", "turns", "history"}


def _strings_under(node: object, out: list[str]) -> None:
    if isinstance(node, str):
        out.append(node)
    elif isinstance(node, dict):
        for value in node.values():
            _strings_under(value, out)
    elif isinstance(node, list):
        for value in node:
            _strings_under(value, out)


def _executed_commands(node: object, out: list[str]) -> None:
    if isinstance(node, dict):
        for key, value in node.items():
            if key in COMMAND_KEYS:
                _strings_under(value, out)
            else:
                _executed_commands(value, out)
    elif isinstance(node, list):
        for value in node:
            _executed_commands(value, out)


def _is_conversation(doc: object) -> bool:
    if isinstance(doc, dict):
        return bool(CONVERSATION_KEYS & set(doc))
    if isinstance(doc, list):
        return bool(doc) and all(
            isinstance(item, dict) and {"role", "source"} & set(item) for item in doc
        )
    return False


def _is_executable_artifact(path: Path, text: str) -> bool:
    """Whether this file can actually RUN, as opposed to describing a run.

    Reports and logs are prose no matter what they quote: only a script, a shebang, or a
    file the agent marked executable counts as a surface where a leak could have executed.
    """
    if path.suffix.lower() in {".sh", ".bash", ".zsh", ".py", ".pl", ".rb"}:
        return True
    if text.startswith("#!"):
        return True
    if path.suffix.lower() in {".json", ".md", ".txt", ".log", ".yaml", ".yml", ".csv"}:
        return False
    try:
        return bool(path.stat().st_mode & 0o111)
    except OSError:
        return False

def audited_surfaces() -> tuple[str, str]:
    """Split the agent's trail into what it ran and what was merely written.

    Scanning the whole trail as text cannot distinguish the two, and that is not a
    theoretical problem: the terminus system prompt documents `curl` and `wget` to
    the model, so a plain regex over the transcript reports a network attempt on
    every trial before the agent has done anything at all. That is a false
    accusation, and because an integrity finding zeroes valid_trial it silently
    converts real agent evidence into a void run.

    So a recognised conversation document is reduced to the command fields the
    harness recorded -- those are written by the runner, not dictated by the
    model, which makes them harder to forge than free text, not easier. Anything
    that is not a recognised conversation (an agent-authored reproduce.sh, a
    plain log) is still scanned verbatim.
    """
    executed: list[str] = []
    prose: list[str] = []
    for base in (AGENT_LOGS, OUTPUT):
        if not base.is_dir():
            continue
        for path in sorted(base.rglob("*")):
            if not path.is_file() or path.stat().st_size > 8 << 20:
                continue
            if path.suffix.lower() in {".png", ".jpg", ".jpeg", ".gif", ".zip", ".gz", ".test"}:
                continue
            try:
                text = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            doc: object = None
            try:
                doc = json.loads(text)
            except (ValueError, RecursionError):
                doc = None
            if doc is not None and _is_conversation(doc):
                found: list[str] = []
                _executed_commands(doc, found)
                executed.extend(found)
                prose.append(text)
            elif _is_executable_artifact(path, text):
                executed.append(text)
            else:
                # a JSON report or a narrative log that merely MENTIONS
                # a forbidden command is not evidence that anything ran. Treating every
                # unrecognised file as executed text let a clean run be invalidated by its
                # own write-up -- the agent describing what it did NOT do. Execution is
                # established by recorded tool-call command fields (above) or by an
                # artifact that can actually run; everything else is prose.
                prose.append(text)
    return "\n".join(executed), "\n".join(prose)


def integrity(stage: str) -> tuple[bool, dict]:
    findings: list[str] = []
    notes: list[str] = []

    executed, prose = audited_surfaces()
    for pattern in LEAK_PATTERNS:
        match = re.search(pattern, executed, re.IGNORECASE)
        if match:
            findings.append(f"reference-solution leakage: {match.group(0)[:120]}")
    for line in executed.splitlines():
        target = egress_target(line)
        if target:
            findings.append(
                f"non-local egress attempt to {target!r}: {line.strip()[:120]}"
            )
            break

    # Recorded, never gating. A pattern that appears only in narration or in a
    # harness-authored system prompt is not something the agent did, but a
    # reviewer should still be able to see that it was there.
    for line in prose.splitlines():
        target = egress_target(line)
        if target:
            notes.append(
                f"note: egress pattern ({target!r}) in narration only, not executed: "
                f"{line.strip()[:120]}"
            )
            break

    # Runtime package installation and fetch-then-remove, both read
    # from EXECUTED commands only. Narration that merely mentions `go install` is
    # not an install, and a false positive here would zero an honest run - the same
    # defect a sibling package was rejected for.
    for line in executed.splitlines():
        if RUNTIME_INSTALL.search(line):
            findings.append(f"runtime package installation: {line.strip()[:120]}")
            break
    for line in executed.splitlines():
        if FETCH_THEN_REMOVE.search(line):
            findings.append(f"fetch-then-remove: {line.strip()[:120]}")
            break

    # /testbed must carry no remotes: a remote is the only way to reach upstream.
    rc, out = run(["git", "-C", str(TESTBED), "remote", "-v"], timeout=120)
    if rc == 0 and out.strip():
        findings.append(f"git remote present in /testbed: {out.strip()[:120]}")

    # REPOSITORY REPLACEMENT. The image records the sanitized root
    # commit at build time while the worktree is still pristine. If the repository
    # the verifier is grading no longer has that root commit, the tree was swapped
    # for a different one -- a re-clone, a restored archive, or a fresh git init --
    # and every "diff against base" the grader performs is meaningless.
    anchor = REPO_IDENTITY_ANCHOR
    if anchor.is_file():
        recorded = anchor.read_text(encoding="utf-8", errors="replace").strip()
        observed = base_commit()
        if recorded and observed and recorded != observed:
            findings.append(
                f"repository replaced: root commit is {observed[:12]}, image recorded {recorded[:12]}"
            )
        elif recorded and not observed:
            findings.append("repository replaced: /testbed has no reachable root commit")
    elif in_container():
        # Fail closed inside the container: an anchor the image should have written
        # is missing, so the one control that detects a swapped tree is not running.
        findings.append("repository identity anchor missing inside the container")

    # Binaries the agent generated inside the graded tree. Go build
    # output belongs in the build cache, not the worktree; an executable committed
    # into /testbed can shadow a real tool or smuggle a prebuilt answer.
    generated = generated_executables()
    if generated:
        findings.append(
            f"generated executable(s) in the worktree: {', '.join(generated[:5])}"
        )

    checks_ok, tool_notes, toolchain = toolchain_inventory()
    notes.extend(tool_notes)
    if not checks_ok:
        findings.extend(tool_notes)

    # Deliberately a note, not a finding: removing in-tree tests cannot help, because
    # the graded corpus is injected from a mount the agent cannot reach and the grader
    # restores whatever was deleted before it grades. Recorded so a reviewer can see
    # it happened at all.
    base = base_commit()
    if base:
        rc, out = run(
            ["git", "-C", str(TESTBED), "diff", "--diff-filter=D", "--name-only", base,
             "--", "*_test.go"],
            timeout=300,
        )
        deleted = [line for line in out.splitlines() if line.strip()] if rc == 0 else []
        if deleted:
            notes.append(
                f"note: the agent deleted {len(deleted)} in-tree test file(s); "
                "restored for the graded run (e.g. " + ", ".join(deleted[:3]) + ")"
            )

    # Informational only. The corpus is protected by *not being mounted* into the
    # agent's container, not by its mode bits -- bind mounts are frequently 0777,
    # so treating the mode as an integrity failure would zero out valid runs.
    if HIDDEN_ROOT.is_dir():
        try:
            if HIDDEN_ROOT.stat().st_mode & 0o002:
                notes.append("note: hidden corpus mount is world-writable (mount property)")
        except OSError:
            pass

    ok = not findings
    return ok, {
        "passed": ok,
        "findings": findings,
        "notes": notes,
        # Published so the digests leave the container with every stage result;
        # comparing them across stages detects a toolchain swapped mid-trial.
        "toolchain": toolchain,
        "detail": "clean" if ok else "; ".join(findings[:5]),
    }


# --------------------------------------------------------------------------- #
# artifact contracts
# --------------------------------------------------------------------------- #
def load_json(path: Path) -> tuple[dict | None, str]:
    if not path.is_file():
        return None, f"missing {path}"
    try:
        size = path.stat().st_size
    except OSError:
        size = 0
    if size > MAX_ARTIFACT_BYTES:
        return None, (
            f"{path} is {size} bytes, over the {MAX_ARTIFACT_BYTES}-byte handoff bound"
        )
    try:
        data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except (json.JSONDecodeError, OSError) as exc:
        return None, f"unparseable {path}: {exc}"
    if not isinstance(data, dict):
        return None, f"{path} is not a JSON object"
    return data, "ok"


def json_contract(
    path: Path,
    required: dict[str, type | tuple[type, ...]],
    *,
    exact: bool = True,
) -> tuple[bool, str]:
    data, note = load_json(path)
    if data is None:
        return False, note
    problems = []
    for key, want in required.items():
        if key not in data:
            problems.append(f"missing key '{key}'")
            continue
        value = data[key]
        if not isinstance(value, want):
            problems.append(f"'{key}' has wrong type {type(value).__name__}")
            continue
        if isinstance(value, str) and not value.strip():
            problems.append(f"'{key}' is empty")
        if isinstance(value, list) and not value:
            problems.append(f"'{key}' is an empty list")
    # The disclosed schema is a floor, not a ceiling: an agent that records extra
    # useful context must not be penalised for it. Extra keys are reported for
    # reviewer visibility only; missing keys and wrong types still fail.
    extra = sorted(set(data) - set(required)) if exact else []
    note = "; ".join(problems) if problems else "ok"
    if extra:
        note += f" (extra keys allowed: {extra})"
    return (not problems), note


def stage_report_contract(stage: str) -> tuple[bool, str]:
    """Grade a stage's report against the one published schema for that stage."""
    spec = ARTIFACT_SCHEMAS[stage]
    return json_contract(OUTPUT / stage / str(spec["file"]), dict(spec["fields"]))


def load_handoff() -> tuple[dict | None, str]:
    return load_json(OUTPUT / "handoff.json")


def handoff_contract() -> tuple[bool, str]:
    """Validate the canonical handoff schema disclosed in every instruction."""
    return json_contract(OUTPUT / "handoff.json", HANDOFF_FIELDS)


# --------------------------------------------------------------------------- #
# stage 01
# --------------------------------------------------------------------------- #
CAPABILITY_TERMS = {
    "plural_model": ("loadprojects", "multiple projects", "many-to-many", "project set"),
    "column_map": ("projectcolumnmap", "column map", "per-project column", "column per project"),
    "wire_shape": ("diffslice", "projects []", "plural filter", "project ids"),
}


# One compile probe per capability area the briefing asks the agent to investigate.
# Each names a symbol the finished feature must expose; on a tree that lacks the
# feature the probe fails to compile with that symbol named in the error.
BASE_GAP_PROBES = {
    "plural_model": (
        'package verifierprobe\n\nimport issues_model "code.gitea.io/gitea/models/issues"\n\n'
        "var _ = (&issues_model.Issue{}).LoadProjects\n",
        "LoadProjects",
    ),
    "column_map": (
        'package verifierprobe\n\nimport issues_model "code.gitea.io/gitea/models/issues"\n\n'
        "var _ = (&issues_model.Issue{}).ProjectColumnMap\n",
        "ProjectColumnMap",
    ),
    # The prompt names three gaps: model, SEARCH, and API/web. Probing an Oracle helper
    # absent. These probe the outward surfaces instead: the search option that must accept a
    # SET of project ids, and the API payload that must carry every project.
    "search_shape": (
        'package verifierprobe\n\nimport issues_model "code.gitea.io/gitea/models/issues"\n\n'
        "var _ = issues_model.IssuesOptions{}.ProjectIDs\n",
        "ProjectIDs",
    ),
    "api_shape": (
        'package verifierprobe\n\nimport "code.gitea.io/gitea/modules/structs"\n\n'
        "var _ = structs.Issue{}.Projects\n",
        "Projects",
    ),
}


def base_gap_observed() -> tuple[bool, str]:
    """Observe the missing capabilities with the compiler instead of trusting prose.

    The reproducer proves the agent looked; this proves the tree really is missing
    what the briefing says it is missing, in all three areas, from evidence the agent
    cannot author. A reproducer that only prints the right words does not satisfy it,
    and a tree where the capability has quietly appeared during a no-production-change
    stage fails it.
    """
    probe_root = TESTBED / "verifierprobe"
    observed: list[str] = []
    problems: list[str] = []
    try:
        for area, (source, symbol) in sorted(BASE_GAP_PROBES.items()):
            pkg = probe_root / area
            pkg.mkdir(parents=True, exist_ok=True)
            (pkg / "probe.go").write_text(source, encoding="utf-8")
            rc, out = go_cmd(["build", f"./verifierprobe/{area}"], 900)
            if rc == 0:
                problems.append(f"{area}: {symbol} already exists in the tree")
            elif symbol in out:
                observed.append(area)
            else:
                problems.append(f"{area}: probe inconclusive ({tail(out, 240)})")
    except OSError as exc:
        problems.append(f"probe could not be written: {exc}")
    finally:
        shutil.rmtree(probe_root, ignore_errors=True)
    if problems:
        return False, "; ".join(problems)
    return True, f"compiler confirms all three capabilities are absent: {observed}"


# Stage 1 is graded on whether a reproducer RUNS and
# fails at base, never on what shape it takes. The brief permits a `*_test.go` left in
# the package, a throwaway program, a shell script, or a recorded command sequence, so
# all four are accepted here and each is executed the way its form requires. Restricting
# this to `.sh` made a brief-following agent fail for doing what it was told.
REPRO_SHELL = {".sh", ".bash"}


def _declared_reproducer() -> str:
    """Whatever the agent named in diagnosis.json's `reproducer` field, if anything."""
    path = OUTPUT / "01-diagnose" / "diagnosis.json"
    if not path.is_file():
        return ""
    try:
        data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return ""
    value = data.get("reproducer")
    return value.strip() if isinstance(value, str) else ""


def _classify(path: Path) -> str:
    name = path.name
    if path.suffix in REPRO_SHELL:
        return "shell"
    if name.endswith("_test.go"):
        return "gotest"
    if path.suffix == ".go":
        return "goprog"
    if path.suffix in {".txt", ".cmds", ".list"}:
        return "commands"
    return ""


def find_reproducer() -> tuple[Path | None, str, str]:
    """Return (path, kind, note). kind is shell|gotest|goprog|commands|command-string.

    A `command-string` carries no path: the agent recorded a command sequence in
    diagnosis.json rather than shipping a file, which the brief also allows.
    """
    root = OUTPUT / "01-diagnose"

    # 1. What the agent explicitly declared. It may be a path (relative to the output
    #    dir or to /testbed, since a left-behind test lives in the tree) or a literal
    #    command sequence.
    declared = _declared_reproducer()
    if declared:
        for base in (root, TESTBED, Path("/")):
            candidate = (base / declared.lstrip("/")).resolve()
            try:
                inside = candidate.is_file() and (
                    str(candidate).startswith(str(TESTBED)) or str(candidate).startswith(str(root))
                )
            except OSError:
                inside = False
            if inside:
                kind = _classify(candidate) or "commands"
                return candidate, kind, f"declared in diagnosis.json as {declared!r}"
        # Not a path we can resolve. If it CONTAINS a command, run that command. Agents
        # write this field as a sentence ("From /testbed run: gitea-test go test ...")
        # and executing the sentence gives "From: command not found" (rc 127), which the
        # verifier then charged to the agent. Extract from the first command token.
        if re.search(r"(^|\s)(go|gitea-test|bash|sh|make)\s", declared):
            return None, "command-string", f"recorded command sequence: {declared[:200]!r}"

    if not root.is_dir():
        return None, "", "no /app/output/01-diagnose directory"

    # 2. Conventional shell names, then any shell script.
    for name in ("reproduce.sh", "reproducer.sh", "reproduce.bash", "repro.sh"):
        candidate = root / name
        if candidate.is_file():
            return candidate, "shell", "conventional shell reproducer"
    for candidate in sorted(root.rglob("*")):
        if candidate.is_file() and candidate.suffix in REPRO_SHELL:
            return candidate, "shell", "shell reproducer"

    # 3. Any other permitted form shipped into the output directory.
    for want in ("gotest", "goprog", "commands"):
        for candidate in sorted(root.rglob("*")):
            if candidate.is_file() and _classify(candidate) == want:
                return candidate, want, f"{want} reproducer under /app/output/01-diagnose"

    # 4. A reproducer test left behind in the tree, which the brief expressly allows.
    changed = {p for p in changed_files() if p.endswith("_test.go")}
    for rel in sorted(changed):
        candidate = TESTBED / rel
        if candidate.is_file():
            return candidate, "gotest", f"reproducer test left in the tree at {rel}"

    return None, "", "no reproducer in any permitted form"


def reproducer_argv(repro: Path | None, kind: str) -> list[str]:
    """The command that exercises a reproducer of this form."""
    if kind == "shell":
        return ["bash", str(repro)]
    if kind == "gotest":
        pkg = repro.parent
        try:
            rel = "./" + str(pkg.relative_to(TESTBED)).replace("\\", "/")
        except ValueError:
            rel = str(pkg)
        # The SAME build tags every other graded Go run in this package uses. Without
        # them gitea's test bootstrap aborts with "sqlite3 requires: -tags sqlite,
        # sqlite_unlock_notify" before any test body executes, so a DB-backed
        # reproducer -- the natural kind for an issue/project association -- exits
        # non-zero for a reason that has nothing to do with the capability, and its
        # output cannot reference the gap. Three different models failed stage 1 this
        # way while their reproducers were correct.
        return ["go", "test", "-count=1", GO_TEST_TAGS, rel]
    if kind == "goprog":
        return ["go", "run", GO_TEST_TAGS, str(repro)]
    if kind == "commands":
        return ["bash", str(repro)]
    if kind == "command-string":
        # The brief tells the agent to run Go through `gitea-test`, so a recorded command
        # usually already starts with it. Wrapping again nests setpriv inside setpriv, which
        # fails with "setgroups failed: Operation not permitted" and the reproducer never
        # runs. Strip a leading wrapper here; the caller adds exactly one.
        cmd = _declared_reproducer()
        # Trim any leading prose: start at the first real command token. Without this a
        # perfectly good recorded command inside a sentence never runs.
        m = re.search(r"(?:^|[\s:])((?:/usr/local/bin/)?(?:gitea-test|go|bash|sh|make)\s.*)", cmd, re.S)
        if m:
            cmd = m.group(1)
        # Keep only the command LINE. Agents label the field -- "Command to run the
        # reproducer test:" then the command, then a blank line and an explanatory
        # paragraph -- and bash ran that paragraph as a second command, exiting 127,
        # which the verifier then scored as the agent's failure.
        kept: list[str] = []
        for line in cmd.splitlines():
            kept.append(line)
            if not line.rstrip().endswith("\\"):
                break
        cmd = "\n".join(kept)
        # ...and drop trailing prose after the command sentence ("... -count=1 -v. The
        # test logs ..."), which bash would treat as further arguments.
        cmd = re.split(r"(?<=[^.])\.\s+[A-Z]", cmd)[0].strip().rstrip(".")
        for prefix in ("/usr/local/bin/gitea-test ", "gitea-test "):
            if cmd.startswith(prefix):
                cmd = cmd[len(prefix):].lstrip()
                break
        return ["bash", "-c", cmd]
    return []


def reproducer_engages_repository(repro: Path | None, kind: str) -> tuple[bool, str]:
    """Reject a generic failing script that only names the feature in prose.

    A valid Go reproducer must contain a real test/program importing the Gitea
    module. A shell/recorded-command reproducer must execute a repository-aware
    Go or search command against an existing source path. Comments and echo/printf
    narration are deliberately ignored, so ``# project`` followed by ``exit 1``
    cannot satisfy the critical gate.
    """
    source = ""
    if repro is not None:
        try:
            source = repro.read_text(encoding="utf-8", errors="replace")
        except OSError:
            source = ""
    declared = _declared_reproducer()
    combined = source + "\n" + declared
    if kind in {"gotest", "goprog"}:
        has_gitea_import = "code.gitea.io/gitea/" in combined
        has_executable_go = (
            bool(re.search(r"(?m)^\s*func\s+Test\w+\s*\(", combined))
            if kind == "gotest"
            else "package main" in combined and "func main(" in combined
        )
        ok = has_gitea_import and has_executable_go
        return ok, (
            "Go reproducer imports Gitea and defines executable test/program code"
            if ok else "Go reproducer does not import Gitea executable code"
        )

    executable_lines = []
    for raw in combined.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if re.match(r"^(?:echo|printf)\b", line):
            continue
        if re.search(
            r"(?:^|[;&|]\s*)(?:(?:/usr/local/bin/)?gitea-test\s+)?"
            r"(?:go\s+(?:test|doc|build|run)\b|grep\b|rg\b|test\b)",
            line,
        ):
            executable_lines.append(line)
    existing_refs: set[str] = set()
    for line in executable_lines:
        for ref in re.findall(r"(?:models|modules|routers|services)/[A-Za-z0-9_./-]+", line):
            cleaned = ref.rstrip("'\";,){}")
            if (TESTBED / cleaned).exists():
                existing_refs.add(cleaned)
    imports_gitea = any("code.gitea.io/gitea/" in line for line in executable_lines)
    ok = bool(executable_lines) and (bool(existing_refs) or imports_gitea)
    return ok, (
        f"repository-aware commands={len(executable_lines)}, existing source refs={sorted(existing_refs)[:4]}"
        if ok else "no executable repository-aware Go/search command found"
    )


def diagnose() -> dict:
    checks: dict[str, dict] = {}
    # First, and cleaned up before anything reads the working tree, so the probe
    # package never shows up as a change the agent made.
    ok, note = base_gap_observed()
    checks["base_gap_observed"] = {"passed": ok, "detail": note}

    repro, repro_kind, repro_note = find_reproducer()
    # Accepted in any disclosed form: shell script, *_test.go (in the output dir or left
    # in the tree), throwaway program, or a recorded command sequence.
    checks["reproducer_present"] = {
        "passed": bool(repro_kind),
        "detail": (f"{repro_kind}: {repro_note}" if repro_kind else repro_note),
    }

    # The agent's script used to be executed as root, with the
    # verifier's own environment, straight into /testbed. Three things changed.
    #
    # 1. It runs UNPRIVILEGED, through the same `gitea-test` wrapper the graded Go
    #    commands use, with a minimal environment. It can still exercise the
    #    repository - that is the point of a reproducer - but it can no longer
    #    write anywhere the grader trusts, install anything, or inherit verifier
    #    paths from the environment.
    # 2. Its output is bounded and its timeout is tighter, so a script that spews
    #    or hangs cannot distort the stage.
    # 3. Integrity is re-checked AFTERWARDS (below), not only before, so a script
    #    that tampers on execution is caught rather than pre-cleared.
    repro_out = ""
    repro_rc = None
    if repro_kind:
        argv = reproducer_argv(repro, repro_kind)
        if in_container() and Path("/usr/local/bin/gitea-test").is_file():
            argv = ["/usr/local/bin/gitea-test", *argv]
        repro_rc, repro_out = run(
            argv,
            cwd=TESTBED,
            timeout=600,
            env=hardened_env({"HOME": "/home/giteatest", "GOFLAGS": ""}),
        )
        repro_out = tail(repro_out, 64 * 1024)
    checks["reproducer_runs"] = {
        "passed": bool(repro_kind) and repro_rc is not None and bool(repro_out.strip()),
        "detail": f"rc={repro_rc}, {len(repro_out)} bytes of output (sandboxed, unprivileged)",
        "output_tail": tail(repro_out, 2000),
    }

    # TRUTH IS VERIFIER-OWNED. The previous revision granted this
    # check partly on keywords appearing in the agent's own output, which a script
    # that merely prints the right words satisfies. The authoritative signal is
    # base_gap_observed() - the verifier compiling and running its OWN probes
    # against the pristine tree - and the agent's contribution is only that its
    # reproducer actually fails at base, which is what a real reproducer does.
    #
    # Naming the affected areas is still scored, but it moved to the non-critical
    # diagnosis_report where prose belongs, so wording can never decide the stage.
    blob = (repro_out + "\n" + read_trajectory()).lower()
    named = [area for area, terms in CAPABILITY_TERMS.items() if any(t in blob for t in terms)]
    # A reproducer must fail because the CAPABILITY is missing, not because it could not
    # start. rc=127 (command not found) and wrapper/exec errors are harness failures: an
    # agent whose command is simply wrong would otherwise clear this gate for free.
    harness_failure = repro_rc == 127 or any(
        marker in repro_out
        for marker in ("setpriv:", "command not found", "No such file or directory", "permission denied")
    )
    # A nonzero exit alone is not evidence: `exit 1` would earn full credit without touching
    # the repository. Require the reproducer to mention at least one capability under test,
    # so the artifact has to engage with THIS defect rather than merely fail.
    gap_terms = (
        "project", "projects", "projectid", "projectids",
        "loadprojects", "projectcolumnmap", "column",
    )
    # EVIDENCE IS THE REPRODUCER'S OWN TEXT, NEVER ITS RUNTIME STDOUT. A prior revision
    # also searched `repro_out` (what the script printed when it ran), which let a script
    # that does nothing but `echo "project column" >&2; exit 1` satisfy this gate -- the
    # exact "prints the right words" loophole review flagged. What the artifact IS (its
    # own source, or the exact command string the agent declared) still legitimately
    # covers a failing Go test named e.g. TestMultiProjectSupport in
    # issue_project_multiboard_test.go, whose failure never spells the word in its
    # assertion diff but whose own filename/body does -- so that case is still credited.
    # What it no longer covers is a script whose only connection to the capability is
    # something it prints at runtime rather than something it IS.
    evidence: list[str] = []
    if repro is not None:
        evidence.append(str(repro))
        try:
            evidence.append(repro.read_text(encoding="utf-8", errors="replace"))
        except OSError:
            pass
    evidence.append(_declared_reproducer())
    blob_lower = "\n".join(evidence).lower()
    references_gap = any(term in blob_lower for term in gap_terms)
    engages_repository, engagement_note = reproducer_engages_repository(repro, repro_kind)
    demonstrates = (
        bool(repro_kind)
        and repro_rc is not None
        and repro_rc != 0
        and not harness_failure
        and references_gap
        and engages_repository
        and bool(checks["base_gap_observed"]["passed"])
    )
    checks["reproducer_demonstrates_gap"] = {
        "passed": demonstrates,
        "detail": (
            f"rc={repro_rc} (non-zero required, harness failures rejected, the "
            f"reproducer's OWN source/declared command -- never its runtime stdout -- "
            f"must reference the capability: referenced={references_gap}, and execute "
            f"against the repository: engaged={engages_repository} ({engagement_note})); "
            f"harness_failure={harness_failure}; verifier-owned base probe "
            f"passed={checks['base_gap_observed']['passed']}; capability areas named "
            f"(scored in diagnosis_report, not here): {named}"
        ),
    }

    # Integrity is not evaluated here: main() runs it AFTER every stage function
    # returns, precisely so the audit sees the worktree as the agent's reproducer
    # left it. See the ordering note in main().
    # Production (non-test) files must be untouched at the diagnose stage. A
    # reproducer *_test.go ships nothing and is explicitly allowed by the prompt,
    # so it never counts as a production change wherever it lives.
    production = [
        f for f in changed_files()
        if f.startswith(("models/", "modules/", "routers/", "services/"))
        and not f.endswith("_test.go")
    ]
    checks["no_production_changes"] = {
        "passed": not production,
        "detail": (
            "no production file modified"
            if not production
            else f"production files changed during diagnose: {production[:10]}"
        ),
    }

    ok, note = stage_report_contract("01-diagnose")
    # Naming the affected capability areas is scored here, where prose belongs and
    # where it cannot decide the stage (diagnosis_report is non-critical).
    checks["diagnosis_report"] = {
        "passed": ok and len(named) >= 2,
        "detail": f"{note}; capability areas named: {named}",
    }

    ok, note = handoff_contract()
    checks["handoff"] = {"passed": ok, "detail": note}
    return checks


# --------------------------------------------------------------------------- #
# stages 02-04
# --------------------------------------------------------------------------- #
def graded_go_gates(stage: str, checks: dict[str, dict]) -> None:
    """Build, then run the injected upstream corpus, then vet."""
    build_key = "full_build" if stage == "04-api-web-and-harden" else "build_clean"
    ok, out = go_build(STAGE_BUILD[stage])
    checks[build_key] = {"passed": ok, "detail": "ok" if ok else out}

    stages = stages_upto(stage)
    corpus = hidden_corpus_size(stages)
    backups: dict[str, bytes | None] = {}
    restored = restore_deleted_tests(backups)
    inject_hidden(stages, backups)
    try:
        ok, out, raw = go_test(STAGE_PKGS[stage], timeout=2400, verbose=True)
        ran_ok, ran_note = graded_tests_all_ran(stages, raw)
        tests_ok, excused, blocking = graded_run_verdict(ok, raw, stages)
        checks["hidden_tests_pass"] = {
            "passed": tests_ok and ran_ok,
            "detail": f"{corpus} graded test files over {len(STAGE_PKGS[stage])} packages; {ran_note}"
            + (f"; restored {restored} in-tree test files the agent deleted" if restored else "")
            + (
                f"; excused (this image, not the agent): {excused}"
                f" [{'; '.join(env_failure_notes())}]"
                if excused
                else ""
            )
            + ("" if tests_ok else f" -- BLOCKING: {blocking}\n{out}"),
        }
        vet_ok, vet_out = go_vet(STAGE_PKGS[stage])
    finally:
        restore_hidden(backups)
    checks["vet_clean"] = {"passed": vet_ok, "detail": "ok" if vet_ok else vet_out}


def persistence(stage: str) -> dict:
    checks: dict[str, dict] = {}
    graded_go_gates(stage, checks)

    ok, note = stage_report_contract(stage)
    checks["implementation_report"] = {"passed": ok, "detail": note}

    ok, note = handoff_contract()
    checks["handoff"] = {"passed": ok, "detail": note}
    return checks


def detection(stage: str) -> dict:
    checks: dict[str, dict] = {}
    graded_go_gates(stage, checks)

    # elasticsearch/meilisearch routing used to be its own regex check here
    # (ADAPTER_SEARCH_FILES / adapter_routes_plural_filter). It is now proved by
    # tests/hidden/03-search-and-indexing/modules/indexer/issues/{elasticsearch,
    # meilisearch}/*_test.go, which run the real Search() against a local httptest
    # fake and inspect the outgoing query -- folded into hidden_tests_pass above via
    # graded_go_gates(), like every other backend's behaviour.

    ok, note = stage_report_contract(stage)
    checks["review_report"] = {"passed": ok, "detail": note}

    ok, note = handoff_contract()
    checks["handoff"] = {"passed": ok, "detail": note}
    return checks


def harden(stage: str) -> dict:
    checks: dict[str, dict] = {}
    graded_go_gates(stage, checks)
    touched = changed_files()

    if not cgo_available():
        checks["race_clean"] = {
            "passed": False,
            "detail": "no C toolchain available; `go test -race` could not run",
        }
    else:
        stages = stages_upto(stage)
        backups: dict[str, bytes | None] = {}
        restore_deleted_tests(backups)
        inject_hidden(stages, backups)
        try:
            ok, out, raw = go_test(RACE_PKGS, timeout=2700, race=True)
        finally:
            restore_hidden(backups)
        # RACE_PKGS holds no environment-excused test today, but the race run is
        # graded by the same rule so a future one cannot quietly fail this stage.
        race_ok, race_excused, _ = graded_run_verdict(ok, raw, stages)
        checks["race_clean"] = {
            "passed": race_ok,
            "detail": (
                "no data races"
                + (f"; excused (this image): {race_excused}" if race_excused else "")
            )
            if race_ok
            else out,
        }

    ok, note = gofmt_offenders(touched)
    checks["gofmt_clean"] = {"passed": ok, "detail": note}

    ok, note = stage_report_contract(stage)
    checks["final_report"] = {"passed": ok, "detail": note}

    # NOTE: a `merge_ready` check used to sit here and graded a self-declared
    # boolean in the agent's own handoff. It is deleted rather than kept: rewarding
    # an agent for asserting its own success is a reward-hacking surface, and no
    # reviewer can tell an earned `true` from a typed one. Merge readiness is what
    # the merge_readiness JUDGE is for, and that judge is training-only.
    return checks


# --------------------------------------------------------------------------- #
# reward
# --------------------------------------------------------------------------- #
def numeric_only(payload: dict) -> tuple[dict[str, float], dict[str, object]]:
    """Split a reward payload into the numbers Harbor accepts and everything else.

    Harbor loads reward.json wholesale into VerifierResult.rewards and pydantic
    validates every value as float|int, so one nested object in this file aborts
    the trial with a ValidationError instead of scoring the stage. This is the gate
    that keeps that from happening again: booleans collapse to 1.0/0.0, non-finite
    numbers to 0.0, and anything richer is handed back to the caller to publish in
    reward-details.json rather than being silently dropped.
    """
    numeric: dict[str, float] = {}
    overflow: dict[str, object] = {}
    for key, value in payload.items():
        if isinstance(value, bool):
            numeric[key] = 1.0 if value else 0.0
        elif isinstance(value, (int, float)):
            number = float(value)
            numeric[key] = number if math.isfinite(number) else 0.0
        else:
            overflow[key] = value
    return numeric, overflow


def toolchain_fingerprint(integrity_report: dict) -> float:
    """One number standing in for the whole per-tool digest map.

    Both this fold and the digests it summarises live in reward-details.json, which
    the platform retains beside reward.json for every stage. It is deliberately kept
    out of reward.json: that file is loaded as the trial's reward vector, and a
    15-digit number sitting in it corrupts any surface that aggregates the vector.
    Every critical binary's digest plus the manifest and the verifier's own digest
    hash into 52 bits, which a JSON number represents exactly. It is a comparison
    anchor rather than a secret: two stages of one trial reporting different
    fingerprints ran different toolchains, and that comparison happens outside the
    container, beyond the reach of a root agent.
    """
    inventory = integrity_report.get("toolchain")
    if not isinstance(inventory, dict):
        return 0.0
    tools = inventory.get("tools")
    parts = [
        f"{name}={entry.get('sha256') or ''}"
        for name, entry in sorted((tools or {}).items())
        if isinstance(entry, dict)
    ]
    parts.append(f"manifest={inventory.get('manifest_sha256') or ''}")
    parts.append(f"verifier={inventory.get('verifier_sha256') or ''}")
    digest = hashlib.sha256(";".join(parts).encode("utf-8")).hexdigest()
    return float(int(digest[:13], 16))


def write_ctrf(
    stage: str,
    checks: dict[str, dict],
    weights: dict[str, float],
    critical: tuple[str, ...] | list[str],
    integrity_report: dict,
    started: float,
) -> dict:
    """Publish the stage's results as CTRF, the per-test format Harbor renders.

    reward.json answers "what score", never "which checks". Harbor reads the
    individual test list from /logs/verifier/ctrf.json, so a stage that writes only
    a reward vector is reported as having run no tests at all -- which is how four
    stages that each scored binary_reward=1.0 were still displayed as FAILED.

    One entry per weighted check, one per Go test function the stage actually ran,
    and one for integrity. Every entry carries name/status/duration, the three
    fields CTRF requires.
    """
    stop = time.time()
    entries: list[dict] = []
    for name in sorted(checks):
        result = checks[name]
        passed = bool(result.get("passed"))
        entry = {
            "name": name,
            "status": "passed" if passed else "failed",
            "duration": 0,
            "suite": f"{stage} :: deterministic checks",
            "tags": (["critical"] if name in critical else []) + [f"weight={weights.get(name, 0.0)}"],
        }
        if not passed:
            entry["message"] = str(result.get("detail", ""))[:2000]
        entries.append(entry)

    integrity_ok = bool(integrity_report.get("passed"))
    integrity_entry = {
        "name": "integrity",
        "status": "passed" if integrity_ok else "failed",
        "duration": 0,
        "suite": f"{stage} :: integrity",
        "tags": ["critical"],
    }
    if not integrity_ok:
        integrity_entry["message"] = "; ".join(
            str(f) for f in integrity_report.get("findings", [])
        )[:2000]
    entries.append(integrity_entry)

    for event in GO_TEST_EVENTS:
        entry = {
            "name": event["name"],
            "status": event["status"],
            "duration": event["duration"],
            "suite": f"{stage} :: {event['suite']}",
        }
        if event.get("message"):
            entry["message"] = str(event["message"])[:2000]
        entries.append(entry)

    def count(status: str) -> int:
        return sum(1 for e in entries if e["status"] == status)

    report = {
        "results": {
            "tool": {"name": "gitea-multi-project-verifier", "version": "1.0.0"},
            "summary": {
                "tests": len(entries),
                "passed": count("passed"),
                "failed": count("failed"),
                "pending": 0,
                "skipped": count("skipped"),
                "other": 0,
                "start": int(started * 1000),
                "stop": int(stop * 1000),
            },
            "tests": entries,
            "environment": {
                "appName": "gitea-multi-project",
                "buildName": stage,
            },
        }
    }
    atomic_write_text(
        RESULT_DIR / "ctrf.json",
        json.dumps(report, indent=2) + "\n",
    )
    return report


JUDGE_DIMENSIONS = ("process", "validity", "merge_readiness", "task_quality")


def judge_rubric_discovery(stage: str) -> dict:
    """Parse every shipped rubric and report what a RewardKit run would discover.

    Emitted into reward-details.json on every run, judged or not, so a reviewer can
    see that the rubrics parse, which model they name, which criteria they carry and
    which of them this stage would select -- without having to run a judged pass.
    Parsing here is also the cheapest way to catch a rubric that would only fail
    later, inside a paid judge call.
    """
    try:
        import tomllib
    except ModuleNotFoundError:  # pragma: no cover - python < 3.11
        return {"parsed": False, "reason": "tomllib unavailable"}

    prompt = TESTS / "judge_prompt.md"
    report: dict[str, object] = {
        "prompt_template": {
            "path": "tests/judge_prompt.md",
            "present": prompt.is_file(),
            "bytes": prompt.stat().st_size if prompt.is_file() else 0,
        },
        "selection_rule": (
            "process and validity at every agent stage; merge_readiness only at "
            "04-api-web-and-harden and only once binary_reward is 1.0; task_quality "
            "ships at weight 0.0 as an author-side audit and is never selected"
        ),
        "dimensions": {},
    }
    for dimension in JUDGE_DIMENSIONS:
        path = TESTS / dimension / "judge.toml"
        entry: dict[str, object] = {"path": f"tests/{dimension}/judge.toml"}
        if not path.is_file():
            entry.update({"parsed": False, "reason": "missing"})
            report["dimensions"][dimension] = entry  # type: ignore[index]
            continue
        try:
            data = tomllib.loads(path.read_text(encoding="utf-8"))
        except (tomllib.TOMLDecodeError, OSError) as exc:
            entry.update({"parsed": False, "reason": str(exc)[:200]})
            report["dimensions"][dimension] = entry  # type: ignore[index]
            continue
        criteria = data.get("criterion") or []
        entry.update(
            {
                "parsed": True,
                "model": (data.get("judge") or {}).get("judge"),
                "weight": (data.get("judge") or {}).get("weight"),
                "criteria": [str(c.get("name")) for c in criteria],
                "criterion_weight_total": round(
                    sum(float(c.get("weight", 0.0)) for c in criteria), 6
                ),
                "selected_for_this_stage": (
                    dimension in ("process", "validity")
                    or (dimension == "merge_readiness" and stage == STAGES[-1])
                ),
            }
        )
        report["dimensions"][dimension] = entry  # type: ignore[index]
    models = {
        entry.get("model")
        for entry in report["dimensions"].values()  # type: ignore[union-attr]
        if entry.get("parsed")
    }
    report["parsed"] = all(
        entry.get("parsed") for entry in report["dimensions"].values()  # type: ignore[union-attr]
    )
    report["single_model"] = len(models) == 1
    report["model"] = next(iter(models)) if len(models) == 1 else None
    return report


def agent_contributed(stage: str) -> tuple[bool, str]:
    """Whether this stage shows any real agent work, independent of whether it succeeded.

    Some checks are verifier-owned facts that a completely untouched tree satisfies
    for free: `base_gap_observed` (the pristine base really is missing the three
    capabilities) and `no_production_changes` (nothing was touched) at Stage 1, and
    `build_clean` at every stage (the sanitized base already builds). A no-op run
    passing exactly those checks is how an unmodified repository banked non-zero
    deterministic/training score in an earlier revision. This predicate is the single
    gate write_reward() uses to zero that out, regardless of which individual
    baseline-only check happens to be free on a pristine tree.
    """
    if stage == "01-diagnose":
        # Stage 1 makes no production changes by design (the brief says so
        # explicitly), so the agent's contribution is the reproducer artifact it
        # produced, not a source diff.
        _repro, repro_kind, _note = find_reproducer()
        ok = bool(repro_kind)
        return ok, (
            "a reproducer artifact was produced" if ok
            else "no reproducer artifact found under /app/output/01-diagnose"
        )
    # Same production-path/`_test.go`-exclusion filter diagnose() already uses for
    # no_production_changes, applied to the opposite question: at least one such file
    # must have changed since the sanitized base for this to be real work.
    production = [
        f for f in changed_files()
        if f.startswith(("models/", "modules/", "routers/", "services/"))
        and not f.endswith("_test.go")
    ]
    ok = bool(production)
    return ok, (
        f"{len(production)} production file(s) changed since the sanitized base"
        if ok else "no production file changed since the sanitized base"
    )


def write_reward(stage: str, checks: dict[str, dict], integrity_report: dict) -> float:
    weights = WEIGHTS[stage]
    integrity_ok = bool(integrity_report.get("passed"))
    contributed_ok, contributed_note = agent_contributed(stage)

    d_num, d_den = deterministic_components(
        checks, weights, integrity_ok=integrity_ok, agent_contributed=contributed_ok
    )
    critical = CRITICAL_CHECKS[stage]
    required_pass = all(bool(checks.get(name, {}).get("passed")) for name in critical)
    binary = binary_outcome(required_checks_pass=required_pass, integrity_ok=integrity_ok)

    lam = parse_lambda(os.environ.get("NONDETERMINISTIC_LAMBDA", "0.0"))
    n_num = n_den = 0.0
    judge_path = RESULT_DIR / "judge_scores.json"
    rewardkit_available = False
    if judge_path.is_file() and os.environ.get("RUN_LLM_JUDGES", "0") == "1":
        try:
            payload = json.loads(judge_path.read_text(encoding="utf-8"))
            n_num = float(payload.get("numerator", 0.0))
            n_den = float(payload.get("denominator", 0.0))
            rewardkit_available = n_den > 0.0
        except (json.JSONDecodeError, OSError, TypeError, ValueError):
            rewardkit_available = False

    training = calculate_training_score(
        d_num=d_num,
        d_den=d_den,
        n_num=n_num,
        n_den=n_den,
        nondeterministic_lambda=lam,
        integrity_ok=integrity_ok,
        rewardkit_available=rewardkit_available,
    )

    failing = sorted(n for n in weights if not checks.get(n, {}).get("passed"))
    every_passed = not failing
    formula = formula_text(
        d_num=d_num,
        d_den=d_den,
        n_num=n_num,
        n_den=n_den,
        nondeterministic_lambda=lam,
        result=clamp01(training),
    )
    # Stated explicitly so a reader never has to infer it: the pass/fail outcome is
    # decided by the critical checks alone. The remaining weighted checks shape
    # training_score and are reported in reward-details.json for transparency.
    outcome_rule = (
        "binary_reward = 1.0 iff every critical check passes and integrity holds"
    )

    # reward.json is loaded wholesale into Harbor's VerifierResult.rewards, so it
    # carries the canonical scored scalars and nothing else. DataOS averages every
    # numeric member of this object, so validity flags and metadata belong in
    # reward-details.json (valid_trial, counts, digests, per-check detail).
    valid_trial = 1.0 if integrity_ok and contributed_ok else 0.0
    payload = {
        "reward": binary,
        "binary_reward": binary,
        "training_score": clamp01(training),
        "deterministic_score": round(clamp01(d_num / d_den) if d_den else 0.0, 6),
    }
    # Only when a judge actually scored this stage. A judge that was skipped (every
    # Oracle run) or that failed has no score to report, and a placeholder 0.0 would
    # be averaged into any aggregate view of the vector as though the stage had been
    # judged and found worthless. lambda travels with the judge score for the same
    # reason: it is meaningless without a rubric to weight, and is reported N/A -- by
    # omission -- on any run where none applied.
    if rewardkit_available:
        payload["non_deterministic_score"] = round(
            clamp01(n_num / n_den) if n_den else 0.0, 6
        )
        payload["training_score_lambda"] = round(clamp01(lam), 6)
    payload, overflow = numeric_only(payload)
    assert reward_json_shape_ok(payload), (
        f"reward.json must publish {sorted(REWARD_JSON_CORE_KEYS)}, optionally plus "
        f"{sorted(REWARD_JSON_JUDGED_KEYS)}; got {sorted(payload)}"
    )

    # reward-details.json carries the per-check detail and the scoring breakdown, in the
    # shape the optional judge merge reads (D_num/D_den/integrity_passed) so a judged
    # pass never has to re-derive them. reward.txt is the 1-D reward, reward-events.json
    # is one row per check, and the manifest labels what a training export may keep.
    details = {
        "stage": stage,
        "stage_index": STAGES.index(stage) + 1 if stage in STAGES else 0,
        "valid_trial": valid_trial,
        "valid_trial_rule": (
            "valid_trial = 1.0 iff integrity passed and the agent contributed real work"
        ),
        "checks": checks,
        "weights": weights,
        "critical_checks": critical,
        "non_critical_checks": sorted(set(weights) - set(critical)),
        "critical_pass": required_pass and integrity_ok,
        "promotion_ready": binary,
        "integrity_passed": integrity_ok,
        "every_weighted_check_passed": every_passed,
        "critical_check_count": len(critical),
        "failing_check_count": len(failing),
        "failing_checks": failing,
        "outcome_rule": outcome_rule,
        "formula": formula,
        "deterministic": {
            "numerator": round(d_num, 6),
            "denominator": round(d_den, 6),
            "ratio": round(clamp01(d_num / d_den) if d_den else 0.0, 6),
        },
        # Records the agent_contributed() gate's own verdict so a reviewer can see,
        # for any stage, WHY the numerator was forced to zero when it was: an
        # unmodified base earns no deterministic/training credit no matter which
        # individual baseline-only checks pass for free on a pristine tree.
        "agent_contribution": {
            "passed": contributed_ok,
            "detail": contributed_note,
            "gates_deterministic_numerator": not contributed_ok,
        },
        # Judge-only quantities are N/A - JSON null - when no judge scored this
        # stage, which is every Oracle run and every run with RUN_LLM_JUDGES=0.
        # And Final-both flagged the previous
        # behaviour: writing them as numeric 0.0 is indistinguishable from "the
        # judge ran and scored zero", so any reader aggregating these fields sees
        # a judged failure where there was simply no judge.
        "nondeterministic": {
            "numerator": round(n_num, 6) if rewardkit_available else None,
            "denominator": round(n_den, 6) if rewardkit_available else None,
            "lambda": lam if rewardkit_available else None,
            "available": rewardkit_available,
            "authoritative": False,
            "applicability": (
                "judged" if rewardkit_available
                else "N/A - no judge scored this stage (Oracle runs never invoke RewardKit)"
            ),
            "rubric_discovery": judge_rubric_discovery(stage),
        },
        # The toolchain digests themselves, plus the stable fold of them that lets a
        # reviewer compare stages of one trial from outside the container.
        "toolchain_fingerprint": toolchain_fingerprint(integrity_report),
        "integrity": integrity_report,
        "changed_files": changed_files(),
        "scoring": {
            "D_num": round(d_num, 6),
            "D_den": round(d_den, 6),
            # Same rule as the nondeterministic block: null, not zero, when no
            # judge ran. training_score then equals the deterministic ratio, and
            # that identity is asserted by the package self-test.
            "N_num": round(n_num, 6) if rewardkit_available else None,
            "N_den": round(n_den, 6) if rewardkit_available else None,
            "lambda": lam if rewardkit_available else None,
            "effective_lambda": lam if rewardkit_available else None,
            "lambda_range": [score_formula.LAMBDA_MIN, score_formula.LAMBDA_MAX],
            "training_score": clamp01(training),
            "calculation": formula,
            "integrity_passed": integrity_ok,
            "integrity_hard_gate": True,
            "rewardkit_available": rewardkit_available,
            "rewardkit_applied": integrity_ok and rewardkit_available and lam > 0.0,
            "calculation_mode": (
                "integrity hard gate"
                if not integrity_ok
                else (
                    "lambda formula"
                    if rewardkit_available and lam > 0.0
                    else "deterministic-only fallback"
                )
            ),
            "deterministic_weights": weights,
            "required_checks_passed": required_pass,
        },
    }
    if overflow:
        details["reward_json_overflow"] = overflow
    events = [
        {
            "stage": stage,
            "check": name,
            "passed": bool(value.get("passed")),
            "weight": round(float(weights.get(name, 0.0)), 6),
            "critical": name in critical,
            "deterministic": True,
        }
        for name, value in checks.items()
    ]
    # Reasons a run must not be booked as a clean model result. Stating them here means a
    # reviewer does not have to reconstruct why a low score should be discounted -- which is
    # the exact judgement the checklist requires before booking any failure against a model.
    # The judge merger withdraws the non-deterministic term when a rubric is incomplete;
    # surface that here so an incomplete judge is visible in the export decision rather than
    # only in the merge output.
    judge_status_note = ""
    try:
        _js = json.loads((RESULT_DIR / "judge_status.json").read_text(encoding="utf-8"))
        if _js.get("judge_complete") is False:
            judge_status_note = "judge rubric incomplete; non-deterministic term withdrawn"
    except (OSError, ValueError):
        judge_status_note = ""
    export_hold_reasons: list[str] = []
    if not integrity_ok:
        export_hold_reasons.append("integrity findings present")
    if judge_status_note:
        export_hold_reasons.append(judge_status_note)
    # The verifier cannot observe the runner's effective agent network after the
    # agent container has been torn down. Fail trainer export closed here; an
    # author-side release step may promote the record only after checking Harbor's
    # config.json/result.json for the exact trial. The previous implementation
    # documented this missing attestation but still emitted "export".
    export_hold_reasons.append("runner-level agent network/topology attestation required")
    manifest = {
        "schema": "repo-engineering-training-v2",
        "task_family": os.environ.get("TASK_FAMILY", "gitea-multi-project-tier2"),
        "stage": stage,
        "eligible_for_eval": integrity_ok,
        "eligible_for_training": False,
        "training_candidate": False,
        # One authoritative predicate. "eligible_for_training: false" sitting next to
        # "training_candidate: true" told a reader nothing actionable; export_decision is
        # the field to read, and export_hold_reasons says why when it is "hold".
        "export_decision": "hold",
        "export_hold_reasons": export_hold_reasons,
        # A prior revision tried to hold export on network contamination by reading
        # EFFECTIVE_NETWORK_MODE from os.environ -- nothing in this package ever set
        # that variable, so the check silently never fired on any run, including ones
        # Harbor's own config recorded as override_network_mode="public". The verifier
        # runs inside its OWN container, torn down independently of the agent's; it
        # has no way to introspect a different, already-terminated container's live
        # network state, and fabricating a check that can't actually observe that
        # would be worse than admitting the gap. What genuinely changed since that
        # revision: [environment].network_mode = "no-network" is now a Harbor-enforced
        # platform policy on the agent's container (task.toml, not a runtime claim),
        # and Harbor's own per-trial config.json/result.json already records the
        # effective network mode it actually applied. Attest against THAT, outside
        # this container, before trusting export_decision for a specific trial.
        "network_mode_attested_in_container": False,
        "network_mode_attestation_source": (
            "cross-check the trial's own Harbor config.json/result.json "
            "(environment.override_network_mode / effective network policy) "
            "before treating export_decision as final for this trial"
        ),
        "artifacts": [
            "patch.diff",
            "changed_files.txt",
            "repo_state.txt",
            "reward-details.json",
            "reward-events.json",
            "agent_output",
        ],
        "failure_labels": failing,
    }

    for name, content in (
        ("reward.json", payload),
        ("reward-details.json", details),
        ("reward-events.json", events),
        ("training_export_manifest.json", manifest),
    ):
        atomic_write_text(
            RESULT_DIR / name,
            json.dumps(content, indent=2, sort_keys=True) + "\n",
        )
    atomic_write_text(RESULT_DIR / "reward.txt", f"{binary:.4f}\n")
    return binary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", required=True, choices=STAGES)
    args = parser.parse_args()
    stage = args.stage
    started = time.time()

    # Scaffolding from an earlier stage's gap probe, if that run was killed between
    # writing it and its cleanup. A leftover package would fail `go build ./...`.
    shutil.rmtree(TESTBED / "verifierprobe", ignore_errors=True)

    if stage == "01-diagnose":
        checks = diagnose()
    elif stage == "02-multi-project-model":
        checks = persistence(stage)
    elif stage == "03-search-and-indexing":
        checks = detection(stage)
    else:
        checks = harden(stage)

    # A weighted check that the stage never produced reads as "not passed" everywhere
    # downstream, so a verifier wiring bug silently scores the SUBMISSION zero and looks
    # exactly like an agent failure. That is how adapter_routing shipped: it was added to
    # the weight map and the critical set but attached to the wrong stage function, and
    # stage 03 returned 0.0 with the check simply absent. Fail loudly instead: this is a
    # defect in the grader and must never be booked against a run.
    missing = sorted(set(WEIGHTS[stage]) - set(checks))
    if missing:
        raise SystemExit(
            f"VERIFIER DEFECT: stage {stage} declares weights for {missing} but produced "
            f"no such check(s). A missing check would be scored as a failure against the "
            f"submission. Fix the stage function; do not grade this run."
        )

    # Integrity is evaluated AFTER the stage's checks, not before.
    # caught the previous ordering: stage 01 executes the agent's own reproducer
    # script, so clearing integrity first pre-approved a script whose purpose was
    # to tamper on execution. Every stage runs agent-authored or agent-influenced
    # code (the reproducer, then `go build`/`go test` over the agent's tree), so
    # the audit belongs at the end, where it sees the final state of the worktree,
    # the trajectory and the toolchain.
    integrity_ok, integrity_report = integrity(stage)

    binary = write_reward(stage, checks, integrity_report)
    report = write_ctrf(
        stage,
        checks,
        WEIGHTS[stage],
        CRITICAL_CHECKS[stage],
        integrity_report,
        started,
    )

    print(f"stage={stage} integrity_ok={integrity_ok} binary_reward={binary}")
    for name in sorted(checks):
        state = "PASS" if checks[name].get("passed") else "FAIL"
        print(f"  [{state}] {name}: {str(checks[name].get('detail', ''))[:400]}")
    if not integrity_ok:
        print("INTEGRITY FINDINGS:")
        for finding in integrity_report.get("findings", []):
            print(f"  - {finding}")

    # A per-test summary on stdout as well as in ctrf.json. Harbor captures this
    # stream as the verifier's test output, and it was previously empty because the
    # grader's own output went only to a log file.
    summary = report["results"]["summary"]
    print("=========================== short test summary info ============================")
    for entry in report["results"]["tests"]:
        print(f"{entry['status'].upper()} {entry['suite']}::{entry['name']}")
    print(
        f"======= {summary['passed']} passed, {summary['failed']} failed, "
        f"{summary['skipped']} skipped ======="
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
