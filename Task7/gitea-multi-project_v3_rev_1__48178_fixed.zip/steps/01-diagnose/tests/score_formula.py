#!/usr/bin/env python3
"""Shared deterministic/RewardKit scoring primitives.

Task-agnostic. The trial reward is a strict deterministic binary; the
continuous training_score blends deterministic evidence (D) with optional,
never-authoritative RewardKit signals (N) under a configurable lambda.
"""

from __future__ import annotations

import math
from collections.abc import Mapping


# The exact key set reward.json may contain. Harbor loads that file wholesale as the
# trial's reward vector, so every member is a score in [0, 1]: no counts, no indices,
# no digests. Anything else belongs in reward-details.json. The grader and the judge
# merge both assert against this set so a later edit cannot quietly widen the file.
#
# The core keys are always published. `non_deterministic_score` is published only
# when a judge actually returned a score, because a judge that did not run has no
# score -- it is N/A, not zero. Publishing a placeholder 0.0 both misreports the
# run and drags any surface that averages the reward vector: a fully passing Oracle
# rendered as 0.86 because six 1.0s were averaged with one "no judge here".
# The published scalar contract, exactly as the reward specification defines it. Four
# fields are always present; the two judge-dependent ones are omitted rather than
# zero-filled when no rubric applies, which is what "N/A for Oracle" means in practice.
# valid_trial lives in reward-details.json only: DataOS averages every numeric field
# in reward.json, so a validity flag must not sit beside the scored fields.
REWARD_JSON_CORE_KEYS = frozenset(
    {
        "reward",
        "binary_reward",
        "training_score",
        "deterministic_score",
    }
)

REWARD_JSON_JUDGED_KEYS = frozenset({"non_deterministic_score", "training_score_lambda"})

REWARD_JSON_KEYS = REWARD_JSON_CORE_KEYS | REWARD_JSON_JUDGED_KEYS


def reward_json_shape_ok(keys: object) -> bool:
    """True when a reward.json key set is the core set, optionally plus judge keys."""
    try:
        present = frozenset(keys)  # type: ignore[arg-type]
    except TypeError:
        return False
    return present >= REWARD_JSON_CORE_KEYS and present <= REWARD_JSON_KEYS


def clamp01(value: float) -> float:
    if not math.isfinite(value):
        return 0.0
    return max(0.0, min(1.0, float(value)))


# Documented, enforced range for NONDETERMINISTIC_LAMBDA. flagged
# that lambda had no stated upper bound: an operator export of, say, 50 would let
# judge annotations dominate training_score entirely, which is not what a
# "lambda-weighted annotation" is for. Binary reward is unaffected at any value -
# lambda never enters binary_outcome - but training_score has to stay
# interpretable, so the value is clamped into [0, 1] and the clamping is recorded.
LAMBDA_MIN = 0.0
LAMBDA_MAX = 1.0


def parse_lambda(value: object) -> float:
    """Coerce NONDETERMINISTIC_LAMBDA into the documented [0, 1] range.

    Anything unparseable, negative or non-finite becomes 0.0 (deterministic only);
    anything above LAMBDA_MAX is clamped down rather than honoured.
    """
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return LAMBDA_MIN
    if not math.isfinite(parsed) or parsed < LAMBDA_MIN:
        return LAMBDA_MIN
    return min(parsed, LAMBDA_MAX)


def deterministic_components(
    checks: Mapping[str, Mapping[str, object]],
    weights: Mapping[str, float],
    *,
    integrity_ok: bool,
    agent_contributed: bool = True,
) -> tuple[float, float]:
    """D_num/D_den for one stage.

    `agent_contributed` gates the numerator exactly like `integrity_ok` does: it is
    False when the tree shows no real agent work (an unmodified base, or a Stage 1
    run with no reproducer artifact), which zeroes every check's credit regardless of
    which individual baseline-only checks happen to pass for free on a pristine tree.
    A no-op must not earn deterministic or training score, and gating the callers'
    numerator here -- rather than reweighting the checks that are free on a clean
    tree -- means a FUTURE check that is also free on a pristine tree is covered by
    the same gate without anyone having to remember to reweight it too.
    """
    denominator = sum(max(0.0, float(weight)) for weight in weights.values())
    if not integrity_ok or not agent_contributed:
        return 0.0, denominator
    numerator = sum(
        max(0.0, float(weight))
        for name, weight in weights.items()
        if bool(checks.get(name, {}).get("passed"))
    )
    return numerator, denominator


def binary_outcome(*, required_checks_pass: bool, integrity_ok: bool) -> float:
    return 1.0 if required_checks_pass and integrity_ok else 0.0


def calculate_training_score(
    *,
    d_num: float,
    d_den: float,
    n_num: float = 0.0,
    n_den: float = 0.0,
    nondeterministic_lambda: float = 0.0,
    integrity_ok: bool = True,
    rewardkit_available: bool = True,
) -> float:
    if not integrity_ok:
        return 0.0
    d_num = max(0.0, float(d_num))
    d_den = max(0.0, float(d_den))
    n_num = max(0.0, float(n_num))
    n_den = max(0.0, float(n_den))
    weight = parse_lambda(nondeterministic_lambda)
    if not rewardkit_available or weight == 0.0 or n_den == 0.0:
        return clamp01(d_num / d_den) if d_den else 0.0
    denominator = d_den + weight * n_den
    if denominator == 0.0:
        return 0.0
    return clamp01((d_num + weight * n_num) / denominator)


def formula_text(
    *,
    d_num: float,
    d_den: float,
    n_num: float,
    n_den: float,
    nondeterministic_lambda: float,
    result: float,
) -> str:
    return (
        f"({d_num:.6f} + {nondeterministic_lambda:.6f} * {n_num:.6f}) / "
        f"({d_den:.6f} + {nondeterministic_lambda:.6f} * {n_den:.6f}) "
        f"= {result:.6f}"
    )
