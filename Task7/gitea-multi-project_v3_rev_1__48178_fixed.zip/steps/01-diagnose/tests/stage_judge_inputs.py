#!/usr/bin/env python3
"""Stage bounded, post-run evidence for optional semantic judges.

Copies only the verifier's own outputs plus size-bounded changed sources into
judge_inputs/. Never exposes /tests, /solution, golden patches, or git history.
"""

from __future__ import annotations

import json
import os
import shutil
from pathlib import Path


RESULT = Path(os.environ.get("RESULT_DIR", "/logs/verifier"))
TESTBED = Path(os.environ.get("TESTBED_DIR", "/testbed"))
OUTPUT = Path(os.environ.get("AGENT_OUTPUT_DIR", "/app/output"))
TESTS = Path(__file__).resolve().parent
DEST = RESULT / "judge_inputs"
AGENT_LOGS = Path(os.environ.get("AGENT_LOGS_DIR", "/logs/agent"))

# / Final-only the changed-source copy was bounded.
# Trajectories, patches, logs, reward files and the whole agent output tree were
# copied wholesale, so a large or hostile run could produce an unbounded bundle.
# Two limits now apply to EVERY file that enters the bundle, and one to the bundle
# as a whole; anything refused is recorded in judge_inputs/manifest.json rather
# than dropped silently, so a judge reading a truncated bundle can see that.
MAX_FILE_BYTES = 512 * 1024
MAX_BUNDLE_BYTES = 8 * 1024 * 1024

_budget = {"used": 0}
_skipped: list[dict[str, object]] = []


def _safe_source(source: Path) -> bool:
    """Reject anything that is not a regular file reachable without following a
    link out of its own tree. A symlink planted by the agent must not be able to
    pull /tests, /solution or an arbitrary host path into the judge bundle."""
    try:
        if source.is_symlink():
            _skipped.append({"path": str(source), "reason": "symlink"})
            return False
        if not source.is_file():
            return False
        resolved = source.resolve(strict=True)
    except (OSError, RuntimeError) as exc:
        _skipped.append({"path": str(source), "reason": repr(exc)})
        return False
    # AGENT_LOGS is the agent's own trajectory directory. It is added explicitly rather than
    # by widening the allow-list: the trajectory is required evidence for the process judge,
    # and without a root of its own it resolves outside every permitted root and is silently
    # dropped -- which is why no judge has ever run. Protected material is still refused
    # below, so this grants exactly one extra read-only source and nothing more.
    allowed = (RESULT.resolve(), TESTBED.resolve(), OUTPUT.resolve(), TESTS.resolve(),
               AGENT_LOGS.resolve()) if AGENT_LOGS.exists() else (
               RESULT.resolve(), TESTBED.resolve(), OUTPUT.resolve(), TESTS.resolve())
    if not any(resolved == root or root in resolved.parents for root in allowed):
        _skipped.append({"path": str(source), "reason": f"resolves outside the allowed roots: {resolved}"})
        return False
    # Never stage the protected material even if something above resolves into it.
    parts = set(resolved.parts)
    if {"hidden", "solution"} & parts or resolved.name == "golden.patch":
        _skipped.append({"path": str(source), "reason": "protected material"})
        return False
    return True


def copy_file(source: Path, destination: Path) -> None:
    if not _safe_source(source):
        return
    size = source.stat().st_size
    if size > MAX_FILE_BYTES:
        # Keep the head: a judge reading the first 512 KiB of a log learns far more
        # than one handed nothing, and the truncation is declared.
        destination.parent.mkdir(parents=True, exist_ok=True)
        with source.open("rb") as handle:
            head = handle.read(MAX_FILE_BYTES)
        if _budget["used"] + len(head) > MAX_BUNDLE_BYTES:
            _skipped.append({"path": str(source), "reason": "bundle budget exhausted"})
            return
        destination.write_bytes(head)
        _budget["used"] += len(head)
        _skipped.append({"path": str(source), "reason": f"truncated from {size} to {MAX_FILE_BYTES} bytes"})
        return
    if _budget["used"] + size > MAX_BUNDLE_BYTES:
        _skipped.append({"path": str(source), "reason": "bundle budget exhausted"})
        return
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    _budget["used"] += size


def copy_tree(source: Path, destination: Path) -> None:
    """Bounded replacement for shutil.copytree: every file goes through copy_file,
    so the per-file cap, the bundle budget and the path validation all apply."""
    if not source.is_dir():
        return
    for path in sorted(source.rglob("*")):
        if path.is_dir():
            continue
        copy_file(path, destination / path.relative_to(source))


def find_trajectory() -> Path | None:
    candidates = [
        os.environ.get("TRAJECTORY_PATH", ""),
        "/logs/agent/trajectory.json",
        "/logs/artifacts/trajectory.json",
        "/logs/trajectory.json",
        "/app/trajectory.json",
        "/logs/agent/terminus_2.pane",
        "/logs/agent/claude-code.txt",
    ]
    for candidate in candidates:
        path = Path(candidate) if candidate else None
        if path and path.is_file():
            return path
    return None


def instruction_from_trajectory(path: Path) -> str:
    try:
        payload = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return ""
    strings: list[str] = []

    def walk(value: object) -> None:
        if isinstance(value, str):
            strings.append(value)
        elif isinstance(value, dict):
            for child in value.values():
                walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)

    walk(payload)
    for text in strings:
        marker = "Task Description:"
        if marker not in text:
            continue
        task = text.split(marker, 1)[1]
        for ending in ("\n\nCurrent terminal state:", "\nCurrent terminal state:"):
            if ending in task:
                task = task.split(ending, 1)[0]
                break
        if task.strip():
            return task.strip() + "\n"
    return ""


def trajectory_activity(path: Path | None) -> dict[str, object]:
    if path is None:
        return {
            "trajectory_available": False,
            "agent_steps": 0,
            "tool_calls": 0,
        }
    try:
        payload = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except Exception as exc:
        return {
            "trajectory_available": True,
            "agent_steps": 0,
            "tool_calls": 0,
            "parse_error": repr(exc),
        }
    agent_steps = [
        step
        for step in payload.get("steps", [])
        if isinstance(step, dict) and step.get("source") == "agent"
    ]
    return {
        "trajectory_available": True,
        "agent_steps": len(agent_steps),
        "tool_calls": sum(
            len(step.get("tool_calls", []))
            for step in agent_steps
            if isinstance(step.get("tool_calls", []), list)
        ),
    }


def copy_changed_sources() -> dict[str, object]:
    copied: list[str] = []
    skipped: list[str] = []
    total = 0
    changed_file = RESULT / "changed_files.txt"
    if not changed_file.is_file():
        return {"copied": copied, "skipped": skipped, "bytes": total}
    for raw in changed_file.read_text(encoding="utf-8", errors="replace").splitlines():
        rel = Path(raw.strip())
        if not raw.strip() or rel.is_absolute() or ".." in rel.parts:
            continue
        source = TESTBED / rel
        try:
            size = source.stat().st_size
        except OSError:
            skipped.append(str(rel))
            continue
        if size > 524_288 or total + size > 4_194_304:
            skipped.append(str(rel))
            continue
        data = source.read_bytes()
        if b"\0" in data:
            skipped.append(str(rel))
            continue
        copy_file(source, DEST / "source" / rel)
        copied.append(str(rel))
        total += size
    return {"copied": copied, "skipped": skipped, "bytes": total}


def write_flat_manifest() -> None:
    """RewardKit 0.1.7 reads only the immediate children of a directory it is given.

    Evidence staged under judge_inputs/source/... and judge_inputs/agent_output/... is
    therefore invisible to it, so the prompt's promise that the judge sees changed sources
    and agent output is false. Write a single bounded, flat digest at the top level so the
    judge receives the substance rather than an empty directory listing.
    """
    lines: list[str] = []
    budget = 200_000
    for label, root in (("changed source", DEST / "source"), ("agent output", DEST / "agent_output")):
        if not root.is_dir():
            continue
        for f in sorted(root.rglob("*")):
            if not f.is_file():
                continue
            rel = f.relative_to(DEST).as_posix()
            try:
                body = f.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            if len(body) > 20_000:
                body = body[:20_000] + "\n... [truncated]\n"
            chunk = f"\n===== {label}: {rel} =====\n{body}\n"
            if budget - len(chunk) < 0:
                lines.append("\n... [manifest budget exhausted; remaining files omitted]\n")
                break
            budget -= len(chunk)
            lines.append(chunk)
    (DEST / "evidence_manifest.txt").write_text(
        "Flattened evidence. RewardKit 0.1.7 does not descend into subdirectories, so the "
        "nested trees under source/ and agent_output/ are reproduced here.\n"
        + "".join(lines),
        encoding="utf-8",
    )


def main() -> int:
    shutil.rmtree(DEST, ignore_errors=True)
    DEST.mkdir(parents=True)
    for name in (
        "reward.json",
        "reward-details.json",
        "reward-events.json",
        "reward.txt",
        "test_output.log",
        "patch.diff",
        "changed_files.txt",
        "training_export_manifest.json",
    ):
        copy_file(RESULT / name, DEST / name)
    # Bounded copy: the agent output tree is agent-controlled, so it must go
    # through the same per-file cap, bundle budget and path validation as
    # everything else rather than a wholesale copytree.
    copy_tree(OUTPUT, DEST / "agent_output")
    write_flat_manifest()
    copy_file(TESTS / "judge_prompt.md", DEST / "judge_prompt.md")
    copy_file(TESTS / "merge_readiness_rubric.md", DEST / "merge_readiness_rubric.md")

    trajectory = find_trajectory()
    if trajectory:
        copy_file(trajectory, DEST / "trajectory.json")
    instruction_candidates = [
        Path(os.environ.get("TASK_INSTRUCTION_PATH", "")),
        Path("/task/instruction.md"),
        Path("/instruction.md"),
        TESTS.parent / "instruction.md",
    ]
    instruction = next((path for path in instruction_candidates if str(path) and path.is_file()), None)
    if instruction:
        copy_file(instruction, DEST / "instruction.md")
    elif trajectory:
        extracted = instruction_from_trajectory(trajectory)
        if extracted:
            (DEST / "instruction.md").write_text(extracted, encoding="utf-8")

    source_manifest = copy_changed_sources()
    reward = {}
    reward_details = {}
    try:
        reward = json.loads((RESULT / "reward.json").read_text(encoding="utf-8"))
    except Exception:
        pass
    try:
        reward_details = json.loads(
            (RESULT / "reward-details.json").read_text(encoding="utf-8")
        )
    except Exception:
        pass
    deterministic_failures = {
        name: {
            "detail": check.get("detail"),
            "failure_reasons": check.get("failure_reasons", []),
            "requirements": check.get("requirements"),
            "failed_requirements": check.get("failed_requirements", []),
            "script_contract": check.get("script_contract"),
        }
        for name, check in reward_details.get("checks", {}).items()
        if isinstance(check, dict) and not check.get("passed")
    }
    context = {
        "task_family": os.environ.get("TASK_FAMILY", "gitea-multi-project-tier2"),
        "stage": os.environ.get("TASK_STAGE", "unknown"),
        "agent_activity": trajectory_activity(trajectory),
        "deterministic_binary_reward": reward.get("binary_reward", reward.get("reward", 0.0)),
        "deterministic_training_score": reward.get("training_score", 0.0),
        "deterministic_failures": deterministic_failures,
        "deterministic_failure_policy": (
            "The binary outcome is immutable, but these machine-generated reasons "
            "must be independently classified from supplied evidence as a model miss, "
            "prompt ambiguity, verifier defect, environment/build issue, timeout, "
            "contamination, or invalid shortcut."
        ),
        "judge_role": (
            "independent failure-classification and quality review; never a binary "
            "reward override"
        ),
        "source_snapshot": source_manifest,
        # Declared so a judge (and a reviewer) can see the bundle is bounded and
        # exactly what was refused or truncated on the way in.
        "bundle_budget": {
            "max_file_bytes": MAX_FILE_BYTES,
            "max_bundle_bytes": MAX_BUNDLE_BYTES,
            "bytes_used": _budget["used"],
            "within_budget": _budget["used"] <= MAX_BUNDLE_BYTES,
            "skipped_or_truncated": _skipped,
            "path_policy": (
                "regular files only; symlinks rejected; every path must resolve inside "
                "/logs/verifier, /testbed, /app/output or the verifier's own directory; "
                "hidden-test and solution material is refused even if reachable"
            ),
        },
    }
    (DEST / "judge_context.json").write_text(
        json.dumps(context, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (RESULT / "judge_status.json").write_text(
        json.dumps(
            {
                "available": False,
                "reason": "not requested; set RUN_LLM_JUDGES=1 and provide OPENAI_API_KEY to the verifier",
                "binary_reward_affected": False,
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
