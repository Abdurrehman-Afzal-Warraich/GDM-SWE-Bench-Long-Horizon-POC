// Copyright 2026 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package elasticsearch

import (
	"context"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"

	inner_elasticsearch "code.gitea.io/gitea/modules/indexer/internal/elasticsearch"
	"code.gitea.io/gitea/modules/indexer/issues/internal"

	"github.com/olivere/elastic/v7"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// TestElasticsearchSearchRoutesProjectIDs proves the elasticsearch backend actually
// consumes the plural project filter when it builds a search request, not merely
// that the field name appears somewhere in the source text of Search. It runs the
// REAL Search method against a local, hermetic fake Elasticsearch endpoint and
// inspects the outgoing query, so a Search that reads options.ProjectIDs into an
// unused variable, or that never reaches the query builder at all, fails here even
// though it still compiles.
//
// The fake server never leaves localhost and never touches a real search cluster:
// the client is built with elastic.SetHealthcheck(false)/SetSniff(false), so the
// only network call Search triggers is the search request itself.
func TestElasticsearchSearchRoutesProjectIDs(t *testing.T) {
	var mu sync.Mutex
	var lastBody string

	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if strings.HasSuffix(r.URL.Path, "/_search") {
			body, _ := io.ReadAll(r.Body)
			mu.Lock()
			lastBody = string(body)
			mu.Unlock()
			w.Header().Set("Content-Type", "application/json")
			_, _ = w.Write([]byte(`{
				"took": 1, "timed_out": false,
				"_shards": {"total": 1, "successful": 1, "skipped": 0, "failed": 0},
				"hits": {"total": {"value": 0, "relation": "eq"}, "max_score": null, "hits": []}
			}`))
			return
		}
		// Anything else (there should be nothing else, since Init()/health checks are
		// bypassed below) gets a generic empty-ack so a stray request never hangs.
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"acknowledged": true}`))
	}))
	defer server.Close()

	client, err := elastic.NewSimpleClient(elastic.SetURL(server.URL))
	require.NoError(t, err, "constructing a hermetic elastic client against the local fake must not fail")

	inner := inner_elasticsearch.NewIndexer(server.URL, "gitea-test-issues", 2, "{}")
	// Init() would drive the client through a real cluster ping and an index-exists
	// check this fake does not implement; assigning Client directly exercises the
	// SAME Search method the Oracle solution and every other submission runs,
	// without requiring a full Elasticsearch server for a project-filter test.
	inner.Client = client
	idx := &Indexer{inner: inner, Indexer: inner}

	ctx := context.Background()

	_, err = idx.Search(ctx, &internal.SearchOptions{ProjectIDs: []int64{101, 202}})
	require.NoError(t, err, "Search with ProjectIDs set must not error against the fake")
	mu.Lock()
	withFilter := lastBody
	mu.Unlock()
	require.NotEmpty(t, withFilter, "Search never reached the fake search endpoint")

	_, err = idx.Search(ctx, &internal.SearchOptions{})
	require.NoError(t, err, "Search with no project filter must not error against the fake")
	mu.Lock()
	withoutFilter := lastBody
	mu.Unlock()

	assert.Contains(t, withFilter, `"project_ids"`,
		"the outgoing query must reference project_ids when ProjectIDs is set")
	assert.NotContains(t, withoutFilter, `"project_ids"`,
		"the outgoing query must NOT reference project_ids when no project filter was requested")

	// Both ids must actually reach the query, not just the first one -- a Search
	// that filters on options.ProjectIDs[:1] would still contain "project_ids" and
	// pass the two assertions above while silently dropping the OR semantics the
	// briefing requires.
	assert.Contains(t, withFilter, "101")
	assert.Contains(t, withFilter, "202")

	// NoProjectOnly is a disclosed, distinct filter from ProjectIDs (the internal
	// SEARCH OPTIONS boolean, not the indexed-document flag) and must reach the
	// query as its own clause rather than being folded into an empty ProjectIDs
	// filter.
	_, err = idx.Search(ctx, &internal.SearchOptions{NoProjectOnly: true})
	require.NoError(t, err)
	mu.Lock()
	noProjectOnly := lastBody
	mu.Unlock()
	assert.Contains(t, noProjectOnly, `"no_project"`,
		"NoProjectOnly must route to its own no_project query clause")
}
