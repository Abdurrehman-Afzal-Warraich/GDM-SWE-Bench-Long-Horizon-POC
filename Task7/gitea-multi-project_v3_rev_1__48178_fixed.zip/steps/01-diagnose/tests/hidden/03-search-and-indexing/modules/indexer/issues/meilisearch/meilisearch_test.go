// Copyright 2026 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package meilisearch

import (
	"context"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"

	inner_meilisearch "code.gitea.io/gitea/modules/indexer/internal/meilisearch"
	"code.gitea.io/gitea/modules/indexer/issues/internal"

	ms "github.com/meilisearch/meilisearch-go"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// TestMeilisearchSearchRoutesProjectIDs is the meilisearch counterpart of the
// elasticsearch routing test: it runs the REAL Search method against a local,
// hermetic fake Meilisearch endpoint and inspects the outgoing filter, so a Search
// that reads options.ProjectIDs into an unused variable fails here even though it
// still compiles and even though no live Meilisearch service exists in this image.
func TestMeilisearchSearchRoutesProjectIDs(t *testing.T) {
	var mu sync.Mutex
	var lastBody string

	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if strings.Contains(r.URL.Path, "/search") {
			body, _ := io.ReadAll(r.Body)
			mu.Lock()
			lastBody = string(body)
			mu.Unlock()
			w.Header().Set("Content-Type", "application/json")
			_, _ = w.Write([]byte(`{
				"hits": [], "estimatedTotalHits": 0, "query": "",
				"limit": 1, "offset": 0, "processingTimeMs": 1
			}`))
			return
		}
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{}`))
	}))
	defer server.Close()

	inner := inner_meilisearch.NewIndexer(server.URL, "", "gitea-test-issues", 4, &ms.Settings{})
	// Init() would drive the client through GetIndex/CreateIndex/UpdateSettings this
	// fake does not implement; assigning Client directly (meilisearch.New performs no
	// network call at construction) exercises the SAME Search method the Oracle
	// solution and every other submission runs.
	inner.Client = ms.New(server.URL)
	idx := &Indexer{inner: inner, Indexer: inner}

	ctx := context.Background()

	_, err := idx.Search(ctx, &internal.SearchOptions{ProjectIDs: []int64{101, 202}})
	require.NoError(t, err, "Search with ProjectIDs set must not error against the fake")
	mu.Lock()
	withFilter := lastBody
	mu.Unlock()
	require.NotEmpty(t, withFilter, "Search never reached the fake search endpoint")

	_, err = idx.Search(ctx, &internal.SearchOptions{})
	require.NoError(t, err, "Search with no project filter must not error against the fake")
	mu.Lock()
	withoutFilter := lastBody
	mu.Unlock()

	assert.Contains(t, withFilter, "project_ids",
		"the outgoing filter must reference project_ids when ProjectIDs is set")
	assert.NotContains(t, withoutFilter, "project_ids",
		"the outgoing filter must NOT reference project_ids when no project filter was requested")
	assert.Contains(t, withFilter, "101")
	assert.Contains(t, withFilter, "202")

	_, err = idx.Search(ctx, &internal.SearchOptions{NoProjectOnly: true})
	require.NoError(t, err)
	mu.Lock()
	noProjectOnly := lastBody
	mu.Unlock()
	assert.Contains(t, noProjectOnly, "no_project",
		"NoProjectOnly must route to its own no_project filter clause")
}
