// Copyright 2026 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package issues_test

import (
	"fmt"
	"testing"

	issues_model "code.gitea.io/gitea/models/issues"
	project_model "code.gitea.io/gitea/models/project"
	"code.gitea.io/gitea/models/unittest"
	user_model "code.gitea.io/gitea/models/user"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// Searching issues by several project ids at once. This lives in Stage 3 because it is a
// SEARCH capability (models/issues/issue_search.go), not part of the Stage 2 model: an
// agent that has only built the multi-project model is not expected to satisfy it yet.
func TestIssueSearchByMultipleProjectIDs(t *testing.T) {
	require.NoError(t, unittest.PrepareTestDatabase())

	issue1 := unittest.AssertExistsAndLoadBean(t, &issues_model.Issue{ID: 1})
	issue2 := unittest.AssertExistsAndLoadBean(t, &issues_model.Issue{ID: 2})
	user2 := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 2})

	var projects []*project_model.Project
	for i := 1; i <= 3; i++ {
		project := &project_model.Project{
			Title:        fmt.Sprintf("Query Test Project %d", i),
			RepoID:       issue1.RepoID,
			Type:         project_model.TypeRepository,
			TemplateType: project_model.TemplateTypeBasicKanban,
		}
		require.NoError(t, project_model.NewProject(t.Context(), project))
		projects = append(projects, project)
		defer func(id int64) {
			_ = project_model.DeleteProjectByID(t.Context(), id)
		}(project.ID)
	}

	// issue1 -> projects 1 and 2; issue2 -> project 3.
	err := issues_model.IssueAssignOrRemoveProject(t.Context(), issue1, user2, []int64{projects[0].ID, projects[1].ID})
	require.NoError(t, err)
	err = issues_model.IssueAssignOrRemoveProject(t.Context(), issue2, user2, []int64{projects[2].ID})
	require.NoError(t, err)

	// Filtering by a single id must select exactly the issue in that project.
	issues, err := issues_model.Issues(t.Context(), &issues_model.IssuesOptions{
		RepoIDs:    []int64{issue1.RepoID},
		ProjectIDs: []int64{projects[2].ID},
	})
	require.NoError(t, err)
	assert.NotEmpty(t, issues, "should find issues in project 3")
	assert.True(t, containsIssue(issues, issue2.ID), "issue 2 should be found when querying project 3")
	assert.False(t, containsIssue(issues, issue1.ID), "issue 1 is not in project 3 and must not be returned")

	// Filtering by SEVERAL ids is a union: an issue in any of the named projects matches.
	issues, err = issues_model.Issues(t.Context(), &issues_model.IssuesOptions{
		RepoIDs:    []int64{issue1.RepoID},
		ProjectIDs: []int64{projects[0].ID, projects[2].ID},
	})
	require.NoError(t, err)
	assert.True(t, containsIssue(issues, issue1.ID), "issue 1 is in project 1 and must be returned")
	assert.True(t, containsIssue(issues, issue2.ID), "issue 2 is in project 3 and must be returned")

	// Order of the ids must not change the result set.
	reordered, err := issues_model.Issues(t.Context(), &issues_model.IssuesOptions{
		RepoIDs:    []int64{issue1.RepoID},
		ProjectIDs: []int64{projects[2].ID, projects[0].ID},
	})
	require.NoError(t, err)
	assert.ElementsMatch(t, idsOf(issues), idsOf(reordered), "filter result must not depend on id order")

	// A duplicated id must not duplicate rows.
	deduped, err := issues_model.Issues(t.Context(), &issues_model.IssuesOptions{
		RepoIDs:    []int64{issue1.RepoID},
		ProjectIDs: []int64{projects[2].ID, projects[2].ID},
	})
	require.NoError(t, err)
	assert.Len(t, idsOf(deduped), len(unique(idsOf(deduped))), "a repeated project id must not duplicate issues")

	err = issues_model.IssueAssignOrRemoveProject(t.Context(), issue1, user2, []int64{})
	require.NoError(t, err)
	err = issues_model.IssueAssignOrRemoveProject(t.Context(), issue2, user2, []int64{})
	require.NoError(t, err)
}

func containsIssue(issues issues_model.IssueList, id int64) bool {
	for _, issue := range issues {
		if issue.ID == id {
			return true
		}
	}
	return false
}

func idsOf(issues issues_model.IssueList) []int64 {
	ids := make([]int64, 0, len(issues))
	for _, issue := range issues {
		ids = append(ids, issue.ID)
	}
	return ids
}

func unique(ids []int64) []int64 {
	seen := make(map[int64]struct{}, len(ids))
	out := make([]int64, 0, len(ids))
	for _, id := range ids {
		if _, ok := seen[id]; ok {
			continue
		}
		seen[id] = struct{}{}
		out = append(out, id)
	}
	return out
}
