// Copyright 2026 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package repo

import (
	"encoding/json"
	"net/http"
	"strconv"
	"testing"

	issues_model "code.gitea.io/gitea/models/issues"
	project_model "code.gitea.io/gitea/models/project"
	"code.gitea.io/gitea/models/unittest"
	api "code.gitea.io/gitea/modules/structs"
	"code.gitea.io/gitea/modules/web"
	"code.gitea.io/gitea/services/contexttest"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// TestIssueProjectsAPISetClearOmitAndCreate calls the real v1 handlers. The
// structs-only tests establish JSON shape; this test proves that the handler
// carries that shape through persistence and back into the response.
func TestIssueProjectsAPISetClearOmitAndCreate(t *testing.T) {
	unittest.PrepareTestEnv(t)

	issue := unittest.AssertExistsAndLoadBean(t, &issues_model.Issue{ID: 1})
	doerID := int64(2)
	project1 := unittest.AssertExistsAndLoadBean(t, &project_model.Project{ID: 1})
	project2 := &project_model.Project{
		Title:        "Second API project",
		RepoID:       issue.RepoID,
		Type:         project_model.TypeRepository,
		TemplateType: project_model.TemplateTypeBasicKanban,
	}
	require.NoError(t, project_model.NewProject(t.Context(), project2))
	t.Cleanup(func() { _ = project_model.DeleteProjectByID(t.Context(), project2.ID) })

	projectIDs := func(issueID int64) []int64 {
		fresh, err := issues_model.GetIssueByID(t.Context(), issueID)
		require.NoError(t, err)
		require.NoError(t, fresh.LoadProjects(t.Context()))
		ids := make([]int64, 0, len(fresh.Projects))
		for _, project := range fresh.Projects {
			ids = append(ids, project.ID)
		}
		return ids
	}

	edit := func(projects *[]int64) (*api.Issue, int) {
		ctx, recorder := contexttest.MockAPIContext(t, "PATCH /user2/repo1/issues/1")
		contexttest.LoadUser(t, ctx, doerID)
		contexttest.LoadRepo(t, ctx, issue.RepoID)
		ctx.SetPathParam("index", strconv.FormatInt(issue.Index, 10))
		web.SetForm(ctx, &api.EditIssueOption{Projects: projects})
		EditIssue(ctx)
		response := &api.Issue{}
		if recorder.Body.Len() > 0 {
			_ = json.Unmarshal(recorder.Body.Bytes(), response)
		}
		return response, recorder.Code
	}

	t.Run("edit set is persisted and returned", func(t *testing.T) {
		want := []int64{project1.ID, project2.ID}
		response, status := edit(&want)
		require.Equal(t, http.StatusCreated, status)
		assert.ElementsMatch(t, want, projectIDs(issue.ID))
		returned := make([]int64, 0, len(response.Projects))
		for _, project := range response.Projects {
			returned = append(returned, project.ID)
		}
		assert.ElementsMatch(t, want, returned, "the API response must carry every persisted project")
	})

	t.Run("omitting projects preserves membership", func(t *testing.T) {
		before := projectIDs(issue.ID)
		_, status := edit(nil)
		require.Equal(t, http.StatusCreated, status)
		assert.ElementsMatch(t, before, projectIDs(issue.ID))
	})

	t.Run("explicit empty projects clears membership", func(t *testing.T) {
		empty := []int64{}
		response, status := edit(&empty)
		require.Equal(t, http.StatusCreated, status)
		assert.Empty(t, projectIDs(issue.ID))
		assert.Empty(t, response.Projects)
	})

	t.Run("invalid project is rejected atomically", func(t *testing.T) {
		baseline := []int64{project1.ID, project2.ID}
		_, status := edit(&baseline)
		require.Equal(t, http.StatusCreated, status)
		invalid := []int64{project2.ID, 9_999_999}
		_, status = edit(&invalid)
		assert.Equal(t, http.StatusBadRequest, status)
		assert.ElementsMatch(t, baseline, projectIDs(issue.ID), "a rejected edit must not partially mutate membership")
	})

	t.Run("create persists and returns the requested set", func(t *testing.T) {
		ctx, recorder := contexttest.MockAPIContext(t, "POST /user2/repo1/issues")
		contexttest.LoadUser(t, ctx, doerID)
		contexttest.LoadRepo(t, ctx, issue.RepoID)
		want := []int64{project1.ID, project2.ID}
		web.SetForm(ctx, &api.CreateIssueOption{
			Title:    "API multi-project creation",
			Projects: want,
		})
		CreateIssue(ctx)
		require.Equal(t, http.StatusCreated, recorder.Code)
		response := &api.Issue{}
		require.NoError(t, json.Unmarshal(recorder.Body.Bytes(), response))
		assert.ElementsMatch(t, want, projectIDs(response.ID))
		returned := make([]int64, 0, len(response.Projects))
		for _, project := range response.Projects {
			returned = append(returned, project.ID)
		}
		assert.ElementsMatch(t, want, returned)
	})
}
