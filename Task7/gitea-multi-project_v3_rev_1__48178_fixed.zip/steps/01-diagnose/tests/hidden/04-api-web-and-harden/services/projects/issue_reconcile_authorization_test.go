// Copyright 2026 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package project

import (
	"testing"

	issues_model "code.gitea.io/gitea/models/issues"
	project_model "code.gitea.io/gitea/models/project"
	repo_model "code.gitea.io/gitea/models/repo"
	"code.gitea.io/gitea/models/unittest"
	user_model "code.gitea.io/gitea/models/user"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// TestIssueAssignOrRemoveProjectDuplicateAndUnauthorized covers the two reconciliation
// failure/edge cases the model-layer corpus (issue_project_multi_test.go) does not:
// a duplicate id inside one requested set, and a project belonging to a repository the
// issue is not on. Both are exercised through the SAME entry point the API router calls
// directly (routers/api/v1/repo/issue.go's EditIssue), so this proves the router's error
// mapping has real failures to map, not merely that the compile-time call site exists.
func TestIssueAssignOrRemoveProjectDuplicateAndUnauthorized(t *testing.T) {
	require.NoError(t, unittest.PrepareTestDatabase())
	user2 := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 2})

	t.Run("DuplicateIDInOneCallIsNotAnError", func(t *testing.T) {
		issue1 := unittest.AssertExistsAndLoadBean(t, &issues_model.Issue{ID: 1})
		project := &project_model.Project{
			Title:        "Duplicate ID target",
			RepoID:       issue1.RepoID,
			Type:         project_model.TypeRepository,
			TemplateType: project_model.TemplateTypeBasicKanban,
		}
		require.NoError(t, project_model.NewProject(t.Context(), project))
		defer func() { _ = project_model.DeleteProjectByID(t.Context(), project.ID) }()

		// The same id twice in one requested set: reconciliation is a SET operation, so
		// this must behave exactly like requesting it once -- neither an error nor a
		// double column-map entry -- rather than surfacing a unique-constraint failure
		// from a naive implementation that inserts once per element of the input slice.
		err := issues_model.IssueAssignOrRemoveProject(t.Context(), issue1, user2, []int64{project.ID, project.ID})
		require.NoError(t, err, "a duplicate id in the requested set must not itself be an error")

		fresh, err := issues_model.GetIssueByID(t.Context(), issue1.ID)
		require.NoError(t, err)
		require.NoError(t, fresh.LoadProjects(t.Context()))
		assert.Len(t, fresh.Projects, 1, "a duplicate id must not create two memberships")
		if len(fresh.Projects) > 0 {
			assert.Equal(t, project.ID, fresh.Projects[0].ID)
		}

		columnMap, err := fresh.ProjectColumnMap(t.Context())
		require.NoError(t, err)
		assert.Len(t, columnMap, 1, "a duplicate id must not create two column placements")

		require.NoError(t, issues_model.IssueAssignOrRemoveProject(t.Context(), issue1, user2, []int64{}))
	})

	t.Run("ProjectFromAnotherRepositoryIsRejectedAndMembershipUnchanged", func(t *testing.T) {
		// issue6 belongs to repository 3 (see services/projects/issue_test.go's own
		// fixture comment); repository 1 is a distinct, unrelated repository. A project
		// that lives on repository 1 is not one issue6's repository is allowed to use,
		// which the contract states is its own failure mode, distinct from "does not
		// exist at all".
		issue6 := unittest.AssertExistsAndLoadBean(t, &issues_model.Issue{ID: 6})
		otherRepo := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 1})
		require.NotEqual(t, issue6.RepoID, otherRepo.ID, "the fixture must give the issue and the foreign project different repositories")

		foreignProject := &project_model.Project{
			Title:        "Belongs to a different repository",
			RepoID:       otherRepo.ID,
			Type:         project_model.TypeRepository,
			TemplateType: project_model.TemplateTypeBasicKanban,
		}
		require.NoError(t, project_model.NewProject(t.Context(), foreignProject))
		defer func() { _ = project_model.DeleteProjectByID(t.Context(), foreignProject.ID) }()

		// Establish a known-good baseline membership first, so a partially-applied
		// rejection would be visible as a CHANGE rather than coincidentally matching
		// the pristine fixture state.
		ownProject := &project_model.Project{
			Title:        "Issue6's own project",
			RepoID:       issue6.RepoID,
			Type:         project_model.TypeRepository,
			TemplateType: project_model.TemplateTypeBasicKanban,
		}
		require.NoError(t, project_model.NewProject(t.Context(), ownProject))
		defer func() { _ = project_model.DeleteProjectByID(t.Context(), ownProject.ID) }()
		require.NoError(t, issues_model.IssueAssignOrRemoveProject(t.Context(), issue6, user2, []int64{ownProject.ID}))

		err := issues_model.IssueAssignOrRemoveProject(t.Context(), issue6, user2, []int64{foreignProject.ID})
		require.Error(t, err, "a project belonging to a different repository must be rejected")

		fresh, err := issues_model.GetIssueByID(t.Context(), issue6.ID)
		require.NoError(t, err)
		require.NoError(t, fresh.LoadProjects(t.Context()))
		require.Len(t, fresh.Projects, 1, "the rejected call must leave membership exactly as it was")
		assert.Equal(t, ownProject.ID, fresh.Projects[0].ID)

		require.NoError(t, issues_model.IssueAssignOrRemoveProject(t.Context(), issue6, user2, []int64{}))
	})
}
