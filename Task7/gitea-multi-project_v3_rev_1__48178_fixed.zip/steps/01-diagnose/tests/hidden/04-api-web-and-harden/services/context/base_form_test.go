// Copyright 2026 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package context

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"code.gitea.io/gitea/modules/setting"

	"github.com/stretchr/testify/assert"
)

// The issue list accepts the project filter as a comma-joined query parameter
// and feeds the result straight into the search options, so how it parses is
// part of the outward contract. Expectations here follow the documented
// behaviour of the shared string-to-int64 helper: empty fields are skipped, and
// a single unparseable field discards the whole filter rather than silently
// dropping one board.
func TestFormStringInt64sParsesTheProjectFilter(t *testing.T) {
	setting.IsInTesting = true
	for _, c := range []struct {
		query string
		want  []int64
	}{
		{"", nil},
		{"?project=", nil},
		{"?project=7", []int64{7}},
		{"?project=7,9,11", []int64{7, 9, 11}},
		{"?project=7,,9", []int64{7, 9}},
		{"?project=7,%209", nil},
		{"?project=7,notanumber", nil},
	} {
		req, err := http.NewRequest(http.MethodGet, "/"+c.query, nil)
		assert.NoError(t, err)
		b := NewBaseContextForTest(httptest.NewRecorder(), req)
		got := b.FormStringInt64s("project")
		if len(c.want) == 0 {
			assert.Empty(t, got, "query = %q", c.query)
			continue
		}
		assert.Equal(t, c.want, got, "query = %q", c.query)
	}
}
