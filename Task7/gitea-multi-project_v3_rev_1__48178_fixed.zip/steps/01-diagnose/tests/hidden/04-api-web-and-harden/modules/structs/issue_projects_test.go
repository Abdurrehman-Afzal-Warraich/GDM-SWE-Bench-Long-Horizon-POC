// Copyright 2026 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package structs

import (
	"encoding/json"
	"reflect"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// The outward API contract for multi-project placement. These are shape
// assertions rather than behaviour, but the shape IS the contract here: whether
// an omitted field can be told apart from an empty one is decided by the type,
// and getting it wrong silently clears every board on an unrelated edit.
func TestIssueAPICarriesEveryProject(t *testing.T) {
	field, ok := reflect.TypeOf(Issue{}).FieldByName("Projects")
	require.True(t, ok, "the issue payload must expose the projects it belongs to")
	assert.Equal(t, reflect.Slice, field.Type.Kind(),
		"an issue can be on several boards, so the payload must be a list")
	assert.Equal(t, "projects", field.Tag.Get("json"))
}

func TestCreateIssueAcceptsASetOfProjects(t *testing.T) {
	field, ok := reflect.TypeOf(CreateIssueOption{}).FieldByName("Projects")
	require.True(t, ok, "creating an issue must accept the set of boards to put it on")
	assert.Equal(t, reflect.Slice, field.Type.Kind())
	assert.Equal(t, reflect.Int64, field.Type.Elem().Kind())
}

// The one that matters most. On edit the field must be a POINTER, so that
// "projects omitted" and "projects set to none" are different requests. If it
// were a plain slice, every edit that did not mention projects would arrive as
// an empty set and remove the issue from every board it was on.
func TestEditIssueDistinguishesOmittedProjectsFromAnEmptySet(t *testing.T) {
	field, ok := reflect.TypeOf(EditIssueOption{}).FieldByName("Projects")
	require.True(t, ok, "editing an issue must be able to set the project list")
	require.Equal(t, reflect.Pointer, field.Type.Kind(),
		"Projects must be a pointer on edit so an omitted field is distinguishable "+
			"from an explicit empty list; a plain slice would clear the boards on "+
			"any edit that did not mention them")
	assert.Equal(t, reflect.Slice, field.Type.Elem().Kind())
	assert.Equal(t, reflect.Int64, field.Type.Elem().Elem().Kind())

	var omitted EditIssueOption
	require.NoError(t, json.Unmarshal([]byte(`{"title":"t"}`), &omitted))
	assert.Nil(t, omitted.Projects, "an absent field must decode to nil (leave alone)")

	var cleared EditIssueOption
	require.NoError(t, json.Unmarshal([]byte(`{"projects":[]}`), &cleared))
	require.NotNil(t, cleared.Projects, "an explicit empty list must decode to non-nil")
	assert.Empty(t, *cleared.Projects, "and must mean: remove from every board")

	var set EditIssueOption
	require.NoError(t, json.Unmarshal([]byte(`{"projects":[7,9]}`), &set))
	require.NotNil(t, set.Projects)
	assert.Equal(t, []int64{7, 9}, *set.Projects)
}
