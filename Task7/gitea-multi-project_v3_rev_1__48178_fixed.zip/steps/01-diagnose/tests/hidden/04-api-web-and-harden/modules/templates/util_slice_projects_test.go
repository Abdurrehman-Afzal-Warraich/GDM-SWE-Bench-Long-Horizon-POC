// Copyright 2026 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package templates

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

// The sidebar renders one toggle per project board. Both helpers are part of the
// disclosed identifier contract for this stage, so both are graded here: a
// contract that names an identifier the corpus never exercises is a requirement
// the submission cannot be held to.
func TestSliceUtilsJoinInt64(t *testing.T) {
	su := &SliceUtils{}
	assert.Empty(t, su.JoinInt64(nil))
	assert.Empty(t, su.JoinInt64([]int64{}))
	assert.Equal(t, "7", su.JoinInt64([]int64{7}))
	assert.Equal(t, "7,9,11", su.JoinInt64([]int64{7, 9, 11}))
	// order is the caller's, not sorted for them
	assert.Equal(t, "11,7", su.JoinInt64([]int64{11, 7}))
	assert.Equal(t, "-3,0", su.JoinInt64([]int64{-3, 0}))
}

// Toggling is the outward behaviour of the project sidebar: clicking a board the
// issue is already on removes it, clicking any other board adds it, and every
// other board keeps its placement either way.
func TestSliceUtilsJoinToggleIDs(t *testing.T) {
	su := &SliceUtils{}

	t.Run("adds a project the issue is not on", func(t *testing.T) {
		got := su.JoinToggleIDs([]int64{7, 9}, 11)
		assert.False(t, got.IsIncluded)
		assert.Equal(t, "7,9,11", got.ToggledIDs)
	})

	t.Run("removes a project the issue is already on", func(t *testing.T) {
		got := su.JoinToggleIDs([]int64{7, 9, 11}, 9)
		assert.True(t, got.IsIncluded)
		assert.Equal(t, "7,11", got.ToggledIDs,
			"removing one board must leave the others untouched")
	})

	t.Run("toggling the only project clears the set", func(t *testing.T) {
		got := su.JoinToggleIDs([]int64{7}, 7)
		assert.True(t, got.IsIncluded)
		assert.Empty(t, got.ToggledIDs)
	})

	t.Run("adds to an empty set", func(t *testing.T) {
		got := su.JoinToggleIDs(nil, 7)
		assert.False(t, got.IsIncluded)
		assert.Equal(t, "7", got.ToggledIDs)
	})

	t.Run("repeated calls over one slice stay independent", func(t *testing.T) {
		// The sidebar renders a toggle for every board from the same slice, so each
		// call must be computed against the ORIGINAL set, not against the result of
		// the previous call. This pins that usage; it deliberately does not claim
		// the helper never writes through a slice with spare capacity, which is a
		// property of append that the caller's slice shape decides.
		current := []int64{7, 9}
		first := su.JoinToggleIDs(current, 11)
		second := su.JoinToggleIDs(current, 13)
		assert.Equal(t, "7,9,11", first.ToggledIDs)
		assert.Equal(t, "7,9,13", second.ToggledIDs,
			"the second toggle must not see the first one's addition")
		assert.Equal(t, []int64{7, 9}, current)
	})

	t.Run("round trip returns to the original set", func(t *testing.T) {
		added := su.JoinToggleIDs([]int64{7, 9}, 11)
		assert.Equal(t, "7,9,11", added.ToggledIDs)
		back := su.JoinToggleIDs([]int64{7, 9, 11}, 11)
		assert.Equal(t, "7,9", back.ToggledIDs)
	})
}
