// Copyright 2026 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package issues_test

import (
	"fmt"
	"sync"
	"testing"

	issues_model "code.gitea.io/gitea/models/issues"
	project_model "code.gitea.io/gitea/models/project"
	"code.gitea.io/gitea/models/unittest"
	user_model "code.gitea.io/gitea/models/user"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestIssueMultipleProjects(t *testing.T) {
	require.NoError(t, unittest.PrepareTestDatabase())

	t.Run("GeneralTest", func(t *testing.T) {
		// Get test data
		issue1 := unittest.AssertExistsAndLoadBean(t, &issues_model.Issue{ID: 1})
		user2 := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 2})
		project1 := unittest.AssertExistsAndLoadBean(t, &project_model.Project{ID: 1})

		// Create a second project for the same repository
		project2 := &project_model.Project{
			Title:        "Test Project 2",
			RepoID:       issue1.RepoID,
			Type:         project_model.TypeRepository,
			TemplateType: project_model.TemplateTypeBasicKanban,
		}
		require.NoError(t, project_model.NewProject(t.Context(), project2))
		defer func() {
			_ = project_model.DeleteProjectByID(t.Context(), project2.ID)
		}()

		err := issues_model.IssueAssignOrRemoveProject(t.Context(), issue1, user2, []int64{})
		require.NoError(t, err)
		err = issue1.LoadProjects(t.Context())
		require.NoError(t, err)
		require.Empty(t, issue1.Projects)

		// assign issue to both projects (each project uses its own default column)
		err = issues_model.IssueAssignOrRemoveProject(t.Context(), issue1, user2, []int64{project1.ID})
		require.NoError(t, err)
		assertPersistedProjects(t, issue1.ID, project1.ID)
		// Cache representation is deliberately NOT asserted here: nil-ing the slice and
		// eagerly refreshing it are both correct under the prompt. Freshness is proved
		// below by reading the persisted state back through an independent instance.
		err = issue1.LoadProjects(t.Context())
		require.NoError(t, err)
		require.Len(t, issue1.Projects, 1)

		err = issues_model.IssueAssignOrRemoveProject(t.Context(), issue1, user2, []int64{project1.ID, project2.ID})
		require.NoError(t, err)
		assertPersistedProjects(t, issue1.ID, project1.ID, project2.ID)
		// Cache representation is deliberately NOT asserted here: nil-ing the slice and
		// eagerly refreshing it are both correct under the prompt. Freshness is proved
		// below by reading the persisted state back through an independent instance.
		err = issue1.LoadProjects(t.Context())
		require.NoError(t, err)
		require.Len(t, issue1.Projects, 2)
		assert.ElementsMatch(t, []int64{project1.ID, project2.ID}, []int64{issue1.Projects[0].ID, issue1.Projects[1].ID}, "Issue should be in both projects")

		// test issue's project column map
		projectColumnMap, err := issue1.ProjectColumnMap(t.Context())
		p1Col, _ := project1.MustDefaultColumn(t.Context())
		p2Col, _ := project2.MustDefaultColumn(t.Context())
		require.NoError(t, err)
		assert.Equal(t, p1Col.ID, projectColumnMap[project1.ID])
		assert.Equal(t, p2Col.ID, projectColumnMap[project2.ID])

		// only keep project2
		err = issues_model.IssueAssignOrRemoveProject(t.Context(), issue1, user2, []int64{project2.ID})
		require.NoError(t, err)
		err = issue1.LoadProjects(t.Context())
		require.NoError(t, err)
		require.Len(t, issue1.Projects, 1)
		assert.Equal(t, project2.ID, issue1.Projects[0].ID)

		// also test ResetAttributesLoaded
		issue1.Projects = nil
		issue1.ResetAttributesLoaded()
		err = issue1.LoadProjects(t.Context())
		require.NoError(t, err)
		require.Len(t, issue1.Projects, 1)
		assert.Equal(t, project2.ID, issue1.Projects[0].ID)

		// remove issue's projects
		err = issues_model.IssueAssignOrRemoveProject(t.Context(), issue1, user2, []int64{})
		require.NoError(t, err)
		err = issue1.LoadProjects(t.Context())
		require.NoError(t, err)
		require.Empty(t, issue1.Projects)
	})

	// Every transition above moves the membership by exactly one project, so a reconciler that
	// handles only the first pending addition (or removal) and ignores the rest satisfies all
	// of them. Reconciliation is a set operation and has to be graded as one: each call below
	// changes membership by more than one project at a time.
	t.Run("BatchedReconciliation", func(t *testing.T) {
		issue2 := unittest.AssertExistsAndLoadBean(t, &issues_model.Issue{ID: 2})
		user2 := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 2})

		made := make([]*project_model.Project, 0, 3)
		for i := range 3 {
			p := &project_model.Project{
				Title:        fmt.Sprintf("Batch Project %d", i+1),
				RepoID:       issue2.RepoID,
				Type:         project_model.TypeRepository,
				TemplateType: project_model.TemplateTypeBasicKanban,
			}
			require.NoError(t, project_model.NewProject(t.Context(), p))
			made = append(made, p)
		}
		defer func() {
			for _, p := range made {
				_ = project_model.DeleteProjectByID(t.Context(), p.ID)
			}
		}()
		a, b, c := made[0].ID, made[1].ID, made[2].ID

		require.NoError(t, issues_model.IssueAssignOrRemoveProject(t.Context(), issue2, user2, []int64{}))
		assertPersistedProjects(t, issue2.ID)

		// two additions in a single call, from an empty membership
		require.NoError(t, issues_model.IssueAssignOrRemoveProject(t.Context(), issue2, user2, []int64{a, b}))
		assertPersistedProjects(t, issue2.ID, a, b)

		// one call that adds and removes at the same time: {a,b} -> {b,c}
		require.NoError(t, issues_model.IssueAssignOrRemoveProject(t.Context(), issue2, user2, []int64{b, c}))
		assertPersistedProjects(t, issue2.ID, b, c)

		// re-stating the same set must be a no-op, not a duplicate or a wipe
		require.NoError(t, issues_model.IssueAssignOrRemoveProject(t.Context(), issue2, user2, []int64{b, c}))
		assertPersistedProjects(t, issue2.ID, b, c)

		// two removals in a single call
		require.NoError(t, issues_model.IssueAssignOrRemoveProject(t.Context(), issue2, user2, []int64{}))
		assertPersistedProjects(t, issue2.ID)
	})

	// A rejected reconciliation must leave the membership exactly as it was. Removals are
	// applied before additions, so an implementation that does not perform the whole
	// reconciliation as one unit drops the removed projects and then fails on the bad id,
	// leaving a partially applied set. Only the persisted state is asserted, and the error
	// itself only has to BE an error: which sentinel it wraps is an internal choice.
	t.Run("FailedReconciliationLeavesMembershipUnchanged", func(t *testing.T) {
		issue3 := unittest.AssertExistsAndLoadBean(t, &issues_model.Issue{ID: 3})
		user2 := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 2})

		made := make([]*project_model.Project, 0, 2)
		for i := range 2 {
			p := &project_model.Project{
				Title:        fmt.Sprintf("Atomic Project %d", i+1),
				RepoID:       issue3.RepoID,
				Type:         project_model.TypeRepository,
				TemplateType: project_model.TemplateTypeBasicKanban,
			}
			require.NoError(t, project_model.NewProject(t.Context(), p))
			made = append(made, p)
		}
		defer func() {
			for _, p := range made {
				_ = project_model.DeleteProjectByID(t.Context(), p.ID)
			}
		}()
		a, b := made[0].ID, made[1].ID

		require.NoError(t, issues_model.IssueAssignOrRemoveProject(t.Context(), issue3, user2, []int64{a, b}))
		assertPersistedProjects(t, issue3.ID, a, b)

		// {a,b} -> {b, <nonexistent>}: drops a, adds an id that cannot resolve.
		const missingProjectID int64 = 9999999
		unittest.AssertNotExistsBean(t, &project_model.Project{ID: missingProjectID})
		err := issues_model.IssueAssignOrRemoveProject(t.Context(), issue3, user2, []int64{b, missingProjectID})
		require.Error(t, err, "reconciling to a set containing an unknown project must fail")
		assertPersistedProjects(t, issue3.ID, a, b)

		require.NoError(t, issues_model.IssueAssignOrRemoveProject(t.Context(), issue3, user2, []int64{}))
		assertPersistedProjects(t, issue3.ID)
	})

	// Each call has to apply as a unit. Several reconciliations of the same issue, each
	// asking for a different single project, must leave the issue on exactly one of them --
	// whichever call is applied last. A reconciliation that is not a unit can interleave one
	// call's removals with another's insert and leave the issue on none of them or on
	// several, which is the state a user sees as a board membership that silently vanished.
	t.Run("ConcurrentReconciliationsEachApplyAsAUnit", func(t *testing.T) {
		issue4 := unittest.AssertExistsAndLoadBean(t, &issues_model.Issue{ID: 4})
		user2 := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 2})

		const workers = 4
		made := make([]*project_model.Project, 0, workers)
		for i := range workers {
			p := &project_model.Project{
				Title:        fmt.Sprintf("Concurrent Project %d", i+1),
				RepoID:       issue4.RepoID,
				Type:         project_model.TypeRepository,
				TemplateType: project_model.TemplateTypeBasicKanban,
			}
			require.NoError(t, project_model.NewProject(t.Context(), p))
			made = append(made, p)
		}
		defer func() {
			for _, p := range made {
				_ = project_model.DeleteProjectByID(t.Context(), p.ID)
			}
		}()

		require.NoError(t, issues_model.IssueAssignOrRemoveProject(t.Context(), issue4, user2, []int64{}))

		var wg sync.WaitGroup
		errs := make([]error, workers)
		for i := range workers {
			wg.Add(1)
			go func(i int) {
				defer wg.Done()
				// Each goroutine owns its own *Issue value: the in-memory cache field is
				// not shared state under test here, the persisted membership is.
				own := &issues_model.Issue{ID: issue4.ID, RepoID: issue4.RepoID, Repo: issue4.Repo}
				errs[i] = issues_model.IssueAssignOrRemoveProject(
					t.Context(), own, user2, []int64{made[i].ID},
				)
			}(i)
		}
		wg.Wait()
		for i, err := range errs {
			require.NoErrorf(t, err, "concurrent reconciliation %d must not fail", i)
		}

		fresh, err := issues_model.GetIssueByID(t.Context(), issue4.ID)
		require.NoError(t, err)
		require.NoError(t, fresh.LoadProjects(t.Context()))
		require.Len(t, fresh.Projects, 1,
			"after concurrent whole-set reconciliations the issue must be on exactly one project")
		wanted := make([]int64, 0, workers)
		for _, p := range made {
			wanted = append(wanted, p.ID)
		}
		assert.Contains(t, wanted, fresh.Projects[0].ID,
			"the surviving project must be one that was actually requested")

		columnMap, err := fresh.ProjectColumnMap(t.Context())
		require.NoError(t, err)
		assert.Len(t, columnMap, 1, "exactly one column placement must survive")

		require.NoError(t, issues_model.IssueAssignOrRemoveProject(t.Context(), issue4, user2, []int64{}))
	})

}

// assertPersistedProjects reloads the issue from the database through a fresh instance and
// checks the persisted membership. This is the property the prompt actually states: after
// reconciliation a subsequent load observes exactly the requested set. It is insensitive to
// how (or whether) the caller's in-memory cache was invalidated, but a stale slice cannot
// satisfy it because the assertion never reads the original instance.
func assertPersistedProjects(t *testing.T, issueID int64, want ...int64) {
	t.Helper()

	fresh, err := issues_model.GetIssueByID(t.Context(), issueID)
	require.NoError(t, err)
	require.NoError(t, fresh.LoadProjects(t.Context()))

	got := make([]int64, 0, len(fresh.Projects))
	for _, p := range fresh.Projects {
		got = append(got, p.ID)
	}
	assert.ElementsMatch(t, want, got,
		"a fresh load of the issue must observe exactly the reconciled project set")

	columnMap, err := fresh.ProjectColumnMap(t.Context())
	require.NoError(t, err)
	assert.Len(t, columnMap, len(want),
		"the per-project column map must cover exactly the persisted projects")
	for _, id := range want {
		assert.Contains(t, columnMap, id,
			"every persisted project must have a column placement")
	}
}
