#!/usr/bin/env python3
"""Merge applicable RewardKit rubric scores into the continuous training score.

RewardKit is advisory only: it may move training_score via the lambda formula,
but `reward` and `binary_reward` remain the immutable deterministic binary.
"""

from __future__ import annotations

import argparse
import json
import os
import tomllib
from pathlib import Path

from score_formula import (
    REWARD_JSON_CORE_KEYS,
    REWARD_JSON_JUDGED_KEYS,
    calculate_training_score,
    clamp01,
    formula_text,
    parse_lambda,
    reward_json_shape_ok,
)


AGENT_DIMENSIONS = ("process", "validity", "merge_readiness")


def load_json(path: Path) -> dict[str, object]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return payload if isinstance(payload, dict) else {}


def clamp(value: object) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return max(0.0, min(1.0, float(value)))


def rubric_definition(tests_dir: Path, dimension: str) -> tuple[float, dict[str, float]]:
    payload = tomllib.loads(
        (tests_dir / dimension / "judge.toml").read_text(encoding="utf-8")
    )
    dimension_weight = max(0.0, float(payload["judge"]["weight"]))
    criteria = {
        str(criterion["name"]): max(0.0, float(criterion["weight"]))
        for criterion in payload.get("criterion", [])
    }
    total = sum(criteria.values())
    if total:
        criteria = {
            name: dimension_weight * weight / total
            for name, weight in criteria.items()
        }
    return dimension_weight, criteria


def nondeterministic_components(
    runs_dir: Path,
    selected_dimensions: tuple[str, ...],
    tests_dir: Path,
) -> tuple[float, float, dict[str, object]]:
    selected = tuple(
        dimension
        for dimension in selected_dimensions
        if dimension in AGENT_DIMENSIONS
    )
    # Read every selected dimension's full rubric up front, once, so each repeat can be
    # checked against the SAME expected criterion set it is supposed to have answered.
    rubric_by_dimension: dict[str, tuple[float, dict[str, float]]] = {
        dimension: rubric_definition(tests_dir, dimension) for dimension in selected
    }
    criterion_values: dict[tuple[str, str], list[float]] = {}
    dimension_values: dict[str, list[float]] = {
        dimension: [] for dimension in selected
    }
    successful_runs: list[str] = []
    # repeat name -> the reasons it is not a complete rubric; a repeat with any entry here
    # is reported as incomplete rather than silently contributing a reweighted score.
    incomplete: dict[str, list[str]] = {}

    for run in sorted(runs_dir.glob("repeat-*")):
        reward = load_json(run / "reward.json")
        if not reward:
            continue
        successful_runs.append(run.name)
        details = load_json(run / "reward-details.json")
        # Criterion names THIS repeat actually returned a usable value for, per
        # dimension. Compared against the full rubric below -- a criterion present in
        # some OTHER repeat does not rescue this one, because that would silently
        # pool a partial rubric into the aggregate instead of withdrawing it.
        seen_this_run: dict[str, set[str]] = {dimension: set() for dimension in selected}
        for dimension in selected:
            dimension_value = clamp(reward.get(dimension))
            if dimension_value is not None:
                dimension_values[dimension].append(dimension_value)
            dimension_detail = details.get(dimension, {})
            if not isinstance(dimension_detail, dict):
                continue
            criteria = dimension_detail.get("criteria", [])
            if not isinstance(criteria, list):
                continue
            for criterion in criteria:
                if not isinstance(criterion, dict):
                    continue
                name = criterion.get("name")
                raw = str(criterion.get("raw", "")).strip().casefold()
                if raw in {
                    "not_applicable",
                    "not applicable",
                    "n/a",
                    "na",
                }:
                    if isinstance(name, str):
                        seen_this_run[dimension].add(name)
                    continue
                # A provider error, timeout or malformed payload is NOT a score of zero.
                # 0.1.7 reports timeouts as zero-valued criteria inside an otherwise normal
                # result, so without this the run is merged as "the agent did badly".
                if raw in {"error", "timeout", "timed_out", "unavailable", "malformed"}:
                    incomplete.setdefault(run.name, []).append(
                        f"{dimension}.{name}: {raw}"
                    )
                    continue
                value = clamp(criterion.get("value"))
                if isinstance(name, str) and value is not None:
                    criterion_values.setdefault((dimension, name), []).append(value)
                    seen_this_run[dimension].add(name)
                elif isinstance(name, str):
                    incomplete.setdefault(run.name, []).append(
                        f"{dimension}.{name}: unparseable value {criterion.get('value')!r}"
                    )
        # PER-REPEAT completeness. A criterion this repeat never returned at all (not
        # even as an error/timeout row -- just absent from the payload) is the case the
        # aggregate-only check missed: repeat 1 lacking a criterion that repeat 2
        # happened to report used to be invisible, because only "absent from EVERY
        # repeat" was checked. Each repeat now has to independently answer its whole
        # rubric before it counts.
        for dimension in selected:
            _weight, rubric_criteria = rubric_by_dimension[dimension]
            missing_here = sorted(set(rubric_criteria) - seen_this_run[dimension])
            if missing_here:
                incomplete.setdefault(run.name, []).extend(
                    f"{dimension}.{name}: absent from this repeat" for name in missing_here
                )

    n_num = 0.0
    n_den = 0.0
    rubric_rows: list[dict[str, object]] = []
    dimension_means: dict[str, float] = {}
    dimension_spreads: dict[str, float] = {}
    for dimension in selected:
        dimension_samples = dimension_values[dimension]
        if dimension_samples:
            dimension_means[dimension] = sum(dimension_samples) / len(
                dimension_samples
            )
            if len(dimension_samples) > 1:
                dimension_spreads[dimension] = max(
                    dimension_samples
                ) - min(dimension_samples)
        dimension_weight, criteria = rubric_by_dimension[dimension]
        used_criteria = False
        for name, rubric_weight in criteria.items():
            criterion_samples = criterion_values.get((dimension, name), [])
            if not criterion_samples:
                # Previously `continue`, which dropped the criterion from N_den and rescaled
                # whatever survived. Record it instead: an incomplete rubric must be visible,
                # not silently renormalised into a different scale.
                incomplete.setdefault("<aggregate>", []).append(
                    f"{dimension}.{name}: absent from every repeat"
                )
                continue
            value = sum(criterion_samples) / len(criterion_samples)
            n_num += value * rubric_weight
            n_den += rubric_weight
            used_criteria = True
            rubric_rows.append(
                {
                    "dimension": dimension,
                    "criterion": name,
                    "value": round(value, 6),
                    "weight": round(rubric_weight, 6),
                    "weighted_value": round(value * rubric_weight, 6),
                }
            )
        if not used_criteria and dimension_samples:
            value = sum(dimension_samples) / len(dimension_samples)
            n_num += value * dimension_weight
            n_den += dimension_weight
            rubric_rows.append(
                {
                    "dimension": dimension,
                    "criterion": "dimension_score_fallback",
                    "value": round(value, 6),
                    "weight": round(dimension_weight, 6),
                    "weighted_value": round(value * dimension_weight, 6),
                }
            )

    evidence = {
        "selected_dimensions": list(selected),
        "successful_runs": successful_runs,
        "dimension_means": {
            name: round(value, 6) for name, value in dimension_means.items()
        },
        "dimension_spreads": {
            name: round(value, 6) for name, value in dimension_spreads.items()
        },
        "rubrics": rubric_rows,
    }
    # Completeness is published separately from provider process exit: a judge that
    # returned 200 with half a rubric is not a usable measurement. When the rubric is
    # incomplete the non-deterministic term is withdrawn (N_den = 0) rather than
    # contributing a rescaled number, so lambda cannot import a partial judgement.
    if incomplete:
        evidence['judge_incomplete'] = {k: sorted(set(v)) for k, v in incomplete.items()}
        evidence['judge_complete'] = False
        evidence['withdrawn_reason'] = (
            'one or more selected criteria were absent, errored or timed out; the '
            'non-deterministic term is withdrawn rather than reweighted'
        )
        return 0.0, 0.0, evidence
    evidence['judge_complete'] = True

    return n_num, n_den, evidence


def merge_scores(
    result_dir: Path,
    *,
    stage: str,
    selected_dimensions: tuple[str, ...],
    judge_model: str,
    attempted_runs: int,
    successful_run_count: int,
    tests_dir: Path,
    nondeterministic_lambda: object,
) -> dict[str, object]:
    reward_path = result_dir / "reward.json"
    details_path = result_dir / "reward-details.json"
    reward = load_json(reward_path)
    details = load_json(details_path)
    scoring = details.get("scoring", {})
    if not isinstance(scoring, dict):
        scoring = {}

    # The deterministic half of the formula comes from whatever the grader published.
    # reward.json holds only the canonical bounded scalars (see REWARD_JSON_KEYS), so
    # the raw D_num/D_den pair lives in reward-details.json. Prefer that; if the
    # details file is missing, recover the pair from the normalised score, which is
    # exact because a stage's weights sum to 1.0 and therefore D_den is 1.0. Never
    # silently treat a green stage as 0/0, which would rewrite training_score to 0.0
    # and destroy exactly the annotation the judges exist to produce.
    deterministic = details.get("deterministic")
    if not isinstance(deterministic, dict):
        deterministic = {}
    published_score = reward.get("deterministic_score")
    fallback_num = float(published_score or 0.0)
    fallback_den = 1.0 if isinstance(published_score, (int, float)) else 0.0
    d_num = float(
        scoring.get("D_num", deterministic.get("numerator", fallback_num)) or 0.0
    )
    d_den = float(
        scoring.get("D_den", deterministic.get("denominator", fallback_den)) or 0.0
    )
    if "integrity_passed" in scoring:
        integrity_ok = bool(scoring["integrity_passed"])
    elif "integrity_passed" in reward:
        integrity_ok = float(reward.get("integrity_passed", 0.0) or 0.0) == 1.0
    else:
        integrity = details.get("integrity")
        integrity_ok = (
            bool(integrity.get("passed")) if isinstance(integrity, dict) else False
        )
    n_num, n_den, evidence = nondeterministic_components(
        result_dir / "judge_runs",
        selected_dimensions,
        tests_dir,
    )
    complete_repeats = (
        attempted_runs > 0
        and successful_run_count == attempted_runs
        and len(evidence.get("successful_runs", [])) == attempted_runs
        and evidence.get("judge_complete") is True
    )
    if not complete_repeats:
        evidence["judge_complete"] = False
        evidence["withdrawn_reason"] = (
            "every configured repeat must return a complete parseable rubric; "
            f"attempted={attempted_runs}, provider_successes={successful_run_count}, "
            f"parseable={len(evidence.get('successful_runs', []))}"
        )
        n_num = 0.0
        n_den = 0.0
    weight = parse_lambda(nondeterministic_lambda)
    training_score = calculate_training_score(
        d_num=d_num,
        d_den=d_den,
        n_num=n_num,
        n_den=n_den,
        nondeterministic_lambda=weight,
        integrity_ok=integrity_ok,
        rewardkit_available=n_den > 0.0,
    )

    # The formula string lives in reward-details.json (Harbor rejects strings in
    # reward.json). Leaving the grader's deterministic-only string next to a merged
    # training_score would publish a visible contradiction (a 0.84 score beside
    # "= 1.000000"), so the string is recomputed here too.
    calculation = (
        formula_text(
            d_num=d_num,
            d_den=d_den,
            n_num=n_num,
            n_den=n_den,
            nondeterministic_lambda=weight,
            result=training_score,
        )
        if integrity_ok
        else "integrity hard gate failed => training_score = 0.000000"
    )

    means = evidence["dimension_means"]
    spreads = evidence["dimension_spreads"]
    # A judged pass may move training_score and publish its own aggregate; it may not
    # widen reward.json. Per-dimension means, spreads and applicability flags are
    # annotations about the run, not components of its reward vector, so they go to
    # reward-details.json and judge_summary.json where a reviewer reads them.
    reward["training_score"] = round(training_score, 6)
    # Only a judge that actually scored may add this key; judges that ran but
    # returned nothing leave it absent rather than reporting a 0.0 they did not
    # measure. See score_formula.REWARD_JSON_JUDGED_KEYS.
    if n_den > 0.0:
        reward["non_deterministic_score"] = round(clamp01(n_num / n_den), 6)
    else:
        reward.pop("non_deterministic_score", None)

    max_disagreement = max(
        (float(value) for value in spreads.values()),
        default=0.0,
    )
    agreement_threshold = 0.25
    agreement_passed = complete_repeats and max_disagreement <= agreement_threshold
    details["judges"] = {
        "available": complete_repeats and n_den > 0.0,
        "judge_complete": complete_repeats,
        "model": judge_model,
        "selected_dimensions": list(selected_dimensions),
        "dimension_means": means,
        "dimension_spreads": spreads,
        "judge_disagreement": max_disagreement,
        "agreement_threshold": agreement_threshold,
        "agreement_passed": agreement_passed,
        "process_judge": float(means.get("process", 0.0)),
        "process_judge_applicable": "process" in selected_dimensions,
        "validity_review": float(means.get("validity", 0.0)),
        "validity_review_applicable": "validity" in selected_dimensions,
        "merge_readiness_judge": float(means.get("merge_readiness", 0.0)),
        "merge_readiness_judge_applicable": (
            "merge_readiness" in selected_dimensions
        ),
        "binary_reward_affected": False,
    }

    scoring.update(
        {
            "D_num": round(d_num, 6),
            "D_den": round(d_den, 6),
            "N_num": round(n_num, 6),
            "N_den": round(n_den, 6),
            "lambda": weight,
            # N/A rather than 0.0 when nothing was judged.
            "effective_lambda": weight if n_den > 0.0 else None,
            "training_score": round(training_score, 6),
            "calculation": calculation,
            "integrity_hard_gate": True,
            "rewardkit_available": n_den > 0.0,
            "rewardkit_applied": (
                integrity_ok and n_den > 0.0 and weight > 0.0
            ),
            "calculation_mode": (
                "integrity hard gate"
                if not integrity_ok
                else (
                    "lambda formula"
                    if n_den > 0.0 and weight > 0.0
                    else "deterministic-only fallback"
                )
            ),
            "rewardkit_dimensions": list(selected_dimensions),
            "rewardkit_rubrics": evidence["rubrics"],
        }
    )
    details["scoring"] = scoring
    details["formula"] = calculation
    details["nondeterministic"] = {
        "numerator": round(n_num, 6),
        "denominator": round(n_den, 6),
        "lambda": weight,
        "available": n_den > 0.0,
        "authoritative": False,
    }

    # These fields are deterministic truth and must remain identical and binary.
    # The file is then rebuilt from the canonical key set rather than filtered, so a
    # judged pass can neither reintroduce the Harbor ValidationError this file exists
    # to avoid nor leave a stray scalar that a reviewer surface would aggregate.
    binary = 1.0 if float(reward.get("binary_reward", 0.0) or 0.0) == 1.0 else 0.0
    reward["binary_reward"] = binary
    reward["reward"] = binary
    publish = set(REWARD_JSON_CORE_KEYS) | (set(REWARD_JSON_JUDGED_KEYS) & set(reward))
    numeric_reward: dict[str, float] = {}
    for key in sorted(publish):
        value = reward.get(key, 0.0)
        if isinstance(value, bool):
            numeric_reward[key] = 1.0 if value else 0.0
        elif isinstance(value, (int, float)):
            numeric_reward[key] = float(value)
        else:
            numeric_reward[key] = 0.0
    assert reward_json_shape_ok(numeric_reward), sorted(numeric_reward)
    reward_path.write_text(
        json.dumps(numeric_reward, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    details_path.write_text(
        json.dumps(details, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    summary = {
        "available": complete_repeats and n_den > 0.0,
        "applicable": True,
        "judge_complete": complete_repeats,
        "stage": stage,
        "judge_model": judge_model,
        "selected_dimensions": list(selected_dimensions),
        "attempted_runs": attempted_runs,
        "successful_run_count": successful_run_count,
        "successful_runs": evidence["successful_runs"],
        "dimension_means": means,
        "dimension_spreads": spreads,
        "maximum_disagreement": max_disagreement,
        "agreement_threshold": agreement_threshold,
        "agreement_passed": agreement_passed,
        "D_num": round(d_num, 6),
        "D_den": round(d_den, 6),
        "N_num": round(n_num, 6),
        "N_den": round(n_den, 6),
        "lambda": weight,
        "training_score": round(training_score, 6),
        "binary_reward_affected": False,
    }
    if not complete_repeats:
        summary["reason"] = evidence.get("withdrawn_reason", "judge rubric incomplete")
    for name in ("judge_summary.json", "judge_status.json"):
        (result_dir / name).write_text(
            json.dumps(summary, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
    manifest_path = result_dir / "training_export_manifest.json"
    manifest = load_json(manifest_path)
    manifest.update(
        {
            "judge_available": complete_repeats and n_den > 0.0,
            "judge_complete": complete_repeats,
            "judge_model": judge_model,
            "judge_selected_dimensions": list(selected_dimensions),
            "judge_dimension_means": means,
            "judge_maximum_disagreement": max_disagreement,
            "judge_agreement_threshold": agreement_threshold,
            "judge_agreement_passed": agreement_passed,
            "judge_artifacts": [
                "judge_summary.json",
                "judge_runs/",
                "judge_inputs/",
            ],
        }
    )
    manifest_path.write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return summary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("result_dir", type=Path)
    parser.add_argument("--stage", required=True)
    parser.add_argument("--dimensions", required=True)
    parser.add_argument("--judge-model", required=True)
    parser.add_argument("--attempted-runs", required=True, type=int)
    parser.add_argument("--successful-runs", required=True, type=int)
    args = parser.parse_args()
    selected = tuple(
        item for item in args.dimensions.split(",") if item in AGENT_DIMENSIONS
    )
    merge_scores(
        args.result_dir,
        stage=args.stage,
        selected_dimensions=selected,
        judge_model=args.judge_model,
        attempted_runs=args.attempted_runs,
        successful_run_count=args.successful_runs,
        tests_dir=Path(__file__).resolve().parent,
        nondeterministic_lambda=os.environ.get(
            "NONDETERMINISTIC_LAMBDA", "0.0"
        ),
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
