#!/usr/bin/env bash
# Oracle, stage 01.
#
# Nothing is materialised here: this stage produces a diagnosis, and a diagnosis
# has to be established rather than declared. So before writing anything, the
# script asks the toolchain whether the capabilities it is about to call missing
# are in fact missing -- `go doc` resolves a symbol through the real package
# loader, so a non-zero exit is the compiler's answer, not a grep's guess. If any
# of them already existed the base would be mis-pinned and the stage aborts.
set -euo pipefail
OUT=/app/output
STAGE_OUT="$OUT/01-diagnose"
mkdir -p "$STAGE_OUT"
cd /testbed

echo "== confirm the base really lacks each capability =="
probe_absent() {
    local pkg="$1" sym="$2"
    if gitea-test go doc "$pkg" "$sym" >/dev/null 2>&1; then
        echo "FATAL: $pkg.$sym already exists; the base commit is not the pre-change tree" >&2
        exit 1
    fi
    echo "  absent, as expected: $pkg.$sym"
}
probe_absent code.gitea.io/gitea/models/issues Issue.LoadProjects
probe_absent code.gitea.io/gitea/models/issues Issue.ProjectColumnMap
probe_absent code.gitea.io/gitea/modules/util DiffSlice

cat > "$STAGE_OUT/reproduce.sh" <<'SH'
#!/usr/bin/env bash
# Fails on the unfixed tree: each check names a capability the plural
# association needs and the base does not have.
cd /testbed
failed=0
grep -q 'func (issue \*Issue) LoadProjects' models/issues/issue_project.go 2>/dev/null   || { echo 'plural model gap: an issue exposes one project, not a set'; failed=1; }
grep -q 'ProjectColumnMap' models/issues/issue_project.go 2>/dev/null   || { echo 'column map gap: the issue column is not resolved per project'; failed=1; }
grep -q 'func DiffSlice' modules/util/util.go 2>/dev/null   || { echo 'wire shape gap: no set difference helper for reconciling project ids'; failed=1; }
grep -q 'ProjectIDs' modules/indexer/issues/internal/model.go 2>/dev/null   || { echo 'search gap: issue search filters by a single project id'; failed=1; }
exit $failed
SH
chmod +x "$STAGE_OUT/reproduce.sh"

cat > "$STAGE_OUT/diagnosis.json" <<'JSON'
{
  "missing_capabilities": [
    "An issue exposes a single project rather than the set of projects it belongs to",
    "The issue column is resolved as one id instead of one column per project",
    "Issue search filters by a single project id, so no caller can ask for any-of",
    "The API and web surfaces carry the single value outward"
  ],
  "affected_packages": ["models/issues", "models/project", "modules/indexer/issues", "modules/structs", "services/projects", "routers/web/repo"],
  "reproducer": "/app/output/01-diagnose/reproduce.sh exits non-zero and names the plural-model, column-map, set-difference and search gaps",
  "root_cause": "The issue-to-project association is modelled as a single value at every layer, so the join table that already exists cannot be used to place one issue on several boards."
}
JSON

cat > "$OUT/handoff.json" <<'JSON'
{
  "stage": "01-diagnose",
  "summary": "The base treats an issue as belonging to at most one project: the loader, the column accessor, the search filter and the API payload are all single-valued, even though the project_issue join table can already hold many rows per issue.",
  "next_steps": [
    "Rework the model layer so an issue loads all its projects and resolves a column per project.",
    "Carry a set-valued project filter through all four issue-search indexer backends.",
    "Project the plural association through the API, the web routers and the services."
  ]
}
JSON
# The reproducer has to fail on the unfixed tree; a zero exit would mean it does
# not actually demonstrate the gap, so treat that as a broken stage.
if bash "$STAGE_OUT/reproduce.sh"; then
    echo "FATAL: the reproducer exited 0 on the unfixed base" >&2
    exit 1
fi
echo "stage 01 complete"
