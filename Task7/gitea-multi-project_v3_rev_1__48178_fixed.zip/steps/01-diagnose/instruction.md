# Stage 1 — Diagnose the single-project limitation

The repository is at `/testbed`; run Go there. Gitea lets an issue or pull request
belong to a project board, and users want an issue to sit on several boards at
once. Establish that the association is single-valued today and find every place
that assumption is baked in.

Leave behind evidence that runs and shows that:

1. an issue exposes **one** project, not a set — the loader and the accessor that
   returns the issue's project column both speak in the singular;
2. issue **search** filters by a single project id, so no caller can ask for
   "issues in any of these projects";
3. the **API and web** surfaces carry that single value outward.

Go tests run unprivileged: use the `gitea-test` wrapper. Investigate however you
like — a reproducer `*_test.go`, a throwaway program, or a recorded command. A
reproducer test left behind ships nothing — but do **not** change production
(non-test) code yet.

Write `/app/output/01-diagnose/diagnosis.json` (≤ 256 KiB) with at least these
keys: `root_cause` (string), `missing_capabilities` (array), `affected_packages`
(array), `reproducer` (string), and `/app/output/handoff.json` with `stage`
(string), `summary` (string), `next_steps` (array). The verifier RUNS `reproducer`, so
make it a file path or an exact command and nothing else - not a sentence. The
sqlite build tags are added for you when it is a test path.

**Graded:** your reproducer runs, exits non-zero on the unfixed tree, and concerns
the missing capability; and no production file changed. The verifier re-establishes
the three gaps itself, so you are not scored on how you reached them.

**Scored but never decisive:** both artifacts and *which* areas you name.
This stage cannot end the trial.
