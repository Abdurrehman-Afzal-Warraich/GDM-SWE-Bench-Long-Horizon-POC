#!/usr/bin/env bash
set -euo pipefail
stage=02-multi-project-model
RESULT_DIR="${RESULT_DIR:-/logs/verifier}"
mkdir -p "$RESULT_DIR"
printf '%s\n' '{"binary_reward":0.0,"deterministic_score":0.0,"reward":0.0,"training_score":0.0}' > "$RESULT_DIR/reward.json"
printf '%s\n' '0.0000' > "$RESULT_DIR/reward.txt"
printf '%s\n' "{\"results\":{\"tool\":{\"name\":\"gitea-multi-project-bootstrap\"},\"summary\":{\"tests\":1,\"passed\":0,\"failed\":1,\"pending\":0,\"skipped\":0,\"other\":0,\"start\":0,\"stop\":0},\"tests\":[{\"name\":\"shared_verifier_completed\",\"status\":\"failed\",\"duration\":0,\"suite\":\"${stage} :: bootstrap\",\"message\":\"shared verifier did not complete\"}]}}" > "$RESULT_DIR/ctrf.json"
chmod a+rw "$RESULT_DIR/reward.json" "$RESULT_DIR/reward.txt" "$RESULT_DIR/ctrf.json" 2>/dev/null || true
exec bash /tests/stage_test.sh 02-multi-project-model
