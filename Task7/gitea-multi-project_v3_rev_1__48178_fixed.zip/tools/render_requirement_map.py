#!/usr/bin/env python3
"""Derive the prompt-explicit / codebase-implied / future-only requirement map.

asked for exactly this map, and the fairness checks asked whether the protected corpus can reject a behaviourally correct
solution. Both reduce to one question that has to be answered mechanically rather
than by spot-checking a handful of names:

    For every identifier the protected corpus links against, is that identifier
    either (a) stated to the agent, or (b) already present in the base tree?

Anything in neither bucket is FUTURE-ONLY: a name introduced by the upstream
change that the corpus requires but nobody told the agent about. That is the
fairness bug the review is pointing at, and this tool exists so its count can be
asserted to be zero instead of argued about.

    python3 tools/render_requirement_map.py               # write the map
    python3 tools/render_requirement_map.py --check       # fail if stale
    python3 tools/render_requirement_map.py --repo-dir D  # classify against a real base checkout

Without --repo-dir the base tree is read from the shipped golden patches' CONTEXT
lines, which is enough to recognise pre-existing symbols the patches touch; with
it, classification is exact.
"""

from __future__ import annotations

import argparse
import json
import re
import subprocess
from pathlib import Path

TASK_ROOT = Path(__file__).resolve().parent.parent
HIDDEN = TASK_ROOT / "tests/hidden"
STEPS = TASK_ROOT / "steps"
DOCKERFILE = TASK_ROOT / "environment/Dockerfile"
OUT = TASK_ROOT / "tests/contracts/requirement_map.json"
BASE_COMMIT = "52d6baf5a816b294662a6b2da26b82425d320930"

PATCH_STAGES = ("02-multi-project-model", "03-search-and-indexing", "04-api-web-and-harden")

# Identifiers that are Go, the standard library, or the repository's test
# dependencies - never something the task has to disclose.
IGNORE = {
    # builtins / keywords / common stdlib
    "T", "B", "Errorf", "Fatalf", "Fatal", "Error", "Log", "Logf", "Run", "Skip",
    "SkipNow", "Helper", "Cleanup", "TempDir", "Setenv", "Context", "Background",
    "TODO", "Sprintf", "Sprint", "Printf", "Errors", "New", "Is", "As", "Now",
    "Unix", "Since", "Duration", "Second", "Millisecond", "Marshal", "Unmarshal",
    "Len", "Cap", "Append", "Make", "String", "Int", "Int64", "Bool", "Float64",
    "Parse", "Join", "Split", "Contains", "HasPrefix", "HasSuffix", "TrimSpace",
    "ReplaceAll", "Fields", "Atoi", "Itoa", "Getenv", "ReadFile", "WriteFile",
    "MkdirAll", "Create", "Open", "Close", "Remove", "RemoveAll", "Stat",
    # testify
    "Equal", "EqualValues", "NoError", "Error", "True", "False", "Nil", "NotNil",
    "Empty", "NotEmpty", "Len", "Contains", "ElementsMatch", "Greater", "Less",
    "GreaterOrEqual", "LessOrEqual", "ErrorIs", "ErrorContains", "Require",
    "Assert", "Panics", "NotPanics", "Zero", "NotZero", "Same", "NotEqual",
    "Positive", "Subset", "FailNow", "Fail", "InDelta", "JSONEq", "NotContains",
    "Eventually", "WithinDuration", "IsType", "Implements",
}

# Referenced as `Ident(`, `.Ident`, or `Ident{`.
REF = re.compile(r"(?:\.([A-Za-z_]\w*)|\b([A-Z]\w*)\s*[({])")

# a struct-literal KEY is compile-linked just as hard as a call, but
# `Field:` matches none of the patterns above - it is neither `.Field` nor `Field(`/`Field{`.
# That is why `ProjectIDs` was never extracted and the fairness proof came back a false
# negative: the map cannot classify a symbol it never saw. Composite-literal keys and
# explicit field assignments are collected too.
FIELD_KEY = re.compile(r"^\s*([A-Z]\w*)\s*:(?!=)", re.M)
FIELD_SET = re.compile(r"^\s*\w+\.([A-Z]\w*)\s*=(?!=)", re.M)


def corpus_refs(stage: str) -> set[str]:
    names: set[str] = set()
    root = HIDDEN / stage
    if not root.is_dir():
        return names
    # Not just *_test.go: the corpus also ships shared suite helpers such as
    # modules/indexer/issues/internal/tests/tests.go, which bind real identifiers.
    # Globbing only *_test.go hid `NoProjectOnly` from the fairness map entirely.
    for path in sorted(root.rglob("*.go")):
        text = path.read_text(encoding="utf-8", errors="replace")
        # Drop the file's own declarations: a helper the test defines is not a
        # contract the agent has to satisfy.
        own = set(re.findall(r"^func\s+(?:\([^)]*\)\s*)?([A-Za-z_]\w*)", text, re.M))
        own |= set(re.findall(r"^type\s+([A-Za-z_]\w*)", text, re.M))
        candidates = [a or b for a, b in REF.findall(text)]
        candidates += FIELD_KEY.findall(text)
        candidates += FIELD_SET.findall(text)
        for name in candidates:
            if not name or name in IGNORE or name in own:
                continue
            if name.startswith("Test") or name.startswith("Benchmark"):
                continue
            names.add(name)
    return names


def disclosed_text() -> str:
    """Everything the agent is told: the contract files the image writes, plus the
    stage briefings themselves."""
    parts = [DOCKERFILE.read_text(encoding="utf-8", errors="replace")]
    for step in sorted(STEPS.iterdir()):
        brief = step / "instruction.md"
        if brief.is_file():
            parts.append(brief.read_text(encoding="utf-8", errors="replace"))
    return "\n".join(parts)


def base_symbols(repo_dir: Path | None) -> set[str] | None:
    """Every identifier that occurs anywhere in the base tree's Go sources.

    Deliberately a whole-tree token index rather than a declaration parse: the
    question this map answers is "could the agent have found this by reading
    /testbed?", and any token present in the tree can be found by grepping it.
    Over-inclusive here is the safe direction, because it can only move a name OUT
    of the future-only bucket if the name genuinely exists at base.
    """
    if repo_dir is None:
        return None
    proc = subprocess.run(
        ["git", "archive", BASE_COMMIT],
        cwd=repo_dir, capture_output=True,
    )
    if proc.returncode != 0:
        raise SystemExit("git archive of the base commit failed")
    import io as _io
    import tarfile

    found: set[str] = set()
    with tarfile.open(fileobj=_io.BytesIO(proc.stdout)) as tar:
        for member in tar:
            if not member.isfile() or not member.name.endswith((".go", ".ini")):
                continue
            handle = tar.extractfile(member)
            if handle is None:
                continue
            text = handle.read().decode("utf-8", "replace")
            found.update(re.findall(r"[A-Za-z_]\w*", text))
    return found


def patch_added_symbols() -> set[str]:
    """Identifiers introduced on ADDED lines of the staged golden patches - i.e.
    names the upstream change brings into existence."""
    names: set[str] = set()
    for stage in PATCH_STAGES:
        patch = STEPS / stage / "solution/golden.patch"
        for line in patch.read_text(encoding="utf-8", errors="replace").splitlines():
            if line.startswith("+") and not line.startswith("+++"):
                names.update(re.findall(r"[A-Za-z_]\w*", line[1:]))
    return names


def build(repo_dir: Path | None) -> dict:
    told = disclosed_text()
    base = base_symbols(repo_dir)
    added = patch_added_symbols()
    stages = []
    future_only_total = 0
    for stage in PATCH_STAGES:
        refs = sorted(corpus_refs(stage))
        explicit, implied, future, not_a_contract = [], [], [], []
        for name in refs:
            in_base = base is None or name in base
            introduced = name in added
            if not introduced and not in_base:
                # Neither part of the change nor part of the repository: a local
                # variable, a string fragment, or a stdlib/testify name the ignore
                # list did not cover. Not a contract the agent has to satisfy.
                not_a_contract.append(name)
            elif re.search(rf"\b{re.escape(name)}\b", told):
                explicit.append(name)
            elif in_base:
                implied.append(name)
            else:
                future.append(name)
        future_only_total += len(future)
        stages.append({
            "stage": stage,
            "identifiersLinkedByCorpus": len(refs),
            "promptExplicit": explicit,
            "codebaseImplied": implied,
            "futureOnlyUndisclosed": future,
            "notAContract": not_a_contract,
        })
    return {
        "description": (
            "Generated by tools/render_requirement_map.py. Every identifier the protected "
            "corpus links against, classified as prompt-explicit (stated in a stage briefing "
            "or in the /app/contracts file the image writes), codebase-implied (already "
            "present at the base commit, so discoverable by reading /testbed), or future-only "
            "(introduced by the upstream change, required by the corpus, and never disclosed)."
        ),
        "fairnessRule": (
            "futureOnlyUndisclosed must be empty. A non-empty list means the corpus can reject "
            "a behaviourally correct solution for not guessing a name nobody supplied."
        ),
        "baseClassificationVerified": base is not None,
        "futureOnlyCount": future_only_total,
        "stages": stages,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--repo-dir", type=Path, default=None)
    args = parser.parse_args()

    built = build(args.repo_dir)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    current = json.loads(OUT.read_text(encoding="utf-8")) if OUT.is_file() else None

    print(f"future-only undisclosed identifiers: {built['futureOnlyCount']}")
    for row in built["stages"]:
        print(f"  {row['stage']}: {row['identifiersLinkedByCorpus']} linked, "
              f"{len(row['promptExplicit'])} explicit, {len(row['codebaseImplied'])} implied, "
              f"{len(row['futureOnlyUndisclosed'])} future-only")
        if row["futureOnlyUndisclosed"]:
            print(f"      UNDISCLOSED: {row['futureOnlyUndisclosed']}")

    if current == built:
        print("requirement_map.json is up to date.")
        return 0 if built["futureOnlyCount"] == 0 else 1
    if args.check:
        print("requirement_map.json is STALE - run tools/render_requirement_map.py")
        return 1
    OUT.write_text(json.dumps(built, indent=1) + "\n", encoding="utf-8")
    print(f"wrote {OUT.relative_to(TASK_ROOT)}")
    return 0 if built["futureOnlyCount"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
