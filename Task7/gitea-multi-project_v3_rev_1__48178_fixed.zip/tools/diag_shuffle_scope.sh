#!/usr/bin/env bash
# Is the residual order dependence UPSTREAM or in the AUTHORED corpus?
#
# On a solved tree the terminal stage scores 1.0 unshuffled and 0.0 shuffled. This run keeps
# the container alive and names the tests that fail under -shuffle=on, then classifies each as
# upstream (gitea's own suite) or authored (tests/hidden/). Gitea's model tests share one
# sqlite database and fixture set, so an inherited constraint is the likely answer -- but it
# has to be shown, not assumed.
set -euo pipefail
export MSYS_NO_PATHCONV=1

TASK_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
IMAGE="${IMAGE:-lh-gitea-multi-project:rework}"
C=lh-shufscope
STAGES=(01-diagnose 02-multi-project-model 03-search-and-indexing 04-api-web-and-harden)
TERM=04-api-web-and-harden

docker rm -f "$C" >/dev/null 2>&1 || true
docker run -d --name "$C" -v "$TASK_ROOT/tests:/tests:ro" -v "$TASK_ROOT/steps:/steps:ro" \
  "$IMAGE" sleep infinity >/dev/null
docker exec "$C" bash -lc 'mkdir -p /app/output /logs/verifier /logs/agent /solution'

echo "==> solve AND grade each stage (the sequence solve.sh actually requires)"
for s in "${STAGES[@]}"; do
  docker exec "$C" bash -lc "cp -r /steps/$s/solution/. /solution/ 2>/dev/null || true; bash /solution/solve.sh >/dev/null 2>&1 || true"
  docker exec "$C" bash -lc "RESULT_DIR=/logs/verifier bash /tests/stage_test.sh $s >/dev/null 2>&1 || true"
  r="$(docker exec "$C" bash -lc 'python3 -c "import json;print(json.load(open(\"/logs/verifier/reward.json\")).get(\"binary_reward\"))"' 2>/dev/null || echo ERR)"
  echo "   $s -> $r"
done

echo
echo "==> terminal stage, UNSHUFFLED (control)"
docker exec "$C" bash -lc "RESULT_DIR=/logs/verifier bash /tests/stage_test.sh $TERM >/dev/null 2>&1 || true"
echo "   unshuffled = $(docker exec "$C" bash -lc 'python3 -c "import json;print(json.load(open(\"/logs/verifier/reward.json\")).get(\"binary_reward\"))"' 2>/dev/null || echo ERR)"

echo
echo "==> terminal stage, SHUFFLED"
docker exec "$C" bash -lc "STAGE_TEST_SHUFFLE=on RESULT_DIR=/logs/verifier bash /tests/stage_test.sh $TERM >/dev/null 2>&1 || true"
echo "   shuffled   = $(docker exec "$C" bash -lc 'python3 -c "import json;print(json.load(open(\"/logs/verifier/reward.json\")).get(\"binary_reward\"))"' 2>/dev/null || echo ERR)"

echo
echo "==> tests that FAILED under shuffle"
docker exec "$C" bash -lc 'grep -hoE "^\s*--- FAIL: [A-Za-z0-9_/]+" /logs/verifier/go_test_failure.log 2>/dev/null | sed "s/.*--- FAIL: //" | sort -u' > /tmp/shuf_failed.txt || true
cat /tmp/shuf_failed.txt

echo
echo "==> classification (authored corpus vs upstream suite)"
docker exec "$C" bash -lc 'grep -rhoE "^func (Test[A-Za-z0-9_]+)" /tests/hidden --include=*.go 2>/dev/null | sed "s/^func //" | sort -u' > /tmp/authored.txt || true
while read -r t; do
  [ -z "$t" ] && continue
  base="${t%%/*}"
  if grep -qx "$base" /tmp/authored.txt 2>/dev/null; then echo "   AUTHORED  $t"; else echo "   UPSTREAM  $t"; fi
done < /tmp/shuf_failed.txt

echo
echo "container $C left running for inspection"
