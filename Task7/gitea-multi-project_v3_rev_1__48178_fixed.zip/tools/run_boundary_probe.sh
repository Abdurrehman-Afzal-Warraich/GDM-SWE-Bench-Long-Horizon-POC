#!/usr/bin/env bash
# Fail-closed runtime proof of the protected boundary, written to BOUNDARY.json.
#
# The package DECLARED offline execution and hidden-material isolation; it never evidenced
# either at runtime, and every delivered evaluation in fact ran with public networking. A
# declaration is not a boundary. This probes from inside a built agent container, as the
# agent's own account, using both a shell client and a language runtime -- command-text
# auditing cannot see a Python socket, so it is not a security control on its own.
set -euo pipefail
export MSYS_NO_PATHCONV=1

TASK_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
IMAGE="${IMAGE:-lh-gmp:rework}"
OUT="$TASK_ROOT/BOUNDARY.json"
OUT_HOST="$(cygpath -w "$OUT" 2>/dev/null || echo "$OUT")"
C="gmp-boundary-$$"
PY_HOST="$(command -v python3 || command -v python)"
TMPF="/tmp/gmp_boundary.$$"
# The aggregator may be a native Windows python, which cannot open a POSIX path.
TMPF_HOST="$(cygpath -w "$TMPF" 2>/dev/null || echo "$TMPF")"

cleanup() { docker rm -f "$C" >/dev/null 2>&1 || true; rm -f "$TMPF"; }
trap cleanup EXIT

docker run -d --name "$C" "$IMAGE" sleep infinity >/dev/null
: > "$TMPF"

probe() { # label, command -- must FAIL for the boundary to hold
  local rc out
  out="$(docker exec "$C" gitea-test bash -lc "$2" 2>&1)" && rc=0 || rc=$?
  if [ "$rc" -ne 0 ]; then echo "  DENIED  $1"; printf '%s\0denied\0%s\0' "$1" "${out:0:200}" >> "$TMPF"
  else echo "  LEAKED  $1"; printf '%s\0LEAKED\0%s\0' "$1" "${out:0:200}" >> "$TMPF"; fi
}

echo "==> protected material"
probe "hidden corpus"        'ls /tests/hidden'
probe "grader source"        'cat /tests/stage_check.py'
probe "golden patches"       'ls /solution/golden.patch'
probe "reward files"         'ls /logs/verifier/reward.json'
echo "==> repository sanitization"
probe "git remotes"          'cd /testbed && git remote -v | grep -q .'
probe "upstream tags"        'cd /testbed && git tag | grep -q .'
probe "history beyond anchor" 'cd /testbed && [ "$(git reflog | wc -l)" -gt 1 ]'
# Network isolation is enforced by the PLATFORM (task.toml allow_internet=false), not by the
# image: a bare `docker run` is deliberately unrestricted, so probing egress here would only
# measure Docker's default and would report a leak that says nothing about a graded run. What
# the IMAGE must guarantee is that no graded step NEEDS egress -- the module cache is warm and
# the build works with the proxy off. Platform isolation has to be evidenced in a platform run.
echo "==> offline capability (platform enforces isolation; this proves nothing is REQUIRED)"
probe "graded build needs network (must not)" 'cd /testbed && GOFLAGS=-mod=mod GOPROXY=off go build ./models/issues/ >/dev/null 2>&1; [ $? -ne 0 ]'
probe "provider keys"        'env | grep -Eiq "(ANTHROPIC|OPENAI|GEMINI)_?API_?KEY"'

"$PY_HOST" - "$OUT_HOST" "$IMAGE" "$TMPF_HOST" <<'PY'
import sys, json, datetime, pathlib
out, image, tmpf = sys.argv[1:4]
parts = pathlib.Path(tmpf).read_bytes().decode("utf-8", "replace").split("\0")
probes = [{"probe": parts[i], "result": parts[i+1], "detail": parts[i+2]}
          for i in range(0, len(parts)-2, 3)]
leaked = [p["probe"] for p in probes if p["result"] != "denied"]
doc = {
    "description": "Runtime protected-boundary evidence, recorded inside a built agent "
                   "container as the unprivileged agent account. Network is probed with a "
                   "shell client, a Python socket and the Go toolchain, because scanning "
                   "recorded command text cannot observe a socket opened from a runtime.",
    "generatedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "image": image,
    "allDenied": not leaked,
    "leaked": leaked,
    "probes": probes,
}
pathlib.Path(out).write_text(json.dumps(doc, indent=2) + "\n", encoding="utf-8")
print(f"wrote {out}: {len(probes)} probes, allDenied={doc['allDenied']}")
if leaked:
    raise SystemExit(1)
PY
