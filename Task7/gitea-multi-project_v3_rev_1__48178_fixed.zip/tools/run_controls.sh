#!/usr/bin/env bash
# Execute the calibration controls the review asked for, and record what they did.
#
# were all the same finding: the controls were designed but
# never run, so "the no-op fails at a functional gate" and "shortcuts are rejected"
# were assertions. This runs them and writes CALIBRATION.json from the grader's own
# reward files - never from a hand-written summary.
#
#   bash tools/run_controls.sh                 # every control
#   bash tools/run_controls.sh oracle nop      # a subset
#   REPEATS=3 bash tools/run_controls.sh oracle
#
# Controls
#   oracle      solve every stage in order; expect binary_reward 1.0 at each,
# Repeated $REPEATS times to show determinism
#   nop         grade the untouched base; expect 0.0 at a NAMED functional gate,
# Never an infrastructure error
# Mut-* seeded mutations, each expected to fail one named gate:
#                 mut-single-project collapse the project set to its first member
#                 mut-no-diff        replace the set difference with a no-op
#                 mut-index-scope    drop the project fan-out from the indexed document
#                 mut-weaken-tests   delete the agent-visible tests (must NOT help)
#                 mut-hardcode       return fixed values instead of real state
#                 mut-singular-search collapse the project-id filter to its first
#                                    member (the pre-PR behaviour)
#                 mut-shell-only     a shell Stage 1 reproducer that exits 0: the
#                                    form is allowed, the evidence is not
#                 mut-fake-gap-stdout  a shell Stage 1 reproducer whose only connection
#                                    to the capability is text it PRINTS at runtime,
#                                    built so it is not a substring of its own source
#   shuffle     re-run the terminal stage with -shuffle to prove order independence
#
#
# Needs Docker. This is a release control; nothing here runs during grading.

set -euo pipefail

# On Windows/Git Bash, MSYS rewrites POSIX-looking arguments into Windows paths, which
# silently mangles `-v host:/tests:ro` so the mount lands somewhere else and the grader
# is simply absent inside the container. Harmless on Linux; essential here.
export MSYS_NO_PATHCONV=1

TASK_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
IMAGE="${IMAGE:-lh-gitea-multi-project:rework}"
REPEATS="${REPEATS:-2}"
OUT="$TASK_ROOT/CALIBRATION.json"
STAGES=(01-diagnose 02-multi-project-model 03-search-and-indexing 04-api-web-and-harden)

CONTROLS=("$@")
if [ ${#CONTROLS[@]} -eq 0 ]; then
  CONTROLS=(oracle nop mut-single-project mut-no-diff mut-index-scope mut-weaken-tests mut-hardcode mut-singular-search mut-shell-only mut-fake-gap-stdout shuffle)
fi

command -v docker >/dev/null || { echo "FATAL: docker is required"; exit 1; }
# Host python: Git Bash on Windows ships `python`, not `python3`. The in-container
# calls below keep using python3, which the image always has.
PY_HOST="${PY_HOST:-$(command -v python3 || command -v python || true)}"
[ -n "$PY_HOST" ] || { echo "FATAL: need python3 (or python) on the host"; exit 1; }
docker image inspect "$IMAGE" >/dev/null 2>&1 || {
  echo "FATAL: image $IMAGE not built. Run:";
  echo "  docker build -t $IMAGE -f environment/Dockerfile environment"; exit 1; }

WORK="$(mktemp -d)"; trap 'rm -rf "$WORK"' EXIT
# MSYS_NO_PATHCONV (needed above so docker -v mounts are not rewritten) also stops the
# POSIX temp path being translated for the HOST python, which on Windows is a native
# exe that cannot open "/tmp/...". Hand the aggregator a path its interpreter can open.
ROWS="$WORK/rows.jsonl"
ROWS_HOST="$(cygpath -w "$ROWS" 2>/dev/null || echo "$ROWS")"
# $OUT is a POSIX path too, and the aggregator OPENS IT FOR WRITING.
OUT_HOST="$(cygpath -w "$OUT" 2>/dev/null || echo "$OUT")"
: > "$ROWS"

start() { # $1 container name
  docker rm -f "$1" >/dev/null 2>&1 || true
  docker run -d --name "$1" \
    -v "$TASK_ROOT/tests:/tests:ro" \
    -v "$TASK_ROOT/steps:/steps:ro" \
    "$IMAGE" sleep infinity >/dev/null
  docker exec "$1" bash -lc 'mkdir -p /app/output /logs/verifier /logs/agent /solution'
}

solve() { # $1 container, $2 stage
  docker exec "$1" bash -lc "cp -r /steps/$2/solution/. /solution/ 2>/dev/null || true; bash /solution/solve.sh >/dev/null 2>&1 || true"
}

grade() { # $1 container, $2 stage -> prints one JSON row
  docker exec "$1" bash -lc "${STAGE_TEST_SHUFFLE:+STAGE_TEST_SHUFFLE=$STAGE_TEST_SHUFFLE} RESULT_DIR=/logs/verifier bash /tests/stage_test.sh $2 >/dev/null 2>&1 || true" || true
  # `docker exec` without -i gives the container NO stdin, so this heredoc never
  # reached python and grade() printed nothing -- which made emit() choke on an empty
  # string. The control suite could never have produced a row before this fix.
  docker exec -i "$1" python3 - "$2" <<'PY'
import json, sys
stage = sys.argv[1]
try:
    reward = json.load(open("/logs/verifier/reward.json"))
except Exception as exc:
    print(json.dumps({"stage": stage, "error": repr(exc)})); raise SystemExit(0)
try:
    details = json.load(open("/logs/verifier/reward-details.json"))
except Exception:
    details = {}
failed = sorted(
    name for name in details.get("critical_checks", [])
    if not details.get("checks", {}).get(name, {}).get("passed")
)
print(json.dumps({
    "stage": stage,
    "binary_reward": reward.get("binary_reward"),
    "valid_trial": details.get("valid_trial"),
    "training_score": reward.get("training_score"),
    "failed_critical": failed,
    "integrity": (details.get("integrity") or {}).get("detail"),
}))
PY
}

emit() { "$PY_HOST" -c "import json,sys; print(json.dumps(json.loads(sys.argv[1])))" "$1" >> "$ROWS"; }

mutate() { # $1 container, $2 control
  case "$2" in
    mut-single-project)
      docker exec "$1" bash -lc "cd /testbed && grep -rl 'ProjectColumnMap' --include=*.go models routers services | head -3 | xargs -r sed -i 's/range issue.ProjectColumnMap/range issue.ProjectColumnMap[:1]/g'" ;;
    mut-no-diff)
      # util.DiffSlice(oldProjectIDs, newProjectIDs) is the Oracle's set-difference call in
      # models/issues/issue_project.go. Diffing the old set against ITSELF makes both returned
      # slices empty, so the guarded add/remove blocks never run and reconciliation becomes a
      # no-op while the function still returns nil -- exactly the "replace the set difference
      # with a no-op" control this label promises.
      docker exec "$1" bash -lc "cd /testbed && grep -rl 'util.DiffSlice(oldProjectIDs, newProjectIDs)' --include=*.go models/issues | head -1 | xargs -r sed -i 's/util.DiffSlice(oldProjectIDs, newProjectIDs)/util.DiffSlice(oldProjectIDs, oldProjectIDs)/g'" ;;
    mut-index-scope)
      docker exec "$1" bash -lc "cd /testbed && grep -rl 'ProjectIDs' --include=*.go modules/indexer/issues | head -3 | xargs -r sed -i 's/ProjectIDs: *\([A-Za-z0-9_.()\[\]]*\)/ProjectIDs: nil/g'" ;;
    mut-weaken-tests)
      docker exec "$1" bash -lc "cd /testbed && find models services routers -name '*_test.go' -delete" ;;
    mut-hardcode)
      docker exec "$1" bash -lc "cd /testbed && grep -rl 'func (issue \*Issue) LoadProject' --include=*.go models/issues | head -1 | xargs -r sed -i 's/return issue.ProjectColumnMap/return nil/g'" ;;
    mut-singular-search)
      # Filter by only the FIRST project id -- exactly the single-project behaviour
      # the PR removed. Must fail the Stage 3 multi-project search test.
      docker exec "$1" bash -lc "cd /testbed && grep -rl 'ProjectIDs' --include=*.go models/issues | head -3 | xargs -r sed -i 's/opts\.ProjectIDs/opts.ProjectIDs[:1]/g'" ;;
  esac
}

for control in "${CONTROLS[@]}"; do
  echo "==> $control"
  case "$control" in
    oracle)
      for i in $(seq 1 "$REPEATS"); do
        c="lh-cal-oracle-$i"; start "$c"
        for s in "${STAGES[@]}"; do solve "$c" "$s"; row="$(grade "$c" "$s")"; emit "$row"
          "$PY_HOST" -c "import json,sys;r=json.loads(sys.argv[1]);print(f\"   run $i {r['stage']}: binary={r.get('binary_reward')} failed={r.get('failed_critical')}\")" "$row"
        done
        docker rm -f "$c" >/dev/null 2>&1 || true
      done ;;
    nop)
      c="lh-cal-nop"; start "$c"
      for s in "${STAGES[@]}"; do row="$(grade "$c" "$s")"; emit "$row"
        "$PY_HOST" -c "import json,sys;r=json.loads(sys.argv[1]);print(f\"   {r['stage']}: binary={r.get('binary_reward')} failed={r.get('failed_critical')}\")" "$row"
      done
      docker rm -f "$c" >/dev/null 2>&1 || true ;;
    shuffle)
      c="lh-cal-shuffle"; start "$c"
      # Solve AND grade each stage in turn, exactly as the oracle control does. Solving all
      # four back-to-back does not work: solve.sh uses `git apply --index`, which refuses on a
      # dirty tree, and stage 01 leaves its reproducer behind. The intervening grade is what
      # cleans up. Because solve() swallows failures with `|| true`, the old loop silently left
      # the tree UNSOLVED and the shuffle control was grading a pristine base - which is why it
      # always reported 0.0 with build failures and proved nothing about ordering.
      for s in "${STAGES[@]}"; do solve "$c" "$s"; grade "$c" "$s" >/dev/null; done
      # Only now turn shuffling on, and re-grade the terminal stage on the solved tree.
      export STAGE_TEST_SHUFFLE=on
      # STAGE_TEST_SHUFFLE, not GOFLAGS -- hardened_env clears GOFLAGS, so the old
      # form never shuffled anything. grade() re-runs the stage, so pass the variable there
      # too or the recorded row would come from an unshuffled run.
      docker exec "$c" bash -lc "cd /testbed && STAGE_TEST_SHUFFLE=on RESULT_DIR=/logs/verifier bash /tests/stage_test.sh ${STAGES[3]} >/dev/null 2>&1 || true"
      row="$(grade "$c" "${STAGES[3]}")"; emit "$row"
      docker rm -f "$c" >/dev/null 2>&1 || true ;;
    mut-shell-only)
      # The reproducer is a shell script (an allowed form) that exits 0. Accepting
      # every FORM must not mean accepting an artifact that demonstrates nothing, so this
      # must still fail reproducer_demonstrates_gap at Stage 1.
      c="lh-cal-$control"; start "$c"
      docker exec "$c" bash -lc "mkdir -p /app/output/01-diagnose && printf '#!/bin/sh\\nexit 0\\n' > /app/output/01-diagnose/reproduce.sh && chmod +x /app/output/01-diagnose/reproduce.sh && printf '%s\\n' '{\"root_cause\":\"x\",\"missing_capabilities\":[],\"affected_packages\":[],\"reproducer\":\"reproduce.sh\"}' > /app/output/01-diagnose/diagnosis.json && printf '%s\\n' '{\"stage\":\"01-diagnose\",\"summary\":\"x\",\"next_steps\":[]}' > /app/output/handoff.json"
      row="$(grade "$c" "${STAGES[0]}")"; emit "$row"
      "$PY_HOST" -c "import json,sys;r=json.loads(sys.argv[1]);print(f\"   stage01: binary={r.get('binary_reward')} failed={r.get('failed_critical')}\")" "$row"
      docker rm -f "$c" >/dev/null 2>&1 || true ;;
    mut-fake-gap-stdout)
      # The gap terms appear only in what the script PRINTS at runtime, built by string
      # concatenation so they are NOT a contiguous substring of the .sh file's own source
      # (unlike a plain `echo "project column"`, which would still match on source text
      # too). Review finding: an earlier revision matched reproducer_demonstrates_gap
      # against runtime stdout, so this exact script -- whose source has no genuine
      # connection to the capability -- would have passed. It must now fail, because
      # evidence is drawn only from the reproducer's own source/declared command.
      c="lh-cal-$control"; start "$c"
      docker exec "$c" bash -lc "mkdir -p /app/output/01-diagnose && printf '#!/bin/sh\\nW=\"pro\"\"ject col\"\"umn load\"\"projects\"\\necho \"\$W\"\\nexit 1\\n' > /app/output/01-diagnose/reproduce.sh && chmod +x /app/output/01-diagnose/reproduce.sh && printf '%s\\n' '{\"root_cause\":\"x\",\"missing_capabilities\":[],\"affected_packages\":[],\"reproducer\":\"reproduce.sh\"}' > /app/output/01-diagnose/diagnosis.json && printf '%s\\n' '{\"stage\":\"01-diagnose\",\"summary\":\"x\",\"next_steps\":[]}' > /app/output/handoff.json"
      row="$(grade "$c" "${STAGES[0]}")"; emit "$row"
      "$PY_HOST" -c "import json,sys;r=json.loads(sys.argv[1]);print(f\"   stage01: binary={r.get('binary_reward')} failed={r.get('failed_critical')}\")" "$row"
      docker rm -f "$c" >/dev/null 2>&1 || true ;;
    mut-*)
      c="lh-cal-$control"; start "$c"
      for s in "${STAGES[@]}"; do solve "$c" "$s"; done
      mutate "$c" "$control"
      row="$(grade "$c" "${STAGES[3]}")"; emit "$row"
      "$PY_HOST" -c "import json,sys;r=json.loads(sys.argv[1]);print(f\"   terminal: binary={r.get('binary_reward')} failed={r.get('failed_critical')}\")" "$row"
      docker rm -f "$c" >/dev/null 2>&1 || true ;;
  esac
done

"$PY_HOST" - "$ROWS_HOST" "$OUT_HOST" "${CONTROLS[*]}" <<'PY'
import json, sys, datetime
rows = [json.loads(line) for line in open(sys.argv[1], encoding="utf-8") if line.strip()]
out = {
    "description": (
        "Executed calibration controls. Every number comes from the grader's own "
        "reward.json / reward-details.json inside the container, never from a summary."
    ),
    "generatedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "controlsRun": sys.argv[3].split(),
    "rows": rows,
}
json.dump(out, open(sys.argv[2], "w", encoding="utf-8"), indent=1)
print(f"wrote {sys.argv[2]} ({len(rows)} rows)")
PY
