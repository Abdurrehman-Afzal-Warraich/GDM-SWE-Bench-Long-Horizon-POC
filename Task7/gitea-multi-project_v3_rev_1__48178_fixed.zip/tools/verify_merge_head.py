#!/usr/bin/env python3
"""Derive the merge-head equivalence and scope claims against the upstream repo.

Final-said the staged patch union "excludes PR-changed tests,
templates, locales, and generated files and does not reconstruct the full merge
tree". Both halves are answered here, by derivation rather than assertion:

  1. every file the staged patches DO touch is byte-identical to that path at the
     upstream merge commit, and
  2. every file the merge touches that the patches do NOT cover falls into a
     declared exclusion category, with zero unclassified remainder.

Needs network and git, which the task image deliberately lacks, so this is a
release control and never a graded check. The offline half - that the shipped
proof still matches the shipped patches - is asserted by tests/test_package_contract.py.

    python3 tools/verify_merge_head.py                 # clone + verify
    python3 tools/verify_merge_head.py --repo-dir DIR  # reuse a clone
    python3 tools/verify_merge_head.py --write-proof   # refresh MERGE_HEAD_PROOF.json
"""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path

TASK_ROOT = Path(__file__).resolve().parent.parent
PROOF = TASK_ROOT / "MERGE_HEAD_PROOF.json"
REPO_URL = "https://github.com/go-gitea/gitea.git"
BASE = "52d6baf5a816b294662a6b2da26b82425d320930"
MERGE = "81692ceafaa6540f9ea80f86642b255dcb7efc36"
STAGES = ("02-multi-project-model", "03-search-and-indexing", "04-api-web-and-harden")

# Every category of upstream change this task deliberately leaves out, with the
# reason. A merge-touched file that matches none of these is an UNJUSTIFIED
# omission and fails the derivation - that is what stops the exclusion list from
# quietly growing to cover a file the task should have graded.
EXCLUSIONS = (
    ("upstream_tests", lambda p: p.endswith("_test.go"),
     "Upstream test files are withheld on purpose: they are the grading corpus, "
     "injected ephemerally by the verifier so an agent cannot read them."),
    ("frontend_sources", lambda p: p.startswith("web_src/"),
     "Browser sources. This task is offline with no frontend gate, so grading them "
     "would assert a surface nothing can execute here."),
    ("templates", lambda p: p.startswith("templates/"),
     "Server-side HTML templates; same reason as web_src - no rendering gate exists "
     "in an offline container."),
    ("integration_e2e", lambda p: p.startswith(("tests/integration", "tests/e2e")),
     "Integration and end-to-end suites need a live Gitea plus a browser; this task "
     "is an offline container with neither."),
    ("build_tooling", lambda p: p in {"Makefile", ".gitignore"},
     "Build tooling unrelated to the graded behaviour."),
    ("i18n", lambda p: p.startswith("options/locale"),
     "Translation catalogues. Grading them would test wording, not behaviour."),
    ("generated", lambda p: "swagger" in p.lower() or p.startswith("public/"),
     "Generated artefacts derived from source that IS graded."),
)


def git(*args: str, cwd: Path) -> str:
    proc = subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True)
    return proc.stdout


def classify(path: str) -> tuple[str, str] | None:
    for name, matches, reason in EXCLUSIONS:
        if matches(path):
            return name, reason
    return None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-dir", type=Path, default=None)
    parser.add_argument("--write-proof", action="store_true")
    args = parser.parse_args()

    tmp = None
    if args.repo_dir is None:
        tmp = tempfile.TemporaryDirectory(prefix="lh-gitea-mergehead-")
        repo = Path(tmp.name)
        print(f"cloning {REPO_URL} (blobless) ...")
        git("init", "-q", ".", cwd=repo)
        git("remote", "add", "origin", REPO_URL, cwd=repo)
        git("fetch", "-q", "--filter=blob:none", "--depth", "1", "origin", BASE, MERGE, cwd=repo)
    else:
        repo = args.repo_dir.resolve()

    for commit in (BASE, MERGE):
        if git("cat-file", "-t", commit, cwd=repo).strip() != "commit":
            raise SystemExit(f"{commit} unavailable in {repo}")

    git("checkout", "-q", "--force", "--detach", BASE, cwd=repo)
    git("clean", "-qfdx", cwd=repo)

    patches = []
    for stage in STAGES:
        patch = TASK_ROOT / "steps" / stage / "solution/golden.patch"
        digest = hashlib.sha256(patch.read_bytes()).hexdigest()
        provenance = json.loads((patch.parent / "provenance.json").read_text(encoding="utf-8"))
        if provenance["patch_sha256"].lower() != digest.lower():
            raise SystemExit(f"{stage}: provenance sha256 does not match the shipped patch")
        print(f"applying {stage} ({digest[:12]}) ...")
        git("apply", "--index", "--whitespace=nowarn", str(patch), cwd=repo)
        patches.append({"stage": stage, "sha256": digest, "files": provenance["files"]})

    applied = sorted(f for f in git("diff", "--name-only", "--cached", BASE, cwd=repo).splitlines() if f.strip())
    rows, mismatches = [], []
    for rel in applied:
        got = git("hash-object", rel, cwd=repo).strip()
        want = git("rev-parse", f"{MERGE}:{rel}", cwd=repo).strip()
        identical = bool(want) and got == want
        rows.append({"file": rel, "applied_blob": got, "merge_blob": want or None, "identical": identical})
        if not identical:
            mismatches.append(rel)

    merge_files = sorted(f for f in git("diff", "--name-only", f"{BASE}..{MERGE}", cwd=repo).splitlines() if f.strip())
    uncovered = sorted(set(merge_files) - set(applied))

    buckets: dict[str, list[str]] = {name: [] for name, _, _ in EXCLUSIONS}
    unjustified = []
    for rel in uncovered:
        hit = classify(rel)
        if hit is None:
            unjustified.append(rel)
        else:
            buckets[hit[0]].append(rel)

    print()
    print(f"files patched            : {len(applied)}")
    print(f"byte-identical at merge  : {len(applied) - len(mismatches)}")
    print(f"mismatches               : {mismatches or 'none'}")
    print(f"files touched by merge   : {len(merge_files)}")
    print(f"not covered              : {len(uncovered)}")
    for name, _, _ in EXCLUSIONS:
        if buckets[name]:
            print(f"   {len(buckets[name]):3d}  {name}")
    print(f"UNJUSTIFIED omissions    : {unjustified or 'none'}")

    proof = {
        "claim": (
            "Applying the three staged golden patches onto the base reproduces every file "
            "they touch byte-for-byte at the upstream merge commit, and every merge-touched "
            "file they do not cover falls into a declared exclusion category."
        ),
        "base_commit": BASE,
        "merge_commit": MERGE,
        "stage_patches": patches,
        "graded_file_count": len(applied),
        "byte_identical": not mismatches,
        "mismatches": mismatches,
        "merge_touched_file_count": len(merge_files),
        "excluded_by_design": {
            name: {"reason": reason, "count": len(buckets[name]), "files": buckets[name]}
            for name, _, reason in EXCLUSIONS
            if buckets[name]
        },
        "unjustified_omissions": unjustified,
        "scope_complete": not mismatches and not unjustified,
        "files": rows,
        "verified_by": "tools/verify_merge_head.py",
        "verification_method": (
            "blobless clone; checkout of the base commit; the three shipped patches applied "
            "in order with `git apply --index`; `git hash-object` per file compared against "
            "`git rev-parse <merge>:<path>`; then `git diff --name-only base..merge` swept "
            "for any merge-touched file the patches do not cover, each of which must match a "
            "declared exclusion category or the derivation fails."
        ),
    }

    if args.write_proof:
        PROOF.write_text(json.dumps(proof, indent=1) + "\n", encoding="utf-8")
        print(f"\nwrote {PROOF.relative_to(TASK_ROOT)}")

    if tmp is not None:
        tmp.cleanup()
    return 0 if proof["scope_complete"] else 1


if __name__ == "__main__":
    sys.exit(main())
