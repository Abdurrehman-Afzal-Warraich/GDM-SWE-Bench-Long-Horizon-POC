#!/usr/bin/env bash
# Diagnostic: is grading one stage twice in a row idempotent?
#
# The shuffle control grades the terminal stage once in its own branch and again inside
# grade(). The second grade scores 0.0 with hidden_tests_pass, race_clean and vet_clean all
# failing, while a single Oracle grade of the same stage scores 1.0. This isolates that.
set -euo pipefail
export MSYS_NO_PATHCONV=1

TASK_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
IMAGE="${IMAGE:-lh-gitea-multi-project:rework}"
C=lh-regrade
STAGES=(01-diagnose 02-multi-project-model 03-search-and-indexing 04-api-web-and-harden)
TERM=04-api-web-and-harden

docker rm -f "$C" >/dev/null 2>&1 || true
docker run -d --name "$C" -v "$TASK_ROOT/tests:/tests:ro" -v "$TASK_ROOT/steps:/steps:ro" \
  "$IMAGE" sleep infinity >/dev/null
docker exec "$C" bash -lc 'mkdir -p /app/output /logs/verifier /logs/agent /solution'

echo "==> solving all four stages"
for s in "${STAGES[@]}"; do
  docker exec "$C" bash -lc "cp -r /steps/$s/solution/. /solution/ 2>/dev/null || true; bash /solution/solve.sh >/dev/null 2>&1 || true"
done

snap() { docker exec "$C" bash -lc 'cd /testbed && git status --porcelain | sort'; }

echo "==> tree BEFORE any grade"
snap > /tmp/rg_before.txt; wc -l < /tmp/rg_before.txt

echo "==> grade #1"
docker exec "$C" bash -lc "RESULT_DIR=/logs/verifier bash /tests/stage_test.sh $TERM >/dev/null 2>&1 || true"
R1="$(docker exec "$C" bash -lc 'python3 -c "import json;print(json.load(open(\"/logs/verifier/reward.json\")).get(\"binary_reward\"))"' 2>/dev/null || echo ERR)"
echo "   grade #1 binary_reward = $R1"
snap > /tmp/rg_after1.txt; echo "   tree entries after #1: $(wc -l < /tmp/rg_after1.txt)"

echo "==> grade #2 (same stage, same container)"
docker exec "$C" bash -lc "RESULT_DIR=/logs/verifier bash /tests/stage_test.sh $TERM >/dev/null 2>&1 || true"
R2="$(docker exec "$C" bash -lc 'python3 -c "import json;print(json.load(open(\"/logs/verifier/reward.json\")).get(\"binary_reward\"))"' 2>/dev/null || echo ERR)"
echo "   grade #2 binary_reward = $R2"
snap > /tmp/rg_after2.txt; echo "   tree entries after #2: $(wc -l < /tmp/rg_after2.txt)"

echo
echo "==> tree delta introduced by grade #1 (before -> after1)"
diff /tmp/rg_before.txt /tmp/rg_after1.txt || true
echo
echo "==> why grade #2 failed (vet output)"
docker exec "$C" bash -lc 'sed -n "1,25p" /logs/verifier/go_test_failure.log 2>/dev/null || echo "(no failure log)"'
echo
echo "VERDICT: grade1=$R1 grade2=$R2"
