#!/usr/bin/env python3
"""Mirror tests/ into every steps/<step>/tests/ directory (separate-verifier builds).

Harbor's SEPARATE verifier build context resolves per step, not per task:
  harbor/trial/trial.py Trial._verifier_env_build_context():
      if step_cfg is not None:
          step_tests_dir = self.task.paths.step_tests_dir(step_cfg.name)
          if step_tests_dir.exists():
              return step_tests_dir
      return self.task.paths.tests_dir

steps/<step>/tests/ always exists (it holds that step's test.sh, required by the
multi-step layout), so this ALWAYS picks the per-step directory and NEVER falls
back to the task-level tests/ directory -- contrary to what the public docs'
prose implies ("the step's own tests/ when available, otherwise the task's
top-level tests/"). Docker COPY cannot reach outside its build context, so
tests/Dockerfile's `COPY . /tests` only sees whatever is physically inside
steps/<step>/tests/ at build time.

The fix is not to hand-duplicate the verifier package four times (guaranteed
drift): tests/ stays the single source of truth, and this script mirrors it
into every step's tests/ directory, preserving that step's own test.sh (the
one file that must legitimately differ). Run this before packing; the pack
step and the package self-test both fail closed if the mirrors are stale.

CONFIRMED BUG (2026-08-18, real `harbor run -a oracle`): four BYTE-IDENTICAL
Dockerfiles built in quick succession, differing only in their build CONTEXT
content, produced a WRONG image for one step -- steps/03-search-and-indexing's
built image had steps/02-multi-project-model's /tests/test.sh inside it
(confirmed with `docker run --rm <image> cat /tests/test.sh`), even though the
source file on disk was correct and every earlier layer (Go toolchain fetch,
gitea base fetch + build, verifier venv install) legitimately IS shareable
cache. The trial still reported binary_reward=1.0 for stage 3 -- it silently
graded stage 2's criteria again instead of stage 3's (confirmed: its
test_output.log started "stage=02-multi-project-model" and stage 3's own
elasticsearch/meilisearch hidden tests never appeared in the log at all). A
false PASS from a mis-cached image is a strictly worse failure mode than a
slow build, so relying on identical-Dockerfile-text cache sharing for the
final COPY layer is not safe as-is.

Fix, layer 1 (necessary but NOT sufficient, kept anyway): this script injects
one line -- `ENV HARBOR_STEP_NAME=<step>` -- immediately before `COPY . /tests`
in each step's own Dockerfile copy, so that layer's cache key differs by
instruction TEXT, not just by context content behind an identical instruction.
Confirmed working IN ISOLATION (each image's HARBOR_STEP_NAME env var is
correct), but NOT sufficient on its own: a second confirmed run, immediately
after adding it, still produced steps/02-multi-project-model's image with
steps/03-search-and-indexing's /tests/test.sh inside it -- HARBOR_STEP_NAME
correctly said "02-multi-project-model" while /tests/test.sh's own `stage=`
line said "03-search-and-indexing". So the very next `COPY . /tests` layer
was STILL wrong even though it was demonstrably built on a distinctly-cached
parent. That rules out "identical instruction text" as the whole story and
points at something less predictable in how this BuildKit handles a `COPY`
of a whole directory across several `docker build` invocations run in quick
succession against the same daemon/cache store -- not something this package
can fix by asking Docker more nicely.

Fix, layer 2 (the one that actually matters): never trust `COPY` for the one
file that legitimately differs per step. This script now ALSO appends a
`RUN cat > /tests/test.sh <<'...'` heredoc, immediately after `COPY . /tests`,
with that step's OWN test.sh content embedded directly as Dockerfile TEXT --
not sourced from the build context at all. A heredoc's bytes are part of the
instruction stream Docker hashes for the RUN layer itself, so there is no
context-directory lookup left for this file to go wrong: whatever COPY
delivered, this RUN unconditionally overwrites /tests/test.sh with the exact
bytes this script embedded, byte for byte, every time. Everything else under
/tests (stage_check.py, hidden/, contracts/, judge configs, ...) is legitimately
IDENTICAL across all four steps, so even if COPY's cross-step flakiness reaches
those too, it is undetectable and harmless -- uniform content delivered to the
wrong image is still the right content. stage_test.sh's HARBOR_STEP_NAME
cross-check stays as a second, independent safety net: it does not depend on
either mechanism above, so it still catches a class of failure neither one does.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

TASK_ROOT = Path(__file__).resolve().parent.parent
TESTS_DIR = TASK_ROOT / "tests"
STEPS_DIR = TASK_ROOT / "steps"

# Never overwritten in a step's own tests/ directory: this is the one file that
# is legitimately different per step (it names that step's own stage).
PRESERVE = {"test.sh"}
# Regenerable bytecode caches, never package content -- must not be mirrored,
# and must not count as drift when comparing tests/ against a step's copy.
IGNORE_DIRS = {"__pycache__", ".pytest_cache"}

_COPY_TESTS_LINE = "COPY . /tests"
_HEREDOC_DELIM = "HARBOR_STEP_TEST_SH_EOF"


def _skip(rel: Path) -> bool:
    return bool(rel.parts) and (
        rel.parts[0] in PRESERVE or IGNORE_DIRS & set(rel.parts) or rel.suffix == ".pyc"
    )


def _strip_previous_template(src_text: str) -> str:
    """Undo both injections, so re-templating (with a possibly different step
    name, or from an already-templated source read by mistake) is idempotent
    rather than stacking markers or heredocs on each run."""
    src_text = re.sub(r"\nENV HARBOR_STEP_NAME=\S+\n(?=COPY \. /tests\n)", "\n", src_text)
    src_text = re.sub(
        rf"\nRUN cat > /tests/test\.sh <<'{_HEREDOC_DELIM}'\n.*?\n{_HEREDOC_DELIM}\n",
        "\n",
        src_text,
        flags=re.DOTALL,
    )
    return src_text


def _templated_dockerfile(src_text: str, step_name: str, test_sh_text: str) -> str:
    """Insert the per-step cache-busting ENV marker before `COPY . /tests`, and
    append a heredoc RUN that rewrites /tests/test.sh from embedded Dockerfile
    text right after it -- see the module docstring for why both are needed."""
    src_text = _strip_previous_template(src_text)
    assert _COPY_TESTS_LINE in src_text, (
        "tests/Dockerfile no longer contains 'COPY . /tests' -- "
        "update _templated_dockerfile()'s insertion point to match"
    )
    assert _HEREDOC_DELIM not in test_sh_text, (
        f"steps/{step_name}/tests/test.sh contains the heredoc delimiter "
        f"{_HEREDOC_DELIM!r} -- pick a different one in sync_step_verifier_contexts.py"
    )
    env_marker = f"ENV HARBOR_STEP_NAME={step_name}\n"
    rewrite_block = (
        f"RUN cat > /tests/test.sh <<'{_HEREDOC_DELIM}'\n"
        f"{test_sh_text}"
        + ("\n" if not test_sh_text.endswith("\n") else "")
        + f"{_HEREDOC_DELIM}\n"
        "RUN chmod 0755 /tests/test.sh\n"
    )
    return src_text.replace(
        _COPY_TESTS_LINE,
        env_marker + _COPY_TESTS_LINE + "\n" + rewrite_block,
        1,
    )


def _rendered_bytes(src: Path, rel: Path, step_name: str) -> bytes:
    if rel == Path("Dockerfile"):
        test_sh_path = STEPS_DIR / step_name / "tests" / "test.sh"
        test_sh_text = test_sh_path.read_text(encoding="utf-8")
        return _templated_dockerfile(
            src.read_text(encoding="utf-8"), step_name, test_sh_text
        ).encode("utf-8")
    return src.read_bytes()


def sync_one(step_dir: Path) -> list[str]:
    dest = step_dir / "tests"
    dest.mkdir(parents=True, exist_ok=True)
    step_name = step_dir.name
    changed: list[str] = []
    for src in sorted(TESTS_DIR.rglob("*")):
        rel = src.relative_to(TESTS_DIR)
        if _skip(rel):
            continue
        target = dest / rel
        if src.is_dir():
            target.mkdir(parents=True, exist_ok=True)
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        rendered = _rendered_bytes(src, rel, step_name)
        if not target.is_file() or target.read_bytes() != rendered:
            target.write_bytes(rendered)
            changed.append(str(rel))
    # Remove anything in dest that no longer exists in tests/ (except the
    # preserved step-specific files), so a file deleted from tests/ actually
    # disappears from every step mirror instead of lingering as stale content.
    for existing in sorted(dest.rglob("*")):
        rel = existing.relative_to(dest)
        if _skip(rel):
            continue
        source_equivalent = TESTS_DIR / rel
        if existing.is_file() and not source_equivalent.exists():
            existing.unlink()
            changed.append(f"removed {rel}")
    return changed


def main() -> int:
    check_only = "--check" in sys.argv
    any_changed = False
    for step_dir in sorted(p for p in STEPS_DIR.iterdir() if p.is_dir()):
        if check_only:
            # Dry check: compare without writing, by syncing into a throwaway
            # copy would be overkill here; instead just report drift file-by-file.
            dest = step_dir / "tests"
            drift = []
            for src in sorted(TESTS_DIR.rglob("*")):
                rel = src.relative_to(TESTS_DIR)
                if _skip(rel) or src.is_dir():
                    continue
                target = dest / rel
                rendered = _rendered_bytes(src, rel, step_dir.name)
                if not target.is_file() or target.read_bytes() != rendered:
                    drift.append(str(rel))
            if drift:
                any_changed = True
                print(f"DRIFT in {step_dir.name}/tests: {drift}")
            continue
        changed = sync_one(step_dir)
        if changed:
            any_changed = True
            print(f"synced {step_dir.name}/tests: {len(changed)} file(s) updated")
        else:
            print(f"{step_dir.name}/tests: already in sync")
    if check_only:
        if any_changed:
            print("FATAL: step verifier contexts are stale; run without --check to fix")
            return 1
        print("all step verifier contexts match tests/")
        return 0
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
