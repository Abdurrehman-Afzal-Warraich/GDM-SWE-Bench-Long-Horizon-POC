#!/usr/bin/env bash
# Populate tests/verifier-constraints.txt from a real build.
#
# The verifier venv installs pytest and harbor-rewardkit from PyPI. Pinning the
# two direct requirements is not enough to make the image reproducible - their
# transitive closure moves. This script resolves that closure once, in the image
# itself, and writes it back into the package so every later build is pinned.
#
#   bash tools/freeze_verifier_env.sh
#
# Re-run it whenever PYTEST_VERSION or REWARDKIT_VERSION changes in
# tests/Dockerfile (the verifier venv's only home since the agent/verifier split;
# environment/Dockerfile carries no Python at all now). Release builds should set
# STRICT_VERIFIER_LOCK=1, which makes an unpopulated constraints file a build
# failure instead of a bootstrap.
set -euo pipefail

here="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
tag="gitea-multi-project-verifier-freeze:$$"

trap 'docker image rm -f "$tag" >/dev/null 2>&1 || true' EXIT

echo "==> building (unconstrained bootstrap)"
docker build -t "$tag" -f "$here/tests/Dockerfile" "$here/tests" >/dev/null

echo "==> reading the resolved set"
cid="$(docker create "$tag")"
resolved="$(docker cp "$cid:/opt/verifier-requirements.lock" - | tar -xO)"
docker rm -f "$cid" >/dev/null

out="$here/tests/verifier-constraints.txt"
python3 - "$out" <<PY
import pathlib, sys
path = pathlib.Path(sys.argv[1])
header = [l for l in path.read_text(encoding="utf-8").splitlines()
          if l.startswith("#") or not l.strip()]
pins = sorted(set(l.strip() for l in """$resolved""".splitlines()
                  if l.strip() and not l.startswith("#") and "==" in l))
path.write_text("\n".join(header + pins) + "\n", encoding="utf-8")
print(f"wrote {len(pins)} pins to {path}")
PY

echo "==> rebuilding with the constraints applied (this is the check that matters)"
docker build -t "$tag" -f "$here/tests/Dockerfile" "$here/tests" >/dev/null
echo "OK - the constrained build reproduces the same environment"
