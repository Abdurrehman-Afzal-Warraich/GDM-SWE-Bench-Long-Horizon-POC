#!/usr/bin/env bash
# Runtime proof of the protected boundary and the resource envelope.
#
# The boundary was specified statically and the reviewer would not accept that: "the
# boundary is statically specified but not runtime-proven. Fix: build the image and archive
# negative access checks for /tests, solution patches, remotes, refs, reward files, and
# provider keys." Everything below runs INSIDE a built agent container, as the agent's own
# unprivileged account, and records what it could and could not reach.
#
# Writes BOUNDARY.json next to the package. Nothing here runs during grading.
set -euo pipefail

TASK_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
IMAGE="${IMAGE:-lh-gitea-multi-project:rework}"
OUT="$TASK_ROOT/BOUNDARY.json"
C="lh-boundary-$$"
TMPF="/tmp/boundary.$$"
PY_HOST="$(command -v python3 || command -v python)"

cleanup() { docker rm -f "$C" >/dev/null 2>&1 || true; }
trap cleanup EXIT

echo "==> starting $IMAGE"
docker run -d --name "$C" "$IMAGE" sleep infinity >/dev/null

# Each probe: a label and a command that must FAIL (non-zero) for the boundary to hold.
# Run as the agent account, not root -- root inside the image is not the threat model.
run_denied() { # $1 label, $2 command
  local rc out
  out="$(docker exec "$C" gitea-test bash -lc "$2" 2>&1)" && rc=0 || rc=$?
  if [ "$rc" -ne 0 ]; then
    echo "  DENIED  $1"
    printf '%s\0%s\0%s\0' "$1" "denied" "${out:0:200}" >> "$TMPF"
  else
    echo "  LEAKED  $1  <-- $out"
    printf '%s\0%s\0%s\0' "$1" "LEAKED" "${out:0:200}" >> "$TMPF"
  fi
}

: > "$TMPF"
echo "==> negative access checks (each must be DENIED)"
run_denied "hidden test corpus /tests"          'ls /tests/hidden'
run_denied "stage_check.py grader"              'cat /tests/stage_check.py'
run_denied "solution golden patches"            'ls /solution || cat /solution/golden.patch'
run_denied "reward files"                       'ls /logs/verifier/reward.json /app/reward.json'
run_denied "git remotes in testbed"             'cd /testbed && git remote -v | grep -q .'
run_denied "git refs beyond the anchor"         'cd /testbed && git log --oneline -n 5 | grep -qv "$(git rev-parse --short HEAD)"'
run_denied "upstream tags"                      'cd /testbed && git tag | grep -q .'
# The reflog cannot be EMPTY -- the sanitized anchor commit is itself one entry. What must
# not exist is upstream history behind it, so assert exactly one entry and that it is the
# anchor. (An earlier version of this probe demanded an empty reflog and reported a false leak.)
run_denied "reflog exposes history beyond the anchor" 'cd /testbed && [ "$(git reflog | wc -l)" -gt 1 ]'
run_denied "provider API keys in env"           'env | grep -Ei "(ANTHROPIC|OPENAI|GEMINI|HF|AWS)_?(API)?_?KEY|TOKEN" | grep -q .'
# Runtime network isolation is the PLATFORM's job (task.toml: allow_internet = false), not
# the image's -- a bare `docker run` here is deliberately unrestricted, so probing egress
# locally proves nothing about the graded environment. What the IMAGE must guarantee is that
# no graded step NEEDS egress: the module cache is warm and the build works offline.
run_denied "graded build needs network (must not)" 'cd /testbed && GOFLAGS=-mod=mod GOPROXY=off go build ./models/issues/ >/dev/null 2>&1; [ $? -ne 0 ]'

echo "==> resource + timing facts"
DISK="$(docker exec "$C" bash -lc 'du -sh /testbed 2>/dev/null | cut -f1')"
IMGSZ="$(docker image inspect "$IMAGE" --format '{{.Size}}' | awk '{printf "%.2f GB", $1/1024/1024/1024}')"
MODCACHE="$(docker exec "$C" bash -lc 'du -sh "$(go env GOMODCACHE)" 2>/dev/null | cut -f1')"
CPUS="$(docker exec "$C" nproc)"
MEM="$(docker exec "$C" bash -lc "free -g | awk '/Mem:/{print \$2\" GB\"}'")"

"$PY_HOST" - "$OUT" "$IMAGE" "$DISK" "$IMGSZ" "$MODCACHE" "$CPUS" "$MEM" "$TMPF" <<'PY'
import sys, json, datetime, pathlib
out, image, disk, imgsz, modcache, cpus, mem, tmpf = sys.argv[1:9]
raw = pathlib.Path(tmpf)
probes = []
try:
    parts = raw.read_bytes().decode("utf-8", "replace").split("\0")
    for i in range(0, len(parts) - 2, 3):
        probes.append({"probe": parts[i], "result": parts[i + 1], "detail": parts[i + 2]})
except OSError:
    pass
doc = {
    "description": "Runtime proof of the protected boundary and the resource envelope, "
                   "recorded inside a built agent container as the unprivileged agent account. "
                   ".",
    "generatedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "image": image,
    "boundary": {
        "allDenied": all(p["result"] == "denied" for p in probes) if probes else False,
        "probes": probes,
    },
    "resources": {"testbedDisk": disk, "imageSize": imgsz, "goModCache": modcache,
                  "cpus": cpus, "memory": mem},
}
pathlib.Path(out).write_text(json.dumps(doc, indent=2) + "\n", encoding="utf-8")
print(f"wrote {out}: {len(probes)} probes, allDenied={doc['boundary']['allDenied']}")
PY

rm -f "$TMPF"
