#!/usr/bin/env python3
"""Find base-tree test files that the upstream change invalidates.

The hidden corpus is NOT purely additive. Some of its entries exist to REPLACE a
`*_test.go` that already sits in the base tree and that stops compiling once the
production change lands - the upstream PR updates those files, and because every
upstream test is withheld from the agent, the corpus has to carry the replacement.

Dropping one is a build break, not a coverage trim: a Go package that fails to
compile takes every test in it down. That is exactly how Oracle eval 140290 lost
an earlier build, when a base `_test.go` file was removed from the corpus
and the base version's `Issue{ConcurrencyGroup: ...}` literal no longer
matched the migrated schema.

This derives the list from the repository instead of relying on anyone remembering
it, and writes tests/contracts/stale_base_tests.json. The package self-test then
fails if any listed file stops being overlaid.

    python3 tools/render_stale_base_tests.py --repo-dir DIR [--write]
"""

from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path

TASK_ROOT = Path(__file__).resolve().parent.parent
OUT = TASK_ROOT / "tests/contracts/stale_base_tests.json"
BASE = "52d6baf5a816b294662a6b2da26b82425d320930"
MERGE = "81692ceafaa6540f9ea80f86642b255dcb7efc36"

# Only packages this task actually builds and grades. A test file outside them
# cannot break a graded build.
GRADED_PREFIXES = (
    "models/issues/", "models/project/",
    "modules/indexer/", "modules/structs/", "modules/templates/", "modules/util/",
    "routers/api/v1/", "routers/web/",
    "services/context/", "services/convert/", "services/forms/",
    "services/issue/", "services/projects/", "services/pull/",
)


def git(*args: str, cwd: Path) -> str:
    return subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True).stdout


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-dir", type=Path, required=True)
    parser.add_argument("--write", action="store_true")
    args = parser.parse_args()
    repo = args.repo_dir.resolve()

    changed = [
        line.strip()
        for line in git("diff", "--name-only", f"{BASE}..{MERGE}", cwd=repo).splitlines()
        if line.strip()
    ]
    rows = []
    for rel in sorted(changed):
        if not rel.endswith("_test.go") or not rel.startswith(GRADED_PREFIXES):
            continue
        exists_at_base = (
            subprocess.run(
                ["git", "cat-file", "-e", f"{BASE}:{rel}"], cwd=repo, capture_output=True
            ).returncode
            == 0
        )
        rows.append(
            {
                "file": rel,
                "existsAtBase": exists_at_base,
                # A file that already exists at base AND is modified by the change is
                # the dangerous kind: leaving the base copy in place can break the
                # package build. A file the change ADDS is safe to simply withhold.
                "mustBeOverlaid": exists_at_base,
            }
        )

    doc = {
        "description": (
            "Base-tree *_test.go files inside graded packages that the upstream change "
            "modifies. Those that already exist at the base commit MUST be overlaid by "
            "the hidden corpus: the production change can invalidate them, and a Go "
            "package that does not compile takes every test in it down with it."
        ),
        "derivedBy": "tools/render_stale_base_tests.py",
        "baseCommit": BASE,
        "mergeCommit": MERGE,
        "files": rows,
        "mustBeOverlaid": sorted(r["file"] for r in rows if r["mustBeOverlaid"]),
    }

    print(f"graded test files touched by the change : {len(rows)}")
    print(f"must be overlaid (exist at base)        : {len(doc['mustBeOverlaid'])}")
    for rel in doc["mustBeOverlaid"]:
        print(f"   {rel}")

    if args.write:
        OUT.parent.mkdir(parents=True, exist_ok=True)
        OUT.write_text(json.dumps(doc, indent=1) + "\n", encoding="utf-8")
        print(f"\nwrote {OUT.relative_to(TASK_ROOT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
