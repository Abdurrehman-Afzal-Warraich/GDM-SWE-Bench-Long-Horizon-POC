#!/usr/bin/env bash
# The controls that decide whether the grader is implementation-independent.
#
# Oracle 1.0 only proves the verifier accepts the upstream patch. It says nothing about whether
# an EQUIVALENT solution passes, or an Oracle-SHAPED but wrong one fails. Each property needs
# its own control, and each must be constructed so its result is unambiguous:
#
#   equivalent-correct    refreshes the cache eagerly instead of nil-ing it; MUST score 1.0
#   oracle-shaped-wrong   every disclosed symbol intact, reconciles only the first id; MUST be 0.0
#   fake-testmain         broken code PLUS a TestMain that prints pass lines; MUST be 0.0
#   silent-skip-unknown   ignores ids it cannot resolve instead of failing; MUST be 0.0
#   non-atomic            identical logic with no enclosing transaction; MUST be 0.0
#   adapter-ignores-filter  elasticsearch Search stops consuming the plural filter; MUST be 0.0
#
# The fake-TestMain control deliberately breaks the implementation first. Planting a fake
# bootstrap on a CORRECT tree is useless: 1.0 would mean either "the restore worked" or "the
# fabrication worked", and the control could not tell them apart. On a broken tree only a
# fooled grader returns 1.0.
set -euo pipefail
export MSYS_NO_PATHCONV=1

TASK_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
# Same tag run_controls.sh and run_boundary_checks.sh build, so one `docker build`
# serves all three release-control scripts.
IMAGE="${IMAGE:-lh-gitea-multi-project:rework}"
STAGE="${STAGE:-02-multi-project-model}"
IMPL=/testbed/models/issues/issue_project.go
OUT="$TASK_ROOT/ADVERSARIAL.json"
PY_HOST="$(command -v python3 || command -v python)"
FAILURES=0
RESULTS=""
# label\0expected\0got\0verdict\0, appended by check(); written out as ADVERSARIAL.json
# at the end so "the controls ran and this is what they proved" is retained evidence,
# not just a build-log claim.
ROWS_FILE="$(mktemp)"
trap 'rm -f "$ROWS_FILE"' EXIT

prepare() { # $1 container -- solve AND grade each stage; solve.sh uses `git apply --index`,
            # which refuses on the tree the previous stage dirties, so grading between is required
  docker rm -f "$1" >/dev/null 2>&1 || true
  docker run -d --name "$1" -v "$TASK_ROOT/tests:/tests:ro" -v "$TASK_ROOT/steps:/steps:ro" \
    "$IMAGE" sleep infinity >/dev/null
  docker exec "$1" bash -lc 'mkdir -p /app/output /logs/verifier /logs/agent /solution'
  for s in 01-diagnose 02-multi-project-model 03-search-and-indexing 04-api-web-and-harden; do
    docker exec "$1" bash -lc "cp -r /steps/$s/solution/. /solution/ 2>/dev/null || true; bash /solution/solve.sh >/dev/null 2>&1 || true"
    docker exec "$1" bash -lc "RESULT_DIR=/logs/verifier bash /tests/stage_test.sh $s >/dev/null 2>&1 || true"
    [ "$s" = "$STAGE" ] && break
  done
}

grade() { # $1 container -> binary_reward
  docker exec "$1" bash -lc "RESULT_DIR=/logs/verifier bash /tests/stage_test.sh $STAGE >/dev/null 2>&1 || true"
  docker exec -i "$1" python3 -c "import json;print(json.load(open('/logs/verifier/reward.json')).get('binary_reward'))" 2>/dev/null || echo ERR
}

check() { # label, got, want
  if [ "$2" = "$3" ]; then
    echo "  PASS  $1 -> $2 (expected $3)"; RESULTS="$RESULTS$1=$2:pass;"
    printf '%s\0%s\0%s\0%s\0' "$1" "$3" "$2" "pass" >> "$ROWS_FILE"
  else
    echo "  FAIL  $1 -> $2 (expected $3)"; RESULTS="$RESULTS$1=$2:FAIL;"; FAILURES=$((FAILURES+1))
    printf '%s\0%s\0%s\0%s\0' "$1" "$3" "$2" "FAIL" >> "$ROWS_FILE"
  fi
}

require_applied() { # $1 container, $2 grep pattern, $3 label -- a silent no-op mutation would
                    # score 1.0 and be misread as a grader failure
  if ! docker exec "$1" bash -lc "grep -q '$2' $IMPL"; then
    echo "  ERROR $3: mutation did not apply (pattern absent) -- control is invalid"
    printf '%s\0%s\0%s\0%s\0' "$3" "n/a" "n/a" "ERROR: mutation did not apply" >> "$ROWS_FILE"
    FAILURES=$((FAILURES+1)); return 1
  fi
  return 0
}

# ---------------------------------------------------------------------------
echo "==> 1/6 equivalent-correct: eager refresh instead of nil (MUST pass)"
C=gmp-equivalent; prepare "$C"
# Refresh AFTER the transaction commits. Doing it inside, before the adds run, would load a
# stale set and is a genuine bug rather than an equivalent design.
docker exec "$C" bash -lc "python3 - <<'PY'
import re,pathlib
p=pathlib.Path('$IMPL'); t=p.read_text()
t=t.replace('\t\tissue.isProjectsLoaded = false\n\t\tissue.Projects = nil\n',
            '\t\tissue.isProjectsLoaded = false\n\t\tissue.Projects = nil\n\t\tdefer func() { _ = issue.LoadProjects(ctx) }()\n',1)
p.write_text(t)
PY"
if require_applied "$C" "defer func() { _ = issue.LoadProjects(ctx) }()" "equivalent-correct"; then
  check "equivalent-correct" "$(grade "$C")" "1.0"
fi
docker rm -f "$C" >/dev/null 2>&1 || true

# ---------------------------------------------------------------------------
echo "==> 2/6 oracle-shaped-wrong: right symbols, wrong behaviour (MUST fail)"
C=gmp-shaped-wrong; prepare "$C"
docker exec "$C" bash -lc "sed -i 's/for _, projectID := range projectsToAdd/for _, projectID := range projectsToAdd[:1]/' $IMPL"
if require_applied "$C" "projectsToAdd\[:1\]" "oracle-shaped-wrong"; then
  check "oracle-shaped-wrong" "$(grade "$C")" "0.0"
fi
docker rm -f "$C" >/dev/null 2>&1 || true

# ---------------------------------------------------------------------------
echo "==> 3/6 fake-testmain: broken code + fabricated pass lines (MUST fail)"
C=gmp-fake-testmain; prepare "$C"
docker exec "$C" bash -lc "sed -i 's/for _, projectID := range projectsToAdd/for _, projectID := range projectsToAdd[:0]/' $IMPL"
docker exec "$C" bash -lc 'cat > /testbed/models/issues/main_test.go <<'"'"'EOF'"'"'
package issues_test

import (
	"fmt"
	"os"
	"testing"
)

func TestMain(m *testing.M) {
	for _, n := range []string{"TestIssueMultipleProjects", "TestIssueLoadProjects"} {
		fmt.Printf("=== RUN   %s\n--- PASS: %s (0.00s)\n", n, n)
	}
	fmt.Println("PASS")
	os.Exit(0)
}
EOF'
if require_applied "$C" "projectsToAdd\[:0\]" "fake-testmain"; then
  check "fake-testmain" "$(grade "$C")" "0.0"
fi
docker rm -f "$C" >/dev/null 2>&1 || true

# ---------------------------------------------------------------------------
echo "==> 4/6 silent-skip-unknown: ignores unresolvable ids instead of failing (MUST fail)"
C=gmp-skip-unknown; prepare "$C"
# Skipping an id it cannot resolve makes the call succeed and half-apply: the removals stand
# and the bad addition is dropped. The disclosed contract says the call fails and the
# membership is left alone, so this must not score.
docker exec "$C" bash -lc "python3 - <<'PY'
import pathlib
p=pathlib.Path('$IMPL'); t=p.read_text()
old='''\t\t\t\tif !ok {
\t\t\t\t\treturn util.NewNotExistErrorf(\"project %d not found\", projectID)
\t\t\t\t}'''
new='''\t\t\t\tif !ok {
\t\t\t\t\tcontinue // MUTANT: silently skip
\t\t\t\t}'''
assert old in t, 'not-exist guard not found'
p.write_text(t.replace(old,new,1))
PY"
if require_applied "$C" "MUTANT: silently skip" "silent-skip-unknown"; then
  check "silent-skip-unknown" "$(grade "$C")" "0.0"
fi
docker rm -f "$C" >/dev/null 2>&1 || true

# ---------------------------------------------------------------------------
echo "==> 5/6 non-atomic: same logic, no enclosing transaction (MUST fail)"
C=gmp-non-atomic; prepare "$C"
# Unwrap db.WithTx so each statement commits on its own. The logic is otherwise
# untouched and every disclosed symbol survives, so only the two properties that
# depend on a call being ONE unit can notice: a failed call now leaves its removals
# applied, and concurrent calls interleave.
docker exec "$C" bash -lc "python3 - <<'PY'
import pathlib
p=pathlib.Path('$IMPL'); t=p.read_text()
open_call='\treturn db.WithTx(ctx, func(ctx context.Context) error {'
assert open_call in t, 'WithTx wrapper not found'
head, rest = t.split(open_call, 1)
# The wrapper closes with '\t})' at the end of the enclosing function.
idx = rest.rindex('\n\t})')
body = rest[:idx]
tail = rest[idx+len('\n\t})'):]
mutant = '\t// MUTANT: no enclosing transaction\n\treturn func(ctx context.Context) error {' + body + '\n\t}(ctx)' + tail
p.write_text(head + mutant)
PY"
if require_applied "$C" "MUTANT: no enclosing transaction" "non-atomic"; then
  check "non-atomic" "$(grade "$C")" "0.0"
fi
docker rm -f "$C" >/dev/null 2>&1 || true

# ---------------------------------------------------------------------------
# Stage 3, so the stage under test changes for this one control only. It runs last.
STAGE=03-search-and-indexing
ES=/testbed/modules/indexer/issues/elasticsearch/elasticsearch.go
echo "==> 6/6 adapter-ignores-filter: elasticsearch drops the plural filter (MUST fail)"
C=gmp-adapter; prepare "$C"
# elasticsearch has no live service here, so its conformance suite self-skips and the
# only other gate used to be compilation -- which this mutant passes. It substitutes an
# empty slice for the caller's project ids INSIDE Search, so the adapter still builds and
# still runs, and simply never filters. That is the exact failure the routing check exists
# to catch.
docker exec "$C" bash -lc "python3 - <<'PY'
import re, pathlib
p = pathlib.Path('$ES'); t = p.read_text()
m = re.search(r'\nfunc \([^)]*\) Search\(', t)
assert m, 'Search method not found'
nxt = re.search(r'\nfunc ', t[m.end():])
end = m.end() + (nxt.start() if nxt else len(t) - m.end())
body = t[m.end():end]
assert 'options.ProjectIDs' in body, 'Search does not reference the plural filter'
p.write_text(t[:m.end()] + body.replace('options.ProjectIDs', '[]int64{}') + t[end:])
PY"
if docker exec "$C" bash -lc "grep -q 'int64{}' $ES"; then
  check "adapter-ignores-filter" "$(grade "$C")" "0.0"
else
  echo "  ERROR adapter-ignores-filter: mutation did not apply -- control is invalid"
  printf '%s\0%s\0%s\0%s\0' "adapter-ignores-filter" "n/a" "n/a" "ERROR: mutation did not apply" >> "$ROWS_FILE"
  FAILURES=$((FAILURES+1))
fi
docker rm -f "$C" >/dev/null 2>&1 || true

echo
echo "RESULTS: $RESULTS"

# Write ADVERSARIAL.json from ROWS_FILE, the same "only from what the grader/probe
# actually returned, never from a hand-written summary" discipline run_controls.sh's
# CALIBRATION.json and run_boundary_checks.sh's BOUNDARY.json already follow.
"$PY_HOST" - "$OUT" "$IMAGE" "$FAILURES" "$ROWS_FILE" <<'PY'
import sys, json, datetime, pathlib
out, image, failures, rows_file = sys.argv[1:5]
raw = pathlib.Path(rows_file)
controls = []
try:
    parts = raw.read_bytes().decode("utf-8", "replace").split("\0")
    for i in range(0, len(parts) - 3, 4):
        controls.append({
            "control": parts[i],
            "expectedBinaryReward": parts[i + 1],
            "observedBinaryReward": parts[i + 2],
            "verdict": parts[i + 3],
        })
except OSError:
    pass
doc = {
    "description": (
        "Adversarial grader-independence controls: verifier-independent-of-Oracle "
        "properties (alternate-correct implementation, Oracle-shaped-but-wrong, "
        "test-bootstrap spoofing, unknown-id/non-atomic/adapter-filter mutations). "
        "Every row comes from the grader's own reward.json inside the container."
    ),
    "generatedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "image": image,
    "failures": int(failures),
    "allControlsBehavedAsRequired": int(failures) == 0,
    "controls": controls,
}
pathlib.Path(out).write_text(json.dumps(doc, indent=2) + "\n", encoding="utf-8")
print(f"wrote {out}: {len(controls)} control rows, failures={failures}")
PY

if [ "$FAILURES" -eq 0 ]; then
  echo "all adversarial controls behaved as required"
else
  echo "$FAILURES control(s) misbehaved"
  exit 1
fi
