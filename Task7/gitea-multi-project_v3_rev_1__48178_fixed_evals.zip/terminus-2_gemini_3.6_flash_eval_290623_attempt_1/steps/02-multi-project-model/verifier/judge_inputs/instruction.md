# Stage 2 — Make the association many-to-many

Rework the model layer in `/testbed` so an issue can belong to any number of
projects. `/app/output/handoff.json` carries stage 1's findings.

- An issue loads **all** its projects, not one.
- The column an issue occupies is per-project: asking for "the column" of an
  issue now means asking for a map from project id to column id.
- Assigning projects takes the **full desired set** and reconciles to it — adding
  what is missing, removing what is no longer wanted, leaving the rest alone.
- Existing single-project behaviour is preserved: one project in, one project out.

The `project_issue` join table already exists at the base commit, so no schema
migration is part of this work.

The protected tests link against package-private and exported identifiers by
name. Every one of them is listed in `/app/contracts/02-multi-project-model.md`
— read it before you start; nothing else is required to match the reference.

Run Go tests through the unprivileged wrapper: `gitea-test go test ./models/issues/`.

Write `/app/output/02-multi-project-model/implementation.json` (≤ 256 KiB) with
at least: `association_shape` (string), `column_mapping` (string),
`single_project_compatibility` (string), `packages_touched` (array). Carry
`/app/output/handoff.json` forward with `stage`, `summary`, `next_steps`.

**Graded:** the behaviours above through the injected test corpus, plus a build
and `go vet` of the changed packages. **Scored but never decisive:** the report
and the handoff.
