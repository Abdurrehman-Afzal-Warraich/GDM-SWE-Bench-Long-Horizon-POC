// Copyright 2021 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package issues

import (
"context"

"code.gitea.io/gitea/models/db"
project_model "code.gitea.io/gitea/models/project"
user_model "code.gitea.io/gitea/models/user"
"code.gitea.io/gitea/modules/util"
)

// LoadProjects loads all projects the issue is assigned to
func (issue *Issue) LoadProjects(ctx context.Context) error {
if issue.Projects != nil {
return nil
}
projects := make([]*project_model.Project, 0)
err := db.GetEngine(ctx).Table("project").
Join("INNER", "project_issue", "project.id=project_issue.project_id").
Where("project_issue.issue_id = ?", issue.ID).
Find(&projects)
if err != nil {
return err
}
issue.Projects = projects
if len(projects) > 0 {
issue.Project = projects[0]
} else {
issue.Project = nil
}
return nil
}

// LoadProject loads the project the issue was assigned to (for backward compatibility)
func (issue *Issue) LoadProject(ctx context.Context) error {
return issue.LoadProjects(ctx)
}

func (issue *Issue) projectID(ctx context.Context) int64 {
var ip project_model.ProjectIssue
has, err := db.GetEngine(ctx).Where("issue_id=?", issue.ID).Get(&ip)
if err != nil || !has {
return 0
}
return ip.ProjectID
}

// ProjectColumnMap returns a map from project id to column id for the issue
func (issue *Issue) ProjectColumnMap(ctx context.Context) (map[int64]int64, error) {
var projectIssues []project_model.ProjectIssue
if err := db.GetEngine(ctx).Where("issue_id=?", issue.ID).Find(&projectIssues); err != nil {
return nil, err
}
res := make(map[int64]int64, len(projectIssues))
for _, pi := range projectIssues {
res[pi.ProjectID] = pi.ProjectColumnID
}
return res, nil
}

// ProjectColumnID returns project column id if issue was assigned to one
func (issue *Issue) ProjectColumnID(ctx context.Context) (int64, error) {
var ip project_model.ProjectIssue
has, err := db.GetEngine(ctx).Where("issue_id=?", issue.ID).Get(&ip)
if err != nil {
return 0, err
} else if !has {
return 0, nil
}
return ip.ProjectColumnID, nil
}

func LoadProjectIssueColumnMap(ctx context.Context, projectID, defaultColumnID int64) (map[int64]int64, error) {
issues := make([]project_model.ProjectIssue, 0)
if err := db.GetEngine(ctx).Where("project_id=?", projectID).Find(&issues);
err != nil {
return nil, err
}
result := make(map[int64]int64, len(issues))
for _, issue := range issues {
if issue.ProjectColumnID == 0 {
issue.ProjectColumnID = defaultColumnID
}
result[issue.IssueID] = issue.ProjectColumnID
}
return result, nil
}

// IssueAssignOrRemoveProject takes the full desired set of project IDs and reconciles to it.
func IssueAssignOrRemoveProject(ctx context.Context, issue *Issue, doer *user_model.User, newProjectIDs []int64) error {
if err := issue.LoadRepo(ctx); err != nil {
return err
}

desiredMap := make(map[int64]bool)
var desiredIDs []int64
for _, id := range newProjectIDs {
if id > 0 && !desiredMap[id] {
desiredMap[id] = true
desiredIDs = append(desiredIDs, id)
}
}

projectObjs := make(map[int64]*project_model.Project, len(desiredIDs))
for _, pID := range desiredIDs {
p, err := project_model.GetProjectByID(ctx, pID)
if err != nil {
return err
}
if !p.CanBeAccessedByOwnerRepo(issue.Repo.OwnerID, issue.Repo) {
return util.NewPermissionDeniedErrorf("issue %d can't be accessed by project %d", issue.ID, p.ID)
}
projectObjs[pID] = p
}

return db.WithTx(ctx, func(ctx context.Context) error {
var dummy Issue
_, _ = db.GetEngine(ctx).Where("id=?", issue.ID).ForUpdate().Get(&dummy)

var currentPIs []project_model.ProjectIssue
if err := db.GetEngine(ctx).Where("issue_id=?", issue.ID).Find(&currentPIs); err != nil {
return err
}

currentMap := make(map[int64]project_model.ProjectIssue, len(currentPIs))
for _, pi := range currentPIs {
currentMap[pi.ProjectID] = pi
}

var toAdd []int64
for _, pID := range desiredIDs {
if _, exists := currentMap[pID]; !exists {
toAdd = append(toAdd, pID)
}
}

var toRemove []int64
for pID := range currentMap {
if !desiredMap[pID] {
toRemove = append(toRemove, pID)
}
}

if len(toAdd) == 0 && len(toRemove) == 0 {
return nil
}

for _, pID := range toRemove {
if _, err := db.GetEngine(ctx).Where("issue_id=? AND project_id=?", issue.ID, pID).Delete(&project_model.ProjectIssue{}); err != nil {
return err
}
if _, err := CreateComment(ctx, &CreateCommentOptions{
Type:         CommentTypeProject,
Doer:         doer,
Repo:         issue.Repo,
Issue:        issue,
OldProjectID: pID,
ProjectID:    0,
}); err != nil {
return err
}
}

for _, pID := range toAdd {
p := projectObjs[pID]
defaultColumn, err := p.MustDefaultColumn(ctx)
if err != nil {
return err
}
sorting, err := project_model.GetColumnIssueNextSorting(ctx, pID, defaultColumn.ID)
if err != nil {
return err
}
if err := db.Insert(ctx, &project_model.ProjectIssue{
IssueID:         issue.ID,
ProjectID:       pID,
ProjectColumnID: defaultColumn.ID,
Sorting:         sorting,
}); err != nil {
return err
}
if _, err := CreateComment(ctx, &CreateCommentOptions{
Type:         CommentTypeProject,
Doer:         doer,
Repo:         issue.Repo,
Issue:        issue,
OldProjectID: 0,
ProjectID:    pID,
}); err != nil {
return err
}
}

issue.Projects = nil
issue.Project = nil
return nil
})
}
