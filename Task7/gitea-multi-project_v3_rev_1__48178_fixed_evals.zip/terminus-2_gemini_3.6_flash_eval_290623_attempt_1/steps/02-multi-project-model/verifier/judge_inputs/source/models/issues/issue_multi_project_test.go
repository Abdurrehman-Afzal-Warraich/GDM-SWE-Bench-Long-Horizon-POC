// Copyright 2024 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package issues

import (
"testing"

project_model "code.gitea.io/gitea/models/project"
"code.gitea.io/gitea/models/unittest"
user_model "code.gitea.io/gitea/models/user"

"github.com/stretchr/testify/assert"
)

func TestMultiProjectSupport(t *testing.T) {
assert.NoError(t, unittest.PrepareTestDatabase())

issue := unittest.AssertExistsAndLoadBean(t, &Issue{ID: 1})
err := issue.LoadRepo(t.Context())
assert.NoError(t, err)

user := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 2})

p2 := &project_model.Project{
Title:     "Second Project",
RepoID:    issue.RepoID,
Type:      project_model.TypeRepository,
OwnerID:   issue.Repo.OwnerID,
CreatorID: user.ID,
}
err = project_model.NewProject(t.Context(), p2)
assert.NoError(t, err)

p3 := &project_model.Project{
Title:     "Third Project",
RepoID:    issue.RepoID,
Type:      project_model.TypeRepository,
OwnerID:   issue.Repo.OwnerID,
CreatorID: user.ID,
}
err = project_model.NewProject(t.Context(), p3)
assert.NoError(t, err)

err = IssueAssignOrRemoveProject(t.Context(), issue, user, []int64{1, p2.ID})
assert.NoError(t, err)

issue.ResetAttributesLoaded()
err = issue.LoadProjects(t.Context())
assert.NoError(t, err)
assert.Len(t, issue.Projects, 2)

colMap, err := issue.ProjectColumnMap(t.Context())
assert.NoError(t, err)
assert.Len(t, colMap, 2)
assert.Contains(t, colMap, int64(1))
assert.Contains(t, colMap, p2.ID)

err = IssueAssignOrRemoveProject(t.Context(), issue, user, []int64{p2.ID, p3.ID})
assert.NoError(t, err)

issue.ResetAttributesLoaded()
err = issue.LoadProjects(t.Context())
assert.NoError(t, err)
assert.Len(t, issue.Projects, 2)

colMap, err = issue.ProjectColumnMap(t.Context())
assert.NoError(t, err)
assert.Len(t, colMap, 2)
assert.NotContains(t, colMap, int64(1))
assert.Contains(t, colMap, p2.ID)
assert.Contains(t, colMap, p3.ID)

err = IssueAssignOrRemoveProject(t.Context(), issue, user, []int64{p2.ID, p3.ID})
assert.NoError(t, err)

err = IssueAssignOrRemoveProject(t.Context(), issue, user, []int64{p2.ID, 999999})
assert.Error(t, err)

colMap, err = issue.ProjectColumnMap(t.Context())
assert.NoError(t, err)
assert.Len(t, colMap, 2)
assert.Contains(t, colMap, p2.ID)
assert.Contains(t, colMap, p3.ID)
}
