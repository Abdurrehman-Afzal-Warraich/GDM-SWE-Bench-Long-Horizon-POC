// Copyright 2025 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package issues

import (
"testing"

"code.gitea.io/gitea/models/db"
project_model "code.gitea.io/gitea/models/project"
"code.gitea.io/gitea/models/unittest"
user_model "code.gitea.io/gitea/models/user"

"github.com/stretchr/testify/assert"
)

func TestMultiProjectSupport(t *testing.T) {
assert.NoError(t, unittest.PrepareTestDatabase())

issue := unittest.AssertExistsAndLoadBean(t, &Issue{ID: 1})
user := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 1})

p2 := &project_model.Project{
Title:     "Second Project",
RepoID:    issue.RepoID,
Type:      project_model.TypeRepository,
CreatorID: user.ID,
}
err := project_model.NewProject(t.Context(), p2)
assert.NoError(t, err)

// Assign issue to project 1
err = IssueAssignOrRemoveProject(t.Context(), issue, user, 1, 1)
assert.NoError(t, err)

// Assign issue to project 2
err = IssueAssignOrRemoveProject(t.Context(), issue, user, p2.ID, 0)
assert.NoError(t, err)

// Verify issue is associated with BOTH project 1 and project 2
var projectIssues []project_model.ProjectIssue
err = db.GetEngine(t.Context()).Where("issue_id = ?", issue.ID).Find(&projectIssues)
assert.NoError(t, err)
assert.Len(t, projectIssues, 2, "issue should belong to multiple projects simultaneously")
}
