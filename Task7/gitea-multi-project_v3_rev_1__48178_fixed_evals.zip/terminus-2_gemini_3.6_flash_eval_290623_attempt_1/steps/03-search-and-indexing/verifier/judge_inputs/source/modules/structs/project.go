// Copyright 2024 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package structs

import "time"

// Project represents a project
// swagger:model
type Project struct {
	ID          int64      `json:"id"`
	Title       string     `json:"title"`
	Description string     `json:"description"`
	IsClosed    bool       `json:"is_closed"`
	Created     time.Time  `json:"created_at"`
	Updated     time.Time  `json:"updated_at"`
	Closed      *time.Time `json:"closed_at"`
}
