# Stage 3 — Carry the plural filter through search

Stage 2 made the model plural. Issue search still filters by a single project id,
so the new capability is invisible to every list and query. Fix that in
`/testbed`.

- The issue-search options carry a **set** of project ids instead of one optional
  id, and matching is an **OR**: an issue in any requested project matches.
- All four indexer backends honour the plural filter — the database backend plus
  bleve, elasticsearch and meilisearch. In this tree they already read one shared
  options struct and are exercised by one conformance harness, and the protected
  tests construct both directly, so the shape they expect is fixed for you.
- **Graded precisely.** Database and bleve run the shared conformance cases, so
  their any-of behaviour is executed. Elasticsearch and meilisearch have no live
  service here, so their suites skip themselves — expected, not a failure. For
  those two the requirement is that each one's `Search` consumes the plural filter,
  checked by reading the adapters: compiling alone would accept one that ignores
  it. How you build the query is yours.
- The wire structs gain the plural project shape the API will project in stage 4.

Identifiers the protected tests link against are listed in
`/app/contracts/03-search-and-indexing.md`.

Run Go tests through the unprivileged wrapper, e.g.
`gitea-test go test ./modules/indexer/issues/...`.

Write `/app/output/03-search-and-indexing/review_response.json` (≤ 256 KiB) with
at least: `filter_shape` (string), `backends_covered` (array), `wire_shape`
(string), `packages_touched` (array). Carry `/app/output/handoff.json` forward with `stage` (string), `summary`
(string) and `next_steps` (array).

**Graded:** the search behaviour through the injected corpus, plus a build and
`go vet` over the cumulative package set. **Scored but never decisive:** the
report and the handoff.
