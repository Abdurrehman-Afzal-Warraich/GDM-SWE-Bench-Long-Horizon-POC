# Merge-readiness rubric — Gitea issues on multiple project boards

The executable verdict is already final. A terminal reviewer evaluates the six
standard dimensions declared in `merge_readiness/judge.toml`: repository
conventions, focused change, maintainability, architecture, useful tests and no
patch bloat. Two task-specific dimensions cover single-project compatibility
(an issue on exactly one board behaves as it did before, with no data migration)
and consistency of the per-project column mapping across the model, indexer, API
and template layers. Record a failure only when it supports a concrete
change-request comment on a file or hunk.
