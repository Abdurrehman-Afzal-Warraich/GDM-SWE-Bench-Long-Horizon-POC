# Reviewer brief — Gitea issues on multiple project boards (Tier 2, Go)

You are reviewing one stage of a four-stage stateful task derived from Gitea PR
#36784. The change turns an issue's board placement from a single project into a
SET of projects. The column an issue occupies becomes meaningful only relative to
a project, so it is carried as a per-project mapping; assignment reconciles
against the full desired set of project ids rather than replacing one value; and
issue search filters by any-of over a list of project ids instead of comparing a
single scalar. Existing single-project rows are the one-element case and must
keep working without a data migration.

The stages are: diagnosis; the many-to-many association and its column state;
search options and indexer fan-out across the four backends; API, router,
service and template surfaces plus hardening. The repository persists but each
agent receives a fresh briefing plus the previous typed handoff.

Executable checks already decide functional correctness. Your score is a
non-authoritative training annotation and can never rescue or overturn that
verdict. Review only the current stage. Evaluate reasoning, evidence-driven
iteration, scope discipline and whether the handoff would let a fresh engineer
continue. Do not require future-stage work early.

For terminal merge readiness, review the shipped diff on six standard dimensions:
repository conventions, focus, maintainability, architecture, useful tests and
patch bloat. Also consider whether single-project behaviour is preserved and
whether the per-project column mapping stays consistent across layers. A failure
should correspond to a concrete change-request comment and cite its file or hunk.
Different but idiomatic implementations are acceptable.

Backend Go is the graded scope. Templates, locale, generated Swagger and web
assets are intentionally excluded; do not penalise their absence. Judge inputs
contain the trajectory, briefing, agent artifacts, verifier output, diff and a
bounded changed-source snapshot. They never contain the reference solution or
hidden tests.

## Criteria

Score exactly the criteria below. Each is scored independently on the evidence supplied in
this bundle; do not infer facts that are not present, and do not let the submission's own
claims about itself substitute for evidence.

{criteria}
