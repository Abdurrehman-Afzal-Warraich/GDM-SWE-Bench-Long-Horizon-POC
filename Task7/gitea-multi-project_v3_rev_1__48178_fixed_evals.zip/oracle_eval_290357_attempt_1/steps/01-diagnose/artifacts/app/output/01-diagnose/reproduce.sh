#!/usr/bin/env bash
# Fails on the unfixed tree: each check names a capability the plural
# association needs and the base does not have.
cd /testbed
failed=0
grep -q 'func (issue \*Issue) LoadProjects' models/issues/issue_project.go 2>/dev/null   || { echo 'plural model gap: an issue exposes one project, not a set'; failed=1; }
grep -q 'ProjectColumnMap' models/issues/issue_project.go 2>/dev/null   || { echo 'column map gap: the issue column is not resolved per project'; failed=1; }
grep -q 'func DiffSlice' modules/util/util.go 2>/dev/null   || { echo 'wire shape gap: no set difference helper for reconciling project ids'; failed=1; }
grep -q 'ProjectIDs' modules/indexer/issues/internal/model.go 2>/dev/null   || { echo 'search gap: issue search filters by a single project id'; failed=1; }
exit $failed
