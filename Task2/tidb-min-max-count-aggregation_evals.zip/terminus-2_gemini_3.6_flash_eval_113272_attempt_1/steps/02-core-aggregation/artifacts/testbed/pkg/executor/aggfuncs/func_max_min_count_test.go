package aggfuncs_test

import (
"testing"

"github.com/pingcap/tidb/pkg/executor/aggfuncs"
"github.com/pingcap/tidb/pkg/expression"
"github.com/pingcap/tidb/pkg/expression/aggregation"
"github.com/pingcap/tidb/pkg/parser/ast"
"github.com/pingcap/tidb/pkg/parser/mysql"
"github.com/pingcap/tidb/pkg/types"
"github.com/pingcap/tidb/pkg/util/chunk"
"github.com/pingcap/tidb/pkg/util/mock"
"github.com/stretchr/testify/require"
)

func TestMaxCountMinCountBasic(t *testing.T) {
ctx := mock.NewContext()
sctx := ctx.GetEvalCtx()
col := &expression.Column{Index: 0, RetType: types.NewFieldType(mysql.TypeLonglong)}

for _, name := range []string{ast.AggFuncMaxCount, ast.AggFuncMinCount} {
desc, err := aggregation.NewAggFuncDesc(ctx, name, []expression.Expression{col}, false)
require.NoError(t, err)

af := aggfuncs.Build(ctx.GetExprCtx(), desc, 0)
require.NotNil(t, af)

// 1. All NULLs or empty
pr, _ := af.AllocPartialResult()
chk := chunk.NewChunkWithCapacity([]*types.FieldType{desc.RetTp}, 1)
err = af.AppendFinalResult2Chunk(sctx, pr, chk)
require.NoError(t, err)
require.Equal(t, int64(0), chk.GetRow(0).GetInt64(0))

// Reset
af.ResetPartialResult(pr)

// 2. Rows: 10, 20, 20, 5, 20
srcChk := chunk.NewChunkWithCapacity([]*types.FieldType{col.RetType}, 5)
srcChk.AppendInt64(0, 10)
srcChk.AppendInt64(0, 20)
srcChk.AppendInt64(0, 20)
srcChk.AppendInt64(0, 5)
srcChk.AppendInt64(0, 20)

rows := []chunk.Row{
srcChk.GetRow(0), srcChk.GetRow(1), srcChk.GetRow(2), srcChk.GetRow(3), srcChk.GetRow(4),
}
_, err = af.UpdatePartialResult(sctx, rows, pr)
require.NoError(t, err)

outChk := chunk.NewChunkWithCapacity([]*types.FieldType{desc.RetTp}, 1)
err = af.AppendFinalResult2Chunk(sctx, pr, outChk)
require.NoError(t, err)

if name == ast.AggFuncMaxCount {
require.Equal(t, int64(3), outChk.GetRow(0).GetInt64(0))
} else {
require.Equal(t, int64(1), outChk.GetRow(0).GetInt64(0))
}
}
}

func TestMaxCountMinCountNegativeAndTies(t *testing.T) {
ctx := mock.NewContext()
sctx := ctx.GetEvalCtx()
col := &expression.Column{Index: 0, RetType: types.NewFieldType(mysql.TypeLonglong)}

for _, name := range []string{ast.AggFuncMaxCount, ast.AggFuncMinCount} {
desc, err := aggregation.NewAggFuncDesc(ctx, name, []expression.Expression{col}, false)
require.NoError(t, err)

af := aggfuncs.Build(ctx.GetExprCtx(), desc, 0)

// Input: -10, -5, -5, -10, -10
srcChk := chunk.NewChunkWithCapacity([]*types.FieldType{col.RetType}, 5)
srcChk.AppendInt64(0, -10)
srcChk.AppendInt64(0, -5)
srcChk.AppendInt64(0, -5)
srcChk.AppendInt64(0, -10)
srcChk.AppendInt64(0, -10)

rows := []chunk.Row{
srcChk.GetRow(0), srcChk.GetRow(1), srcChk.GetRow(2), srcChk.GetRow(3), srcChk.GetRow(4),
}
pr, _ := af.AllocPartialResult()
_, err = af.UpdatePartialResult(sctx, rows, pr)
require.NoError(t, err)

outChk := chunk.NewChunkWithCapacity([]*types.FieldType{desc.RetTp}, 1)
err = af.AppendFinalResult2Chunk(sctx, pr, outChk)
require.NoError(t, err)

if name == ast.AggFuncMaxCount {
require.Equal(t, int64(2), outChk.GetRow(0).GetInt64(0))
} else {
require.Equal(t, int64(3), outChk.GetRow(0).GetInt64(0))
}
}
}

func TestMaxCountMinCountMergePartial(t *testing.T) {
ctx := mock.NewContext()
sctx := ctx.GetEvalCtx()
col := &expression.Column{Index: 0, RetType: types.NewFieldType(mysql.TypeLonglong)}

desc, err := aggregation.NewAggFuncDesc(ctx, ast.AggFuncMaxCount, []expression.Expression{col}, false)
require.NoError(t, err)
af := aggfuncs.Build(ctx.GetExprCtx(), desc, 0)

// Partial 1: 10, 20, 20
src1 := chunk.NewChunkWithCapacity([]*types.FieldType{col.RetType}, 3)
src1.AppendInt64(0, 10)
src1.AppendInt64(0, 20)
src1.AppendInt64(0, 20)

// Partial 2: 20, 20, 15
src2 := chunk.NewChunkWithCapacity([]*types.FieldType{col.RetType}, 3)
src2.AppendInt64(0, 20)
src2.AppendInt64(0, 20)
src2.AppendInt64(0, 15)

pr1, _ := af.AllocPartialResult()
pr2, _ := af.AllocPartialResult()

_, _ = af.UpdatePartialResult(sctx, []chunk.Row{src1.GetRow(0), src1.GetRow(1), src1.GetRow(2)}, pr1)
_, _ = af.UpdatePartialResult(sctx, []chunk.Row{src2.GetRow(0), src2.GetRow(1), src2.GetRow(2)}, pr2)

_, err = af.MergePartialResult(sctx, pr1, pr2)
require.NoError(t, err)

outChk := chunk.NewChunkWithCapacity([]*types.FieldType{desc.RetTp}, 1)
_ = af.AppendFinalResult2Chunk(sctx, pr2, outChk)
require.Equal(t, int64(4), outChk.GetRow(0).GetInt64(0))
}

func TestMaxCountMinCountSlidingWindow(t *testing.T) {
ctx := mock.NewContext()
sctx := ctx.GetEvalCtx()
col := &expression.Column{Index: 0, RetType: types.NewFieldType(mysql.TypeLonglong)}

for _, name := range []string{ast.AggFuncMaxCount, ast.AggFuncMinCount} {
desc, err := aggregation.NewAggFuncDesc(ctx, name, []expression.Expression{col}, false)
require.NoError(t, err)

af := aggfuncs.BuildWindowFunctions(ctx.GetExprCtx(), desc, 0, nil)
sliding, ok := af.(aggfuncs.SlidingWindowAggFunc)
require.True(t, ok)

if maxMinSliding, ok := af.(aggfuncs.MaxMinSlidingWindowAggFunc); ok {
maxMinSliding.SetWindowStart(0)
}

// Input sequence: 5, 3, 5, 2, 5, 4
srcChk := chunk.NewChunkWithCapacity([]*types.FieldType{col.RetType}, 6)
srcChk.AppendInt64(0, 5)
srcChk.AppendInt64(0, 3)
srcChk.AppendInt64(0, 5)
srcChk.AppendInt64(0, 2)
srcChk.AppendInt64(0, 5)
srcChk.AppendInt64(0, 4)

pr, _ := af.AllocPartialResult()
getRow := func(idx uint64) chunk.Row {
return srcChk.GetRow(int(idx))
}

// Initial window [0, 6)
_, err = af.UpdatePartialResult(sctx, []chunk.Row{
srcChk.GetRow(0), srcChk.GetRow(1), srcChk.GetRow(2), srcChk.GetRow(3), srcChk.GetRow(4), srcChk.GetRow(5),
}, pr)
require.NoError(t, err)

out1 := chunk.NewChunkWithCapacity([]*types.FieldType{desc.RetTp}, 1)
_ = af.AppendFinalResult2Chunk(sctx, pr, out1)

if name == ast.AggFuncMaxCount {
require.Equal(t, int64(3), out1.GetRow(0).GetInt64(0))
} else {
require.Equal(t, int64(1), out1.GetRow(0).GetInt64(0))
}

// Slide to [2, 6) -> evict 0, 1
err = sliding.Slide(sctx, getRow, 0, 6, 2, 0, pr)
require.NoError(t, err)

out2 := chunk.NewChunkWithCapacity([]*types.FieldType{desc.RetTp}, 1)
_ = af.AppendFinalResult2Chunk(sctx, pr, out2)

if name == ast.AggFuncMaxCount {
require.Equal(t, int64(2), out2.GetRow(0).GetInt64(0))
} else {
require.Equal(t, int64(1), out2.GetRow(0).GetInt64(0))
}

// Test reset and reuse for new partition
af.ResetPartialResult(pr)
if maxMinSliding, ok := af.(aggfuncs.MaxMinSlidingWindowAggFunc); ok {
maxMinSliding.SetWindowStart(0)
}
// New partition input: 7, 7, 7
p2Chk := chunk.NewChunkWithCapacity([]*types.FieldType{col.RetType}, 3)
p2Chk.AppendInt64(0, 7)
p2Chk.AppendInt64(0, 7)
p2Chk.AppendInt64(0, 7)

_, err = af.UpdatePartialResult(sctx, []chunk.Row{
p2Chk.GetRow(0), p2Chk.GetRow(1), p2Chk.GetRow(2),
}, pr)
require.NoError(t, err)

out3 := chunk.NewChunkWithCapacity([]*types.FieldType{desc.RetTp}, 1)
_ = af.AppendFinalResult2Chunk(sctx, pr, out3)
require.Equal(t, int64(3), out3.GetRow(0).GetInt64(0))
}
}

func TestMaxCountMinCountSpill(t *testing.T) {
ctx := mock.NewContext()
sctx := ctx.GetEvalCtx()
col := &expression.Column{Index: 0, RetType: types.NewFieldType(mysql.TypeLonglong)}

desc, err := aggregation.NewAggFuncDesc(ctx, ast.AggFuncMaxCount, []expression.Expression{col}, false)
require.NoError(t, err)
af := aggfuncs.Build(ctx.GetExprCtx(), desc, 0)

srcChk := chunk.NewChunkWithCapacity([]*types.FieldType{col.RetType}, 3)
srcChk.AppendInt64(0, 100)
srcChk.AppendInt64(0, 100)
srcChk.AppendInt64(0, 50)

pr, _ := af.AllocPartialResult()
_, _ = af.UpdatePartialResult(sctx, []chunk.Row{srcChk.GetRow(0), srcChk.GetRow(1), srcChk.GetRow(2)}, pr)

spillHelper := aggfuncs.NewSerializeHelper()
spillChk := chunk.NewChunkWithCapacity([]*types.FieldType{types.NewFieldType(mysql.TypeString)}, 1)
af.SerializePartialResult(pr, spillChk, spillHelper)

deserializedPRs, _ := af.DeserializePartialResult(spillChk)
require.Equal(t, 1, len(deserializedPRs))

outChk := chunk.NewChunkWithCapacity([]*types.FieldType{desc.RetTp}, 1)
_ = af.AppendFinalResult2Chunk(sctx, deserializedPRs[0], outChk)
require.Equal(t, int64(2), outChk.GetRow(0).GetInt64(0))
}
