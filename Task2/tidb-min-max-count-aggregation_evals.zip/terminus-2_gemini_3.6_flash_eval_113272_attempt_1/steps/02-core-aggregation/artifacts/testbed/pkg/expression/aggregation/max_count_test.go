package aggregation_test

import (
"testing"

"github.com/pingcap/tidb/pkg/expression"
"github.com/pingcap/tidb/pkg/expression/aggregation"
"github.com/pingcap/tidb/pkg/parser/ast"
"github.com/pingcap/tidb/pkg/parser/mysql"
"github.com/pingcap/tidb/pkg/types"
"github.com/pingcap/tidb/pkg/util/mock"
"github.com/stretchr/testify/require"
)

func TestMaxCountMinCountDesc(t *testing.T) {
ctx := mock.NewContext()
col := &expression.Column{Index: 0, RetType: types.NewFieldType(mysql.TypeLonglong)}

for _, name := range []string{ast.AggFuncMaxCount, ast.AggFuncMinCount} {
desc, err := aggregation.NewAggFuncDesc(ctx, name, []expression.Expression{col}, false)
require.NoError(t, err)
require.Equal(t, name, desc.Name)
require.Equal(t, mysql.TypeLonglong, desc.RetTp.GetType())
require.True(t, mysql.HasNotNullFlag(desc.RetTp.GetFlag()))

eval := desc.GetAggFunc(ctx)
require.NotNil(t, eval)
}
}
