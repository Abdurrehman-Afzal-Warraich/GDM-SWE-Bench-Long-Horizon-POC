// Copyright 2024 PingCAP, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package aggfuncs

import (
"unsafe"

"github.com/pingcap/tidb/pkg/types"
"github.com/pingcap/tidb/pkg/util/chunk"
"github.com/pingcap/tidb/pkg/util/collate"
)

const (
DefPartialResult4MaxMinCountIntSize           = int64(unsafe.Sizeof(partialResult4MaxMinCountInt{}))
DefPartialResult4MaxMinCountUintSize          = int64(unsafe.Sizeof(partialResult4MaxMinCountUint{}))
DefPartialResult4MaxMinCountDecimalSize       = int64(unsafe.Sizeof(partialResult4MaxMinCountDecimal{}))
DefPartialResult4MaxMinCountFloat32Size       = int64(unsafe.Sizeof(partialResult4MaxMinCountFloat32{}))
DefPartialResult4MaxMinCountFloat64Size       = int64(unsafe.Sizeof(partialResult4MaxMinCountFloat64{}))
DefPartialResult4MaxMinCountTimeSize          = int64(unsafe.Sizeof(partialResult4MaxMinCountTime{}))
DefPartialResult4MaxMinCountDurationSize      = int64(unsafe.Sizeof(partialResult4MaxMinCountDuration{}))
DefPartialResult4MaxMinCountStringSize        = int64(unsafe.Sizeof(partialResult4MaxMinCountString{}))
DefPartialResult4MaxMinCountJSONSize          = int64(unsafe.Sizeof(partialResult4MaxMinCountJSON{}))
DefPartialResult4MaxMinCountVectorFloat32Size = int64(unsafe.Sizeof(partialResult4MaxMinCountVectorFloat32{}))
DefPartialResult4MaxMinCountEnumSize          = int64(unsafe.Sizeof(partialResult4MaxMinCountEnum{}))
DefPartialResult4MaxMinCountSetSize           = int64(unsafe.Sizeof(partialResult4MaxMinCountSet{}))
)

func enqueueCount(d *MinMaxDeque, idx uint64, item any) {
for !d.IsEmpty() {
pair, _ := d.Back()
cmp := d.cmpFunc(item, pair.Item)
if (d.IsMax && cmp > 0) || (!d.IsMax && cmp < 0) {
_ = d.PopBack()
} else {
break
}
}
d.PushBack(idx, item)
}

type baseMaxMinCountAggFunc struct {
baseAggFunc
isMax    bool
collator collate.Collator
}

// ---------------------- Int ----------------------
type partialResult4MaxMinCountInt struct {
	val    int64
	cnt    int64
	isNull bool
	deque  *MinMaxDeque
}

type maxMinCount4Int struct {
	baseMaxMinCountAggFunc
}

func (*maxMinCount4Int) AllocPartialResult() (pr PartialResult, memDelta int64) {
	p := new(partialResult4MaxMinCountInt)
	p.isNull = true
	return PartialResult(p), DefPartialResult4MaxMinCountIntSize
}

func (*maxMinCount4Int) ResetPartialResult(pr PartialResult) {
	p := (*partialResult4MaxMinCountInt)(pr)
	p.val = 0
	p.cnt = 0
	p.isNull = true
	if p.deque != nil {
		p.deque.Reset()
	}
}

func (e *maxMinCount4Int) AppendFinalResult2Chunk(_ AggFuncUpdateContext, pr PartialResult, chk *chunk.Chunk) error {
	p := (*partialResult4MaxMinCountInt)(pr)
	if p.isNull {
		chk.AppendInt64(e.ordinal, 0)
		return nil
	}
	chk.AppendInt64(e.ordinal, p.cnt)
	return nil
}

func (e *maxMinCount4Int) UpdatePartialResult(sctx AggFuncUpdateContext, rowsInGroup []chunk.Row, pr PartialResult) (memDelta int64, err error) {
	p := (*partialResult4MaxMinCountInt)(pr)
	for _, row := range rowsInGroup {
		input, isNull, err := e.args[0].EvalInt(sctx, row)
		if err != nil {
			return 0, err
		}
		if isNull {
			continue
		}
		if p.isNull {
			p.val = input
			p.cnt = 1
			p.isNull = false
			continue
		}
		if input == p.val {
			p.cnt++
		} else if (e.isMax && (input > p.val)) || (!e.isMax && (input < p.val)) {
			p.val = input
			p.cnt = 1
		}
	}
	return 0, nil
}

func (e *maxMinCount4Int) MergePartialResult(_ AggFuncUpdateContext, src, dst PartialResult) (memDelta int64, err error) {
	p1, p2 := (*partialResult4MaxMinCountInt)(src), (*partialResult4MaxMinCountInt)(dst)
	if p1.isNull || p1.cnt == 0 {
		return 0, nil
	}
	if p2.isNull || p2.cnt == 0 {
		*p2 = *p1
		return 0, nil
	}
	if p1.val == p2.val {
		p2.cnt += p1.cnt
	} else if (e.isMax && (p1.val > p2.val)) || (!e.isMax && (p1.val < p2.val)) {
		p2.val = p1.val
		p2.cnt = p1.cnt
	}
	return 0, nil
}

func (e *maxMinCount4Int) SerializePartialResult(partialResult PartialResult, chk *chunk.Chunk, spillHelper *SerializeHelper) {
	pr := (*partialResult4MaxMinCountInt)(partialResult)
	resBuf := spillHelper.serializePartialResult4MaxMinCountInt(*pr)
	chk.AppendBytes(e.ordinal, resBuf)
}

func (e *maxMinCount4Int) DeserializePartialResult(src *chunk.Chunk) ([]PartialResult, int64) {
	return deserializePartialResultCommon(src, e.ordinal, e.deserializeForSpill)
}

func (e *maxMinCount4Int) deserializeForSpill(helper *deserializeHelper) (PartialResult, int64) {
	pr, memDelta := e.AllocPartialResult()
	result := (*partialResult4MaxMinCountInt)(pr)
	success := helper.deserializePartialResult4MaxMinCountInt(result)
	if !success {
		return nil, 0
	}
	return pr, memDelta
}

type maxMinCount4IntSliding struct {
	maxMinCount4Int
	windowInfo
}

func (e *maxMinCount4IntSliding) AllocPartialResult() (pr PartialResult, memDelta int64) {
	p, memDelta := e.maxMinCount4Int.AllocPartialResult()
	(*partialResult4MaxMinCountInt)(p).deque = NewDeque(e.isMax, func(i, j any) int {
		a, b := i.(int64), j.(int64)
		if a < b {
			return -1
		} else if a > b {
			return 1
		}
		return 0
	})
	return p, memDelta + DefMaxMinDequeSize
}

func (e *maxMinCount4IntSliding) ResetPartialResult(pr PartialResult) {
	e.maxMinCount4Int.ResetPartialResult(pr)
	(*partialResult4MaxMinCountInt)(pr).deque.Reset()
}

func (e *maxMinCount4IntSliding) updateResultFromDeque(p *partialResult4MaxMinCountInt) {
	if p.deque.IsEmpty() {
		p.isNull = true
		p.cnt = 0
		return
	}
	front, _ := p.deque.Front()
	p.val = front.Item.(int64)
	p.isNull = false
	cnt := int64(0)
	for _, pair := range p.deque.Items {
		a, b := pair.Item.(int64), p.val
		if a == b {
			cnt++
		} else {
			break
		}
	}
	p.cnt = cnt
}

func (e *maxMinCount4IntSliding) UpdatePartialResult(sctx AggFuncUpdateContext, rowsInGroup []chunk.Row, pr PartialResult) (memDelta int64, err error) {
	p := (*partialResult4MaxMinCountInt)(pr)
	for i, row := range rowsInGroup {
		input, isNull, err := e.args[0].EvalInt(sctx, row)
		if err != nil {
			return 0, err
		}
		if isNull {
			continue
		}
		enqueueCount(p.deque, uint64(i)+e.start, input)
	}
	e.updateResultFromDeque(p)
	return 0, nil
}

var _ SlidingWindowAggFunc = &maxMinCount4IntSliding{}

func (e *maxMinCount4IntSliding) Slide(sctx AggFuncUpdateContext, getRow func(uint64) chunk.Row, lastStart, lastEnd uint64, shiftStart, shiftEnd uint64, pr PartialResult) error {
	p := (*partialResult4MaxMinCountInt)(pr)
	for i := range shiftEnd {
		input, isNull, err := e.args[0].EvalInt(sctx, getRow(lastEnd+i))
		if err != nil {
			return err
		}
		if isNull {
			continue
		}
		enqueueCount(p.deque, lastEnd+i, input)
	}
	if lastStart+shiftStart >= 1 {
		_ = p.deque.Dequeue(lastStart + shiftStart - 1)
	}
	e.updateResultFromDeque(p)
	return nil
}


// ---------------------- Uint ----------------------
type partialResult4MaxMinCountUint struct {
	val    uint64
	cnt    int64
	isNull bool
	deque  *MinMaxDeque
}

type maxMinCount4Uint struct {
	baseMaxMinCountAggFunc
}

func (*maxMinCount4Uint) AllocPartialResult() (pr PartialResult, memDelta int64) {
	p := new(partialResult4MaxMinCountUint)
	p.isNull = true
	return PartialResult(p), DefPartialResult4MaxMinCountUintSize
}

func (*maxMinCount4Uint) ResetPartialResult(pr PartialResult) {
	p := (*partialResult4MaxMinCountUint)(pr)
	p.val = 0
	p.cnt = 0
	p.isNull = true
	if p.deque != nil {
		p.deque.Reset()
	}
}

func (e *maxMinCount4Uint) AppendFinalResult2Chunk(_ AggFuncUpdateContext, pr PartialResult, chk *chunk.Chunk) error {
	p := (*partialResult4MaxMinCountUint)(pr)
	if p.isNull {
		chk.AppendInt64(e.ordinal, 0)
		return nil
	}
	chk.AppendInt64(e.ordinal, p.cnt)
	return nil
}

func (e *maxMinCount4Uint) UpdatePartialResult(sctx AggFuncUpdateContext, rowsInGroup []chunk.Row, pr PartialResult) (memDelta int64, err error) {
	p := (*partialResult4MaxMinCountUint)(pr)
	for _, row := range rowsInGroup {
		input, isNull, err := e.args[0].EvalInt(sctx, row)
		if err != nil {
			return 0, err
		}
		if isNull {
			continue
		}
		uInput := uint64(input)
		if p.isNull {
			p.val = uint64(input)
			p.cnt = 1
			p.isNull = false
			continue
		}
		if uInput == p.val {
			p.cnt++
		} else if (e.isMax && (uInput > p.val)) || (!e.isMax && (uInput < p.val)) {
			p.val = uint64(input)
			p.cnt = 1
		}
	}
	return 0, nil
}

func (e *maxMinCount4Uint) MergePartialResult(_ AggFuncUpdateContext, src, dst PartialResult) (memDelta int64, err error) {
	p1, p2 := (*partialResult4MaxMinCountUint)(src), (*partialResult4MaxMinCountUint)(dst)
	if p1.isNull || p1.cnt == 0 {
		return 0, nil
	}
	if p2.isNull || p2.cnt == 0 {
		*p2 = *p1
		return 0, nil
	}
	if p1.val == p2.val {
		p2.cnt += p1.cnt
	} else if (e.isMax && (p1.val > p2.val)) || (!e.isMax && (p1.val < p2.val)) {
		p2.val = p1.val
		p2.cnt = p1.cnt
	}
	return 0, nil
}

func (e *maxMinCount4Uint) SerializePartialResult(partialResult PartialResult, chk *chunk.Chunk, spillHelper *SerializeHelper) {
	pr := (*partialResult4MaxMinCountUint)(partialResult)
	resBuf := spillHelper.serializePartialResult4MaxMinCountUint(*pr)
	chk.AppendBytes(e.ordinal, resBuf)
}

func (e *maxMinCount4Uint) DeserializePartialResult(src *chunk.Chunk) ([]PartialResult, int64) {
	return deserializePartialResultCommon(src, e.ordinal, e.deserializeForSpill)
}

func (e *maxMinCount4Uint) deserializeForSpill(helper *deserializeHelper) (PartialResult, int64) {
	pr, memDelta := e.AllocPartialResult()
	result := (*partialResult4MaxMinCountUint)(pr)
	success := helper.deserializePartialResult4MaxMinCountUint(result)
	if !success {
		return nil, 0
	}
	return pr, memDelta
}

type maxMinCount4UintSliding struct {
	maxMinCount4Uint
	windowInfo
}

func (e *maxMinCount4UintSliding) AllocPartialResult() (pr PartialResult, memDelta int64) {
	p, memDelta := e.maxMinCount4Uint.AllocPartialResult()
	(*partialResult4MaxMinCountUint)(p).deque = NewDeque(e.isMax, func(i, j any) int {
		a, b := i.(uint64), j.(uint64)
		if a < b {
			return -1
		} else if a > b {
			return 1
		}
		return 0
	})
	return p, memDelta + DefMaxMinDequeSize
}

func (e *maxMinCount4UintSliding) ResetPartialResult(pr PartialResult) {
	e.maxMinCount4Uint.ResetPartialResult(pr)
	(*partialResult4MaxMinCountUint)(pr).deque.Reset()
}

func (e *maxMinCount4UintSliding) updateResultFromDeque(p *partialResult4MaxMinCountUint) {
	if p.deque.IsEmpty() {
		p.isNull = true
		p.cnt = 0
		return
	}
	front, _ := p.deque.Front()
	p.val = front.Item.(uint64)
	p.isNull = false
	cnt := int64(0)
	for _, pair := range p.deque.Items {
		a, b := pair.Item.(uint64), p.val
		if a == b {
			cnt++
		} else {
			break
		}
	}
	p.cnt = cnt
}

func (e *maxMinCount4UintSliding) UpdatePartialResult(sctx AggFuncUpdateContext, rowsInGroup []chunk.Row, pr PartialResult) (memDelta int64, err error) {
	p := (*partialResult4MaxMinCountUint)(pr)
	for i, row := range rowsInGroup {
		input, isNull, err := e.args[0].EvalInt(sctx, row)
		if err != nil {
			return 0, err
		}
		if isNull {
			continue
		}
		enqueueCount(p.deque, uint64(i)+e.start, uint64(input))
	}
	e.updateResultFromDeque(p)
	return 0, nil
}

var _ SlidingWindowAggFunc = &maxMinCount4UintSliding{}

func (e *maxMinCount4UintSliding) Slide(sctx AggFuncUpdateContext, getRow func(uint64) chunk.Row, lastStart, lastEnd uint64, shiftStart, shiftEnd uint64, pr PartialResult) error {
	p := (*partialResult4MaxMinCountUint)(pr)
	for i := range shiftEnd {
		input, isNull, err := e.args[0].EvalInt(sctx, getRow(lastEnd+i))
		if err != nil {
			return err
		}
		if isNull {
			continue
		}
		enqueueCount(p.deque, lastEnd+i, uint64(input))
	}
	if lastStart+shiftStart >= 1 {
		_ = p.deque.Dequeue(lastStart + shiftStart - 1)
	}
	e.updateResultFromDeque(p)
	return nil
}


// ---------------------- Float32 ----------------------
type partialResult4MaxMinCountFloat32 struct {
	val    float32
	cnt    int64
	isNull bool
	deque  *MinMaxDeque
}

type maxMinCount4Float32 struct {
	baseMaxMinCountAggFunc
}

func (*maxMinCount4Float32) AllocPartialResult() (pr PartialResult, memDelta int64) {
	p := new(partialResult4MaxMinCountFloat32)
	p.isNull = true
	return PartialResult(p), DefPartialResult4MaxMinCountFloat32Size
}

func (*maxMinCount4Float32) ResetPartialResult(pr PartialResult) {
	p := (*partialResult4MaxMinCountFloat32)(pr)
	p.val = 0
	p.cnt = 0
	p.isNull = true
	if p.deque != nil {
		p.deque.Reset()
	}
}

func (e *maxMinCount4Float32) AppendFinalResult2Chunk(_ AggFuncUpdateContext, pr PartialResult, chk *chunk.Chunk) error {
	p := (*partialResult4MaxMinCountFloat32)(pr)
	if p.isNull {
		chk.AppendInt64(e.ordinal, 0)
		return nil
	}
	chk.AppendInt64(e.ordinal, p.cnt)
	return nil
}

func (e *maxMinCount4Float32) UpdatePartialResult(sctx AggFuncUpdateContext, rowsInGroup []chunk.Row, pr PartialResult) (memDelta int64, err error) {
	p := (*partialResult4MaxMinCountFloat32)(pr)
	for _, row := range rowsInGroup {
		input, isNull, err := e.args[0].EvalReal(sctx, row)
		if err != nil {
			return 0, err
		}
		if isNull {
			continue
		}
		fInput := float32(input)
		if p.isNull {
			p.val = float32(input)
			p.cnt = 1
			p.isNull = false
			continue
		}
		if fInput == p.val {
			p.cnt++
		} else if (e.isMax && (fInput > p.val)) || (!e.isMax && (fInput < p.val)) {
			p.val = float32(input)
			p.cnt = 1
		}
	}
	return 0, nil
}

func (e *maxMinCount4Float32) MergePartialResult(_ AggFuncUpdateContext, src, dst PartialResult) (memDelta int64, err error) {
	p1, p2 := (*partialResult4MaxMinCountFloat32)(src), (*partialResult4MaxMinCountFloat32)(dst)
	if p1.isNull || p1.cnt == 0 {
		return 0, nil
	}
	if p2.isNull || p2.cnt == 0 {
		*p2 = *p1
		return 0, nil
	}
	if p1.val == p2.val {
		p2.cnt += p1.cnt
	} else if (e.isMax && (p1.val > p2.val)) || (!e.isMax && (p1.val < p2.val)) {
		p2.val = p1.val
		p2.cnt = p1.cnt
	}
	return 0, nil
}

func (e *maxMinCount4Float32) SerializePartialResult(partialResult PartialResult, chk *chunk.Chunk, spillHelper *SerializeHelper) {
	pr := (*partialResult4MaxMinCountFloat32)(partialResult)
	resBuf := spillHelper.serializePartialResult4MaxMinCountFloat32(*pr)
	chk.AppendBytes(e.ordinal, resBuf)
}

func (e *maxMinCount4Float32) DeserializePartialResult(src *chunk.Chunk) ([]PartialResult, int64) {
	return deserializePartialResultCommon(src, e.ordinal, e.deserializeForSpill)
}

func (e *maxMinCount4Float32) deserializeForSpill(helper *deserializeHelper) (PartialResult, int64) {
	pr, memDelta := e.AllocPartialResult()
	result := (*partialResult4MaxMinCountFloat32)(pr)
	success := helper.deserializePartialResult4MaxMinCountFloat32(result)
	if !success {
		return nil, 0
	}
	return pr, memDelta
}

type maxMinCount4Float32Sliding struct {
	maxMinCount4Float32
	windowInfo
}

func (e *maxMinCount4Float32Sliding) AllocPartialResult() (pr PartialResult, memDelta int64) {
	p, memDelta := e.maxMinCount4Float32.AllocPartialResult()
	(*partialResult4MaxMinCountFloat32)(p).deque = NewDeque(e.isMax, func(i, j any) int {
		a, b := i.(float32), j.(float32)
		if a < b {
			return -1
		} else if a > b {
			return 1
		}
		return 0
	})
	return p, memDelta + DefMaxMinDequeSize
}

func (e *maxMinCount4Float32Sliding) ResetPartialResult(pr PartialResult) {
	e.maxMinCount4Float32.ResetPartialResult(pr)
	(*partialResult4MaxMinCountFloat32)(pr).deque.Reset()
}

func (e *maxMinCount4Float32Sliding) updateResultFromDeque(p *partialResult4MaxMinCountFloat32) {
	if p.deque.IsEmpty() {
		p.isNull = true
		p.cnt = 0
		return
	}
	front, _ := p.deque.Front()
	p.val = front.Item.(float32)
	p.isNull = false
	cnt := int64(0)
	for _, pair := range p.deque.Items {
		a, b := pair.Item.(float32), p.val
		if a == b {
			cnt++
		} else {
			break
		}
	}
	p.cnt = cnt
}

func (e *maxMinCount4Float32Sliding) UpdatePartialResult(sctx AggFuncUpdateContext, rowsInGroup []chunk.Row, pr PartialResult) (memDelta int64, err error) {
	p := (*partialResult4MaxMinCountFloat32)(pr)
	for i, row := range rowsInGroup {
		input, isNull, err := e.args[0].EvalReal(sctx, row)
		if err != nil {
			return 0, err
		}
		if isNull {
			continue
		}
		enqueueCount(p.deque, uint64(i)+e.start, float32(input))
	}
	e.updateResultFromDeque(p)
	return 0, nil
}

var _ SlidingWindowAggFunc = &maxMinCount4Float32Sliding{}

func (e *maxMinCount4Float32Sliding) Slide(sctx AggFuncUpdateContext, getRow func(uint64) chunk.Row, lastStart, lastEnd uint64, shiftStart, shiftEnd uint64, pr PartialResult) error {
	p := (*partialResult4MaxMinCountFloat32)(pr)
	for i := range shiftEnd {
		input, isNull, err := e.args[0].EvalReal(sctx, getRow(lastEnd+i))
		if err != nil {
			return err
		}
		if isNull {
			continue
		}
		enqueueCount(p.deque, lastEnd+i, float32(input))
	}
	if lastStart+shiftStart >= 1 {
		_ = p.deque.Dequeue(lastStart + shiftStart - 1)
	}
	e.updateResultFromDeque(p)
	return nil
}


// ---------------------- Float64 ----------------------
type partialResult4MaxMinCountFloat64 struct {
	val    float64
	cnt    int64
	isNull bool
	deque  *MinMaxDeque
}

type maxMinCount4Float64 struct {
	baseMaxMinCountAggFunc
}

func (*maxMinCount4Float64) AllocPartialResult() (pr PartialResult, memDelta int64) {
	p := new(partialResult4MaxMinCountFloat64)
	p.isNull = true
	return PartialResult(p), DefPartialResult4MaxMinCountFloat64Size
}

func (*maxMinCount4Float64) ResetPartialResult(pr PartialResult) {
	p := (*partialResult4MaxMinCountFloat64)(pr)
	p.val = 0
	p.cnt = 0
	p.isNull = true
	if p.deque != nil {
		p.deque.Reset()
	}
}

func (e *maxMinCount4Float64) AppendFinalResult2Chunk(_ AggFuncUpdateContext, pr PartialResult, chk *chunk.Chunk) error {
	p := (*partialResult4MaxMinCountFloat64)(pr)
	if p.isNull {
		chk.AppendInt64(e.ordinal, 0)
		return nil
	}
	chk.AppendInt64(e.ordinal, p.cnt)
	return nil
}

func (e *maxMinCount4Float64) UpdatePartialResult(sctx AggFuncUpdateContext, rowsInGroup []chunk.Row, pr PartialResult) (memDelta int64, err error) {
	p := (*partialResult4MaxMinCountFloat64)(pr)
	for _, row := range rowsInGroup {
		input, isNull, err := e.args[0].EvalReal(sctx, row)
		if err != nil {
			return 0, err
		}
		if isNull {
			continue
		}
		if p.isNull {
			p.val = input
			p.cnt = 1
			p.isNull = false
			continue
		}
		if input == p.val {
			p.cnt++
		} else if (e.isMax && (input > p.val)) || (!e.isMax && (input < p.val)) {
			p.val = input
			p.cnt = 1
		}
	}
	return 0, nil
}

func (e *maxMinCount4Float64) MergePartialResult(_ AggFuncUpdateContext, src, dst PartialResult) (memDelta int64, err error) {
	p1, p2 := (*partialResult4MaxMinCountFloat64)(src), (*partialResult4MaxMinCountFloat64)(dst)
	if p1.isNull || p1.cnt == 0 {
		return 0, nil
	}
	if p2.isNull || p2.cnt == 0 {
		*p2 = *p1
		return 0, nil
	}
	if p1.val == p2.val {
		p2.cnt += p1.cnt
	} else if (e.isMax && (p1.val > p2.val)) || (!e.isMax && (p1.val < p2.val)) {
		p2.val = p1.val
		p2.cnt = p1.cnt
	}
	return 0, nil
}

func (e *maxMinCount4Float64) SerializePartialResult(partialResult PartialResult, chk *chunk.Chunk, spillHelper *SerializeHelper) {
	pr := (*partialResult4MaxMinCountFloat64)(partialResult)
	resBuf := spillHelper.serializePartialResult4MaxMinCountFloat64(*pr)
	chk.AppendBytes(e.ordinal, resBuf)
}

func (e *maxMinCount4Float64) DeserializePartialResult(src *chunk.Chunk) ([]PartialResult, int64) {
	return deserializePartialResultCommon(src, e.ordinal, e.deserializeForSpill)
}

func (e *maxMinCount4Float64) deserializeForSpill(helper *deserializeHelper) (PartialResult, int64) {
	pr, memDelta := e.AllocPartialResult()
	result := (*partialResult4MaxMinCountFloat64)(pr)
	success := helper.deserializePartialResult4MaxMinCountFloat64(result)
	if !success {
		return nil, 0
	}
	return pr, memDelta
}

type maxMinCount4Float64Sliding struct {
	maxMinCount4Float64
	windowInfo
}

func (e *maxMinCount4Float64Sliding) AllocPartialResult() (pr PartialResult, memDelta int64) {
	p, memDelta := e.maxMinCount4Float64.AllocPartialResult()
	(*partialResult4MaxMinCountFloat64)(p).deque = NewDeque(e.isMax, func(i, j any) int {
		a, b := i.(float64), j.(float64)
		if a < b {
			return -1
		} else if a > b {
			return 1
		}
		return 0
	})
	return p, memDelta + DefMaxMinDequeSize
}

func (e *maxMinCount4Float64Sliding) ResetPartialResult(pr PartialResult) {
	e.maxMinCount4Float64.ResetPartialResult(pr)
	(*partialResult4MaxMinCountFloat64)(pr).deque.Reset()
}

func (e *maxMinCount4Float64Sliding) updateResultFromDeque(p *partialResult4MaxMinCountFloat64) {
	if p.deque.IsEmpty() {
		p.isNull = true
		p.cnt = 0
		return
	}
	front, _ := p.deque.Front()
	p.val = front.Item.(float64)
	p.isNull = false
	cnt := int64(0)
	for _, pair := range p.deque.Items {
		a, b := pair.Item.(float64), p.val
		if a == b {
			cnt++
		} else {
			break
		}
	}
	p.cnt = cnt
}

func (e *maxMinCount4Float64Sliding) UpdatePartialResult(sctx AggFuncUpdateContext, rowsInGroup []chunk.Row, pr PartialResult) (memDelta int64, err error) {
	p := (*partialResult4MaxMinCountFloat64)(pr)
	for i, row := range rowsInGroup {
		input, isNull, err := e.args[0].EvalReal(sctx, row)
		if err != nil {
			return 0, err
		}
		if isNull {
			continue
		}
		enqueueCount(p.deque, uint64(i)+e.start, input)
	}
	e.updateResultFromDeque(p)
	return 0, nil
}

var _ SlidingWindowAggFunc = &maxMinCount4Float64Sliding{}

func (e *maxMinCount4Float64Sliding) Slide(sctx AggFuncUpdateContext, getRow func(uint64) chunk.Row, lastStart, lastEnd uint64, shiftStart, shiftEnd uint64, pr PartialResult) error {
	p := (*partialResult4MaxMinCountFloat64)(pr)
	for i := range shiftEnd {
		input, isNull, err := e.args[0].EvalReal(sctx, getRow(lastEnd+i))
		if err != nil {
			return err
		}
		if isNull {
			continue
		}
		enqueueCount(p.deque, lastEnd+i, input)
	}
	if lastStart+shiftStart >= 1 {
		_ = p.deque.Dequeue(lastStart + shiftStart - 1)
	}
	e.updateResultFromDeque(p)
	return nil
}


// ---------------------- Decimal ----------------------
type partialResult4MaxMinCountDecimal struct {
	val    types.MyDecimal
	cnt    int64
	isNull bool
	deque  *MinMaxDeque
}

type maxMinCount4Decimal struct {
	baseMaxMinCountAggFunc
}

func (*maxMinCount4Decimal) AllocPartialResult() (pr PartialResult, memDelta int64) {
	p := new(partialResult4MaxMinCountDecimal)
	p.isNull = true
	return PartialResult(p), DefPartialResult4MaxMinCountDecimalSize
}

func (*maxMinCount4Decimal) ResetPartialResult(pr PartialResult) {
	p := (*partialResult4MaxMinCountDecimal)(pr)
	p.val = types.MyDecimal{}
	p.cnt = 0
	p.isNull = true
	if p.deque != nil {
		p.deque.Reset()
	}
}

func (e *maxMinCount4Decimal) AppendFinalResult2Chunk(_ AggFuncUpdateContext, pr PartialResult, chk *chunk.Chunk) error {
	p := (*partialResult4MaxMinCountDecimal)(pr)
	if p.isNull {
		chk.AppendInt64(e.ordinal, 0)
		return nil
	}
	chk.AppendInt64(e.ordinal, p.cnt)
	return nil
}

func (e *maxMinCount4Decimal) UpdatePartialResult(sctx AggFuncUpdateContext, rowsInGroup []chunk.Row, pr PartialResult) (memDelta int64, err error) {
	p := (*partialResult4MaxMinCountDecimal)(pr)
	for _, row := range rowsInGroup {
		input, isNull, err := e.args[0].EvalDecimal(sctx, row)
		if err != nil {
			return 0, err
		}
		if isNull {
			continue
		}
		if p.isNull {
			p.val = *input
			p.cnt = 1
			p.isNull = false
			continue
		}
		if input.Compare(&p.val) == 0 {
			p.cnt++
		} else if (e.isMax && (input.Compare(&p.val) > 0)) || (!e.isMax && (input.Compare(&p.val) < 0)) {
			p.val = *input
			p.cnt = 1
		}
	}
	return 0, nil
}

func (e *maxMinCount4Decimal) MergePartialResult(_ AggFuncUpdateContext, src, dst PartialResult) (memDelta int64, err error) {
	p1, p2 := (*partialResult4MaxMinCountDecimal)(src), (*partialResult4MaxMinCountDecimal)(dst)
	if p1.isNull || p1.cnt == 0 {
		return 0, nil
	}
	if p2.isNull || p2.cnt == 0 {
		*p2 = *p1
		return 0, nil
	}
	if p1.val.Compare(&p2.val) == 0 {
		p2.cnt += p1.cnt
	} else if (e.isMax && (p1.val.Compare(&p2.val) > 0)) || (!e.isMax && (p1.val.Compare(&p2.val) < 0)) {
		p2.val = p1.val
		p2.cnt = p1.cnt
	}
	return 0, nil
}

func (e *maxMinCount4Decimal) SerializePartialResult(partialResult PartialResult, chk *chunk.Chunk, spillHelper *SerializeHelper) {
	pr := (*partialResult4MaxMinCountDecimal)(partialResult)
	resBuf := spillHelper.serializePartialResult4MaxMinCountDecimal(*pr)
	chk.AppendBytes(e.ordinal, resBuf)
}

func (e *maxMinCount4Decimal) DeserializePartialResult(src *chunk.Chunk) ([]PartialResult, int64) {
	return deserializePartialResultCommon(src, e.ordinal, e.deserializeForSpill)
}

func (e *maxMinCount4Decimal) deserializeForSpill(helper *deserializeHelper) (PartialResult, int64) {
	pr, memDelta := e.AllocPartialResult()
	result := (*partialResult4MaxMinCountDecimal)(pr)
	success := helper.deserializePartialResult4MaxMinCountDecimal(result)
	if !success {
		return nil, 0
	}
	return pr, memDelta
}

type maxMinCount4DecimalSliding struct {
	maxMinCount4Decimal
	windowInfo
}

func (e *maxMinCount4DecimalSliding) AllocPartialResult() (pr PartialResult, memDelta int64) {
	p, memDelta := e.maxMinCount4Decimal.AllocPartialResult()
	(*partialResult4MaxMinCountDecimal)(p).deque = NewDeque(e.isMax, func(i, j any) int {
		a, b := i.(types.MyDecimal), j.(types.MyDecimal)
		if a.Compare(&b) < 0 {
			return -1
		} else if a.Compare(&b) > 0 {
			return 1
		}
		return 0
	})
	return p, memDelta + DefMaxMinDequeSize
}

func (e *maxMinCount4DecimalSliding) ResetPartialResult(pr PartialResult) {
	e.maxMinCount4Decimal.ResetPartialResult(pr)
	(*partialResult4MaxMinCountDecimal)(pr).deque.Reset()
}

func (e *maxMinCount4DecimalSliding) updateResultFromDeque(p *partialResult4MaxMinCountDecimal) {
	if p.deque.IsEmpty() {
		p.isNull = true
		p.cnt = 0
		return
	}
	front, _ := p.deque.Front()
	p.val = front.Item.(types.MyDecimal)
	p.isNull = false
	cnt := int64(0)
	for _, pair := range p.deque.Items {
		a, b := pair.Item.(types.MyDecimal), p.val
		if a.Compare(&b) == 0 {
			cnt++
		} else {
			break
		}
	}
	p.cnt = cnt
}

func (e *maxMinCount4DecimalSliding) UpdatePartialResult(sctx AggFuncUpdateContext, rowsInGroup []chunk.Row, pr PartialResult) (memDelta int64, err error) {
	p := (*partialResult4MaxMinCountDecimal)(pr)
	for i, row := range rowsInGroup {
		input, isNull, err := e.args[0].EvalDecimal(sctx, row)
		if err != nil {
			return 0, err
		}
		if isNull {
			continue
		}
		enqueueCount(p.deque, uint64(i)+e.start, *input)
	}
	e.updateResultFromDeque(p)
	return 0, nil
}

var _ SlidingWindowAggFunc = &maxMinCount4DecimalSliding{}

func (e *maxMinCount4DecimalSliding) Slide(sctx AggFuncUpdateContext, getRow func(uint64) chunk.Row, lastStart, lastEnd uint64, shiftStart, shiftEnd uint64, pr PartialResult) error {
	p := (*partialResult4MaxMinCountDecimal)(pr)
	for i := range shiftEnd {
		input, isNull, err := e.args[0].EvalDecimal(sctx, getRow(lastEnd+i))
		if err != nil {
			return err
		}
		if isNull {
			continue
		}
		enqueueCount(p.deque, lastEnd+i, *input)
	}
	if lastStart+shiftStart >= 1 {
		_ = p.deque.Dequeue(lastStart + shiftStart - 1)
	}
	e.updateResultFromDeque(p)
	return nil
}


// ---------------------- String ----------------------
type partialResult4MaxMinCountString struct {
	val    string
	cnt    int64
	isNull bool
	deque  *MinMaxDeque
}

type maxMinCount4String struct {
	baseMaxMinCountAggFunc
}

func (*maxMinCount4String) AllocPartialResult() (pr PartialResult, memDelta int64) {
	p := new(partialResult4MaxMinCountString)
	p.isNull = true
	return PartialResult(p), DefPartialResult4MaxMinCountStringSize
}

func (*maxMinCount4String) ResetPartialResult(pr PartialResult) {
	p := (*partialResult4MaxMinCountString)(pr)
	p.val = ""
	p.cnt = 0
	p.isNull = true
	if p.deque != nil {
		p.deque.Reset()
	}
}

func (e *maxMinCount4String) AppendFinalResult2Chunk(_ AggFuncUpdateContext, pr PartialResult, chk *chunk.Chunk) error {
	p := (*partialResult4MaxMinCountString)(pr)
	if p.isNull {
		chk.AppendInt64(e.ordinal, 0)
		return nil
	}
	chk.AppendInt64(e.ordinal, p.cnt)
	return nil
}

func (e *maxMinCount4String) UpdatePartialResult(sctx AggFuncUpdateContext, rowsInGroup []chunk.Row, pr PartialResult) (memDelta int64, err error) {
	p := (*partialResult4MaxMinCountString)(pr)
	for _, row := range rowsInGroup {
		input, isNull, err := e.args[0].EvalString(sctx, row)
		if err != nil {
			return 0, err
		}
		if isNull {
			continue
		}
		if p.isNull {
			p.val = input
			p.cnt = 1
			p.isNull = false
			continue
		}
		if e.collator.Compare(input, p.val) == 0 {
			p.cnt++
		} else if (e.isMax && (e.collator.Compare(input, p.val) > 0)) || (!e.isMax && (e.collator.Compare(input, p.val) < 0)) {
			p.val = input
			p.cnt = 1
		}
	}
	return 0, nil
}

func (e *maxMinCount4String) MergePartialResult(_ AggFuncUpdateContext, src, dst PartialResult) (memDelta int64, err error) {
	p1, p2 := (*partialResult4MaxMinCountString)(src), (*partialResult4MaxMinCountString)(dst)
	if p1.isNull || p1.cnt == 0 {
		return 0, nil
	}
	if p2.isNull || p2.cnt == 0 {
		*p2 = *p1
		return 0, nil
	}
	if e.collator.Compare(p1.val, p2.val) == 0 {
		p2.cnt += p1.cnt
	} else if (e.isMax && (e.collator.Compare(p1.val, p2.val) > 0)) || (!e.isMax && (e.collator.Compare(p1.val, p2.val) < 0)) {
		p2.val = p1.val
		p2.cnt = p1.cnt
	}
	return 0, nil
}

func (e *maxMinCount4String) SerializePartialResult(partialResult PartialResult, chk *chunk.Chunk, spillHelper *SerializeHelper) {
	pr := (*partialResult4MaxMinCountString)(partialResult)
	resBuf := spillHelper.serializePartialResult4MaxMinCountString(*pr)
	chk.AppendBytes(e.ordinal, resBuf)
}

func (e *maxMinCount4String) DeserializePartialResult(src *chunk.Chunk) ([]PartialResult, int64) {
	return deserializePartialResultCommon(src, e.ordinal, e.deserializeForSpill)
}

func (e *maxMinCount4String) deserializeForSpill(helper *deserializeHelper) (PartialResult, int64) {
	pr, memDelta := e.AllocPartialResult()
	result := (*partialResult4MaxMinCountString)(pr)
	success := helper.deserializePartialResult4MaxMinCountString(result)
	if !success {
		return nil, 0
	}
	return pr, memDelta
}

type maxMinCount4StringSliding struct {
	maxMinCount4String
	windowInfo
}

func (e *maxMinCount4StringSliding) AllocPartialResult() (pr PartialResult, memDelta int64) {
	p, memDelta := e.maxMinCount4String.AllocPartialResult()
	(*partialResult4MaxMinCountString)(p).deque = NewDeque(e.isMax, func(i, j any) int {
		a, b := i.(string), j.(string)
		if e.collator.Compare(a, b) < 0 {
			return -1
		} else if e.collator.Compare(a, b) > 0 {
			return 1
		}
		return 0
	})
	return p, memDelta + DefMaxMinDequeSize
}

func (e *maxMinCount4StringSliding) ResetPartialResult(pr PartialResult) {
	e.maxMinCount4String.ResetPartialResult(pr)
	(*partialResult4MaxMinCountString)(pr).deque.Reset()
}

func (e *maxMinCount4StringSliding) updateResultFromDeque(p *partialResult4MaxMinCountString) {
	if p.deque.IsEmpty() {
		p.isNull = true
		p.cnt = 0
		return
	}
	front, _ := p.deque.Front()
	p.val = front.Item.(string)
	p.isNull = false
	cnt := int64(0)
	for _, pair := range p.deque.Items {
		a, b := pair.Item.(string), p.val
		if e.collator.Compare(a, b) == 0 {
			cnt++
		} else {
			break
		}
	}
	p.cnt = cnt
}

func (e *maxMinCount4StringSliding) UpdatePartialResult(sctx AggFuncUpdateContext, rowsInGroup []chunk.Row, pr PartialResult) (memDelta int64, err error) {
	p := (*partialResult4MaxMinCountString)(pr)
	for i, row := range rowsInGroup {
		input, isNull, err := e.args[0].EvalString(sctx, row)
		if err != nil {
			return 0, err
		}
		if isNull {
			continue
		}
		enqueueCount(p.deque, uint64(i)+e.start, input)
	}
	e.updateResultFromDeque(p)
	return 0, nil
}

var _ SlidingWindowAggFunc = &maxMinCount4StringSliding{}

func (e *maxMinCount4StringSliding) Slide(sctx AggFuncUpdateContext, getRow func(uint64) chunk.Row, lastStart, lastEnd uint64, shiftStart, shiftEnd uint64, pr PartialResult) error {
	p := (*partialResult4MaxMinCountString)(pr)
	for i := range shiftEnd {
		input, isNull, err := e.args[0].EvalString(sctx, getRow(lastEnd+i))
		if err != nil {
			return err
		}
		if isNull {
			continue
		}
		enqueueCount(p.deque, lastEnd+i, input)
	}
	if lastStart+shiftStart >= 1 {
		_ = p.deque.Dequeue(lastStart + shiftStart - 1)
	}
	e.updateResultFromDeque(p)
	return nil
}


// ---------------------- Time ----------------------
type partialResult4MaxMinCountTime struct {
	val    types.Time
	cnt    int64
	isNull bool
	deque  *MinMaxDeque
}

type maxMinCount4Time struct {
	baseMaxMinCountAggFunc
}

func (*maxMinCount4Time) AllocPartialResult() (pr PartialResult, memDelta int64) {
	p := new(partialResult4MaxMinCountTime)
	p.isNull = true
	return PartialResult(p), DefPartialResult4MaxMinCountTimeSize
}

func (*maxMinCount4Time) ResetPartialResult(pr PartialResult) {
	p := (*partialResult4MaxMinCountTime)(pr)
	p.val = types.Time{}
	p.cnt = 0
	p.isNull = true
	if p.deque != nil {
		p.deque.Reset()
	}
}

func (e *maxMinCount4Time) AppendFinalResult2Chunk(_ AggFuncUpdateContext, pr PartialResult, chk *chunk.Chunk) error {
	p := (*partialResult4MaxMinCountTime)(pr)
	if p.isNull {
		chk.AppendInt64(e.ordinal, 0)
		return nil
	}
	chk.AppendInt64(e.ordinal, p.cnt)
	return nil
}

func (e *maxMinCount4Time) UpdatePartialResult(sctx AggFuncUpdateContext, rowsInGroup []chunk.Row, pr PartialResult) (memDelta int64, err error) {
	p := (*partialResult4MaxMinCountTime)(pr)
	for _, row := range rowsInGroup {
		input, isNull, err := e.args[0].EvalTime(sctx, row)
		if err != nil {
			return 0, err
		}
		if isNull {
			continue
		}
		if p.isNull {
			p.val = input
			p.cnt = 1
			p.isNull = false
			continue
		}
		if input.Compare(p.val) == 0 {
			p.cnt++
		} else if (e.isMax && (input.Compare(p.val) > 0)) || (!e.isMax && (input.Compare(p.val) < 0)) {
			p.val = input
			p.cnt = 1
		}
	}
	return 0, nil
}

func (e *maxMinCount4Time) MergePartialResult(_ AggFuncUpdateContext, src, dst PartialResult) (memDelta int64, err error) {
	p1, p2 := (*partialResult4MaxMinCountTime)(src), (*partialResult4MaxMinCountTime)(dst)
	if p1.isNull || p1.cnt == 0 {
		return 0, nil
	}
	if p2.isNull || p2.cnt == 0 {
		*p2 = *p1
		return 0, nil
	}
	if p1.val.Compare(p2.val) == 0 {
		p2.cnt += p1.cnt
	} else if (e.isMax && (p1.val.Compare(p2.val) > 0)) || (!e.isMax && (p1.val.Compare(p2.val) < 0)) {
		p2.val = p1.val
		p2.cnt = p1.cnt
	}
	return 0, nil
}

func (e *maxMinCount4Time) SerializePartialResult(partialResult PartialResult, chk *chunk.Chunk, spillHelper *SerializeHelper) {
	pr := (*partialResult4MaxMinCountTime)(partialResult)
	resBuf := spillHelper.serializePartialResult4MaxMinCountTime(*pr)
	chk.AppendBytes(e.ordinal, resBuf)
}

func (e *maxMinCount4Time) DeserializePartialResult(src *chunk.Chunk) ([]PartialResult, int64) {
	return deserializePartialResultCommon(src, e.ordinal, e.deserializeForSpill)
}

func (e *maxMinCount4Time) deserializeForSpill(helper *deserializeHelper) (PartialResult, int64) {
	pr, memDelta := e.AllocPartialResult()
	result := (*partialResult4MaxMinCountTime)(pr)
	success := helper.deserializePartialResult4MaxMinCountTime(result)
	if !success {
		return nil, 0
	}
	return pr, memDelta
}

type maxMinCount4TimeSliding struct {
	maxMinCount4Time
	windowInfo
}

func (e *maxMinCount4TimeSliding) AllocPartialResult() (pr PartialResult, memDelta int64) {
	p, memDelta := e.maxMinCount4Time.AllocPartialResult()
	(*partialResult4MaxMinCountTime)(p).deque = NewDeque(e.isMax, func(i, j any) int {
		a, b := i.(types.Time), j.(types.Time)
		if a.Compare(b) < 0 {
			return -1
		} else if a.Compare(b) > 0 {
			return 1
		}
		return 0
	})
	return p, memDelta + DefMaxMinDequeSize
}

func (e *maxMinCount4TimeSliding) ResetPartialResult(pr PartialResult) {
	e.maxMinCount4Time.ResetPartialResult(pr)
	(*partialResult4MaxMinCountTime)(pr).deque.Reset()
}

func (e *maxMinCount4TimeSliding) updateResultFromDeque(p *partialResult4MaxMinCountTime) {
	if p.deque.IsEmpty() {
		p.isNull = true
		p.cnt = 0
		return
	}
	front, _ := p.deque.Front()
	p.val = front.Item.(types.Time)
	p.isNull = false
	cnt := int64(0)
	for _, pair := range p.deque.Items {
		a, b := pair.Item.(types.Time), p.val
		if a.Compare(b) == 0 {
			cnt++
		} else {
			break
		}
	}
	p.cnt = cnt
}

func (e *maxMinCount4TimeSliding) UpdatePartialResult(sctx AggFuncUpdateContext, rowsInGroup []chunk.Row, pr PartialResult) (memDelta int64, err error) {
	p := (*partialResult4MaxMinCountTime)(pr)
	for i, row := range rowsInGroup {
		input, isNull, err := e.args[0].EvalTime(sctx, row)
		if err != nil {
			return 0, err
		}
		if isNull {
			continue
		}
		enqueueCount(p.deque, uint64(i)+e.start, input)
	}
	e.updateResultFromDeque(p)
	return 0, nil
}

var _ SlidingWindowAggFunc = &maxMinCount4TimeSliding{}

func (e *maxMinCount4TimeSliding) Slide(sctx AggFuncUpdateContext, getRow func(uint64) chunk.Row, lastStart, lastEnd uint64, shiftStart, shiftEnd uint64, pr PartialResult) error {
	p := (*partialResult4MaxMinCountTime)(pr)
	for i := range shiftEnd {
		input, isNull, err := e.args[0].EvalTime(sctx, getRow(lastEnd+i))
		if err != nil {
			return err
		}
		if isNull {
			continue
		}
		enqueueCount(p.deque, lastEnd+i, input)
	}
	if lastStart+shiftStart >= 1 {
		_ = p.deque.Dequeue(lastStart + shiftStart - 1)
	}
	e.updateResultFromDeque(p)
	return nil
}


// ---------------------- Duration ----------------------
type partialResult4MaxMinCountDuration struct {
	val    types.Duration
	cnt    int64
	isNull bool
	deque  *MinMaxDeque
}

type maxMinCount4Duration struct {
	baseMaxMinCountAggFunc
}

func (*maxMinCount4Duration) AllocPartialResult() (pr PartialResult, memDelta int64) {
	p := new(partialResult4MaxMinCountDuration)
	p.isNull = true
	return PartialResult(p), DefPartialResult4MaxMinCountDurationSize
}

func (*maxMinCount4Duration) ResetPartialResult(pr PartialResult) {
	p := (*partialResult4MaxMinCountDuration)(pr)
	p.val = types.Duration{}
	p.cnt = 0
	p.isNull = true
	if p.deque != nil {
		p.deque.Reset()
	}
}

func (e *maxMinCount4Duration) AppendFinalResult2Chunk(_ AggFuncUpdateContext, pr PartialResult, chk *chunk.Chunk) error {
	p := (*partialResult4MaxMinCountDuration)(pr)
	if p.isNull {
		chk.AppendInt64(e.ordinal, 0)
		return nil
	}
	chk.AppendInt64(e.ordinal, p.cnt)
	return nil
}

func (e *maxMinCount4Duration) UpdatePartialResult(sctx AggFuncUpdateContext, rowsInGroup []chunk.Row, pr PartialResult) (memDelta int64, err error) {
	p := (*partialResult4MaxMinCountDuration)(pr)
	for _, row := range rowsInGroup {
		input, isNull, err := e.args[0].EvalDuration(sctx, row)
		if err != nil {
			return 0, err
		}
		if isNull {
			continue
		}
		if p.isNull {
			p.val = input
			p.cnt = 1
			p.isNull = false
			continue
		}
		if input.Compare(p.val) == 0 {
			p.cnt++
		} else if (e.isMax && (input.Compare(p.val) > 0)) || (!e.isMax && (input.Compare(p.val) < 0)) {
			p.val = input
			p.cnt = 1
		}
	}
	return 0, nil
}

func (e *maxMinCount4Duration) MergePartialResult(_ AggFuncUpdateContext, src, dst PartialResult) (memDelta int64, err error) {
	p1, p2 := (*partialResult4MaxMinCountDuration)(src), (*partialResult4MaxMinCountDuration)(dst)
	if p1.isNull || p1.cnt == 0 {
		return 0, nil
	}
	if p2.isNull || p2.cnt == 0 {
		*p2 = *p1
		return 0, nil
	}
	if p1.val.Compare(p2.val) == 0 {
		p2.cnt += p1.cnt
	} else if (e.isMax && (p1.val.Compare(p2.val) > 0)) || (!e.isMax && (p1.val.Compare(p2.val) < 0)) {
		p2.val = p1.val
		p2.cnt = p1.cnt
	}
	return 0, nil
}

func (e *maxMinCount4Duration) SerializePartialResult(partialResult PartialResult, chk *chunk.Chunk, spillHelper *SerializeHelper) {
	pr := (*partialResult4MaxMinCountDuration)(partialResult)
	resBuf := spillHelper.serializePartialResult4MaxMinCountDuration(*pr)
	chk.AppendBytes(e.ordinal, resBuf)
}

func (e *maxMinCount4Duration) DeserializePartialResult(src *chunk.Chunk) ([]PartialResult, int64) {
	return deserializePartialResultCommon(src, e.ordinal, e.deserializeForSpill)
}

func (e *maxMinCount4Duration) deserializeForSpill(helper *deserializeHelper) (PartialResult, int64) {
	pr, memDelta := e.AllocPartialResult()
	result := (*partialResult4MaxMinCountDuration)(pr)
	success := helper.deserializePartialResult4MaxMinCountDuration(result)
	if !success {
		return nil, 0
	}
	return pr, memDelta
}

type maxMinCount4DurationSliding struct {
	maxMinCount4Duration
	windowInfo
}

func (e *maxMinCount4DurationSliding) AllocPartialResult() (pr PartialResult, memDelta int64) {
	p, memDelta := e.maxMinCount4Duration.AllocPartialResult()
	(*partialResult4MaxMinCountDuration)(p).deque = NewDeque(e.isMax, func(i, j any) int {
		a, b := i.(types.Duration), j.(types.Duration)
		if a.Compare(b) < 0 {
			return -1
		} else if a.Compare(b) > 0 {
			return 1
		}
		return 0
	})
	return p, memDelta + DefMaxMinDequeSize
}

func (e *maxMinCount4DurationSliding) ResetPartialResult(pr PartialResult) {
	e.maxMinCount4Duration.ResetPartialResult(pr)
	(*partialResult4MaxMinCountDuration)(pr).deque.Reset()
}

func (e *maxMinCount4DurationSliding) updateResultFromDeque(p *partialResult4MaxMinCountDuration) {
	if p.deque.IsEmpty() {
		p.isNull = true
		p.cnt = 0
		return
	}
	front, _ := p.deque.Front()
	p.val = front.Item.(types.Duration)
	p.isNull = false
	cnt := int64(0)
	for _, pair := range p.deque.Items {
		a, b := pair.Item.(types.Duration), p.val
		if a.Compare(b) == 0 {
			cnt++
		} else {
			break
		}
	}
	p.cnt = cnt
}

func (e *maxMinCount4DurationSliding) UpdatePartialResult(sctx AggFuncUpdateContext, rowsInGroup []chunk.Row, pr PartialResult) (memDelta int64, err error) {
	p := (*partialResult4MaxMinCountDuration)(pr)
	for i, row := range rowsInGroup {
		input, isNull, err := e.args[0].EvalDuration(sctx, row)
		if err != nil {
			return 0, err
		}
		if isNull {
			continue
		}
		enqueueCount(p.deque, uint64(i)+e.start, input)
	}
	e.updateResultFromDeque(p)
	return 0, nil
}

var _ SlidingWindowAggFunc = &maxMinCount4DurationSliding{}

func (e *maxMinCount4DurationSliding) Slide(sctx AggFuncUpdateContext, getRow func(uint64) chunk.Row, lastStart, lastEnd uint64, shiftStart, shiftEnd uint64, pr PartialResult) error {
	p := (*partialResult4MaxMinCountDuration)(pr)
	for i := range shiftEnd {
		input, isNull, err := e.args[0].EvalDuration(sctx, getRow(lastEnd+i))
		if err != nil {
			return err
		}
		if isNull {
			continue
		}
		enqueueCount(p.deque, lastEnd+i, input)
	}
	if lastStart+shiftStart >= 1 {
		_ = p.deque.Dequeue(lastStart + shiftStart - 1)
	}
	e.updateResultFromDeque(p)
	return nil
}


// ---------------------- JSON ----------------------
type partialResult4MaxMinCountJSON struct {
	val    types.BinaryJSON
	cnt    int64
	isNull bool
	deque  *MinMaxDeque
}

type maxMinCount4JSON struct {
	baseMaxMinCountAggFunc
}

func (*maxMinCount4JSON) AllocPartialResult() (pr PartialResult, memDelta int64) {
	p := new(partialResult4MaxMinCountJSON)
	p.isNull = true
	return PartialResult(p), DefPartialResult4MaxMinCountJSONSize
}

func (*maxMinCount4JSON) ResetPartialResult(pr PartialResult) {
	p := (*partialResult4MaxMinCountJSON)(pr)
	p.val = types.BinaryJSON{}
	p.cnt = 0
	p.isNull = true
	if p.deque != nil {
		p.deque.Reset()
	}
}

func (e *maxMinCount4JSON) AppendFinalResult2Chunk(_ AggFuncUpdateContext, pr PartialResult, chk *chunk.Chunk) error {
	p := (*partialResult4MaxMinCountJSON)(pr)
	if p.isNull {
		chk.AppendInt64(e.ordinal, 0)
		return nil
	}
	chk.AppendInt64(e.ordinal, p.cnt)
	return nil
}

func (e *maxMinCount4JSON) UpdatePartialResult(sctx AggFuncUpdateContext, rowsInGroup []chunk.Row, pr PartialResult) (memDelta int64, err error) {
	p := (*partialResult4MaxMinCountJSON)(pr)
	for _, row := range rowsInGroup {
		input, isNull, err := e.args[0].EvalJSON(sctx, row)
		if err != nil {
			return 0, err
		}
		if isNull {
			continue
		}
		if p.isNull {
			p.val = input
			p.cnt = 1
			p.isNull = false
			continue
		}
		if types.CompareBinaryJSON(input, p.val) == 0 {
			p.cnt++
		} else if (e.isMax && (types.CompareBinaryJSON(input, p.val) > 0)) || (!e.isMax && (types.CompareBinaryJSON(input, p.val) < 0)) {
			p.val = input
			p.cnt = 1
		}
	}
	return 0, nil
}

func (e *maxMinCount4JSON) MergePartialResult(_ AggFuncUpdateContext, src, dst PartialResult) (memDelta int64, err error) {
	p1, p2 := (*partialResult4MaxMinCountJSON)(src), (*partialResult4MaxMinCountJSON)(dst)
	if p1.isNull || p1.cnt == 0 {
		return 0, nil
	}
	if p2.isNull || p2.cnt == 0 {
		*p2 = *p1
		return 0, nil
	}
	if types.CompareBinaryJSON(p1.val, p2.val) == 0 {
		p2.cnt += p1.cnt
	} else if (e.isMax && (types.CompareBinaryJSON(p1.val, p2.val) > 0)) || (!e.isMax && (types.CompareBinaryJSON(p1.val, p2.val) < 0)) {
		p2.val = p1.val
		p2.cnt = p1.cnt
	}
	return 0, nil
}

func (e *maxMinCount4JSON) SerializePartialResult(partialResult PartialResult, chk *chunk.Chunk, spillHelper *SerializeHelper) {
	pr := (*partialResult4MaxMinCountJSON)(partialResult)
	resBuf := spillHelper.serializePartialResult4MaxMinCountJSON(*pr)
	chk.AppendBytes(e.ordinal, resBuf)
}

func (e *maxMinCount4JSON) DeserializePartialResult(src *chunk.Chunk) ([]PartialResult, int64) {
	return deserializePartialResultCommon(src, e.ordinal, e.deserializeForSpill)
}

func (e *maxMinCount4JSON) deserializeForSpill(helper *deserializeHelper) (PartialResult, int64) {
	pr, memDelta := e.AllocPartialResult()
	result := (*partialResult4MaxMinCountJSON)(pr)
	success := helper.deserializePartialResult4MaxMinCountJSON(result)
	if !success {
		return nil, 0
	}
	return pr, memDelta
}


// ---------------------- VectorFloat32 ----------------------
type partialResult4MaxMinCountVectorFloat32 struct {
	val    types.VectorFloat32
	cnt    int64
	isNull bool
	deque  *MinMaxDeque
}

type maxMinCount4VectorFloat32 struct {
	baseMaxMinCountAggFunc
}

func (*maxMinCount4VectorFloat32) AllocPartialResult() (pr PartialResult, memDelta int64) {
	p := new(partialResult4MaxMinCountVectorFloat32)
	p.isNull = true
	return PartialResult(p), DefPartialResult4MaxMinCountVectorFloat32Size
}

func (*maxMinCount4VectorFloat32) ResetPartialResult(pr PartialResult) {
	p := (*partialResult4MaxMinCountVectorFloat32)(pr)
	p.val = types.VectorFloat32{}
	p.cnt = 0
	p.isNull = true
	if p.deque != nil {
		p.deque.Reset()
	}
}

func (e *maxMinCount4VectorFloat32) AppendFinalResult2Chunk(_ AggFuncUpdateContext, pr PartialResult, chk *chunk.Chunk) error {
	p := (*partialResult4MaxMinCountVectorFloat32)(pr)
	if p.isNull {
		chk.AppendInt64(e.ordinal, 0)
		return nil
	}
	chk.AppendInt64(e.ordinal, p.cnt)
	return nil
}

func (e *maxMinCount4VectorFloat32) UpdatePartialResult(sctx AggFuncUpdateContext, rowsInGroup []chunk.Row, pr PartialResult) (memDelta int64, err error) {
	p := (*partialResult4MaxMinCountVectorFloat32)(pr)
	for _, row := range rowsInGroup {
		input, isNull, err := e.args[0].EvalVectorFloat32(sctx, row)
		if err != nil {
			return 0, err
		}
		if isNull {
			continue
		}
		if p.isNull {
			p.val = input
			p.cnt = 1
			p.isNull = false
			continue
		}
		if input.Compare(p.val) == 0 {
			p.cnt++
		} else if (e.isMax && (input.Compare(p.val) > 0)) || (!e.isMax && (input.Compare(p.val) < 0)) {
			p.val = input
			p.cnt = 1
		}
	}
	return 0, nil
}

func (e *maxMinCount4VectorFloat32) MergePartialResult(_ AggFuncUpdateContext, src, dst PartialResult) (memDelta int64, err error) {
	p1, p2 := (*partialResult4MaxMinCountVectorFloat32)(src), (*partialResult4MaxMinCountVectorFloat32)(dst)
	if p1.isNull || p1.cnt == 0 {
		return 0, nil
	}
	if p2.isNull || p2.cnt == 0 {
		*p2 = *p1
		return 0, nil
	}
	if p1.val.Compare(p2.val) == 0 {
		p2.cnt += p1.cnt
	} else if (e.isMax && (p1.val.Compare(p2.val) > 0)) || (!e.isMax && (p1.val.Compare(p2.val) < 0)) {
		p2.val = p1.val
		p2.cnt = p1.cnt
	}
	return 0, nil
}


// ---------------------- Enum ----------------------
type partialResult4MaxMinCountEnum struct {
	val    types.Enum
	cnt    int64
	isNull bool
	deque  *MinMaxDeque
}

type maxMinCount4Enum struct {
	baseMaxMinCountAggFunc
}

func (*maxMinCount4Enum) AllocPartialResult() (pr PartialResult, memDelta int64) {
	p := new(partialResult4MaxMinCountEnum)
	p.isNull = true
	return PartialResult(p), DefPartialResult4MaxMinCountEnumSize
}

func (*maxMinCount4Enum) ResetPartialResult(pr PartialResult) {
	p := (*partialResult4MaxMinCountEnum)(pr)
	p.val = types.Enum{}
	p.cnt = 0
	p.isNull = true
	if p.deque != nil {
		p.deque.Reset()
	}
}

func (e *maxMinCount4Enum) AppendFinalResult2Chunk(_ AggFuncUpdateContext, pr PartialResult, chk *chunk.Chunk) error {
	p := (*partialResult4MaxMinCountEnum)(pr)
	if p.isNull {
		chk.AppendInt64(e.ordinal, 0)
		return nil
	}
	chk.AppendInt64(e.ordinal, p.cnt)
	return nil
}

func (e *maxMinCount4Enum) UpdatePartialResult(sctx AggFuncUpdateContext, rowsInGroup []chunk.Row, pr PartialResult) (memDelta int64, err error) {
	p := (*partialResult4MaxMinCountEnum)(pr)
	for _, row := range rowsInGroup {
		d, err := e.args[0].Eval(sctx, row)
		if err != nil {
			return 0, err
		}
		if d.IsNull() {
			continue
		}
		en := d.GetMysqlEnum()
		if p.isNull {
			p.val = en.Copy()
			p.cnt = 1
			p.isNull = false
			continue
		}
		if e.collator.Compare(en.Name, p.val.Name) == 0 {
			p.cnt++
		} else if (e.isMax && (e.collator.Compare(en.Name, p.val.Name) > 0)) || (!e.isMax && (e.collator.Compare(en.Name, p.val.Name) < 0)) {
			p.val = en.Copy()
			p.cnt = 1
		}
	}
	return 0, nil
}

func (e *maxMinCount4Enum) MergePartialResult(_ AggFuncUpdateContext, src, dst PartialResult) (memDelta int64, err error) {
	p1, p2 := (*partialResult4MaxMinCountEnum)(src), (*partialResult4MaxMinCountEnum)(dst)
	if p1.isNull || p1.cnt == 0 {
		return 0, nil
	}
	if p2.isNull || p2.cnt == 0 {
		*p2 = *p1
		return 0, nil
	}
	if e.collator.Compare(p1.val.Name, p2.val.Name) == 0 {
		p2.cnt += p1.cnt
	} else if (e.isMax && (e.collator.Compare(p1.val.Name, p2.val.Name) > 0)) || (!e.isMax && (e.collator.Compare(p1.val.Name, p2.val.Name) < 0)) {
		p2.val = p1.val
		p2.cnt = p1.cnt
	}
	return 0, nil
}

func (e *maxMinCount4Enum) SerializePartialResult(partialResult PartialResult, chk *chunk.Chunk, spillHelper *SerializeHelper) {
	pr := (*partialResult4MaxMinCountEnum)(partialResult)
	resBuf := spillHelper.serializePartialResult4MaxMinCountEnum(*pr)
	chk.AppendBytes(e.ordinal, resBuf)
}

func (e *maxMinCount4Enum) DeserializePartialResult(src *chunk.Chunk) ([]PartialResult, int64) {
	return deserializePartialResultCommon(src, e.ordinal, e.deserializeForSpill)
}

func (e *maxMinCount4Enum) deserializeForSpill(helper *deserializeHelper) (PartialResult, int64) {
	pr, memDelta := e.AllocPartialResult()
	result := (*partialResult4MaxMinCountEnum)(pr)
	success := helper.deserializePartialResult4MaxMinCountEnum(result)
	if !success {
		return nil, 0
	}
	return pr, memDelta
}


// ---------------------- Set ----------------------
type partialResult4MaxMinCountSet struct {
	val    types.Set
	cnt    int64
	isNull bool
	deque  *MinMaxDeque
}

type maxMinCount4Set struct {
	baseMaxMinCountAggFunc
}

func (*maxMinCount4Set) AllocPartialResult() (pr PartialResult, memDelta int64) {
	p := new(partialResult4MaxMinCountSet)
	p.isNull = true
	return PartialResult(p), DefPartialResult4MaxMinCountSetSize
}

func (*maxMinCount4Set) ResetPartialResult(pr PartialResult) {
	p := (*partialResult4MaxMinCountSet)(pr)
	p.val = types.Set{}
	p.cnt = 0
	p.isNull = true
	if p.deque != nil {
		p.deque.Reset()
	}
}

func (e *maxMinCount4Set) AppendFinalResult2Chunk(_ AggFuncUpdateContext, pr PartialResult, chk *chunk.Chunk) error {
	p := (*partialResult4MaxMinCountSet)(pr)
	if p.isNull {
		chk.AppendInt64(e.ordinal, 0)
		return nil
	}
	chk.AppendInt64(e.ordinal, p.cnt)
	return nil
}

func (e *maxMinCount4Set) UpdatePartialResult(sctx AggFuncUpdateContext, rowsInGroup []chunk.Row, pr PartialResult) (memDelta int64, err error) {
	p := (*partialResult4MaxMinCountSet)(pr)
	for _, row := range rowsInGroup {
		d, err := e.args[0].Eval(sctx, row)
		if err != nil {
			return 0, err
		}
		if d.IsNull() {
			continue
		}
		setVal := d.GetMysqlSet()
		if p.isNull {
			p.val = setVal.Copy()
			p.cnt = 1
			p.isNull = false
			continue
		}
		if e.collator.Compare(setVal.Name, p.val.Name) == 0 {
			p.cnt++
		} else if (e.isMax && (e.collator.Compare(setVal.Name, p.val.Name) > 0)) || (!e.isMax && (e.collator.Compare(setVal.Name, p.val.Name) < 0)) {
			p.val = setVal.Copy()
			p.cnt = 1
		}
	}
	return 0, nil
}

func (e *maxMinCount4Set) MergePartialResult(_ AggFuncUpdateContext, src, dst PartialResult) (memDelta int64, err error) {
	p1, p2 := (*partialResult4MaxMinCountSet)(src), (*partialResult4MaxMinCountSet)(dst)
	if p1.isNull || p1.cnt == 0 {
		return 0, nil
	}
	if p2.isNull || p2.cnt == 0 {
		*p2 = *p1
		return 0, nil
	}
	if e.collator.Compare(p1.val.Name, p2.val.Name) == 0 {
		p2.cnt += p1.cnt
	} else if (e.isMax && (e.collator.Compare(p1.val.Name, p2.val.Name) > 0)) || (!e.isMax && (e.collator.Compare(p1.val.Name, p2.val.Name) < 0)) {
		p2.val = p1.val
		p2.cnt = p1.cnt
	}
	return 0, nil
}

func (e *maxMinCount4Set) SerializePartialResult(partialResult PartialResult, chk *chunk.Chunk, spillHelper *SerializeHelper) {
	pr := (*partialResult4MaxMinCountSet)(partialResult)
	resBuf := spillHelper.serializePartialResult4MaxMinCountSet(*pr)
	chk.AppendBytes(e.ordinal, resBuf)
}

func (e *maxMinCount4Set) DeserializePartialResult(src *chunk.Chunk) ([]PartialResult, int64) {
	return deserializePartialResultCommon(src, e.ordinal, e.deserializeForSpill)
}

func (e *maxMinCount4Set) deserializeForSpill(helper *deserializeHelper) (PartialResult, int64) {
	pr, memDelta := e.AllocPartialResult()
	result := (*partialResult4MaxMinCountSet)(pr)
	success := helper.deserializePartialResult4MaxMinCountSet(result)
	if !success {
		return nil, 0
	}
	return pr, memDelta
}

