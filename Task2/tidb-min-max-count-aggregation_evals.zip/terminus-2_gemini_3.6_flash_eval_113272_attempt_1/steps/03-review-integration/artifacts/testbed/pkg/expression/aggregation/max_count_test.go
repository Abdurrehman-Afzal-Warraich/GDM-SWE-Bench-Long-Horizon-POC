package aggregation_test

import (
"testing"

"github.com/pingcap/tidb/pkg/expression"
"github.com/pingcap/tidb/pkg/expression/aggregation"
"github.com/pingcap/tidb/pkg/kv"
"github.com/pingcap/tidb/pkg/parser/ast"
"github.com/pingcap/tidb/pkg/parser/mysql"
"github.com/pingcap/tidb/pkg/types"
"github.com/pingcap/tidb/pkg/util/mock"
"github.com/pingcap/tipb/go-tipb"
"github.com/stretchr/testify/require"
)

func TestMaxCountMinCountDesc(t *testing.T) {
ctx := mock.NewContext()
col := &expression.Column{Index: 0, RetType: types.NewFieldType(mysql.TypeLonglong)}

for _, name := range []string{ast.AggFuncMaxCount, ast.AggFuncMinCount} {
desc, err := aggregation.NewAggFuncDesc(ctx, name, []expression.Expression{col}, false)
require.NoError(t, err)
require.Equal(t, name, desc.Name)
require.Equal(t, mysql.TypeLonglong, desc.RetTp.GetType())
require.True(t, mysql.HasNotNullFlag(desc.RetTp.GetFlag()))

eval := desc.GetAggFunc(ctx)
require.NotNil(t, eval)
}
}

func TestMaxCountMinCountProtobufAndPushDown(t *testing.T) {
ctx := mock.NewContext()
evalCtx := ctx.GetExprCtx().GetEvalCtx()
client := &mock.Client{}
pushCtx := expression.NewPushDownContextFromSessionVars(evalCtx, ctx.GetSessionVars(), client)
col := &expression.Column{Index: 0, RetType: types.NewFieldType(mysql.TypeLonglong)}

names := []string{ast.AggFuncMaxCount, ast.AggFuncMinCount}
expectedPBTypes := []tipb.ExprType{tipb.ExprType_MaxCount, tipb.ExprType_MinCount}

for i, name := range names {
desc, err := aggregation.NewAggFuncDesc(ctx, name, []expression.Expression{col}, false)
require.NoError(t, err)

pbType := desc.GetTiPBExpr(false)
require.Equal(t, expectedPBTypes[i], pbType)

pbExpr, err := aggregation.AggFuncToPBExpr(pushCtx, desc, kv.TiFlash)
require.NoError(t, err)
require.NotNil(t, pbExpr)
require.Equal(t, expectedPBTypes[i], pbExpr.Tp)

reconstructed, err := aggregation.PBExprToAggFuncDesc(ctx, pbExpr, []*types.FieldType{desc.RetTp})
require.NoError(t, err)
require.Equal(t, name, reconstructed.Name)

checker := kv.RequestTypeSupportedChecker{}
require.True(t, checker.IsRequestTypeSupported(kv.ReqTypeSelect, int64(expectedPBTypes[i])))

desc.Mode = aggregation.CompleteMode
require.True(t, aggregation.CheckAggPushDown(evalCtx, desc, kv.TiFlash))

desc.Mode = aggregation.Partial1Mode
require.True(t, aggregation.CheckAggPushDown(evalCtx, desc, kv.TiFlash))

desc.Mode = aggregation.DedupMode
require.False(t, aggregation.CheckAggPushDown(evalCtx, desc, kv.TiFlash))

desc.Mode = aggregation.FinalMode
require.False(t, aggregation.CheckAggPushDown(evalCtx, desc, kv.TiFlash))

desc.Mode = aggregation.Partial2Mode
require.False(t, aggregation.CheckAggPushDown(evalCtx, desc, kv.TiFlash))

desc.Mode = aggregation.CompleteMode
require.False(t, aggregation.CheckAggPushDown(evalCtx, desc, kv.TiKV))
require.False(t, aggregation.CheckAggPushDown(evalCtx, desc, kv.TiDB))
require.False(t, aggregation.CheckAggPushDown(evalCtx, desc, kv.UnSpecified))
}
}
