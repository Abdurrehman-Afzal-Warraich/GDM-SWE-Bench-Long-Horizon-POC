#!/usr/bin/env bash
set -euo pipefail

export PATH=$PATH:/usr/local/go/bin
mkdir -p /app/output/01-diagnose

echo "=== Reproduce Missing max_count and min_count Aggregates ===" | tee /app/output/01-diagnose/reproducer.log
cd /testbed
go run /app/output/01-diagnose/main.go 2>&1 | tee -a /app/output/01-diagnose/reproducer.log
