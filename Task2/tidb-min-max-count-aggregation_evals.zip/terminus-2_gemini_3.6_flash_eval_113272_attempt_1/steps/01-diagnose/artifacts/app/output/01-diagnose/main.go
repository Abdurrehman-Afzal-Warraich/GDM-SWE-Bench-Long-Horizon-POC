package main

import (
"fmt"
"github.com/pingcap/tidb/pkg/expression"
"github.com/pingcap/tidb/pkg/expression/aggregation"
"github.com/pingcap/tidb/pkg/parser/mysql"
"github.com/pingcap/tidb/pkg/types"
"github.com/pingcap/tidb/pkg/util/mock"
)

func main() {
ctx := mock.NewContext()
col := &expression.Column{Index: 0, RetType: types.NewFieldType(mysql.TypeLonglong)}

_, err1 := aggregation.NewAggFuncDesc(ctx, "max_count", []expression.Expression{col}, false)
fmt.Printf("max_count error: %v\n", err1)

_, err2 := aggregation.NewAggFuncDesc(ctx, "min_count", []expression.Expression{col}, false)
fmt.Printf("min_count error: %v\n", err2)
}
