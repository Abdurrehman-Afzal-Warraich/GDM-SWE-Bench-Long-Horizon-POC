go test -json -count=1 -tags=intest -run ^TestVerifierWindowSlidingBehavior$ ./pkg/executor/aggfuncs
