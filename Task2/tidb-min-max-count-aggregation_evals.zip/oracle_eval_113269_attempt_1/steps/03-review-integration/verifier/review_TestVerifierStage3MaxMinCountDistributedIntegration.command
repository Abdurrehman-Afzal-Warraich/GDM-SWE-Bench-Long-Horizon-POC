go test -json -count=1 -tags=intest -run ^TestVerifierStage3MaxMinCountDistributedIntegration$ ./pkg/expression/aggregation
