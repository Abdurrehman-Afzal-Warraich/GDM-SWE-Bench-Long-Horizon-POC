go test -json -count=1 -tags=intest -run ^TestVerifierStage2MaxMinCountAggregationBehavior$ ./pkg/expression/aggregation
