git diff --no-ext-diff --name-only 15ac41cf66ef3b7ab66732876cb38232b8546ab6 -- .
