go test -json -count=1 -tags=intest -run ^TestVerifierStage1BaseLacksMaxMinCountAggregates$ ./pkg/expression/aggregation
