#!/usr/bin/env bash
set -euo pipefail
cd /testbed

echo "Checking for absence of max_count/min_count aggregate functions..."
if grep -q 'AggFuncMaxCount\|AggFuncMinCount' pkg/parser/ast/functions.go 2>/dev/null; then
  echo "UNEXPECTED: AggFuncMaxCount/AggFuncMinCount already defined"
  exit 1
fi

echo "Verifying no max_count descriptor in expression/aggregation..."
if grep -rq 'AggFuncMaxCount\|AggFuncMinCount' pkg/expression/aggregation/ 2>/dev/null; then
  echo "UNEXPECTED: max_count/min_count aggregation descriptors exist"
  exit 1
fi

echo "Verifying no max_count executor in aggfuncs..."
if find pkg/executor/aggfuncs/ -name '*max_min_count*' 2>/dev/null | grep -q .; then
  echo "UNEXPECTED: max_min_count executor files exist"
  exit 1
fi

echo "CONFIRMED: Base revision lacks max_count and min_count aggregate functions"
echo "Affected subsystems: parser, expression, executor, planner, kv"
exit 0
