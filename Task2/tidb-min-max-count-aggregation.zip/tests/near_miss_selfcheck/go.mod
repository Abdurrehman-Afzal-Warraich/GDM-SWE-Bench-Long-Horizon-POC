module nearmiss

go 1.22
