package nearmiss

import (
	"math/rand"
	"testing"
)

func correct(vals []int, _ int, isMax bool) int {
	if len(vals) == 0 {
		return 0
	}
	ext := vals[0]
	for _, v := range vals[1:] {
		if isMax {
			if v > ext {
				ext = v
			}
		} else if v < ext {
			ext = v
		}
	}
	c := 0
	for _, v := range vals {
		if v == ext {
			c++
		}
	}
	return c
}

func nmCountAllNonNull(vals []int, _ int, _ bool) int { return len(vals) }
func nmCountInclNull(vals []int, nulls int, _ bool) int {
	return len(vals) + nulls
}
func nmReturnExtremeValue(vals []int, _ int, isMax bool) int {
	if len(vals) == 0 {
		return 0
	}
	ext := vals[0]
	for _, v := range vals[1:] {
		if isMax {
			if v > ext {
				ext = v
			}
		} else if v < ext {
			ext = v
		}
	}
	return ext
}
func nmSwapMinMax(vals []int, nulls int, isMax bool) int { return correct(vals, nulls, !isMax) }
func nmAlwaysOne(vals []int, _ int, _ bool) int {
	if len(vals) == 0 {
		return 0
	}
	return 1
}

func genGroup(rng *rand.Rand) (vals []int, nulls int) {
	n := rng.Intn(40)
	vals = make([]int, 0, n)
	for range n {
		if rng.Intn(4) == 0 {
			nulls++
			continue
		}
		vals = append(vals, rng.Intn(11)-5)
	}
	return vals, nulls
}

func TestNearMissesAreDiscriminated(t *testing.T) {
	nearMisses := []struct {
		name string
		fn   func([]int, int, bool) int
	}{
		{"count_all_non_null_rows", nmCountAllNonNull},
		{"count_including_nulls", nmCountInclNull},
		{"return_extreme_value_not_count", nmReturnExtremeValue},
		{"swap_min_and_max", nmSwapMinMax},
		{"always_return_one", nmAlwaysOne},
	}

	const samples = 5000
	for _, nm := range nearMisses {
		rng := rand.New(rand.NewSource(0x5EEDC0DE))
		disagreements := 0
		for range samples {
			vals, nulls := genGroup(rng)
			for _, isMax := range []bool{true, false} {
				if correct(vals, nulls, isMax) != nm.fn(vals, nulls, isMax) {
					disagreements++
				}
			}
		}
		if disagreements == 0 {
			t.Fatalf("near-miss %q is NOT discriminated by the test distribution", nm.name)
		}
		t.Logf("near-miss %-32s discriminated on %d/%d checks", nm.name, disagreements, samples*2)
	}
}
