from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import time
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

TESTBED = Path(os.environ.get('TESTBED_DIR', '/testbed'))
OUTPUT = Path('/app/output')
LOGDIR = Path(os.environ.get('RESULT_DIR', '/logs/verifier'))
HIDDEN = Path('/tests/hidden')

INFRA_PATTERNS = (
    'no space left on device', 'cannot allocate memory', 'signal: killed',
    'exec format error', 'permission denied: \'go\'', 'go: command not found',
    'temporary failure in name resolution', 'could not resolve host',
    'network is unreachable', 'tls handshake timeout', 'i/o timeout',
)

PKG_BUILD_CMD = [
    'go', 'build', '-tags=intest',
    './pkg/expression/...',
    './pkg/executor/aggfuncs/...',
    './pkg/planner/...',
    './pkg/kv/...',
    './pkg/util/serialization/...',
]

STAGE2_TEST_CMD = [
    'go', 'test', '-json', '-count=1', '-tags=intest',
    './pkg/executor/aggfuncs/...',
    './pkg/expression/aggregation/...',
]

STAGE3_TEST_CMD = [
    'go', 'test', '-json', '-count=1', '-tags=intest',
    './pkg/expression/aggregation/...',
    './pkg/kv/...',
]

CUMULATIVE_TEST_CMD = [
    'go', 'test', '-json', '-count=1', '-tags=intest',
    './pkg/executor/aggfuncs/...',
    './pkg/expression/aggregation/...',
]

@dataclass
class CommandResult:
    command: list[str]
    returncode: int
    stdout: str
    stderr: str
    duration_sec: float
    infrastructure_failure: bool

    @property
    def combined(self) -> str:
        return self.stdout + ('\n' if self.stdout and self.stderr else '') + self.stderr

def run_command(
    command: list[str],
    *,
    cwd: Path = TESTBED,
    timeout: int = 1800,
    env: dict[str, str] | None = None,
    log_name: str | None = None,
) -> CommandResult:
    safe_env = {
        'PATH': os.environ.get(
            'PATH',
            '/opt/verifier-venv/bin:/usr/local/go/bin:/go/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
        ),
        'HOME': '/tmp/verifier-home',
        'GOTOOLCHAIN': 'local',
        'GONOSUMDB': '*',
        'GOPROXY': 'file:///go/pkg/mod/cache/download,direct',
        'GOSUMDB': 'off',
        'CGO_ENABLED': os.environ.get('CGO_ENABLED', '1'),
        'LANG': 'C.UTF-8',
        'LC_ALL': 'C.UTF-8',
        'GIT_NO_REPLACE_OBJECTS': '1',
    }
    if env:
        safe_env.update(env)
    Path(safe_env['HOME']).mkdir(parents=True, exist_ok=True)
    start = time.monotonic()
    try:
        proc = subprocess.run(
            command,
            cwd=cwd,
            env=safe_env,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            check=False,
        )
        rc, out, err = proc.returncode, proc.stdout, proc.stderr
    except subprocess.TimeoutExpired as exc:
        rc = 124
        out = exc.stdout or ''
        err = (exc.stderr or '') + f'\nverifier timeout after {timeout}s'
    duration = time.monotonic() - start
    combined = (out + '\n' + err).lower()
    infra = rc != 0 and any(pattern in combined for pattern in INFRA_PATTERNS)
    result = CommandResult(command, rc, out, err, duration, infra)
    if log_name:
        LOGDIR.mkdir(parents=True, exist_ok=True)
        (LOGDIR / f'{log_name}.command').write_text(' '.join(command) + '\n', encoding='utf-8')
        (LOGDIR / f'{log_name}.log').write_text(result.combined, encoding='utf-8')
        (LOGDIR / f'{log_name}.meta.json').write_text(
            json.dumps(
                {
                    'returncode': rc,
                    'duration_sec': round(duration, 3),
                    'infrastructure_failure': infra,
                },
                indent=2,
            )
            + '\n',
            encoding='utf-8',
        )
    return result

def read_json(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(data, dict):
        raise ValueError(f'{path} must contain a JSON object')
    return data

def validate_output_file(value: Any, allowed_root: Path, label: str) -> list[str]:
    if not isinstance(value, str) or not value.startswith('/'):
        return [f'{label} must be an absolute path']
    path = Path(value)
    if path.is_symlink():
        return [f'{label} must not be a symlink']
    try:
        resolved = path.resolve(strict=True)
        resolved.relative_to(allowed_root.resolve(strict=True))
    except (OSError, ValueError):
        return [f'{label} must resolve under {allowed_root}']
    if not resolved.is_file():
        return [f'{label} must be a regular file']
    return []

def validate_commands(items: Any, allowed_root: Path) -> list[str]:
    errors: list[str] = []
    if not isinstance(items, list) or not items:
        return ['commands_run must be a non-empty array']
    for i, item in enumerate(items):
        if not isinstance(item, dict):
            errors.append(f'commands_run[{i}] must be an object')
            continue
        cmd = item.get('command')
        code = item.get('exit_code')
        if not isinstance(cmd, str) or not cmd.strip():
            errors.append(f'commands_run[{i}].command must be non-empty')
        if not isinstance(code, int) or code != 0:
            errors.append(f'commands_run[{i}].exit_code must be 0')
        errors.extend(
            validate_output_file(
                item.get('output_file'), allowed_root, f'commands_run[{i}].output_file'
            )
        )
    return errors

def validate_string_list(value: Any, label: str, *, min_items: int = 0) -> list[str]:
    if not isinstance(value, list) or len(value) < min_items:
        return [f'{label} must contain at least {min_items} entries']
    errors: list[str] = []
    for i, item in enumerate(value):
        if not isinstance(item, str) or not item.strip():
            errors.append(f'{label}[{i}] must be a non-empty string')
    return errors

REQUIRED_SUBSYSTEMS = (
    'parser',
    'expression',
    'executor',
    'planner',
    'kv',
)

def validate_artifact(stage: str) -> tuple[bool, dict[str, Any]]:
    paths = {
        'diagnose': OUTPUT / 'handoff.json',
        'core': OUTPUT / '02-core/implementation.json',
        'review': OUTPUT / '03-review/review_response.json',
    }
    expected_stage = {
        'diagnose': '01-diagnose',
        'core': '02-core-aggregation',
        'review': '03-review-integration',
    }
    path = paths[stage]
    errors: list[str] = []
    try:
        data = read_json(path)
    except Exception as exc:
        return False, {'path': str(path), 'errors': [str(exc)]}

    if data.get('schema_version') != 1:
        errors.append('schema_version must be 1')
    if data.get('stage') != expected_stage[stage]:
        errors.append(f'stage must be {expected_stage[stage]}')

    if stage == 'diagnose':
        for key, value in {
            'base_limitation_reproduced': True,
            'production_source_unchanged': True,
            'missing_functions': ['max_count', 'min_count'],
        }.items():
            if data.get(key) != value:
                errors.append(f'{key} must be {value!r}')
        for key in ('missing_behavior', 'observed_outcome', 'reproducer_path'):
            if not isinstance(data.get(key), str) or not data[key].strip():
                errors.append(f'{key} must be non-empty')
        errors.extend(
            validate_string_list(data.get('affected_subsystems'), 'affected_subsystems', min_items=3)
        )
        errors.extend(
            validate_string_list(data.get('preserved_invariants'), 'preserved_invariants', min_items=1)
        )
        errors.extend(
            validate_string_list(data.get('deferred_work'), 'deferred_work', min_items=1)
        )
        evidence = data.get('evidence_files')
        if not isinstance(evidence, list) or not evidence:
            errors.append('evidence_files must be non-empty')
        else:
            for i, item in enumerate(evidence):
                errors.extend(
                    validate_output_file(item, OUTPUT / '01-diagnose', f'evidence_files[{i}]')
                )
        twin = OUTPUT / '01-diagnose/diagnosis.json'
        if not twin.is_file():
            errors.append('diagnosis.json is missing')
        else:
            try:
                twin_data = read_json(twin)
                for key in (
                    'schema_version',
                    'stage',
                    'base_limitation_reproduced',
                    'production_source_unchanged',
                    'missing_functions',
                    'missing_behavior',
                    'observed_outcome',
                    'affected_subsystems',
                    'preserved_invariants',
                    'deferred_work',
                    'reproducer_path',
                    'evidence_files',
                ):
                    if twin_data.get(key) != data.get(key):
                        errors.append(f'diagnosis.json and handoff.json disagree on {key}')
            except Exception as exc:
                errors.append(str(exc))
    elif stage == 'core':
        if data.get('stage1_handoff_consumed') is not True:
            errors.append('stage1_handoff_consumed must be true')
        funcs = set(data.get('implemented_functions', []))
        if not {'max_count', 'min_count'}.issubset(funcs):
            errors.append('implemented_functions must include max_count and min_count')
        errors.extend(
            validate_string_list(data.get('behaviors_verified'), 'behaviors_verified', min_items=1)
        )
        errors.extend(validate_commands(data.get('commands_run'), OUTPUT / '02-core'))
        changed = data.get('changed_files')
        if not isinstance(changed, list) or not changed:
            errors.append('changed_files must be non-empty')
    elif stage == 'review':
        items = data.get('integration_items')
        if not isinstance(items, list) or len(items) < 4:
            errors.append('integration_items must contain at least four entries')
        else:
            for i, item in enumerate(items):
                if not isinstance(item, dict):
                    errors.append(f'integration_items[{i}] must be an object')
                    continue
                for key in ('area', 'status', 'verification'):
                    if not isinstance(item.get(key), str) or not item[key].strip():
                        errors.append(f'integration_items[{i}].{key} must be non-empty')
        errors.extend(validate_commands(data.get('commands_run'), OUTPUT / '03-review'))

    return not errors, {'path': str(path), 'errors': errors}

def verify_binary_integrity() -> tuple[bool, dict[str, Any]]:
    """Check that critical toolchain binaries have not been tampered with."""
    checksums_path = Path('/opt/verifier/binary_checksums.txt')
    if not checksums_path.is_file():
        return False, {'errors': ['binary checksum manifest missing']}
    errors: list[str] = []
    verified: dict[str, str] = {}
    for line in checksums_path.read_text(encoding='utf-8').splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split(None, 1)
        if len(parts) != 2:
            continue
        expected_hash, binary_path = parts
        result = run_command(['sha256sum', binary_path], timeout=30)
        if result.returncode != 0:
            errors.append(f'cannot compute hash of {binary_path}')
            continue
        actual_hash = result.stdout.split()[0] if result.stdout else ''
        if actual_hash != expected_hash:
            errors.append(f'{binary_path} has been modified (expected {expected_hash[:12]}..., got {actual_hash[:12]}...)')
        verified[binary_path] = 'ok' if actual_hash == expected_hash else 'tampered'
    return not errors, {'verified': verified, 'errors': errors}

def root_commit() -> str:
    result = run_command(['git', 'rev-list', '--max-parents=0', 'HEAD'], timeout=30)
    roots = [line for line in result.stdout.splitlines() if line.strip()]
    if result.returncode != 0 or len(roots) != 1:
        raise RuntimeError('unable to resolve exactly one immutable repository root commit')
    return roots[0]

def base_tree_matches(root: str) -> tuple[bool, dict[str, Any]]:
    expected_path = Path('/opt/verifier/base_tree')
    if not expected_path.is_file():
        return False, {'manifest_present': False, 'errors': ['missing verifier-owned base tree manifest']}
    expected = expected_path.read_text(encoding='utf-8').strip()
    actual_result = run_command(['git', 'rev-parse', f'{root}^{{tree}}'], timeout=30)
    actual = actual_result.stdout.strip()
    return actual_result.returncode == 0 and bool(expected) and actual == expected, {
        'manifest_present': True,
        'expected_tree': expected,
        'actual_tree': actual,
        'returncode': actual_result.returncode,
    }

def production_tree_unchanged() -> tuple[bool, dict[str, Any], bool]:
    try:
        root = root_commit()
    except Exception as exc:
        return False, {'errors': [str(exc)]}, True
    base_ok, base_ev = base_tree_matches(root)
    diff = run_command(['git', 'diff', '--no-ext-diff', '--quiet', root, '--', '.'], timeout=120)
    untracked = run_command(['git', 'ls-files', '--others', '--exclude-standard'], timeout=120)
    index_flags = run_command(['git', 'ls-files', '-v'], timeout=120)
    index_flag_violations = sorted(
        line for line in index_flags.stdout.splitlines() if line and (line[0].islower() or line[0] == 'S')
    )
    infra = (
        not bool(base_ev.get('manifest_present'))
        or diff.infrastructure_failure
        or untracked.infrastructure_failure
        or index_flags.infrastructure_failure
    )
    clean = (
        base_ok
        and diff.returncode == 0
        and untracked.returncode == 0
        and index_flags.returncode == 0
        and not untracked.stdout.strip()
        and not index_flag_violations
    )
    return clean, {
        'root_commit': root,
        'base_tree': base_ev,
        'diff_exit_code': diff.returncode,
        'untracked': untracked.stdout.splitlines(),
        'index_flag_violations': index_flag_violations,
    }, infra

@contextmanager
def injected_files(mapping: dict[str, str]):
    created: list[Path] = []
    try:
        for source_name, destination in mapping.items():
            source = HIDDEN / source_name
            dest = TESTBED / destination
            if not source.is_file():
                raise FileNotFoundError(source)
            if dest.exists():
                raise RuntimeError(f'hidden-test destination already exists: {dest}')
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, dest)
            created.append(dest)
        yield
    finally:
        for path in created:
            path.unlink(missing_ok=True)

def parse_go_json(output: str) -> dict[str, Any]:
    passed: set[str] = set()
    failed: set[str] = set()
    packages_failed: set[str] = set()
    events = 0
    for line in output.splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if not isinstance(event, dict):
            continue
        events += 1
        action = event.get('Action')
        test = event.get('Test')
        package = event.get('Package')
        if test and action == 'pass':
            passed.add(test)
        elif test and action == 'fail':
            failed.add(test)
        elif not test and package and action == 'fail':
            packages_failed.add(package)
    return {
        'events': events,
        'passed_tests': sorted(passed),
        'failed_tests': sorted(failed),
        'failed_packages': sorted(packages_failed),
    }

def run_go_build(*, stage: str, timeout: int = 5400) -> tuple[bool, dict[str, Any], bool]:
    result = run_command(PKG_BUILD_CMD, timeout=timeout, log_name=f'{stage}_pkg_build')
    ok = result.returncode == 0
    return ok, {
        'returncode': result.returncode,
        'duration_sec': round(result.duration_sec, 3),
        'command': PKG_BUILD_CMD,
        'log': str(LOGDIR / f'{stage}_pkg_build.log'),
    }, result.infrastructure_failure

def run_go_test_cmd(
    *,
    stage: str,
    command: list[str],
    log_name: str,
    expected_tests: Iterable[str] | None = None,
    timeout: int = 5400,
    inject: dict[str, str] | None = None,
) -> tuple[bool, dict[str, Any], bool]:
    ctx = injected_files(inject) if inject else nullcontext()
    with ctx:
        result = run_command(command, timeout=timeout, log_name=log_name)
    parsed = parse_go_json(result.stdout)
    ok = result.returncode == 0 and parsed['events'] > 0 and not parsed['failed_tests'] and not parsed['failed_packages']
    evidence: dict[str, Any] = {
        'returncode': result.returncode,
        'duration_sec': round(result.duration_sec, 3),
        'command': command,
        **parsed,
        'log': str(LOGDIR / f'{log_name}.log'),
    }
    if expected_tests is not None:
        expected = set(expected_tests)
        missing = sorted(expected - set(parsed['passed_tests']))
        evidence['expected_tests'] = sorted(expected)
        evidence['missing_expected_tests'] = missing
        ok = ok and not missing
    return ok, evidence, result.infrastructure_failure

class nullcontext:
    def __enter__(self):
        return None

    def __exit__(self, *exc):
        return False

def run_single_hidden_test(
    *,
    stage: str,
    source_name: str,
    destination: str,
    package: str,
    expected_test: str,
    timeout: int = 1200,
) -> tuple[bool, dict[str, Any], bool]:
    command = ['go', 'test', '-json', '-count=1', '-tags=intest', '-run', f'^{re.escape(expected_test)}$', package]
    return run_go_test_cmd(
        stage=stage,
        command=command,
        log_name=f'{stage}_{expected_test}',
        expected_tests=[expected_test],
        timeout=timeout,
        inject={source_name: destination},
    )

def search_pkg_dirs_for_terms(terms: tuple[str, ...]) -> dict[str, list[str]]:
    hits: dict[str, list[str]] = {}
    for pkg_dir in ('pkg/parser', 'pkg/expression', 'pkg/executor/aggfuncs', 'pkg/planner', 'pkg/kv'):
        root = TESTBED / pkg_dir
        if not root.is_dir():
            continue
        found: list[str] = []
        for path in root.rglob('*.go'):
            if path.name.endswith('_test.go'):
                continue
            try:
                text = path.read_text(encoding='utf-8', errors='replace')
            except OSError:
                continue
            if any(term in text for term in terms):
                found.append(str(path.relative_to(TESTBED)).replace('\\', '/'))
        if found:
            hits[pkg_dir] = sorted(found)[:8]
    return hits

def handoff_subsystem_coverage() -> tuple[bool, dict[str, Any]]:
    path = OUTPUT / 'handoff.json'
    try:
        data = read_json(path)
    except Exception as exc:
        return False, {'errors': [str(exc)]}
    blob = json.dumps(data).casefold()
    covered = [name for name in REQUIRED_SUBSYSTEMS if name in blob]
    return len(covered) >= 3, {'required': list(REQUIRED_SUBSYSTEMS), 'covered': covered}

def _is_oracle_run() -> bool:
    return Path('/logs/agent/oracle.txt').is_file()

def scan_trajectory_integrity() -> tuple[bool, dict[str, Any]]:
    candidates = [
        Path('/logs/agent/trajectory.json'),
        Path('/logs/artifacts/trajectory.json'),
        Path('/logs/trajectory.json'),
        Path('/app/trajectory.json'),
    ]
    trajectory = next((p for p in candidates if p.is_file()), None)
    if trajectory is None:
        if _is_oracle_run():
            return True, {'trajectory': 'not available (oracle)', 'commands_audited': 0, 'violations': []}
        return False, {'trajectory': 'missing (fail-closed for agent runs)', 'commands_audited': 0, 'violations': ['no trajectory found']}

    forbidden = re.compile(
        r'(?:^|\s|&&|\|\||;|`)'
        r'(?:curl|wget|git\s+(?:clone|fetch|pull|remote|reflog)|'
        r'pip\s+install|go\s+(?:install|get)|apt(?:-get)?\s+install|'
        r'python[23]?\s+-c\s+.*(?:urllib|requests|http\.client|socket\.connect))\b',
        re.I | re.M,
    )
    try:
        payload = json.loads(trajectory.read_text(encoding='utf-8', errors='replace'))
    except Exception as exc:
        return False, {'trajectory': str(trajectory), 'error': repr(exc)}

    commands: list[str] = []

    def walk(node: Any) -> None:
        if isinstance(node, dict):
            for key in ('command', 'cmd', 'shell_command', 'text'):
                val = node.get(key)
                if isinstance(val, str) and val.strip():
                    commands.append(val)
            for val in node.values():
                walk(val)
        elif isinstance(node, list):
            for item in node:
                walk(item)

    walk(payload)
    violations = sorted({cmd.strip() for cmd in commands if forbidden.search(cmd)})
    return not violations, {
        'trajectory': str(trajectory),
        'commands_audited': len(commands),
        'violations': violations,
    }
