#!/usr/bin/env python3

import json
import os
import shutil
import sys
from pathlib import Path

stage = os.environ.get('TASK_STAGE', sys.argv[1] if len(sys.argv) > 1 else 'unknown')
RESULT = Path(os.environ.get('RESULT_DIR', '/logs/verifier'))
DEST = RESULT / 'judge_inputs'
DEST.mkdir(parents=True, exist_ok=True)

payload = {
    'task': 'tidb-min-max-count-aggregation',
    'stage': stage,
    'agent_output': str(RESULT / 'agent_output'),
    'patch': str(RESULT / 'patch.diff'),
    'changed_files': str(RESULT / 'changed_files.txt'),
}
(DEST / 'judge_context.json').write_text(json.dumps(payload, indent=2) + '\n', encoding='utf-8')
for name in ('reward.json', 'reward-details.json', 'test_output.log'):
    src = RESULT / name
    if src.is_file():
        shutil.copy2(src, DEST / name)
print(json.dumps(payload))
