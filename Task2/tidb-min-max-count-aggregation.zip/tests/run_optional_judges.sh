#!/usr/bin/env bash
set -uo pipefail

stage="${1:?stage name required}"
RESULT_DIR="${RESULT_DIR:-/logs/verifier}"
JUDGE_MODEL="${JUDGE_MODEL:-gemini/gemini-3.6-flash}"
JUDGE_REPEATS="${JUDGE_REPEATS:-2}"
JUDGE_TIMEOUT="${JUDGE_TIMEOUT_SEC:-300}"

judge_status() {
  local status="$1" reason="$2"
  printf '{"available":%s,"applicable":true,"reason":"%s","binary_reward_affected":false}\n' \
    "$status" "$reason" > "$RESULT_DIR/judge_status.json"
}

if ! python3 -c "import rewardkit" 2>/dev/null; then
  judge_status "false" "rewardkit not available"
  exit 0
fi

if [ -z "${GEMINI_API_KEY:-}" ]; then
  judge_status "false" "GEMINI_API_KEY not set"
  exit 0
fi

judge_status "true" "judges executed"

for dimension in process validity task_quality merge_readiness; do
  toml="/tests/${dimension}/judge.toml"
  if [ ! -f "$toml" ]; then
    continue
  fi
  if [ "$dimension" = "merge_readiness" ]; then
    reward_file="$RESULT_DIR/reward.json"
    if [ -f "$reward_file" ]; then
      binary=$(python3 -c "import json;print(json.load(open('$reward_file')).get('binary_reward',0))")
      if [ "$binary" != "1" ] && [ "$binary" != "1.0" ]; then
        continue
      fi
    fi
  fi
  python3 -c "
import json, sys
from pathlib import Path
try:
    from rewardkit import judge
    result = judge.run_from_toml(
        toml_path='$toml',
        model='$JUDGE_MODEL',
        repeats=int('$JUDGE_REPEATS'),
        timeout=int('$JUDGE_TIMEOUT'),
    )
    Path('$RESULT_DIR/${dimension}_judge.json').write_text(json.dumps(result, indent=2))
except Exception as e:
    Path('$RESULT_DIR/${dimension}_judge.json').write_text(json.dumps({'error': str(e), 'score': None}))
" 2>/dev/null || true
done
exit 0
