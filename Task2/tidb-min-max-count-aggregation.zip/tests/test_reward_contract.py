"""Verifier self-validation: asserts weight sums, critical gate logic, and reward contract."""
from __future__ import annotations

import pytest

from stage_check import (
    ARTIFACT_CHECK,
    BEHAVIOR_CHECK,
    CHECK_SPECS,
    CRITICAL_CHECKS,
    INTEGRITY_CHECK,
    build_payload,
)

@pytest.mark.parametrize("stage", list(CHECK_SPECS.keys()))
def test_weights_sum_to_one(stage: str):
    total = sum(CHECK_SPECS[stage].values())
    assert abs(total - 1.0) < 1e-6, f"Stage {stage} weights sum to {total}, not 1.0"

@pytest.mark.parametrize("stage", list(CHECK_SPECS.keys()))
def test_behavior_check_exists(stage: str):
    assert BEHAVIOR_CHECK[stage] in CHECK_SPECS[stage]

@pytest.mark.parametrize("stage", list(CHECK_SPECS.keys()))
def test_artifact_check_exists(stage: str):
    assert ARTIFACT_CHECK[stage] in CHECK_SPECS[stage]

@pytest.mark.parametrize("stage", list(CHECK_SPECS.keys()))
def test_integrity_check_exists(stage: str):
    assert INTEGRITY_CHECK[stage] in CHECK_SPECS[stage]

@pytest.mark.parametrize("stage", list(CHECK_SPECS.keys()))
def test_critical_checks_subset_of_specs(stage: str):
    for cid in CRITICAL_CHECKS[stage]:
        assert cid in CHECK_SPECS[stage], f"Critical check {cid} not in CHECK_SPECS[{stage}]"

@pytest.mark.parametrize("stage", list(CHECK_SPECS.keys()))
def test_critical_checks_include_build_and_behavior(stage: str):
    crit = CRITICAL_CHECKS[stage]
    assert "pkg_build" in crit, f"pkg_build must be critical in {stage}"
    assert BEHAVIOR_CHECK[stage] in crit, f"behavior check must be critical in {stage}"

@pytest.mark.parametrize("stage", list(CHECK_SPECS.keys()))
def test_all_pass_gives_binary_one(stage: str):
    checks = [
        {"check_id": cid, "weight": w, "passed": True, "evidence": {}}
        for cid, w in CHECK_SPECS[stage].items()
    ]
    payload = build_payload(stage, checks, infra_seen=False, trajectory_ok=True)
    assert payload["binary_reward"] == 1
    assert payload["training_score"] == 1.0
    assert payload["valid_trial"] == 1

@pytest.mark.parametrize("stage", list(CHECK_SPECS.keys()))
def test_behavior_fail_caps_reward(stage: str):
    checks = [
        {
            "check_id": cid,
            "weight": w,
            "passed": cid != BEHAVIOR_CHECK[stage],
            "evidence": {},
        }
        for cid, w in CHECK_SPECS[stage].items()
    ]
    payload = build_payload(stage, checks, infra_seen=False, trajectory_ok=True)
    assert payload["binary_reward"] == 0
    assert payload["reward"] <= 0.29
    assert payload["training_score"] <= 0.29

@pytest.mark.parametrize("stage", list(CHECK_SPECS.keys()))
def test_integrity_failure_zeros_all(stage: str):
    checks = [
        {"check_id": cid, "weight": w, "passed": True, "evidence": {}}
        for cid, w in CHECK_SPECS[stage].items()
    ]
    payload = build_payload(stage, checks, infra_seen=False, trajectory_ok=False)
    assert payload["binary_reward"] == 0
    assert payload["reward"] == 0.0
    assert payload["training_score"] == 0.0
    assert payload["valid_trial"] == 0

@pytest.mark.parametrize("stage", list(CHECK_SPECS.keys()))
def test_infra_failure_zeros_all(stage: str):
    checks = [
        {"check_id": cid, "weight": w, "passed": True, "evidence": {}}
        for cid, w in CHECK_SPECS[stage].items()
    ]
    payload = build_payload(stage, checks, infra_seen=True, trajectory_ok=True)
    assert payload["binary_reward"] == 0
    assert payload["reward"] == 0.0
    assert payload["training_score"] == 0.0
    assert payload["valid_trial"] == 0
