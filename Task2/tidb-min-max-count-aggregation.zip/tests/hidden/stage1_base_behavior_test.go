package aggregation

import (
	"testing"

	"github.com/pingcap/tidb/pkg/expression"
	"github.com/pingcap/tidb/pkg/parser/mysql"
	"github.com/pingcap/tidb/pkg/types"
	"github.com/pingcap/tidb/pkg/util/mock"
	"github.com/stretchr/testify/require"
)

func TestVerifierStage1BaseLacksMaxMinCountAggregates(t *testing.T) {
	ctx := mock.NewContext()
	col := &expression.Column{
		Index:   0,
		RetType: types.NewFieldType(mysql.TypeLonglong),
	}

	for _, name := range []string{"max_count", "min_count"} {
		_, err := NewAggFuncDesc(ctx, name, []expression.Expression{col}, false)
		require.Error(t, err, "base revision must not support %s aggregate", name)
	}
}
