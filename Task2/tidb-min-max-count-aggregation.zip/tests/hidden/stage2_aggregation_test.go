package aggregation

import (
	"math/rand"
	"testing"

	"github.com/pingcap/tidb/pkg/expression"
	"github.com/pingcap/tidb/pkg/parser/mysql"
	"github.com/pingcap/tidb/pkg/types"
	"github.com/pingcap/tidb/pkg/util/chunk"
	"github.com/stretchr/testify/require"
)

func refExtremeCount(vals []int64, isMax bool) int64 {
	if len(vals) == 0 {
		return 0
	}
	ext := vals[0]
	for _, v := range vals[1:] {
		if isMax {
			if v > ext {
				ext = v
			}
		} else if v < ext {
			ext = v
		}
	}
	var c int64
	for _, v := range vals {
		if v == ext {
			c++
		}
	}
	return c
}

func TestVerifierStage2MaxMinCountAggregationBehavior(t *testing.T) {
	s := createAggFuncSuite()
	col := &expression.Column{
		Index:   0,
		RetType: types.NewFieldType(mysql.TypeLonglong),
	}

	maxDesc, err := NewAggFuncDesc(s.ctx, "max_count", []expression.Expression{col}, false)
	require.NoError(t, err)
	minDesc, err := NewAggFuncDesc(s.ctx, "min_count", []expression.Expression{col}, false)
	require.NoError(t, err)

	t.Run("BasicMixed", func(t *testing.T) {
		maxFunc := maxDesc.GetAggFunc(s.ctx)
		minFunc := minDesc.GetAggFunc(s.ctx)
		maxEval := maxFunc.CreateContext(s.ctx)
		minEval := minFunc.CreateContext(s.ctx)

		chk := chunk.NewChunkWithCapacity([]*types.FieldType{col.RetType}, 5)
		chk.AppendInt64(0, 1)
		chk.AppendInt64(0, 3)
		chk.AppendNull(0)
		chk.AppendInt64(0, 3)
		chk.AppendInt64(0, 2)

		sc := s.ctx.GetSessionVars().StmtCtx
		for i := range chk.NumRows() {
			require.NoError(t, maxFunc.Update(maxEval, sc, chk.GetRow(i)))
			require.NoError(t, minFunc.Update(minEval, sc, chk.GetRow(i)))
		}

		maxResult := maxFunc.GetResult(maxEval)
		minResult := minFunc.GetResult(minEval)
		require.Equal(t, int64(2), maxResult.GetInt64())
		require.Equal(t, int64(1), minResult.GetInt64())
	})

	t.Run("AllNulls", func(t *testing.T) {
		maxFunc := maxDesc.GetAggFunc(s.ctx)
		minFunc := minDesc.GetAggFunc(s.ctx)
		maxEval := maxFunc.CreateContext(s.ctx)
		minEval := minFunc.CreateContext(s.ctx)

		chk := chunk.NewChunkWithCapacity([]*types.FieldType{col.RetType}, 3)
		chk.AppendNull(0)
		chk.AppendNull(0)
		chk.AppendNull(0)

		sc := s.ctx.GetSessionVars().StmtCtx
		for i := range chk.NumRows() {
			require.NoError(t, maxFunc.Update(maxEval, sc, chk.GetRow(i)))
			require.NoError(t, minFunc.Update(minEval, sc, chk.GetRow(i)))
		}

		maxResult := maxFunc.GetResult(maxEval)
		minResult := minFunc.GetResult(minEval)
		require.Equal(t, int64(0), maxResult.GetInt64())
		require.Equal(t, int64(0), minResult.GetInt64())
	})

	t.Run("SingleElement", func(t *testing.T) {
		maxFunc := maxDesc.GetAggFunc(s.ctx)
		minFunc := minDesc.GetAggFunc(s.ctx)
		maxEval := maxFunc.CreateContext(s.ctx)
		minEval := minFunc.CreateContext(s.ctx)

		chk := chunk.NewChunkWithCapacity([]*types.FieldType{col.RetType}, 1)
		chk.AppendInt64(0, 42)

		sc := s.ctx.GetSessionVars().StmtCtx
		require.NoError(t, maxFunc.Update(maxEval, sc, chk.GetRow(0)))
		require.NoError(t, minFunc.Update(minEval, sc, chk.GetRow(0)))

		maxResult := maxFunc.GetResult(maxEval)
		minResult := minFunc.GetResult(minEval)
		require.Equal(t, int64(1), maxResult.GetInt64())
		require.Equal(t, int64(1), minResult.GetInt64())
	})

	t.Run("AllSameValue", func(t *testing.T) {
		maxFunc := maxDesc.GetAggFunc(s.ctx)
		minFunc := minDesc.GetAggFunc(s.ctx)
		maxEval := maxFunc.CreateContext(s.ctx)
		minEval := minFunc.CreateContext(s.ctx)

		chk := chunk.NewChunkWithCapacity([]*types.FieldType{col.RetType}, 4)
		chk.AppendInt64(0, 7)
		chk.AppendInt64(0, 7)
		chk.AppendInt64(0, 7)
		chk.AppendInt64(0, 7)

		sc := s.ctx.GetSessionVars().StmtCtx
		for i := range chk.NumRows() {
			require.NoError(t, maxFunc.Update(maxEval, sc, chk.GetRow(i)))
			require.NoError(t, minFunc.Update(minEval, sc, chk.GetRow(i)))
		}

		maxResult := maxFunc.GetResult(maxEval)
		minResult := minFunc.GetResult(minEval)
		require.Equal(t, int64(4), maxResult.GetInt64())
		require.Equal(t, int64(4), minResult.GetInt64())
	})

	t.Run("NegativeNumbers", func(t *testing.T) {
		maxFunc := maxDesc.GetAggFunc(s.ctx)
		minFunc := minDesc.GetAggFunc(s.ctx)
		maxEval := maxFunc.CreateContext(s.ctx)
		minEval := minFunc.CreateContext(s.ctx)

		chk := chunk.NewChunkWithCapacity([]*types.FieldType{col.RetType}, 5)
		chk.AppendInt64(0, -3)
		chk.AppendInt64(0, -1)
		chk.AppendInt64(0, -3)
		chk.AppendInt64(0, -1)
		chk.AppendInt64(0, -1)

		sc := s.ctx.GetSessionVars().StmtCtx
		for i := range chk.NumRows() {
			require.NoError(t, maxFunc.Update(maxEval, sc, chk.GetRow(i)))
			require.NoError(t, minFunc.Update(minEval, sc, chk.GetRow(i)))
		}

		maxResult := maxFunc.GetResult(maxEval)
		require.Equal(t, int64(3), maxResult.GetInt64())

		minResult := minFunc.GetResult(minEval)
		require.Equal(t, int64(2), minResult.GetInt64())
	})

	t.Run("NullsInterspersed", func(t *testing.T) {
		maxFunc := maxDesc.GetAggFunc(s.ctx)
		minFunc := minDesc.GetAggFunc(s.ctx)
		maxEval := maxFunc.CreateContext(s.ctx)
		minEval := minFunc.CreateContext(s.ctx)

		chk := chunk.NewChunkWithCapacity([]*types.FieldType{col.RetType}, 7)
		chk.AppendNull(0)
		chk.AppendInt64(0, 5)
		chk.AppendNull(0)
		chk.AppendInt64(0, 5)
		chk.AppendNull(0)
		chk.AppendInt64(0, 3)
		chk.AppendNull(0)

		sc := s.ctx.GetSessionVars().StmtCtx
		for i := range chk.NumRows() {
			require.NoError(t, maxFunc.Update(maxEval, sc, chk.GetRow(i)))
			require.NoError(t, minFunc.Update(minEval, sc, chk.GetRow(i)))
		}

		maxResult := maxFunc.GetResult(maxEval)
		minResult := minFunc.GetResult(minEval)
		require.Equal(t, int64(2), maxResult.GetInt64())
		require.Equal(t, int64(1), minResult.GetInt64())
	})

	t.Run("RandomizedAgainstReference", func(t *testing.T) {
		rng := rand.New(rand.NewSource(0x5EEDC0DE))
		sc := s.ctx.GetSessionVars().StmtCtx
		for iter := range 400 {
			n := rng.Intn(40)
			chk := chunk.NewChunkWithCapacity([]*types.FieldType{col.RetType}, n+1)
			nonNull := make([]int64, 0, n)
			for range n {
				if rng.Intn(4) == 0 {
					chk.AppendNull(0)
					continue
				}
				v := int64(rng.Intn(11) - 5)
				chk.AppendInt64(0, v)
				nonNull = append(nonNull, v)
			}

			maxFunc := maxDesc.GetAggFunc(s.ctx)
			minFunc := minDesc.GetAggFunc(s.ctx)
			maxEval := maxFunc.CreateContext(s.ctx)
			minEval := minFunc.CreateContext(s.ctx)
			for i := range chk.NumRows() {
				require.NoError(t, maxFunc.Update(maxEval, sc, chk.GetRow(i)))
				require.NoError(t, minFunc.Update(minEval, sc, chk.GetRow(i)))
			}

			maxResult := maxFunc.GetResult(maxEval)
			minResult := minFunc.GetResult(minEval)
			require.Equal(t, refExtremeCount(nonNull, true), maxResult.GetInt64(),
				"iter=%d vals=%v max_count mismatch", iter, nonNull)
			require.Equal(t, refExtremeCount(nonNull, false), minResult.GetInt64(),
				"iter=%d vals=%v min_count mismatch", iter, nonNull)
		}
	})
}
