package aggregation

import (
	"testing"

	"github.com/pingcap/tidb/pkg/expression"
	"github.com/pingcap/tidb/pkg/kv"
	"github.com/pingcap/tidb/pkg/parser/mysql"
	"github.com/pingcap/tidb/pkg/types"
	"github.com/pingcap/tidb/pkg/util/mock"
	"github.com/pingcap/tipb/go-tipb"
	"github.com/stretchr/testify/require"
)

func TestVerifierStage3MaxMinCountDistributedIntegration(t *testing.T) {
	ctx := mock.NewContext()
	col := &expression.Column{
		Index:   0,
		RetType: types.NewFieldType(mysql.TypeLonglong),
	}

	t.Run("ProtobufExprTypeConversion", func(t *testing.T) {
		maxDesc, err := NewAggFuncDesc(ctx, "max_count", []expression.Expression{col}, false)
		require.NoError(t, err)
		minDesc, err := NewAggFuncDesc(ctx, "min_count", []expression.Expression{col}, false)
		require.NoError(t, err)

		require.Equal(t, tipb.ExprType_MaxCount, maxDesc.GetTiPBExpr(false),
			"max_count must convert to tipb.ExprType_MaxCount")
		require.Equal(t, tipb.ExprType_MinCount, minDesc.GetTiPBExpr(false),
			"min_count must convert to tipb.ExprType_MinCount")
	})

	t.Run("PushdownCompleteMode", func(t *testing.T) {
		for _, funcName := range []string{"max_count", "min_count"} {
			desc, err := NewAggFuncDesc(ctx, funcName, []expression.Expression{col}, false)
			require.NoError(t, err)
			desc.Mode = CompleteMode
			require.True(t,
				CheckAggPushDown(ctx.GetExprCtx().GetEvalCtx(), desc, kv.TiFlash),
				"%s should push down to TiFlash in CompleteMode", funcName)
		}
	})

	t.Run("PushdownPartial1Mode", func(t *testing.T) {
		for _, funcName := range []string{"max_count", "min_count"} {
			desc, err := NewAggFuncDesc(ctx, funcName, []expression.Expression{col}, false)
			require.NoError(t, err)
			desc.Mode = Partial1Mode
			require.True(t,
				CheckAggPushDown(ctx.GetExprCtx().GetEvalCtx(), desc, kv.TiFlash),
				"%s should push down to TiFlash in Partial1Mode", funcName)
		}
	})

	t.Run("NotPushdownTiKV", func(t *testing.T) {
		for _, funcName := range []string{"max_count", "min_count"} {
			desc, err := NewAggFuncDesc(ctx, funcName, []expression.Expression{col}, false)
			require.NoError(t, err)
			desc.Mode = CompleteMode
			require.False(t,
				CheckAggPushDown(ctx.GetExprCtx().GetEvalCtx(), desc, kv.TiKV),
				"%s must NOT push down to TiKV", funcName)
		}
	})

	t.Run("NotPushdownDedupMode", func(t *testing.T) {
		for _, funcName := range []string{"max_count", "min_count"} {
			desc, err := NewAggFuncDesc(ctx, funcName, []expression.Expression{col}, false)
			require.NoError(t, err)
			desc.Mode = DedupMode
			require.False(t,
				CheckAggPushDown(ctx.GetExprCtx().GetEvalCtx(), desc, kv.TiFlash),
				"%s must NOT push down in DedupMode", funcName)
		}
	})

	t.Run("NotPushdownFinalModeMultiArgs", func(t *testing.T) {
		countCol := &expression.Column{
			Index:   1,
			RetType: types.NewFieldType(mysql.TypeLonglong),
		}
		for _, funcName := range []string{"max_count", "min_count"} {
			desc, err := NewAggFuncDesc(ctx, funcName, []expression.Expression{col}, false)
			require.NoError(t, err)
			desc.Args = []expression.Expression{countCol, col}
			desc.Mode = FinalMode
			require.False(t,
				CheckAggPushDown(ctx.GetExprCtx().GetEvalCtx(), desc, kv.TiFlash),
				"%s must NOT push down in FinalMode with multiple args", funcName)
		}
	})

	t.Run("ReturnTypeIsInteger", func(t *testing.T) {
		for _, funcName := range []string{"max_count", "min_count"} {
			desc, err := NewAggFuncDesc(ctx, funcName, []expression.Expression{col}, false)
			require.NoError(t, err)
			require.NotNil(t, desc.RetTp, "%s must have a non-nil return type", funcName)
			require.Equal(t, mysql.TypeLonglong, desc.RetTp.GetType(),
				"%s return type must be LONGLONG (integer count)", funcName)
		}
	})
}
