package aggfuncs_test

import (
	"fmt"
	"math/rand"
	"strings"
	"testing"

	"github.com/pingcap/tidb/pkg/testkit"
)

func refFrameCount(vals []int, isMax bool) int {
	if len(vals) == 0 {
		return 0
	}
	ext := vals[0]
	for _, v := range vals[1:] {
		if isMax {
			if v > ext {
				ext = v
			}
		} else if v < ext {
			ext = v
		}
	}
	c := 0
	for _, v := range vals {
		if v == ext {
			c++
		}
	}
	return c
}

func TestVerifierWindowSlidingBehavior(t *testing.T) {
	store := testkit.CreateMockStore(t)
	tk := testkit.NewTestKit(t, store)
	tk.MustExec("use test")

	t.Run("FixedFrame", func(t *testing.T) {
		tk.MustExec("drop table if exists tw")
		tk.MustExec("create table tw(id int, a int)")
		tk.MustExec("insert into tw values (1,5),(2,7),(3,7),(4,3),(5,7),(6,null),(7,3)")

		tk.MustQuery(`
			select id,
				max_count(a) over (order by id rows between 2 preceding and current row),
				min_count(a) over (order by id rows between 2 preceding and current row)
			from tw order by id;
		`).Check(testkit.Rows(
			"1 1 1",
			"2 1 1",
			"3 2 1",
			"4 2 1",
			"5 2 1",
			"6 1 1",
			"7 1 1",
		))
	})

	t.Run("RandomizedAgainstReference", func(t *testing.T) {
		rng := rand.New(rand.NewSource(0x1234ABCD))
		for iter := range 40 {
			const k = 2
			n := 6 + rng.Intn(12)

			type cell struct {
				null bool
				v    int
			}
			cells := make([]cell, n)
			var values strings.Builder
			for i := range n {
				if i > 0 {
					values.WriteString(",")
				}
				if rng.Intn(4) == 0 {
					cells[i] = cell{null: true}
					fmt.Fprintf(&values, "(%d,null)", i+1)
				} else {
					v := rng.Intn(9) - 4
					cells[i] = cell{v: v}
					fmt.Fprintf(&values, "(%d,%d)", i+1, v)
				}
			}

			tbl := fmt.Sprintf("tr%d", iter)
			tk.MustExec("drop table if exists " + tbl)
			tk.MustExec(fmt.Sprintf("create table %s(id int, a int)", tbl))
			tk.MustExec(fmt.Sprintf("insert into %s values %s", tbl, values.String()))

			expected := make([]string, n)
			for i := range n {
				lo := i - k
				if lo < 0 {
					lo = 0
				}
				frame := make([]int, 0, k+1)
				for j := lo; j <= i; j++ {
					if !cells[j].null {
						frame = append(frame, cells[j].v)
					}
				}
				expected[i] = fmt.Sprintf("%d %d %d", i+1,
					refFrameCount(frame, true), refFrameCount(frame, false))
			}

			query := fmt.Sprintf(`
				select id,
					max_count(a) over (order by id rows between %d preceding and current row),
					min_count(a) over (order by id rows between %d preceding and current row)
				from %s order by id;`, k, k, tbl)
			tk.MustQuery(query).Check(testkit.Rows(expected...))
		}
	})
}
