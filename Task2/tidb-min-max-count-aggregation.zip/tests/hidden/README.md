# Hidden verifier tests

Go sources in this directory are copied into `/testbed` at verifier runtime only. They exercise production TiDB packages and are removed after each command completes.

Do not reference these files from agent-facing instructions.
