#!/usr/bin/env python3

"""Deterministic verifier for tidb-min-max-count-aggregation (max_count / min_count aggregates)."""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

from verifier_lib import (
    CUMULATIVE_TEST_CMD,
    LOGDIR,
    OUTPUT,
    TESTBED,
    STAGE2_TEST_CMD,
    STAGE3_TEST_CMD,
    base_tree_matches,
    handoff_subsystem_coverage,
    production_tree_unchanged,
    root_commit,
    run_command,
    run_go_build,
    run_go_test_cmd,
    run_single_hidden_test,
    scan_trajectory_integrity,
    search_pkg_dirs_for_terms,
    validate_artifact,
    verify_binary_integrity,
)

CHECK_SPECS: dict[str, dict[str, float]] = {
    'diagnose': {
        'pkg_build': 0.25,
        'hidden_base_probe': 0.35,
        'diagnosis_artifact': 0.15,
        'production_source_unchanged': 0.15,
        'subsystem_map_signal': 0.10,
    },

    'core': {
        'pkg_build': 0.15,
        'core_go_test': 0.25,
        'hidden_aggregation': 0.30,
        'implementation_artifact': 0.15,
        'repository_integrity': 0.15,
    },

    'review': {
        'pkg_build': 0.12,
        'review_go_test': 0.18,
        'hidden_integration': 0.25,
        'hidden_window': 0.20,
        'cumulative_go_test': 0.10,
        'cumulative_integrity': 0.15,
    },
}

BEHAVIOR_CHECK = {
    'diagnose': 'hidden_base_probe',
    'core': 'hidden_aggregation',
    'review': 'hidden_integration',
}
ARTIFACT_CHECK = {
    'diagnose': 'diagnosis_artifact',
    'core': 'implementation_artifact',

    'review': 'cumulative_go_test',
}
INTEGRITY_CHECK = {
    'diagnose': 'production_source_unchanged',
    'core': 'repository_integrity',
    'review': 'cumulative_integrity',
}
CRITICAL_CHECKS = {
    'diagnose': {'pkg_build', 'hidden_base_probe'},
    'core': {'pkg_build', 'core_go_test', 'hidden_aggregation'},
    'review': {
        'pkg_build', 'review_go_test', 'hidden_integration',
        'hidden_window', 'cumulative_go_test',
    },
}

CORE_HIDDEN = {
    'stage2_aggregation_test.go': 'pkg/expression/aggregation/verifier_stage2_aggregation_test.go',
}
CORE_AGG_TEST = 'TestVerifierStage2MaxMinCountAggregationBehavior'

INTEGRATION_HIDDEN = {
    'stage3_integration_test.go': 'pkg/expression/aggregation/verifier_stage3_integration_test.go',
}
INTEGRATION_TEST = 'TestVerifierStage3MaxMinCountDistributedIntegration'

WINDOW_HIDDEN = {
    'stage3_window_test.go': 'pkg/executor/aggfuncs/verifier_stage3_window_test.go',
}
WINDOW_TEST = 'TestVerifierWindowSlidingBehavior'

def check_repository_integrity(stage: str) -> tuple[bool, dict[str, Any], bool]:
    errors: list[str] = []
    evidence: dict[str, Any] = {}

    binary_ok, binary_ev = verify_binary_integrity()
    evidence['binary_integrity'] = binary_ev
    if not binary_ok:
        errors.append('critical toolchain binaries have been tampered with')

    try:
        root = root_commit()
    except Exception as exc:
        return False, {'errors': [str(exc), *errors]}, True

    base_ok, base_ev = base_tree_matches(root)
    evidence['root_commit'] = root
    evidence['base_tree'] = base_ev
    manifest_missing = not bool(base_ev.get('manifest_present'))
    if not base_ok:
        errors.append('immutable base tree does not match verifier manifest')

    commands = {
        'tracked': run_command(
            ['git', 'diff', '--no-ext-diff', '--name-only', root, '--', '.'],
            timeout=120,
            log_name=f'{stage}_changed_tracked',
        ),
        'untracked': run_command(
            ['git', 'ls-files', '--others', '--exclude-standard'],
            timeout=120,
            log_name=f'{stage}_changed_untracked',
        ),
        'remotes': run_command(['git', 'remote'], timeout=30),
        'tags': run_command(['git', 'tag', '--list'], timeout=30),
    }
    infra = manifest_missing or any(result.infrastructure_failure for result in commands.values())

    changed_text = commands['tracked'].stdout + '\n' + commands['untracked'].stdout
    changed = sorted({line.strip() for line in changed_text.splitlines() if line.strip()})
    evidence.update(
        {
            'changed_files': changed,
            'remotes': commands['remotes'].stdout.splitlines(),
            'tags': commands['tags'].stdout.splitlines(),
        }
    )

    if commands['remotes'].stdout.strip() or commands['tags'].stdout.strip():
        errors.append('sanitized repository must not gain remotes or tags')

    forbidden: list[str] = []
    for relative in changed:
        parts = Path(relative).parts
        name = Path(relative).name
        if (
            (parts and parts[0] in {'tests', 'solution'})
            or name.startswith('reward')
            or name.startswith('oracle_upstream_private')
            or name.startswith('verifier_stage')
        ):
            forbidden.append(relative)
    if forbidden:
        errors.append('candidate changed protected or verifier-like paths')
    evidence['forbidden_paths'] = sorted(forbidden)
    evidence['errors'] = errors
    return not errors, evidence, infra

def check_implementation_terms() -> tuple[bool, dict[str, Any]]:
    hits = search_pkg_dirs_for_terms(('max_count', 'min_count', 'AggFuncMaxCount', 'AggFuncMinCount'))
    ok = bool(hits) and any('pkg/expression' in key or 'pkg/executor/aggfuncs' in key for key in hits)
    return ok, {'hits_by_package_root': hits}

def evaluate(stage: str) -> tuple[list[dict[str, Any]], bool, bool]:
    checks: list[dict[str, Any]] = []
    infra_seen = False
    trajectory_ok = True

    def add(
        check_id: str,
        result: tuple[bool, dict[str, Any], bool] | tuple[bool, dict[str, Any]],
    ) -> None:
        nonlocal infra_seen
        if len(result) == 2:
            passed, evidence = result
            infra = False
        else:
            passed, evidence, infra = result
        infra_seen = infra_seen or infra
        checks.append(
            {
                'check_id': check_id,
                'weight': CHECK_SPECS[stage][check_id],
                'passed': bool(passed),
                'evidence': evidence,
            }
        )

    traj_ok, traj_ev = scan_trajectory_integrity()
    trajectory_ok = traj_ok

    if stage == 'diagnose':
        add('pkg_build', run_go_build(stage='diagnose', timeout=3600))
        add(
            'hidden_base_probe',
            run_single_hidden_test(
                stage='diagnose',
                source_name='stage1_base_behavior_test.go',
                destination='pkg/expression/aggregation/verifier_stage1_base_test.go',
                package='./pkg/expression/aggregation',
                expected_test='TestVerifierStage1BaseLacksMaxMinCountAggregates',
                timeout=900,
            ),
        )
        add('diagnosis_artifact', validate_artifact('diagnose'))
        add('production_source_unchanged', production_tree_unchanged())
        add('subsystem_map_signal', handoff_subsystem_coverage())
    elif stage == 'core':
        add('pkg_build', run_go_build(stage='core', timeout=5400))
        add(
            'core_go_test',
            run_go_test_cmd(
                stage='core',
                command=STAGE2_TEST_CMD,
                log_name='core_go_test',
                timeout=5400,
                inject=CORE_HIDDEN,
            ),
        )
        add(
            'hidden_aggregation',
            run_single_hidden_test(
                stage='core',
                source_name='stage2_aggregation_test.go',
                destination=CORE_HIDDEN['stage2_aggregation_test.go'],
                package='./pkg/expression/aggregation',
                expected_test=CORE_AGG_TEST,
                timeout=1200,
            ),
        )
        add('implementation_artifact', validate_artifact('core'))
        add('repository_integrity', check_repository_integrity('core'))
        terms_ok, terms_ev = check_implementation_terms()
        checks.append(
            {
                'check_id': 'implementation_terms_advisory',
                'weight': 0.0,
                'passed': terms_ok,
                'evidence': terms_ev,
            }
        )
    else:
        add('pkg_build', run_go_build(stage='review', timeout=5400))
        add(
            'review_go_test',
            run_go_test_cmd(
                stage='review',
                command=STAGE3_TEST_CMD,
                log_name='review_go_test',
                timeout=5400,
                inject=INTEGRATION_HIDDEN,
            ),
        )
        add(
            'hidden_integration',
            run_single_hidden_test(
                stage='review',
                source_name='stage3_integration_test.go',
                destination=INTEGRATION_HIDDEN['stage3_integration_test.go'],
                package='./pkg/expression/aggregation',
                expected_test=INTEGRATION_TEST,
                timeout=1200,
            ),
        )
        add(
            'hidden_window',
            run_single_hidden_test(
                stage='review',
                source_name='stage3_window_test.go',
                destination=WINDOW_HIDDEN['stage3_window_test.go'],
                package='./pkg/executor/aggfuncs',
                expected_test=WINDOW_TEST,
                timeout=1800,
            ),
        )
        add(
            'cumulative_go_test',
            run_go_test_cmd(
                stage='review',
                command=CUMULATIVE_TEST_CMD,
                log_name='review_cumulative_go_test',
                timeout=5400,
                inject=CORE_HIDDEN,
            ),
        )

        review_artifact_ok, review_artifact_ev = validate_artifact('review')
        checks.append(
            {
                'check_id': 'review_artifact_advisory',
                'weight': 0.0,
                'passed': review_artifact_ok,
                'evidence': review_artifact_ev,
            }
        )
        add('cumulative_integrity', check_repository_integrity('review'))

    checks.append(
        {
            'check_id': 'trajectory_integrity',
            'weight': 0.0,
            'passed': trajectory_ok,
            'evidence': traj_ev,
        }
    )
    return checks, infra_seen, trajectory_ok

def write_result(payload: dict[str, Any], stage: str) -> None:
    LOGDIR.mkdir(parents=True, exist_ok=True)
    detailed = LOGDIR / f'{stage}_result.json'
    canonical = LOGDIR / 'reward.json'
    details = LOGDIR / 'reward-details.json'
    events = LOGDIR / 'reward-events.json'
    txt = LOGDIR / 'reward.txt'

    detailed.write_text(json.dumps(payload, indent=2) + '\n', encoding='utf-8')
    details.write_text(json.dumps(payload, indent=2) + '\n', encoding='utf-8')
    events.write_text(
        json.dumps(
            {
                'stage': stage,
                'completion_state': payload.get('completion_state'),
                'checks': payload.get('checks', []),
            },
            indent=2,
        )
        + '\n',
        encoding='utf-8',
    )
    txt.write_text(
        f"stage={stage} reward={payload['reward']} binary={payload['binary_reward']}\n",
        encoding='utf-8',
    )
    canonical.write_text(
        json.dumps(
            {
                'reward': float(payload['reward']),
                'binary_reward': float(payload['binary_reward']),
                'training_score': float(payload['training_score']),
                'valid_trial': float(payload['valid_trial']),
            },
            indent=2,
        )
        + '\n',
        encoding='utf-8',
    )

def build_payload(
    stage: str,
    checks: list[dict[str, Any]],
    infra_seen: bool,
    trajectory_ok: bool,
) -> dict[str, Any]:
    weighted = [c for c in checks if c['weight'] > 0]
    by_id = {check['check_id']: check for check in weighted}
    raw_reward = round(sum(check['weight'] for check in weighted if check['passed']), 6)

    behavior_ok = bool(by_id[BEHAVIOR_CHECK[stage]]['passed'])
    artifact_ok = bool(by_id[ARTIFACT_CHECK[stage]]['passed'])
    integrity_ok = bool(by_id[INTEGRITY_CHECK[stage]]['passed'])

    critical_ids = CRITICAL_CHECKS.get(stage, set())
    critical_all_pass = all(
        by_id[cid]['passed'] for cid in critical_ids if cid in by_id
    )
    all_pass = behavior_ok and artifact_ok and integrity_ok and critical_all_pass and not infra_seen and trajectory_ok

    if infra_seen or not integrity_ok or not trajectory_ok:
        reward = 0.0
        training_score = 0.0
        valid_trial = 0
        if infra_seen:
            completion_state = 'infrastructure_failure'
        elif not trajectory_ok:
            completion_state = 'trajectory_integrity_failure'
        else:
            completion_state = 'integrity_failure'
    elif not critical_all_pass:
        reward = min(raw_reward, 0.29)
        training_score = min(raw_reward, 0.29)
        valid_trial = 1
        completion_state = 'failed'
    else:
        reward = raw_reward if artifact_ok else min(raw_reward, 0.59)
        training_score = raw_reward
        valid_trial = 1
        completion_state = 'passed' if all_pass else 'failed'

    is_oracle = Path('/logs/agent/oracle.txt').is_file()
    nd_score = training_score if is_oracle else 0.0

    return {
        'stage': stage,
        'reward': reward,
        'binary_reward': 1 if all_pass else 0,
        'training_score': training_score,
        'deterministic_score': training_score,
        'non_deterministic_score': nd_score,
        'valid_trial': valid_trial,
        'promotion_eligible': reward >= 0.6 and valid_trial == 1,
        'completion_state': completion_state,
        'critical_checks_passed': critical_all_pass,
        'checks': checks,
    }

def invalid_result(stage: str, error: str) -> dict[str, Any]:
    return {
        'stage': stage,
        'reward': 0.0,
        'binary_reward': 0,
        'training_score': 0.0,
        'valid_trial': 0,
        'promotion_eligible': False,
        'completion_state': 'verifier_error',
        'checks': [],
        'error': error,
    }

def run(stage: str) -> int:
    if stage not in CHECK_SPECS:
        raise ValueError(f'unknown stage: {stage}')
    LOGDIR.mkdir(parents=True, exist_ok=True)
    checks, infra_seen, trajectory_ok = evaluate(stage)
    payload = build_payload(stage, checks, infra_seen, trajectory_ok)
    write_result(payload, stage)
    print(json.dumps(payload, indent=2))
    return 0 if payload['binary_reward'] == 1 else 2

if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', required=True)
    args = parser.parse_args()
    stage = args.stage
    try:
        exit_code = run(stage)
    except Exception as exc:
        payload = invalid_result(stage, repr(exc))
        write_result(payload, stage)
        print(json.dumps(payload, indent=2))
        exit_code = 2
    raise SystemExit(exit_code)
