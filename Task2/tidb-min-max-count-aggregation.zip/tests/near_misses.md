# Near-miss / shortcut battery

This task's behavioral gates are designed so that plausible partial or shortcut
"solutions" fail. The **seeded randomized property tests** (in
`tests/hidden/stage2_aggregation_test.go` and `tests/hidden/stage3_window_test.go`)
compare the implementation against an independent reference oracle over random
sizes, orderings, duplicates, NULLs, and negatives — which is what actually kills
these shortcuts at grade time. `tests/near_miss_selfcheck/` is a standalone,
dependency-free `go test` that *proves* the random data distribution
discriminates each near-miss below (run: `cd tests/near_miss_selfcheck && go test -v`).

| # | Near-miss / shortcut | What it gets wrong | Killed by |
|---|----------------------|--------------------|-----------|
| 1 | Count all non-NULL rows (`count(expr)`) | Ignores the extreme filter | Randomized compute test (any group with a non-extreme value); `count_all_non_null_rows` in the self-check |
| 2 | Count including NULLs (`count(*)`) | Does not exclude NULLs | `AllNulls` / `NullsInterspersed` fixed cases + randomized compute test; `count_including_nulls` |
| 3 | Return the extreme value, not its count | Returns `max/min`, not the count | Randomized compute test; `return_extreme_value_not_count` |
| 4 | Swap min and max | Wrong extreme | `BasicMixed`/`NegativeNumbers` + randomized; `swap_min_and_max` |
| 5 | Always return 1 (assume extremes are unique) | Off-by-one on ties/duplicates | `AllSameValue`/`BasicMixed` + randomized (many ties); `always_return_one` |
| 6 | Window count that does not decrement on eviction | Stale count when the extreme leaves the frame | `stage3_window_test.go` fixed frame + randomized-vs-reference sliding frames |
| 7 | Hard-coded answer table for the PR's fixed vectors | Passes only the published examples | Randomized property tests (seed-varied inputs the PR never used) |
| 8 | Copying upstream code under different Go symbol names | — (this is a *valid* solution) | Passes by design: gates use SQL names + the fixed `tipb` wire enum, not internal identifiers |

## Executed evidence

Run the standalone discrimination proof:

```bash
cd tests/near_miss_selfcheck && go test -v
```

Each near-miss line reports the number of random checks (out of 10000) on which
the shortcut disagrees with the correct reference; all are non-zero, so the
hidden tests' distribution would fail each shortcut.

## Not yet covered (known gap)

There is no fault-injection harness that applies each broken *implementation* to
the real TiDB tree and records the resulting `reward.json` (a full seeded-mutation
run). The self-check proves the test *inputs* discriminate the shortcuts; an
end-to-end mutation battery with recorded rewards would be the stronger form.
