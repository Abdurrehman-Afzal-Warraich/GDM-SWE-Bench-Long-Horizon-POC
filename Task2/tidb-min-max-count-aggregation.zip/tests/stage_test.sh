#!/usr/bin/env bash
set -uo pipefail

stage="${1:?stage name required}"
RESULT_DIR="${RESULT_DIR:-/logs/verifier}"
mkdir -p "$RESULT_DIR"

python3 /tests/stage_check.py --stage "$stage" > "$RESULT_DIR/test_output.log" 2>&1
python3 /tests/fallback_reward.py "$RESULT_DIR" "$stage"

git -C /testbed diff --binary > "$RESULT_DIR/patch.diff" 2>/dev/null || true
{
  git -C /testbed diff --name-only
  git -C /testbed diff --cached --name-only
  git -C /testbed ls-files --others --exclude-standard
  git -C /testbed ls-files --deleted
} | sort -u > "$RESULT_DIR/changed_files.txt" 2>/dev/null || true
cp -a /app/output "$RESULT_DIR/agent_output" 2>/dev/null || true

if [ -f /logs/agent/oracle.txt ]; then
  printf '%s\n' '{"available":false,"applicable":false,"reason":"oracle run - judges skipped","binary_reward_affected":false}' > "$RESULT_DIR/judge_status.json"
else
  TASK_FAMILY="tidb-min-max-count-aggregation" TASK_STAGE="$stage" \
    python3 /tests/stage_judge_inputs.py || true
  if [ "${RUN_LLM_JUDGES:-0}" = "1" ]; then
    bash /tests/run_optional_judges.sh "$stage" || true
  else
    printf '%s\n' '{"available":false,"applicable":true,"reason":"RUN_LLM_JUDGES not set","binary_reward_affected":false}' > "$RESULT_DIR/judge_status.json"
  fi
fi
exit 0
