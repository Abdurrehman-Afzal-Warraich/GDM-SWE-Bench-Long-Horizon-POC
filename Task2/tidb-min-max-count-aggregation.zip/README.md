# tidb-min-max-count-aggregation — Tier 2 Stateful Task

Harbor multi-step task derived from TiDB PR **69642** (`max_count` / `min_count`
aggregate functions). The reference PR is decomposed into two disjoint
production slices so that each implementation stage does real, distinctly-graded
engineering work.

## Flow

```mermaid
flowchart LR
  S1[01-diagnose] --> S2[02-core-aggregation]
  S2 --> S3[03-review-integration]
  S1 --> V1[Verifier: base probe + go build]
  S2 --> V2[Verifier: local execution — compute + sliding window]
  S3 --> V3[Verifier: distributed integration — pushdown + protobuf + cumulative rerun]
```

## Repository state

| Field | Value |
|-------|-------|
| Repository | `pingcap/tidb` |
| Base commit | `7d70c1c438198658815e3510027839bfd298274f` (squash-merge parent of PR #69642) |
| Upstream head | `5d6fdbe6f5502ecb86a060b6d9719aeb7bf826a9` (PR #69642 squash-merge) |
| Language | Go |

The base commit is deliberately the merge parent of the squash-merge, so
`git diff base upstream_head` reproduces exactly the PR's 35 changed files with
no unrelated changes; the two stage slices partition those 35 files
(`stage2 ∪ stage3 == full diff`, disjoint), asserted at image-build time.

The Docker image contains a sanitized single-commit `/testbed` tree and two
encrypted upstream diff slices under `/opt/oracle/`. Only the protected Oracle
private key can decrypt them.

## Environment & hermeticity

- **Base images are digest-pinned** for reproducibility: `golang:1.25-bookworm`
  and `python:3.12-bookworm` (verifier venv) are both pinned by `@sha256:`.
- **Go toolchain** is `GOTOOLCHAIN=local` on Go 1.25 (TiDB's `go.mod` requires
  `go 1.25.10`; the pinned image ships a compatible patch release, so no
  toolchain download ever occurs).
- **`pkg/parser` is a separate Go module** (`github.com/pingcap/tidb/pkg/parser`,
  wired into the main module via a `replace` directive). It is built in its own
  module directory; the main module compiles the modified parser through the
  replace directive.
- **Offline (hermetic) grading.** At image-build time the Go module cache is
  warmed by *compiling* the graded packages and their test binaries (main module
  **and** `pkg/parser`) with `go build` / `go test -run '^$'` — the same approach
  as the etcd task, pulling exactly the build+test dependencies the oracle and
  verifier need. Warming happens **before** the base commit, so any `go.sum`
  additions land in the committed base tree and the base worktree stays clean.
  The full oracle passes with networking disabled (`--network none`).

## Stages

1. **Diagnose** — Confirm the base tree lacks the aggregates; produce handoff
   JSON; do not edit production code.
2. **Core implementation (local execution)** — Parser, expression/aggregation
   descriptors and pushdown-eligibility rules, executor aggfuncs (row
   aggregation, sliding window, spill), and serialization. Behavioral gates:
   row-count correctness and sliding-window behavior.
3. **Distributed integration** — Protobuf `ExprType` conversion, KV coprocessor
   whitelist, and MPP planner wiring. Behavioral gates: pushdown eligibility and
   protobuf conversion, plus a cumulative re-run of Stage 2 behavior.

## Oracle design (per-stage slices)

At image build time the base→head diff is split by disjoint pathspecs into two
slices, and the build asserts that their union reproduces the full PR
changed-file set exactly:

- **Stage 2 slice** — `pkg/parser`, `pkg/expression/aggregation` (excluding
  `agg_to_pb.go`), `pkg/executor/aggfuncs`, `pkg/util/serialization`.
- **Stage 3 slice** — `pkg/expression/aggregation/agg_to_pb.go`, `pkg/kv`,
  `pkg/planner`.

Each slice is encrypted (AES-256 payload, RSA-OAEP–wrapped passphrase) and its
SHA-256 recorded. Each stage's `solve.sh` decrypts and applies **only its own
slice**, commits, then builds and tests. Cumulatively applying both slices
reproduces the PR's production diff. Per-stage provenance (base/head, pathspec,
file list) is recorded in each `steps/*/solution/provenance.json` (author-only).

## Verifier design

- Weighted checks per stage (sum **1.0**); `go build` and `go test` are critical.
- Hidden Go tests injected from `/tests/hidden` at runtime. They are decoupled
  from implementation-internal identifiers: they drive the feature through the
  SQL function names (`"max_count"`/`"min_count"`) and the fixed TiFlash wire
  protocol (`tipb.ExprType_MaxCount`/`_MinCount`), so a behaviorally correct
  solution passes regardless of internal naming.
- Independence from the public PR: the compute and sliding-window gates include
  **seeded randomized property tests** that compare the implementation against a
  trivial, independent reference oracle over random sizes/orderings/duplicates/
  NULLs/negatives. This defeats hard-coded answers and memorized PR test vectors
  and kills common near-misses (counting all rows, not excluding NULLs,
  off-by-one on ties, returning the extreme value, swapping min/max, or a window
  count that fails to decrement on eviction). See `tests/near_miss_selfcheck/`
  for a standalone, runnable proof that the random data distribution
  discriminates each near-miss, and `tests/near_misses.md` for the matrix.
- Binary integrity verification (SHA-256 checksums of go/git/python3).
- Trajectory audit (fail-closed for agent runs) flags `curl`, `wget`,
  `git clone/fetch/pull/remote/reflog`, `pip install`, `go install/get`,
  `apt install` (not Go import paths).
- LLM judges are training-only and never affect `binary_reward`.

## Regenerating Oracle keys

If you rotate keys, regenerate a matching RSA pair and update:

- `environment/Dockerfile` `ORACLE_PUBLIC_KEY_B64`
- `steps/02-core-aggregation/solution/oracle_upstream_private.pem`
- `steps/03-review-integration/solution/oracle_upstream_private.pem`

Then rebuild the environment image so `/opt/oracle/*.enc` is encrypted to the
new public key.
