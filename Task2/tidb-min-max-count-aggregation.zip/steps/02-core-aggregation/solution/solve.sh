#!/usr/bin/env bash
set -euo pipefail

mkdir -p /logs/agent
printf 'oracle\n' > /logs/agent/oracle.txt

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PRIVATE_KEY="$SCRIPT_DIR/oracle_upstream_private.pem"
TESTBED=/testbed
OUT=/app/output/02-core
PATCH=/tmp/oracle-stage2.diff
PASSPHRASE=/tmp/oracle-upstream-passphrase.bin
mkdir -p "$OUT/logs"

cleanup() {
  rm -f "$PATCH" "$PASSPHRASE"
}
trap cleanup EXIT INT TERM

[ -r "$PRIVATE_KEY" ] || { echo "missing protected Oracle private key" >&2; exit 1; }
[ -r /opt/oracle/upstream-pr.stage2.diff.enc ] || { echo "missing encrypted Stage 2 slice" >&2; exit 1; }
[ -r /opt/oracle/upstream-passphrase.enc ] || { echo "missing encrypted upstream passphrase" >&2; exit 1; }
[ -r /app/output/handoff.json ] || { echo "missing Stage 1 handoff" >&2; exit 1; }

python3 - <<'PY'
import json
from pathlib import Path
p = Path('/app/output/handoff.json')
data = json.loads(p.read_text(encoding='utf-8'))
required = {
    'schema_version': 1,
    'stage': '01-diagnose',
    'base_limitation_reproduced': True,
    'production_source_unchanged': True,
    'missing_functions': ['max_count', 'min_count'],
}
for key, expected in required.items():
    if data.get(key) != expected:
        raise SystemExit(f'invalid Stage 1 handoff field {key}: {data.get(key)!r}')
PY

openssl pkeyutl -decrypt \
  -inkey "$PRIVATE_KEY" \
  -in /opt/oracle/upstream-passphrase.enc \
  -out "$PASSPHRASE" \
  -pkeyopt rsa_padding_mode:oaep \
  -pkeyopt rsa_oaep_md:sha256

openssl enc -d -aes-256-cbc -pbkdf2 -iter 250000 \
  -in /opt/oracle/upstream-pr.stage2.diff.enc \
  -out "$PATCH" \
  -pass file:"$PASSPHRASE"

actual_sha="$(sha256sum "$PATCH" | awk '{print $1}')"
[ "$actual_sha" = "$(tr -d '[:space:]' < /opt/oracle/upstream-pr.stage2.diff.sha256)" ] || {
  echo "Stage 2 slice checksum mismatch" >&2
  exit 1
}

base_commit="$(tr -d '[:space:]' < /opt/oracle/base_commit)"
[ "$base_commit" = "7d70c1c438198658815e3510027839bfd298274f" ]

cd "$TESTBED"
git apply --numstat "$PATCH" | awk '{print $3}' | sort -u > "$OUT/changed-files.txt"

if git apply --check "$PATCH"; then
  git apply --index "$PATCH"
  git diff --cached --check
  git config user.name "Tier 2 Oracle"
  git config user.email "oracle@invalid"
  git commit -m "tidb: local execution of max_count/min_count (parser, aggregation, aggfuncs, serialization)"
elif git apply --reverse --check "$PATCH"; then
  echo "Stage 2 slice already applied; continuing validation" >&2
else
  echo "Stage 2 slice does not apply cleanly to the persistent worktree" >&2
  exit 1
fi

run_logged() {
  local name="$1"
  shift
  local log="$OUT/logs/$name.log"
  printf '%q ' "$@" > "$OUT/logs/$name.command"
  printf '\n' >> "$OUT/logs/$name.command"
  set +e
  "$@" >"$log" 2>&1
  local rc=$?
  set -e
  printf '%s\n' "$rc" > "$OUT/logs/$name.exit_code"
  cat "$log"
  [ "$rc" -eq 0 ]
}

run_logged parser_build env -C "$TESTBED/pkg/parser" go build ./...
run_logged pkg_build go build -tags=intest ./pkg/expression/aggregation/... ./pkg/executor/aggfuncs/... ./pkg/util/serialization/...
run_logged pkg_vet go vet ./pkg/expression/aggregation/... ./pkg/executor/aggfuncs/...
run_logged core_tests go test -tags=intest ./pkg/executor/aggfuncs/... ./pkg/expression/aggregation/... -count=1

python3 - <<'PY'
import json
from pathlib import Path

out = Path('/app/output/02-core')
changed = [line for line in (out / 'changed-files.txt').read_text().splitlines() if line]
commands = []
for name in ['parser_build', 'pkg_build', 'pkg_vet', 'core_tests']:
    command = (out / 'logs' / f'{name}.command').read_text().strip()
    exit_code = int((out / 'logs' / f'{name}.exit_code').read_text().strip())
    commands.append({
        'command': command,
        'exit_code': exit_code,
        'output_file': str(out / 'logs' / f'{name}.log'),
    })

payload = {
    'schema_version': 1,
    'stage': '02-core-aggregation',
    'stage1_handoff_consumed': True,
    'implemented_functions': ['max_count', 'min_count'],
    'behaviors_verified': [
        'Parser recognizes max_count and min_count as aggregate functions',
        'Row aggregation returns the count of occurrences of the extreme value (NULLs excluded)',
        'Sliding-window execution updates the count as rows enter and leave the frame',
        'Partial results merge and spill/restore correctly',
    ],
    'commands_run': commands,
    'changed_files': changed,
}
(out / 'implementation.json').write_text(json.dumps(payload, indent=2) + '\n', encoding='utf-8')
PY

echo "Stage 2 Oracle completed"
