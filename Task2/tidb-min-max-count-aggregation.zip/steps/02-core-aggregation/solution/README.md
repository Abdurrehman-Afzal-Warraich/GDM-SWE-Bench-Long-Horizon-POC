# Stage 2 Oracle — Standard SWE-Bench Materialization

This solution uses the standard SWE-bench oracle-materialization pattern:
the reference implementation is applied from a protected, encrypted artifact
so the verifier can confirm the task is solvable. The agent never sees this
directory; it must independently derive the implementation from the
Stage 2 instruction alone.

## Engineering Computation Performed

`solve.sh` applies **only the Stage 2 slice**
(`/opt/oracle/upstream-pr.stage2.diff.enc`: parser, aggregation minus protobuf,
aggfuncs, serialization) and executes verifiable engineering steps:

1. **Handoff validation** — confirms Stage 1 diagnosis contract is satisfied.
2. **Slice integrity** — SHA-256 of the decrypted Stage 2 slice matches the
   build-time manifest.
3. **Compilation** — `go build` on parser, aggregation, aggfuncs, serialization.
4. **Static analysis** — `go vet` on aggregation and aggfuncs.
5. **Test execution** — `go test` runs the executor and aggregation suites.
6. **Evidence derivation** — `implementation.json` is generated from actual test
   logs and the real `git apply --numstat` output, not from pre-computed data.

The Stage 3 slice (protobuf/KV/planner) is deliberately **not** applied here; it
is applied by the Stage 3 Oracle. Cumulatively the two slices reproduce PR
#69642 exactly. See `provenance.json` for this slice's file list. The private
key is protected; real agent runs never receive it.
