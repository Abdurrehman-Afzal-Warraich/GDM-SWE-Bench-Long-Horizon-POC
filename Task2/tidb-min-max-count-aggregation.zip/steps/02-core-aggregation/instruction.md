# Stage 2: Core Implementation (Local Execution)

Implement local (single-node) execution of the `max_count` and `min_count` SQL
aggregate functions in the TiDB tree at `/testbed`.

## Required behavior

- `max_count(expr)` returns the number of times the **maximum** non-NULL value
  appears in the group; `min_count(expr)` returns the number of times the
  **minimum** non-NULL value appears.
- NULLs are ignored. A group of all-NULLs (or an empty group) returns `0`.
- The result is an integer count (`BIGINT`).
- The functions must also work as **window functions** over a sliding frame:
  as rows enter and leave the frame the reported count must stay correct,
  including when the current maximum/minimum is evicted from the frame, when all
  frame values are equal, and after the partial state is reset and reused for a
  new partition.
- Partial results must merge correctly and must survive spill (serialize) and
  restore (deserialize) of partial state.

## Public contract the verifier depends on

Your implementation is graded through TiDB's existing public aggregate API — not
through any particular internal symbol names. Specifically, after this stage:

- `aggregation.NewAggFuncDesc(ctx, "max_count", args, false)` and
  `... "min_count" ...` must succeed and return a usable descriptor (they error
  on the base tree). Drive the feature by the SQL function names; you are free to
  name your internal Go constants, types, and files however you like.
- Building the descriptor's aggregate must produce a function that computes the
  correct count via the standard `Update` / `GetResult` (row) path and via the
  executor's `BuildWindowFunctions` + `SlidingWindowAggFunc` (window) path. Use
  the existing base interfaces (e.g. `SlidingWindowAggFunc`,
  `MaxMinSlidingWindowAggFunc`) exactly as the existing `max`/`min` window
  aggregates do.
- The descriptor's return type must be the integer count type.

## Scope for this stage

Parser recognition, expression/aggregation descriptors, executor aggfuncs
(row + sliding window), partial-result merge, and spill serialization/memory
handling. Do **not** yet wire distributed pushdown (protobuf encoding, KV
coprocessor whitelist, MPP planner) — that is Stage 3. Study the existing `max`,
`min`, and `count` implementations to follow the same patterns.

## Verification

The verifier runs:

1. `go build -tags=intest` on the scoped packages.
2. `go test -tags=intest` on `pkg/executor/aggfuncs` and
   `pkg/expression/aggregation`.
3. Hidden behavioral tests that (a) compute `max_count`/`min_count` across NULL,
   tie, negative, single-element, and all-equal inputs, and (b) exercise the
   sliding-window path across evictions, all-equal frames, and reset.

## Output

Write `/app/output/02-core/implementation.json`:

```json
{
  "schema_version": 1,
  "stage": "02-core-aggregation",
  "stage1_handoff_consumed": true,
  "implemented_functions": ["max_count", "min_count"],
  "behaviors_verified": ["string"],
  "commands_run": [
    {
      "command": "string",
      "exit_code": 0,
      "output_file": "/app/output/02-core/logs/build.log"
    }
  ],
  "changed_files": ["repository-relative/path.go"]
}
```

Keep `/app/output/handoff.json` from Stage 1 available.
