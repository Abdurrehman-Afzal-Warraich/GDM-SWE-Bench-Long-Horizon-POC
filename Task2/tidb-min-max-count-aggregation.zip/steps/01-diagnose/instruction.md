# Stage 1: Diagnose Missing max_count / min_count Aggregates

The sanitized TiDB tree at `/testbed` does not implement SQL aggregate functions `max_count(expr)` or `min_count(expr)`.

## Task

- Produce evidence under `/app/output/01-diagnose/` that demonstrates the gap. This must include executable evidence (e.g., attempting to create a "max_count" aggregate descriptor via `aggregation.NewAggFuncDesc(ctx, "max_count", ...)` and observing it fails).
- Map affected subsystems (parser, expression/aggregation, executor, planner, KV pushdown, serialization) without modifying production source files.
- Capture logs under `/app/output/01-diagnose/`.

## Verification

The verifier runs:
1. `go build` on scoped packages (`./pkg/expression/...`, `./pkg/executor/aggfuncs/...`, `./pkg/planner/...`, `./pkg/kv/...`, `./pkg/util/serialization/...`)
2. A hidden behavioral test that calls `NewAggFuncDesc(ctx, "max_count", ...)` and `NewAggFuncDesc(ctx, "min_count", ...)` and asserts they return errors (proving the base lacks support)
3. Validates the handoff artifact schema

Prose-only analysis is insufficient. The hidden test must pass (i.e., confirm the base revision does NOT support these aggregates).

## Output

Write identical findings to `/app/output/handoff.json` and `/app/output/01-diagnose/diagnosis.json`:

```json
{
  "schema_version": 1,
  "stage": "01-diagnose",
  "base_limitation_reproduced": true,
  "production_source_unchanged": true,
  "missing_functions": ["max_count", "min_count"],
  "missing_behavior": "string",
  "observed_outcome": "string",
  "affected_subsystems": ["parser", "expression", "executor", "planner", "kv"],
  "preserved_invariants": ["string"],
  "deferred_work": ["string"],
  "reproducer_path": "/app/output/01-diagnose/reproduce.sh",
  "evidence_files": ["/app/output/01-diagnose/reproducer.log"]
}
```

`affected_subsystems` must name at least three subsystem keywords among: parser, expression, executor, planner, kv.
