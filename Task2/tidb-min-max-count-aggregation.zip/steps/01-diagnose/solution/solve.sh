#!/usr/bin/env bash
set -euo pipefail

mkdir -p /logs/agent
printf 'oracle\n' > /logs/agent/oracle.txt

TESTBED=/testbed
OUT=/app/output/01-diagnose
mkdir -p "$OUT"
cd "$TESTBED"

before_status="$OUT/git-status-before.txt"
git status --porcelain=v1 --untracked-files=all > "$before_status"
if [ -s "$before_status" ]; then
  echo "Stage 1 Oracle requires the untouched base worktree" >&2
  cat "$before_status" >&2
  exit 1
fi

cat > "$OUT/reproduce.sh" <<'REPRO'
#!/usr/bin/env bash
set -euo pipefail
cd /testbed

echo "Checking for absence of max_count/min_count aggregate functions..."
if grep -q 'AggFuncMaxCount\|AggFuncMinCount' pkg/parser/ast/functions.go 2>/dev/null; then
  echo "UNEXPECTED: AggFuncMaxCount/AggFuncMinCount already defined"
  exit 1
fi

echo "Verifying no max_count descriptor in expression/aggregation..."
if grep -rq 'AggFuncMaxCount\|AggFuncMinCount' pkg/expression/aggregation/ 2>/dev/null; then
  echo "UNEXPECTED: max_count/min_count aggregation descriptors exist"
  exit 1
fi

echo "Verifying no max_count executor in aggfuncs..."
if find pkg/executor/aggfuncs/ -name '*max_min_count*' 2>/dev/null | grep -q .; then
  echo "UNEXPECTED: max_min_count executor files exist"
  exit 1
fi

echo "CONFIRMED: Base revision lacks max_count and min_count aggregate functions"
echo "Affected subsystems: parser, expression, executor, planner, kv"
exit 0
REPRO
chmod 0755 "$OUT/reproduce.sh"
"$OUT/reproduce.sh" > "$OUT/reproducer.log" 2>&1

python3 - <<'PYJSON'
import json
from pathlib import Path
payload = {
    "schema_version": 1,
    "stage": "01-diagnose",
    "base_limitation_reproduced": True,
    "production_source_unchanged": True,
    "missing_functions": ["max_count", "min_count"],
    "missing_behavior": "TiDB does not register or evaluate max_count/min_count aggregate functions.",
    "observed_outcome": "Parser constants and aggregation descriptors for max_count/min_count are absent at the base revision.",
    "affected_subsystems": ["parser", "expression", "executor", "planner", "kv"],
    "preserved_invariants": [
        "Existing min/max/count aggregate semantics",
        "Unrelated SQL functions and planner rules",
    ],
    "deferred_work": [
        "Implement parser and aggregation descriptors",
        "Wire executor aggfuncs and downstream planner/pushdown integration",
    ],
    "reproducer_path": "/app/output/01-diagnose/reproduce.sh",
    "evidence_files": [
        "/app/output/01-diagnose/reproducer.log",
        "/app/output/01-diagnose/git-status-before.txt",
    ],
}
for target in [Path("/app/output/handoff.json"), Path("/app/output/01-diagnose/diagnosis.json")]:
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
PYJSON

echo "Stage 1 Oracle completed"
