Stage 1 Oracle writes diagnosis artifacts only; production `/testbed` must remain clean.
