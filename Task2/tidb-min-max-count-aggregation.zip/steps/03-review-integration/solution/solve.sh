#!/usr/bin/env bash
set -euo pipefail

mkdir -p /logs/agent
printf 'oracle\n' > /logs/agent/oracle.txt

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PRIVATE_KEY="$SCRIPT_DIR/oracle_upstream_private.pem"
TESTBED=/testbed
OUT=/app/output/03-review
PATCH=/tmp/oracle-stage3.diff
PASSPHRASE=/tmp/oracle-upstream-passphrase.bin
mkdir -p "$OUT/logs"

cleanup() {
  rm -f "$PATCH" "$PASSPHRASE"
}
trap cleanup EXIT INT TERM

[ -r "$PRIVATE_KEY" ] || { echo "missing protected Oracle private key" >&2; exit 1; }
[ -r /opt/oracle/upstream-pr.stage3.diff.enc ] || { echo "missing encrypted Stage 3 slice" >&2; exit 1; }
[ -r /opt/oracle/upstream-passphrase.enc ] || { echo "missing encrypted upstream passphrase" >&2; exit 1; }
[ -r /app/output/02-core/implementation.json ] || { echo "missing Stage 2 implementation report" >&2; exit 1; }

python3 - <<'PY'
import json
from pathlib import Path
p = Path('/app/output/02-core/implementation.json')
data = json.loads(p.read_text(encoding='utf-8'))
if data.get('stage') != '02-core-aggregation':
    raise SystemExit('invalid Stage 2 implementation report')
if set(data.get('implemented_functions', [])) != {'max_count', 'min_count'}:
    raise SystemExit('Stage 2 must implement max_count and min_count')
PY

openssl pkeyutl -decrypt \
  -inkey "$PRIVATE_KEY" \
  -in /opt/oracle/upstream-passphrase.enc \
  -out "$PASSPHRASE" \
  -pkeyopt rsa_padding_mode:oaep \
  -pkeyopt rsa_oaep_md:sha256

openssl enc -d -aes-256-cbc -pbkdf2 -iter 250000 \
  -in /opt/oracle/upstream-pr.stage3.diff.enc \
  -out "$PATCH" \
  -pass file:"$PASSPHRASE"

actual_sha="$(sha256sum "$PATCH" | awk '{print $1}')"
[ "$actual_sha" = "$(tr -d '[:space:]' < /opt/oracle/upstream-pr.stage3.diff.sha256)" ] || {
  echo "Stage 3 slice checksum mismatch" >&2
  exit 1
}

cd "$TESTBED"
git apply --numstat "$PATCH" | awk '{print $3}' | sort -u > "$OUT/changed-files.txt"

if git apply --check "$PATCH"; then
  git apply --index "$PATCH"
  git diff --cached --check
  git config user.name "Tier 2 Oracle"
  git config user.email "oracle@invalid"
  git commit -m "tidb: distributed integration of max_count/min_count (protobuf, KV coprocessor, MPP planner)"
elif git apply --reverse --check "$PATCH"; then
  echo "Stage 3 slice already applied; continuing validation" >&2
else
  echo "Stage 3 slice does not apply cleanly on top of the Stage 2 worktree" >&2
  exit 1
fi

run_logged() {
  local name="$1"
  shift
  local log="$OUT/logs/$name.log"
  printf '%q ' "$@" > "$OUT/logs/$name.command"
  printf '\n' >> "$OUT/logs/$name.command"
  set +e
  "$@" >"$log" 2>&1
  local rc=$?
  set -e
  printf '%s\n' "$rc" > "$OUT/logs/$name.exit_code"
  cat "$log"
  [ "$rc" -eq 0 ]
}

run_logged pkg_build go build -tags=intest ./pkg/expression/aggregation/... ./pkg/executor/aggfuncs/... ./pkg/planner/... ./pkg/kv/... ./pkg/util/serialization/...
run_logged integration_aggregation_tests go test -tags=intest ./pkg/expression/aggregation/... -count=1
run_logged integration_kv_tests go test -tags=intest ./pkg/kv/... -count=1

python3 - <<'PY'
import json
from pathlib import Path

out = Path('/app/output/03-review')
changed = [line for line in (out / 'changed-files.txt').read_text().splitlines() if line]
commands = []
for name in ['pkg_build', 'integration_aggregation_tests', 'integration_kv_tests']:
    cmd_file = out / 'logs' / f'{name}.command'
    exit_file = out / 'logs' / f'{name}.exit_code'
    if cmd_file.is_file() and exit_file.is_file():
        commands.append({
            'command': cmd_file.read_text().strip(),
            'exit_code': int(exit_file.read_text().strip()),
            'output_file': str(out / 'logs' / f'{name}.log'),
        })

payload = {
    'schema_version': 1,
    'stage': '03-review-integration',
    'integration_items': [
        {
            'area': 'protobuf conversion',
            'status': 'integrated',
            'verification': 'baseFuncDesc.GetTiPBExpr maps max_count/min_count to tipb ExprType_MaxCount/MinCount and PBExprToAggFuncDesc round-trips back',
        },
        {
            'area': 'KV coprocessor support',
            'status': 'integrated',
            'verification': 'RequestTypeSupportedChecker.supportExpr accepts tipb ExprType_MaxCount/MinCount',
        },
        {
            'area': 'TiFlash pushdown eligibility',
            'status': 'integrated',
            'verification': 'CheckAggPushDown accepts max_count/min_count for kv.TiFlash in Complete/Partial1 modes and rejects TiKV, Dedup, and multi-arg Final',
        },
        {
            'area': 'MPP planner wiring',
            'status': 'integrated',
            'verification': 'attach2TaskForMpp enforces single-partition one-phase aggregation when max_count/min_count is present',
        },
    ],
    'commands_run': commands,
    'changed_files': changed,
}
(out / 'review_response.json').write_text(json.dumps(payload, indent=2) + '\n', encoding='utf-8')
PY

echo "Stage 3 Oracle completed"
