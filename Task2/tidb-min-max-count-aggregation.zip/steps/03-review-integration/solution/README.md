# Stage 3 Oracle — distributed-integration slice

`solve.sh` decrypts and applies **only the Stage 3 slice**
(`/opt/oracle/upstream-pr.stage3.diff.enc`: protobuf conversion, KV coprocessor
whitelist, MPP planner wiring) on top of the Stage 2 worktree, verifies its
SHA-256 against the build-time manifest, commits, then builds and tests the
integration packages. It assumes the Stage 2 slice is already present.

The private key is protected; real agent runs never receive it. See
`provenance.json` for the exact file list and pathspec of this slice.
