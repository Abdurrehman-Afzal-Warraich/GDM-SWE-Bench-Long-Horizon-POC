# Stage 3: Distributed Integration

Building on the Stage 2 local implementation, make `max_count` / `min_count`
executable in TiDB's distributed / columnar path so they can be pushed down to
TiFlash and planned as MPP aggregations.

## Required behavior

- **Protobuf conversion**: a `max_count` / `min_count` aggregate descriptor must
  convert to the correct TiFlash wire representation and back. Concretely,
  `GetTiPBExpr` must map the aggregate to `tipb.ExprType_MaxCount` /
  `tipb.ExprType_MinCount`, and `PBExprToAggFuncDesc` must reconstruct the
  descriptor from those expression types.
- **KV coprocessor support**: the request-type checker must accept
  `tipb.ExprType_MaxCount` / `tipb.ExprType_MinCount` as supported expressions.
- **Pushdown eligibility**: `CheckAggPushDown` must accept `max_count` /
  `min_count` for `kv.TiFlash` in `CompleteMode` and `Partial1Mode`, and must
  reject them for `kv.TiKV`, in `DedupMode`, and in the two-argument
  `FinalMode`/`Partial2Mode` shape.
- **MPP planner wiring**: physical hash-aggregation / MPP task construction must
  handle the new aggregates (e.g. enforce the correct single-partition
  one-phase plan) and preserve existing behavior for all other aggregates.

## Public contract the verifier depends on

Grading uses the fixed TiFlash wire protocol and TiDB's existing public
functions — not any internal symbol names you introduce:
`aggregation.NewAggFuncDesc(ctx, "max_count", ...)`, `desc.GetTiPBExpr(...)`,
`aggregation.CheckAggPushDown(...)`, `kv.TiFlash` / `kv.TiKV`, and
`tipb.ExprType_MaxCount` / `tipb.ExprType_MinCount`.

## Verification

The verifier runs:

1. `go build -tags=intest` on the scoped packages (expression, executor,
   planner, kv, serialization).
2. `go test -tags=intest` on `pkg/expression/aggregation` and `pkg/kv`.
3. A hidden behavioral test asserting protobuf `ExprType` conversion and
   pushdown eligibility across engines and aggregation modes.
4. An end-to-end SQL test of `max_count`/`min_count` as **sliding-window**
   functions (`... over (order by id rows between N preceding and current row)`),
   checked against an independent reference over seeded random data — the window
   count must update correctly as rows enter and leave the frame.
5. A cumulative test that re-runs the Stage 2 local-execution behavior to
   guard against regressions.

## Output

Write `/app/output/03-review/review_response.json`:

```json
{
  "schema_version": 1,
  "stage": "03-review-integration",
  "integration_items": [
    {
      "area": "string",
      "status": "string",
      "verification": "string"
    }
  ],
  "commands_run": [
    {
      "command": "string",
      "exit_code": 0,
      "output_file": "/app/output/03-review/logs/tests.log"
    }
  ]
}
```

Provide at least four `integration_items` covering distinct integration areas
(protobuf conversion, KV coprocessor support, pushdown eligibility, MPP planner).
